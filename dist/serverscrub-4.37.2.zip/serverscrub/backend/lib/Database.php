<?php
/**
 * ServerScrub — SQLite Database Layer
 */

// The scheduled tasks installed before 3.19.4 load mode.php only, which records
// SG_ROOT but not SG_DB, so every cron run died with "Undefined constant SG_DB".
// update.sh does not rewrite those cron files, so a corrected installer is not
// enough on its own — derive the path when it is absent.
if (!defined('SG_DB') && defined('SG_ROOT')) {
    define('SG_DB', SG_ROOT . '/database/serverscrub.db');
}

class Database {
    private static ?PDO $pdo = null;

    /**
     * Can this process open the database at all?
     *
     * ── WHY THIS EXISTS ──────────────────────────────────────────────────────
     *
     * The database directory is 0700 and root-owned by design, so a panel
     * running as anything but root fails on its very first query -- which was
     * inside the licence check during bootstrap, BEFORE the handler that
     * produces the JSON envelope. The caller got
     *
     *     PHP Fatal error: Uncaught PDOException: SQLSTATE[HY000]:
     *     General error: 14 unable to open database file in
     *     /opt/serverscrub-src/backend/lib/Database.php:851
     *     Stack trace: #0 ... #3 .../License.php(591)
     *
     * as the HTTP body: the client expects JSON and shows its generic "Server
     * error -- please try again", which is the entire class of failure the
     * router's envelope exists to prevent, and the response discloses absolute
     * paths and the internal call graph.
     *
     * Asked once, as a question, so the answer can be a sentence.
     *
     * @return array{ok:bool,error:?string}
     */
    public static function ready(): array
    {
        try {
            self::get()->query('SELECT 1');
            return ['ok' => true, 'error' => null];
        } catch (Throwable $e) {
            /* error_log(), not Logger: Logger::error() writes a row through
             * Database::insert(), so logging a database that cannot be opened
             * would throw from inside the handler for a database that cannot
             * be opened. PHP's own log is configured by the API entry point.
             *
             * The path goes in the log and not in the return value: SG_DB is
             * an absolute server path and this answer travels over HTTP. */
            @error_log('ServerScrub: database could not be opened at ' . SG_DB
                       . ': ' . $e->getMessage());
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    public static function get(): PDO {
        if (self::$pdo === null) {
            $db_path = SG_DB;
            $dir = dirname($db_path);
            if (!is_dir($dir)) mkdir($dir, 0750, true);

            self::$pdo = new PDO("sqlite:$db_path");
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            self::$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            // BUSY_TIMEOUT WAS MISSING ENTIRELY on the PHP side while the
            // Python monitor set 10 seconds. Six writers share this file --
            // the scheduler, the API under cpsrvd, the CLI, the customer
            // pages, the user-scan picker and the monitor -- and without a
            // timeout a PHP writer meeting a held lock fails INSTANTLY with
            // SQLITE_BUSY rather than waiting the few milliseconds the other
            // writer needs. Every one of those is a lost write that nothing
            // retries.
            //
            // Ten seconds, matching the daemon: one setting, one number.
            self::$pdo->exec('PRAGMA busy_timeout=10000');
            self::$pdo->exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');
            // Bound the WAL. A mass UPDATE -- a migration over 148,551 rows,
            // say -- grows it without limit until something checkpoints, and
            // an unbounded WAL on a server that runs short of disk is one of
            // the few ways SQLite genuinely corrupts.
            self::$pdo->exec('PRAGMA wal_autocheckpoint=1000');
            self::migrate(self::$pdo);
        }
        return self::$pdo;
    }

    /**
     * Run a migration exactly once, atomically.
     *
     * THE OLD SHAPE WAS: check for the marker, do the work, write the marker.
     * Three separate statements with no transaction, in code that runs on
     * EVERY connection. So when cpsrvd, the scheduler and the monitor opened
     * the database inside the same window, each of them found no marker and
     * each independently ran the whole thing -- which for the 4.33.0
     * migration meant three concurrent rewrites of 148,551 rows, three times
     * the WAL, on a file where the PHP side also had no busy timeout.
     *
     * Wrapping it puts the marker in the same transaction as the work: either
     * both land or neither does, and a second process arriving later finds
     * the marker and does nothing. A crash midway leaves the marker absent
     * and the work undone, which is the right way round -- it will simply run
     * again next time.
     *
     * BEGIN IMMEDIATE rather than a plain BEGIN: it takes the write lock up
     * front instead of discovering the conflict at COMMIT, when the work is
     * already done and has to be thrown away.
     */
    private static function once(PDO $db, string $marker, callable $work): void
    {
        $st = $db->prepare("SELECT 1 FROM settings WHERE key = ?");
        $st->execute([$marker]);
        if ($st->fetchColumn()) { return; }

        try {
            $db->exec('BEGIN IMMEDIATE');

            // Checked again INSIDE the lock. Between the read above and the
            // lock, another process may have done the whole thing.
            $st->execute([$marker]);
            if ($st->fetchColumn()) { $db->exec('COMMIT'); return; }

            $work($db);
            $ins = $db->prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, '1')");
            $ins->execute([$marker]);
            $db->exec('COMMIT');
        } catch (Throwable $e) {
            try { $db->exec('ROLLBACK'); } catch (Throwable $ignored) { }
            // Not rethrown: one migration that cannot run must not stop the
            // product from starting. It is logged and retried next time.
            error_log('ServerScrub: migration ' . $marker . ' failed: ' . $e->getMessage());
        }
    }

    /**
     * SQLite's own integrity check.
     *
     * Exists because the first anyone knew of a corrupted database was a
     * command failing in an operator's hands with "database disk image is
     * malformed". The check is cheap enough to run nightly and the one thing
     * that turns silent damage into something the dashboard can say.
     *
     * @return array{ok:bool,problems:string[]}
     */
    public static function integrityCheck(int $maxErrors = 20): array
    {
        try {
            $rows = self::get()->query('PRAGMA integrity_check(' . max(1, $maxErrors) . ')')
                        ->fetchAll(PDO::FETCH_COLUMN);
        } catch (Throwable $e) {
            // The check itself failing IS the finding.
            return ['ok' => false, 'problems' => [$e->getMessage()]];
        }
        $rows = array_values(array_filter(array_map('strval', $rows)));
        if (count($rows) === 1 && strtolower($rows[0]) === 'ok') {
            return ['ok' => true, 'problems' => []];
        }
        return ['ok' => false, 'problems' => $rows];
    }

    private static function migrate(PDO $db): void {
        $db->exec("
            CREATE TABLE IF NOT EXISTS scan_jobs (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_type   TEXT    NOT NULL DEFAULT 'quick',
                status      TEXT    NOT NULL DEFAULT 'pending',
                started_at  INTEGER,
                finished_at INTEGER,
                files_scanned  INTEGER DEFAULT 0,
                threats_found  INTEGER DEFAULT 0,
                scan_path   TEXT    DEFAULT '/',
                created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS threats (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_job_id  INTEGER REFERENCES scan_jobs(id),
                file_path    TEXT    NOT NULL,
                threat_name  TEXT,
                threat_type  TEXT,
                severity     TEXT    DEFAULT 'high',
                status       TEXT    DEFAULT 'active',
                hash         TEXT,
                size         INTEGER,
                detected_at  INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                resolved_at  INTEGER,
                action_taken TEXT
            );

            -- Detection patterns, so they can change without a release and a
            -- bad one can be turned off without a code change. Mirrored to
            -- signatures.json after every write; see Signatures.php for why
            -- there are three places and not one.
            CREATE TABLE IF NOT EXISTS signatures (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                name       TEXT    NOT NULL UNIQUE,
                sig_type   TEXT    NOT NULL DEFAULT 'regex',
                pattern    TEXT    NOT NULL,
                severity   TEXT    NOT NULL DEFAULT 'high',
                source     TEXT    NOT NULL DEFAULT 'builtin',
                enabled    INTEGER NOT NULL DEFAULT 1,
                added_at   INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS firewall_rules (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                name        TEXT    NOT NULL,
                direction   TEXT    NOT NULL DEFAULT 'in',
                protocol    TEXT    DEFAULT 'tcp',
                port        TEXT,
                source_ip   TEXT,
                dest_ip     TEXT,
                action      TEXT    NOT NULL DEFAULT 'DROP',
                enabled     INTEGER NOT NULL DEFAULT 1,
                hits        INTEGER DEFAULT 0,
                priority    INTEGER DEFAULT 100,
                comment     TEXT,
                created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS blocked_ips (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ip_address  TEXT    NOT NULL UNIQUE,
                reason      TEXT,
                country     TEXT,
                threat_score INTEGER DEFAULT 0,
                blocked_at  INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                expires_at  INTEGER,
                permanent   INTEGER DEFAULT 0,
                source      TEXT    DEFAULT 'manual'
            );

            CREATE TABLE IF NOT EXISTS waf_events (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                rule_id     TEXT,
                rule_msg    TEXT,
                severity    TEXT,
                ip_address  TEXT,
                uri         TEXT,
                method      TEXT,
                host        TEXT,
                user_agent  TEXT,
                action      TEXT    DEFAULT 'block',
                ip_source   TEXT    NOT NULL DEFAULT '',
                forwarded_for TEXT  NOT NULL DEFAULT '',
                timestamp   INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            /* Rules the operator has switched off, and where.
               Re-rendered into serverscrub-waf.conf on every mode change:
               writeConfig() rebuilds that file from scratch, so an
               exclusion kept only in the file would vanish the next time
               the WAF was armed. domain and uri_prefix are empty for a
               server-wide exclusion. */
            CREATE TABLE IF NOT EXISTS waf_exclusions (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                rule_id     TEXT    NOT NULL,
                domain      TEXT    NOT NULL DEFAULT (''),
                uri_prefix  TEXT    NOT NULL DEFAULT (''),
                reason      TEXT    NOT NULL DEFAULT (''),
                created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            CREATE UNIQUE INDEX IF NOT EXISTS idx_waf_excl_scope
                ON waf_exclusions (rule_id, domain, uri_prefix);

            CREATE TABLE IF NOT EXISTS security_events (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                type        TEXT    NOT NULL,
                severity    TEXT    NOT NULL DEFAULT 'medium',
                source_ip   TEXT,
                target      TEXT,
                description TEXT,
                raw_data    TEXT,
                resolved    INTEGER DEFAULT 0,
                timestamp   INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS file_integrity (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path   TEXT    NOT NULL UNIQUE,
                hash_sha256 TEXT    NOT NULL,
                size        INTEGER,
                permissions TEXT,
                owner       TEXT,
                baseline_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                last_check  INTEGER,
                status      TEXT    DEFAULT 'clean'
            );

            CREATE TABLE IF NOT EXISTS settings (
                key         TEXT    PRIMARY KEY,
                value       TEXT,
                updated_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS ip_reputation (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ip_address  TEXT    NOT NULL UNIQUE,
                score       INTEGER DEFAULT 0,
                country     TEXT,
                asn         TEXT,
                rbl_hits    TEXT,
                last_seen   INTEGER,
                cached_at   INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS cron_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                job_name    TEXT,
                status      TEXT,
                message     TEXT,
                duration_ms INTEGER,
                ran_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            -- v3.3.1: add cpanel_user to threats (ALTER is idempotent via try/catch in PHP)

            -- Default settings
            INSERT OR IGNORE INTO settings (key, value) VALUES
                ('scan_schedule',           'daily'),
                ('scan_time',               '02:00'),
                ('scan_day',                '0'),
                ('scan_type',               'full'),
                ('sig_update_schedule',     'weekly'),
                ('sig_update_time',         '01:00'),
                ('sig_update_day',          '0'),
                ('iprep_schedule',          'daily'),
                ('iprep_time',              '03:00'),
                ('iprep_day',               '0'),
                ('scan_paths',              '/home'),
                -- Stand down while a backup or bulk transfer is running.
                -- JetBackup walks every account and rsync streams the result
                -- off-box; a real-time scanner competing for the same disks at
                -- that moment is the worst time for it to be working hardest.
                ('rt_pause_on_backup',        '1'),
                -- Bring monitoring back up once the backups have finished.
                -- The daemon suspends its own scanning during a backup, but a
                -- daemon that is stopped cannot restart itself -- and a
                -- monitor that went down in a backup window otherwise stays
                -- down until somebody notices.
                ('rt_autostart_after_backup', '1'),
                -- 'every' means every scheduler tick, which cron fires at */15.
                ('rt_autostart_schedule',     'every'),
                -- Set when a person stops the monitor with no backup running,
                -- so auto-resume does not overrule a deliberate decision.
                ('rt_manual_stop',            '0'),
                ('rt_backup_procs',           'jetbackup,rsync'),
                -- Never treated as a running backup, however they match.
                -- JetBackup's daemon runs continuously whether or not a backup
                -- is happening; matching it suspended real-time monitoring
                -- permanently on every server with JetBackup installed.
                ('rt_backup_exclude',         'jetbackupd,jetbackup5d,jetbackupmysqld'),
                ('rt_backup_check_secs',      '20'),
                -- rsync is usually a series of short runs; resuming between
                -- them costs more than staying down for another minute.
                ('rt_backup_resume_secs',     '60'),
                -- A process merely NAMED rsync is enough to suspend scanning,
                -- so the pause has to end on its own eventually.
                ('rt_backup_max_suspend_secs','14400'),
                ('email_alerts',            '1'),
                ('alert_email',             ''),
                -- Off by default. Quarantine MOVES the file into
                -- /usr/local/serverscrub/quarantine, which is on the root
                -- partition, so an enthusiastic scan can fill / on a server
                -- whose customer data lives on a separate volume. Detection
                -- still records the threat; acting on it is a decision the
                -- operator opts into.
                ('auto_quarantine',         '0'),
                -- What happens to an infected file, by severity.
                -- high/critical: deleted outright, with no copy kept.
                -- medium: quarantined for 5 days, then deleted.
                -- low: quarantined for 7 days, then deleted.
                ('policy_high_action',      'delete'),
                ('policy_medium_days',      '5'),
                ('policy_low_days',         '7'),
                -- At most this many scans at once, and one is the intended
                -- number. Each clamscan loads the whole ClamAV signature
                -- database into its own memory (650MB to 1.3GB observed), so
                -- a second scan buys a second copy of that database and two
                -- processes queued on the same disks -- not half the runtime.
                -- Raising it is possible but is not a throughput control.
                ('scan_max_concurrent',     '1'),
                -- A single clamscan invocation that exceeds this is abandoned;
                -- one was found holding 13 minutes of CPU on one file.
                ('scan_batch_timeout',      '600'),
                -- The bound on destructive action at scale: how many files ONE
                -- signature may account for in one scan before the product
                -- stops quarantining and asks a human. 0 disables it, which is
                -- how 154,323 customer files were quarantined from one
                -- third-party signature on 10 Nov. It bounds what is
                -- DESTROYED, never what is found: the scan runs on and records
                -- every match, because the 30 Apr ransomware event was 154,323
                -- real matches of one signature. See MassDetection.
                ('scan_mass_signature_max', '500'),
                -- Hold a malware scan while a backup is running. OFF since
                -- 4.31.2, on an operator's instruction: on a server whose
                -- backups overlap the scan window this did not delay the
                -- nightly sweep, it CANCELLED it. The wait cap
                -- (scan_backup_max_wait, four hours) is reached, the worker
                -- gives up, and the next scheduled run is a day later -- so a
                -- long backup window bought a day with no scan at all, which
                -- is a far worse outcome than a scan competing with rsync for
                -- I/O.
                --
                -- Set it to 1 to put the gate back; everything that reads it
                -- honours it, including the scheduled sweep.
                ('scan_pause_on_backup',    '0'),
                -- How long a dealt-with threat stays in the log. Active ones
                -- are kept regardless of age: an unresolved threat is exactly
                -- what the log is for.
                ('threat_retention_days',   '7'),
                -- Rootkit scanning runs nightly. It was unseeded, so it fell
                -- back to the code default of weekly; a rootkit that lands on
                -- Monday should not wait until Sunday to be noticed. 03:00 is
                -- after the usual backup window.
                ('rootkit_schedule',        'daily'),
                ('rootkit_time',            '03:00'),
                ('rootkit_day',             '0'),
                -- After this long waiting, the scan gives up and the next
                -- scheduled run picks it up rather than sleeping for ever.
                ('scan_backup_max_wait',    '14400'),
                -- Quarantine grew without limit until this existed. 0 disables
                -- pruning, for anyone who would rather keep everything.
                ('quarantine_retention_days', '7'),
                ('firewall_enabled',        '1'),
                ('waf_enabled',             '1'),
                ('bot_shield_enabled',      '1'),
                ('ip_rep_enabled',          '1'),
                ('geo_block_countries',     ''),
                ('rate_limit_ssh',          '5'),
                -- Brute-force detection. The dashboard has charted this since
                -- it was written and nothing ever produced the data.
                ('bf_enabled',              '1'),
                ('bf_threshold',            '5'),
                ('bf_ladder',               '10800,21600,86400,0'),
                ('bf_offence_memory_days',  '30'),
                ('bf_window',               '600'),
                ('bf_auto_block',           '1'),
                ('bf_retention_days',       '7'),
                ('bf_schedule',             'every'),
                ('bf_whitelist',            ''),
                ('rate_limit_http',         '100'),
                ('php_disable_funcs',       'exec,passthru,shell_exec,system,proc_open,popen'),
                ('installed_at',            CAST(strftime('%s','now') AS TEXT)),
                ('last_scan',               '0'),
                ('clam_db_update',          '0'),
                -- Storage management
                ('quarantine_dir',          ''),
                ('log_dir',                 ''),
                ('log_retention_days',      '30'),
                ('quarantine_retention_days','90'),
                ('db_max_waf_events',       '100000'),
                ('db_max_security_events',  '50000'),
                ('db_max_cron_log',         '1000'),
                ('monitor_log_max_mb',      '50'),
                -- Performance
                ('cpu_limit_percent',       '50'),
                ('rt_poll_interval',        '300'),
                -- A CEILING, not a priority. nice only decides who yields when
                -- processes compete; on a box with an idle core a nice-19
                -- clamscan takes that core to ~100% and is behaving correctly
                -- (observed: NI 19, 97% CPU, 44.8% of the machine idle, with
                -- scan_max_concurrent already 1). Enforcing a cgroup CPU quota
                -- is the only thing that makes cpu_limit_percent an actual
                -- limit. On by default: the setting already claimed to be a
                -- limit, and honouring it is less surprising than not.
                ('scan_cpu_hard_cap',       '1'),
                -- What is ACTUALLY enforcing, written after the probe:
                -- quota | cpulimit | nice | off. The panel shows this rather
                -- than implying a ceiling the kernel never agreed to.
                ('scan_cpu_cap_mode',       'nice'),
                ('scan_cpu_cap_probe',      ''),
                -- Update checker
                ('update_available',        '0'),
                ('update_latest_ver',       ''),
                ('update_checked_at',       '0'),
                ('update_release_url',      ''),
                ('update_release_notes',    '');

            -- Default firewall rules
            INSERT OR IGNORE INTO firewall_rules (name, direction, protocol, port, action, comment) VALUES
                ('ALLOW_SSH',          'in',   'tcp', '22',   'ACCEPT', 'Allow SSH access'),
                ('ALLOW_HTTP',         'in',   'tcp', '80',   'ACCEPT', 'Allow HTTP'),
                ('ALLOW_HTTPS',        'in',   'tcp', '443',  'ACCEPT', 'Allow HTTPS'),
                ('ALLOW_cPanel',       'in',   'tcp', '2082', 'ACCEPT', 'Allow cPanel'),
                ('ALLOW_WHM',          'in',   'tcp', '2086', 'ACCEPT', 'Allow WHM'),
                ('ALLOW_cPanelSSL',    'in',   'tcp', '2083', 'ACCEPT', 'Allow cPanel SSL'),
                ('ALLOW_WHMSSL',       'in',   'tcp', '2087', 'ACCEPT', 'Allow WHM SSL'),
                ('BLOCK_NULL_PACKETS', 'in',   'tcp', NULL,   'DROP',   'Block NULL packets'),
                ('BLOCK_XMAS',         'in',   'tcp', NULL,   'DROP',   'Block XMAS packets'),
                ('RATE_LIMIT_SSH',     'in',   'tcp', '22',   'LIMIT',  'Rate limit SSH brute force');
        ");

        // Operator verdicts: "I looked at this file and it is not malware."
        //
        // Keyed on (file_path, sha256), NOT on path. This is the whole point:
        // an exclusion blinds the scanner to a path forever, while a verdict
        // only suppresses the REPORT for the exact bytes somebody read and
        // cleared. Change one byte and the hash no longer matches, so the file
        // is reported again at full severity. See Verdicts.php.
        //
        // UNIQUE(file_path, sha256) makes a double-click a no-op rather than a
        // duplicate row.
        $db->exec("
            CREATE TABLE IF NOT EXISTS file_verdicts (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path   TEXT    NOT NULL,
                sha256      TEXT    NOT NULL,
                verdict     TEXT    NOT NULL DEFAULT 'not_malware',
                threat_name TEXT,
                size        INTEGER DEFAULT 0,
                note        TEXT,
                created_by  TEXT,
                created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                UNIQUE(file_path, sha256)
            );
            CREATE INDEX IF NOT EXISTS idx_verdict_lookup
                ON file_verdicts(file_path, sha256);
        ");

        // Firewall rules: the seeding INSERT above says OR IGNORE, and until now
        // there was nothing for it to ignore ON.
        //
        // FROM A LIVE SERVER. The Firewall page "took forever to load" and then
        // killed the browser tab. The cause was 343,000 rules in a table the
        // operator had added about a dozen entries to. firewall_rules has no
        // UNIQUE constraint, so "INSERT OR IGNORE" had no conflict to ignore and
        // the ten default rules were appended again on EVERY database open --
        // which is every API request. 343,000 / 10 is roughly 34,000 page loads.
        // The product was manufacturing its own rules, and paging the table only
        // hides that.
        //
        // Give the rule identity a unique index so OR IGNORE has something to
        // ignore, and collapse what has already piled up, keeping the earliest
        // row of each set. port, source_ip and dest_ip are nullable and SQLite
        // treats NULLs as distinct, so the index is on COALESCE'd expressions --
        // otherwise BLOCK_NULL_PACKETS, whose port IS NULL, would go on
        // duplicating straight past the index.
        $hasFwIdx = $db->query(
            "SELECT 1 FROM sqlite_master WHERE type='index' AND name='idx_fw_identity'"
        )->fetchColumn();
        if ($hasFwIdx === false) {
            $db->exec("DELETE FROM firewall_rules WHERE id NOT IN (
                           SELECT MIN(id) FROM firewall_rules
                            GROUP BY name, direction, COALESCE(protocol,''),
                                     COALESCE(port,''), COALESCE(source_ip,''),
                                     COALESCE(dest_ip,''), action)");
            $db->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_fw_identity
                           ON firewall_rules (name, direction, COALESCE(protocol,''),
                                COALESCE(port,''), COALESCE(source_ip,''),
                                COALESCE(dest_ip,''), action)");
        }

        // Incremental migrations — safe to run on every boot (IF NOT EXISTS / IGNORE)
        // How the client address in a WAF event was arrived at.
        //
        // Every row written before 4.35.1 holds the CONNECTION address from
        // ModSecurity's section A, which for an account behind cPanel's nginx
        // is the proxy -- so a live server listed its own IP as the busiest
        // attacker against itself. The address was in the request headers all
        // along. These two columns record what was used and what the chain
        // said, so attribution can be checked instead of assumed.
        //
        // Not backfilled: the header is in the audit log, not in this table,
        // so the old rows genuinely cannot be repaired. They stay labelled ''.
        $wafCols = array_column($db->query("PRAGMA table_info(waf_events)")->fetchAll(PDO::FETCH_ASSOC), 'name');
        if (!in_array('ip_source', $wafCols)) {
            $db->exec("ALTER TABLE waf_events ADD COLUMN ip_source TEXT NOT NULL DEFAULT ''");
        }
        if (!in_array('forwarded_for', $wafCols)) {
            $db->exec("ALTER TABLE waf_events ADD COLUMN forwarded_for TEXT NOT NULL DEFAULT ''");
        }

        // Add cpanel_user column to threats if missing (SQLite ALTER TABLE is append-only)
        $cols = array_column($db->query("PRAGMA table_info(threats)")->fetchAll(PDO::FETCH_ASSOC), 'name');
        if (!in_array('cpanel_user', $cols)) {
            $db->exec("ALTER TABLE threats ADD COLUMN cpanel_user TEXT");
        }

        // Which process is actually doing the scanning.
        //
        // A scan was launched detached with `&` and its PID was never recorded,
        // so nothing could stop it afterwards: once started, clamscan ran to
        // completion whatever the operator did. The process GROUP is the useful
        // thing to keep -- the worker forks clamscan for every batch, and
        // killing only the worker leaves the clamscan it is currently waiting
        // on running.
        $jobCols = array_column($db->query("PRAGMA table_info(scan_jobs)")->fetchAll(PDO::FETCH_ASSOC), 'name');
        if (!in_array('worker_pid', $jobCols)) {
            $db->exec("ALTER TABLE scan_jobs ADD COLUMN worker_pid INTEGER");
        }
        if (!in_array('worker_pgid', $jobCols)) {
            $db->exec("ALTER TABLE scan_jobs ADD COLUMN worker_pgid INTEGER");
        }

        // A scan a customer asked for by hand does not stand down for a
        // backup. It has to be on the job rather than decided by the worker,
        // because the worker checks again between every batch and by then the
        // only thing it knows about the scan is this row.
        if (!in_array('ignore_backup', $jobCols)) {
            $db->exec("ALTER TABLE scan_jobs ADD COLUMN ignore_backup INTEGER NOT NULL DEFAULT 0");
        }

        // Which cPanel account asked for this scan, if any. Two jobs depend on
        // it: publishing progress into that account's home so their page can
        // show it, and deciding whether a cancel request is theirs to make. An
        // empty value means the server asked -- the scheduled sweep, the
        // operator UI or the CLI -- and no customer may stop it.
        if (!in_array('requested_by', $jobCols)) {
            $db->exec("ALTER TABLE scan_jobs ADD COLUMN requested_by TEXT NOT NULL DEFAULT ''");
        }
        // Why a scan stopped.
        //
        // Every row said 'cancelled' and nothing said by what. A nightly
        // /home scan killed by our own updater looked identical to one an
        // operator stopped deliberately, so a scan log full of "cancelled"
        // could not be read at all -- and the real answer (the updater stops
        // every scan, on every update) stayed invisible for months.
        if (!in_array('stop_reason', $jobCols)) {
            $db->exec("ALTER TABLE scan_jobs ADD COLUMN stop_reason TEXT NOT NULL DEFAULT ''");
        }
        // What a disabled file's permissions were before we took them away.
        // Without it, "disable" is a one-way door: nobody can put a false
        // positive back the way they found it, which makes the safe action
        // feel more dangerous than deleting.
        $thrCols = array_column(
            $db->query("PRAGMA table_info(threats)")->fetchAll(PDO::FETCH_ASSOC), 'name');
        if (!in_array('prev_mode', $thrCols)) {
            $db->exec("ALTER TABLE threats ADD COLUMN prev_mode INTEGER");
        }

        // Where a quarantined file went, and when it may be deleted. The sweep
        // needs the exact path: guessing it from the threat's original name
        // would eventually delete the wrong thing.
        $thCols = array_column($db->query("PRAGMA table_info(threats)")->fetchAll(PDO::FETCH_ASSOC), 'name');
        if (!in_array('quarantine_path', $thCols)) {
            $db->exec("ALTER TABLE threats ADD COLUMN quarantine_path TEXT");
        }
        if (!in_array('quarantine_expires_at', $thCols)) {
            $db->exec("ALTER TABLE threats ADD COLUMN quarantine_expires_at INTEGER");
        }

        /* Who owned the file before we took it. These are files in customer
         * homes, and a restore that writes them back as root:root breaks the
         * site a different way -- which is what the 10 Nov false positive made
         * unavoidable for 154,323 files, because nothing recorded the owner.
         * QuarantineRestore falls back to the owner of the directory the file
         * goes back into when these are null, and says in its report which of
         * the two it used. */
        if (!in_array('orig_uid', $thCols)) {
            $db->exec("ALTER TABLE threats ADD COLUMN orig_uid INTEGER");
        }
        if (!in_array('orig_gid', $thCols)) {
            $db->exec("ALTER TABLE threats ADD COLUMN orig_gid INTEGER");
        }

        // One-time repair of mail_activity written before 4.11.1.
        //
        // collect() used to file every log line it read into the CURRENT hour,
        // so a first run -- which reads up to 8 MB of HISTORY -- recorded days
        // of mail as though it had all happened in the last sixty minutes. On
        // a live server that produced a CRITICAL finding of "5,036 messages in
        // the last hour" against an account whose real figure was 22 messages
        // across 300,000 log lines.
        //
        // Those rows cannot be corrected, only discarded: the hour they
        // belonged to was never recorded. The offset is reset too, so the log
        // is re-read and rebuilt with correct timestamps.
        $row = $db->query("SELECT value FROM settings WHERE key = 'mg_bucket_repair'")
                  ->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            // mail_activity is created lazily by MailGuard::ensureSchema(), so
            // it may not exist yet on a fresh install. Checked rather than
            // assumed: an exception here aborts every migration after it.
            $has = $db->query("SELECT name FROM sqlite_master
                                WHERE type='table' AND name='mail_activity'")
                      ->fetch(PDO::FETCH_ASSOC);
            if ($has) { $db->exec("DELETE FROM mail_activity"); }
            $db->exec("DELETE FROM settings WHERE key = 'mg_offset'");
            $db->exec("INSERT OR REPLACE INTO settings (key, value)
                       VALUES ('mg_bucket_repair', '1')");
        }

        // One-time: turn the scanner's backup gate off on an existing install.
        //
        // Changing the SEEDED default only reaches new installs -- INSERT OR
        // IGNORE never touches a row that already exists -- so without this
        // every server already running would keep the gate on and nothing
        // about their coverage would change.
        //
        // Why it is being turned off: the gate does not DELAY a scan that
        // meets a long backup window, it ABANDONS it. waitOutBackup() gives up
        // at scan_backup_max_wait (four hours) and the rest of that sweep is
        // dropped until the next scheduled run a day later. On a server whose
        // JetBackup and rsync windows overlap the scan window, that is whole
        // nights with no malware scan -- traded for I/O contention, which
        // makes both jobs slower but loses neither.
        //
        // Keyed on its own marker so this runs ONCE. An operator who turns the
        // gate back on afterwards keeps it: a migration that re-applied itself
        // on every boot would silently overrule them for ever.
        self::once($db, 'scan_backup_gate_off_4312', function (PDO $db) {
            $db->exec("UPDATE settings SET value = '0'
                        WHERE key = 'scan_pause_on_backup'");
            // Any scan parked by the old gate is no longer parked, and a stale
            // '1' here shows "paused for backup" on the dashboard for ever.
            $db->exec("UPDATE settings SET value = '0'
                        WHERE key = 'scan_paused_for_backup'");
        });

        // Every WAF read filters by time: the event list, the "today"
        // count, and the triage report's aggregates. 148,551 rows is a fast
        // scan but not a free one, and it is scanned several times per page
        // load.
        $db->exec("CREATE INDEX IF NOT EXISTS idx_waf_time
                       ON waf_events (timestamp)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_waf_rule_time
                       ON waf_events (rule_id, timestamp)");

        // One-time: the action on every existing WAF event was invented.
        //
        // saveWafEvent() wrote the literal string 'block' on every row it ever
        // inserted, and the detail dialog displayed it as fact. It was never
        // read from the audit log, so on a server running the engine in
        // DetectionOnly every one of those rows claimed a request had been
        // blocked when it had been served. 148,551 rows on the server that
        // prompted this.
        //
        // They are set to 'unknown', which the panel renders as a dash with an
        // explanation. There is no information to recover here -- the value
        // was never observed -- and leaving a confident wrong answer in place
        // is worse than admitting the gap. Events ingested from now on carry
        // what ModSecurity actually did.
        self::once($db, 'waf_action_honesty_4330', function (PDO $db) {
            $has = $db->query("SELECT name FROM sqlite_master
                                WHERE type='table' AND name='waf_events'")
                      ->fetch(PDO::FETCH_ASSOC);
            if ($has) {
                $db->exec("UPDATE waf_events SET action = 'unknown'
                            WHERE action IS NULL OR action = '' OR action = 'block'");
            }
        });

        // Queued mail that will never be delivered is deleted after this
        // long. Exim retries until retry_data expires -- days -- so these
        // messages sit there for ever, and a queue nobody can read through is
        // a queue in which an active relay is invisible.
        //
        // pruneStale() clamps the age to at least 24 hours whatever is set
        // here: the setting is in HOURS and a '1' meant as "one day" would
        // otherwise delete an hour-old queue.
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('mq_autodelete', '1')");
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('mq_max_age_hours', '72')");
        // Per run, and MailGuard::deleteMessages() refuses more than 500 in
        // one call anyway. A 93,000-message queue is cleared over several
        // hourly passes rather than in one unreviewable sweep.
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('mq_autodelete_cap', '500')");

        // Outbound mail monitoring, on by default.
        //
        // OUTBOUND ONLY. Inbound filtering is MagicSpam's job on this server
        // and two tools fighting over inbound policy is worse than one. Nothing
        // here reads a message body or scores spam; it counts and attributes.
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('mg_enabled', '1')");
        // 500/hour per account. The relay that prompted this ran at ~1,690/hour
        // for a day, so this catches that shape inside the first hour while
        // staying well above what a busy shop or a small newsletter sends.
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('mg_hourly', '500')");
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('mg_queue', '2000')");
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('mg_frozen', '250')");
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('mg_retain_days', '60')");

        // Network-layer guards. Scan detection and flood limits are ON: both
        // only ever record, and the escalation they feed into is the
        // brute-force ladder that was already running.
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('ng_scan_enabled', '1')");
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('ng_scan_ports', '10')");
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('ng_flood_enabled', '1')");
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('ng_flood_limit', '150')");
        // 80 and 443 exempt by default. A browser opens six connections per
        // page, a corporate NAT or CDN presents hundreds of real users as one
        // address, and this product's own dashboard is served over 443 -- a
        // flood limit there blocks the operator out of the page they would
        // need to turn it off.
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('ng_flood_exempt_ports', '80,443')");
        // Egress filtering OFF, with no automatic enable anywhere. A wrong
        // inbound rule blocks visitors and you hear about it; a wrong OUTBOUND
        // rule breaks updates, DNS, mail, licensing and backups quietly.
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('ng_egress_enabled', '0')");

        // Unattended updating, on by default.
        //
        // Defaulting this ON is a real decision and not a neutral one: it
        // replaces the security software on a production server without anyone
        // watching. It is the right default anyway, because the alternative
        // observed in the field is a server running a version from months ago
        // with an "update available" badge nobody reads. The risk is bounded
        // instead by what Updater::shouldApply() refuses -- major versions, a
        // running scan, a running backup, and anything after three failures.
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('auto_update', '1')");
        // Major versions are NOT automatic. X is reserved in this product's
        // versioning for a breaking change.
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('auto_update_major', '0')");
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('autoupdate_schedule', 'daily')");
        // 04:30: after the 03:30 database sweep and the 04:00 CMS discovery,
        // so a restart does not land on top of either.
        $db->exec("INSERT OR IGNORE INTO settings (key, value)
                   VALUES ('autoupdate_time', '04:30')");

        // Why a heuristic fired, in a sentence.
        //
        // Added with the heuristic rule engine. The old flat signatures were
        // self-describing -- "eval_base64" says what it found -- but a rule
        // that fires on a CONJUNCTION cannot be read off its name. An operator
        // deciding whether to delete a customer's file needs to be told that
        // the file checks a 32-hex password with hash_equals() and then calls
        // move_uploaded_file(), not just that rule 'upload_backdoor_hashkey'
        // matched.
        if (!in_array('detail', $thCols)) {
            $db->exec("ALTER TABLE threats ADD COLUMN detail TEXT");
        }

        // Findings that are not files.
        //
        // Everything this product recorded until now was a path. During the
        // October 2026 incident most of what mattered was a database row: 148
        // administrator accounts inserted by SQL, a payload mirrored across
        // wp_options and a draft post, a login token in usermeta, and a
        // contact form whose autoresponder relayed 92,954 spam messages
        // without a single file being modified. None of those fit in `threats`
        // -- there is no file to quarantine and nothing to delete on disk --
        // so they get their own table, and the actions column says what a
        // human should do rather than implying the software already did it.
        $db->exec("
            CREATE TABLE IF NOT EXISTS wp_findings (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_job_id  INTEGER REFERENCES scan_jobs(id),
                install_path TEXT    NOT NULL,
                db_name      TEXT,
                cpanel_user  TEXT,
                finding_type TEXT    NOT NULL,
                severity     TEXT    DEFAULT 'medium',
                what         TEXT,
                action       TEXT,
                status       TEXT    DEFAULT 'open',
                detected_at  INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                resolved_at  INTEGER
            );
        ");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_wpf_open
                     ON wp_findings(status, severity)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_wpf_install
                     ON wp_findings(install_path)");

        // 3.30.4 shipped scan_max_concurrent defaulting to 2; the intended
        // number is 1. The seed above is INSERT OR IGNORE, so it cannot change
        // a row that already exists -- an upgrade would silently keep 2.
        //
        // Guarded by a marker so it runs exactly once: an operator who later
        // sets this to 2 deliberately keeps it, rather than having every
        // upgrade quietly overrule them.
        // Quarantine used to be kept for 30 days. The policy is that nothing
        // stays beyond 7, and the seed is INSERT OR IGNORE so it cannot change
        // a row that already exists -- an upgrade would otherwise keep 30 and
        // the backlog would never clear. Marked so it runs once: an operator
        // who deliberately sets a longer retention afterwards keeps it.
        $qmig = $db->query(
            "SELECT value FROM settings WHERE key='sg_mig_quarantine_7d'"
        )->fetchColumn();
        if ($qmig === false) {
            $db->exec("UPDATE settings SET value='7'
                        WHERE key='quarantine_retention_days'
                          AND CAST(value AS INTEGER) > 7");
            $db->exec("INSERT OR REPLACE INTO settings (key,value) "
                    . "VALUES ('sg_mig_quarantine_7d','1')");
        }

        // Brute force blocked at ten failures in ten minutes and, because
        // nothing ever lifted a block, blocked each address at most once ever.
        // The policy is five failures and an escalating term. Existing
        // installs hold the old threshold, which the seed cannot change.
        // Marked so an operator who afterwards chooses their own threshold
        // keeps it.
        $bfmig = $db->query(
            "SELECT value FROM settings WHERE key='sg_mig_bf_ladder'"
        )->fetchColumn();
        if ($bfmig === false) {
            $db->exec("UPDATE settings SET value='5'
                        WHERE key='bf_threshold' AND CAST(value AS INTEGER) > 5");
            // Auto-blocking off meant the ladder would never run at all. It
            // is turned back on once: watching an attack without acting on it
            // is what prompted this.
            $db->exec("UPDATE settings SET value='1' WHERE key='bf_auto_block'");
            $db->exec("INSERT OR REPLACE INTO settings (key,value) "
                    . "VALUES ('sg_mig_bf_ladder','1')");
        }

        $migrated = $db->query(
            "SELECT value FROM settings WHERE key='sg_mig_scan_concurrency_1'"
        )->fetchColumn();
        if ($migrated === false) {
            $db->exec("UPDATE settings SET value='1' WHERE key='scan_max_concurrent'");
            $db->exec("INSERT OR REPLACE INTO settings (key,value) "
                    . "VALUES ('sg_mig_scan_concurrency_1','1')");
        }
    }

    public static function query(string $sql, array $params = []): PDOStatement {
        $stmt = self::get()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public static function fetchAll(string $sql, array $params = []): array {
        return self::query($sql, $params)->fetchAll();
    }

    public static function fetchOne(string $sql, array $params = []): ?array {
        $row = self::query($sql, $params)->fetch();
        return $row ?: null;
    }

    public static function insert(string $table, array $data): int {
        $cols = implode(',', array_keys($data));
        $placeholders = implode(',', array_fill(0, count($data), '?'));
        self::query("INSERT INTO $table ($cols) VALUES ($placeholders)", array_values($data));
        return (int) self::get()->lastInsertId();
    }

    /**
     * Resolve a storage path — uses DB setting if configured, otherwise falls
     * back to the compile-time constant (QUARANTINE_DIR / SG_LOGS).
     * This lets admins relocate data via the GUI without touching config.php.
     */
    public static function storagePath(string $type): string {
        $key     = ($type === 'quarantine') ? 'quarantine_dir' : 'log_dir';
        $fallback= ($type === 'quarantine') ? QUARANTINE_DIR   : SG_LOGS;
        $val     = self::setting($key, '');
        $path    = ($val !== '') ? rtrim($val, '/') : rtrim($fallback, '/');
        if (!is_dir($path)) @mkdir($path, 0750, true);
        return $path;
    }

    /**
     * Prune old database rows to prevent unbounded growth.
     * Called by the nightly cron and by the GUI "Run Cleanup Now" button.
     */
    public static function pruneOldRecords(): array {
        $deleted = [];

        // WAF events — keep only the most recent N rows
        $maxWaf = (int) self::setting('db_max_waf_events', '100000');
        $total  = self::fetchOne("SELECT COUNT(*) as c FROM waf_events")['c'];
        if ($total > $maxWaf) {
            $keep = self::fetchOne(
                "SELECT id FROM waf_events ORDER BY id DESC LIMIT 1 OFFSET ?",
                [$maxWaf]
            );
            if ($keep) {
                $r = self::query("DELETE FROM waf_events WHERE id <= ?", [$keep['id']]);
                $deleted['waf_events'] = $r->rowCount();
            }
        }

        // Security events — keep only the most recent N rows
        $maxSec = (int) self::setting('db_max_security_events', '50000');
        $total  = self::fetchOne("SELECT COUNT(*) as c FROM security_events")['c'];
        if ($total > $maxSec) {
            $keep = self::fetchOne(
                "SELECT id FROM security_events ORDER BY id DESC LIMIT 1 OFFSET ?",
                [$maxSec]
            );
            if ($keep) {
                $r = self::query("DELETE FROM security_events WHERE id <= ?", [$keep['id']]);
                $deleted['security_events'] = $r->rowCount();
            }
        }

        // IP reputation cache — evict entries older than 24 hours
        $cutoff = time() - 86400;
        $r = self::query("DELETE FROM ip_reputation WHERE cached_at < ?", [$cutoff]);
        $deleted['ip_reputation'] = $r->rowCount();

        // Cron log — keep only last N rows
        $maxCron = (int) self::setting('db_max_cron_log', '1000');
        $total   = self::fetchOne("SELECT COUNT(*) as c FROM cron_log")['c'];
        if ($total > $maxCron) {
            $keep = self::fetchOne(
                "SELECT id FROM cron_log ORDER BY id DESC LIMIT 1 OFFSET ?",
                [$maxCron]
            );
            if ($keep) {
                $r = self::query("DELETE FROM cron_log WHERE id <= ?", [$keep['id']]);
                $deleted['cron_log'] = $r->rowCount();
            }
        }

        // Resolved threats older than quarantine_retention_days — mark as archived
        $retDays = (int) self::setting('quarantine_retention_days', '90');
        $cutoff  = time() - ($retDays * 86400);
        $r = self::query(
            "UPDATE threats SET status='archived' WHERE status='quarantined' AND detected_at < ?",
            [$cutoff]
        );
        $deleted['threats_archived'] = $r->rowCount();

        // Compact the DB after large deletes
        self::get()->exec('PRAGMA wal_checkpoint(PASSIVE); VACUUM;');

        return $deleted;
    }

    public static function setting(string $key, ?string $default = null): ?string {
        $row = self::fetchOne("SELECT value FROM settings WHERE key = ?", [$key]);
        return $row ? $row['value'] : $default;
    }

    public static function setSetting(string $key, string $value): void {
        self::query(
            "INSERT INTO settings (key, value, updated_at) VALUES (?, ?, strftime('%s','now'))
             ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            [$key, $value]
        );
    }
}
