/**
 * ServerScrub — Main Application
 * SPA controller, page routing, all UI interactions
 */

// ── State ─────────────────────────────────────────────────────────────────────
const State = {
  currentPage:  'dashboard',
  scanJobId:    null,
  scanInterval: null,
  refreshInt:   null,
  geoSelected:  new Set(),
  user:         null,
};

// ── Install mode (fetched from API on load) ───────────────────────────────────
State.installMode = 'cpanel'; // default until API responds
State.version     = '';       // filled by detectMode()

async function detectMode() {
  try {
    const res = await API.status();
    if (res?.success) {
      State.installMode = res.mode    || 'cpanel';
      State.version     = res.version || '';
    }
  } catch (_) { /* stay with default */ }
  applyModeUI(State.installMode); // always update UI, even on API failure
}

function applyModeUI(mode) {
  const isStandalone = mode === 'standalone';

  // Login screen labels
  const sub   = document.getElementById('login-mode-sub');
  const badge = document.getElementById('login-mode-badge');
  const label = document.getElementById('login-user-label');
  const hint  = document.getElementById('login-hint');
  const userEl = document.getElementById('login-user');

  if (sub)   sub.textContent   = isStandalone ? 'Standalone Linux Server' : 'cPanel Security Suite';
  if (label) label.textContent = isStandalone ? 'Admin Username' : 'cPanel / WHM Username';
  if (userEl) userEl.placeholder = isStandalone ? 'admin' : 'root';
  if (hint)  hint.textContent  = isStandalone
    ? 'Local admin credentials set during installation'
    : 'Uses your existing cPanel / WHM credentials  ·  Demo: demo / demo';
  if (badge) badge.innerHTML = isStandalone
    ? '<span style="font-size:.68rem;padding:3px 10px;border-radius:20px;background:rgba(16,185,129,.15);color:var(--green);border:1px solid rgba(16,185,129,.3);letter-spacing:.05em">⚡ STANDALONE LINUX</span>'
    : '<span style="font-size:.68rem;padding:3px 10px;border-radius:20px;background:rgba(59,130,246,.15);color:var(--blue);border:1px solid rgba(59,130,246,.3);letter-spacing:.05em">🖥 cPANEL / WHM</span>';

  // Sidebar version / mode label
  const sideLabel = document.getElementById('sidebar-mode-label');
  if (sideLabel) {
    const ver = State.version ? `v${State.version}` : '';
    sideLabel.textContent = isStandalone ? `${ver} · Standalone` : `${ver} · cPanel Plugin`;
  }

  // Settings page: show/hide standalone-only cards
  const banner = document.getElementById('standalone-settings-banner');
  const chpw   = document.getElementById('card-change-password');
  if (banner) banner.classList.toggle('hidden', !isStandalone);
  if (chpw)   chpw.classList.toggle('hidden',   !isStandalone);
}

// ── Auth ──────────────────────────────────────────────────────────────────────
const Auth = {
  isLoggedIn() { return !!localStorage.getItem('sg_token'); },

  logout() {
    localStorage.removeItem('sg_token');
    localStorage.removeItem('sg_user');
    location.reload();
  },

  init() {
    if (this.isLoggedIn()) {
      document.getElementById('login-screen').style.display = 'none';
      const u = JSON.parse(localStorage.getItem('sg_user') || '{}');
      State.user = u;
      State.installMode = u.mode || 'cpanel';
      const av = document.getElementById('user-avatar');
      if (av && u.username) av.textContent = u.username.slice(0,2).toUpperCase();
      applyModeUI(State.installMode);
      detectMode(); // async: fetches live version from API and updates sidebar

      // Licence gate, checked before the dashboard loads rather than after.
      // Letting the pages load first means every panel fires a request that is
      // refused with 402 and renders empty behind the activation screen.
      enforceLicenseGate();

      return true;
    }
    // Not logged in — detect mode for login screen
    detectMode();
    return false;
  }
};

// ── Toast Notifications ───────────────────────────────────────────────────────
function toast(msg, type = 'info') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  const icons = { success: '✓', error: '✕', info: 'ℹ', warn: '⚠' };
  el.innerHTML = `<span style="font-size:1rem">${icons[type]||'ℹ'}</span><span>${msg}</span>`;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ── Page Navigation ───────────────────────────────────────────────────────────
// The monitor page had no refresh of its own: it loaded once when opened and
// then showed whatever was true at that moment until someone pressed Refresh.
// A paused/running state that changes on its own -- which is the whole point of
// the backup pause and the auto-resume -- was therefore routinely wrong on
// screen. Poll while the page is actually visible, and stop when it is not.
let _monitorPoll = null;

function startMonitorPolling(name) {
  if (_monitorPoll) { clearInterval(_monitorPoll); _monitorPoll = null; }
  if (name !== 'monitor' && name !== 'dashboard') { return; }

  _monitorPoll = setInterval(() => {
    // Not while a start/stop is mid-flight: refreshing then would render the
    // state the button is in the middle of changing.
    if (_monitorBusy) { return; }
    if (document.hidden) { return; }   // background tab: no point polling
    if (State.currentPage === 'monitor')        { loadMonitor(); }
    else if (State.currentPage === 'dashboard') { loadMonitorStats(); }
    else { clearInterval(_monitorPoll); _monitorPoll = null; }
  }, 15000);
}

// The markup every page shows while its data is on the way.
// An image URL that changes when the release does.
//
// Cache-busting the markup is not enough: several images are referenced from
// here, and a filename whose CONTENTS change between releases is cached by the
// browser exactly as hard as one whose name never changes. icon-64.png held
// the old crop in 4.0.0 and the new mark in 4.1.0, so updated servers kept
// drawing the old logo with nothing to suggest why.
function assetUrl(path) {
  const v = (typeof window !== 'undefined' && window.SG_ASSET_V) || '';
  return v ? path + '?v=' + encodeURIComponent(v) : path;
}

function loadingMark(caption) {
  return '<div class="ss-load" style="padding:28px 0">'
       + '<img src="' + assetUrl('images/icon.png') + '" alt="">'
       + '<span class="ss-cap">' + esc(caption || 'Loading…') + '</span>'
       + '</div>';
}

// Same thing sized for a table cell, so a table does not jump as it fills.
function loadingRow(cols, caption) {
  return '<tr><td colspan="' + (cols || 6) + '" style="padding:18px 0">'
       + loadingMark(caption) + '</td></tr>';
}

// Drop the splash once the first page has actually drawn something. Hiding it
// on a timer would either cover a ready page or uncover a blank one.
let _splashGone = false;

// Nothing may leave the user looking at a logo for ever.
//
// The splash is dismissed when a page renders, which is the right moment --
// but it is also the only moment, and 4.1.0 shipped with that call landing
// after a `return` in an unrelated function. The result was an app that was
// running perfectly behind a cover that never lifted, with no error anywhere
// to say so. A cover that can stick is worse than no cover, so these remove it
// regardless of whether anything remembered to.
window.addEventListener('load', () => setTimeout(dismissSplash, 1200));
setTimeout(dismissSplash, 6000);

function dismissSplash() {
  if (_splashGone) return;
  _splashGone = true;
  const el = document.getElementById('ss-splash');
  if (!el) return;
  el.classList.add('gone');
  setTimeout(() => el.remove(), 400);
}

function openPage(name) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));

  // Show target
  const page = document.getElementById(`page-${name}`);
  if (page) page.classList.remove('hidden');

  // Update nav state
  document.querySelectorAll('.nav-item, .sidebar-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page === name);
  });

  State.currentPage = name;
  startMonitorPolling(name);
  // The pill is in the topbar, so it is on every page; the dashboard is the
  // only page that would otherwise supply it.
  refreshTopStatus();

  // Trigger page-specific data load.
  //
  // A TABLE, not a switch, for two reasons that both bit us.
  //
  // 1. The switch was missing `monitor`. Every other page had a case;
  //    Real-Time Monitor did not, so opening it loaded nothing and the panel
  //    sat on "Loading…" and "Checking…" for ever. The Refresh button worked,
  //    because it calls the loader directly -- which made it look like a
  //    refresh problem rather than a missing wire. A missing entry in a table
  //    is visible; a missing `case` in a 16-arm switch is not, and
  //    tests/test_navigation.php now asserts every sidebar page has one.
  //
  // 2. Only `firewall` went through API.withBusy(), so every other page
  //    loaded with no indication anything was happening. Dispatching through
  //    one place means the busy overlay is automatic and cannot be forgotten
  //    for the next page added.
  //
  // Each entry RETURNS a promise. The overlay lifts when the work finishes,
  // so an entry that forgets to return one would flash and vanish --
  // Promise.all is used wherever a page needs more than one call.
  const PAGE_LOADERS = {
    dashboard:  ['Loading dashboard…', () => refreshDashboard()],
    // loadExclusions() belongs here: the Scan exclusions card lives on this
    // page and nothing else fills it. Without it the card rendered with an
    // empty "already excluded" line and an empty textarea showing only its
    // placeholder, which reads as "there are no exclusions" rather than "this
    // was never loaded".
    scanner:    ['Loading scanner…',   () => Promise.all([loadThreats(),
                                                          adoptRunningScan(),
                                                          loadExclusions(),
                                                          loadScanJobs(),
                                                          loadSuppressions(),
                                                   loadVerdicts()])],
    firewall:   ['Loading firewall…',  () => loadFirewall()],
    waf:        ['Loading WAF…',       () => Promise.all([loadWAF(),
                                                          loadWafEngine()])],
    iprep:      ['Loading reputation…', () => Promise.all([loadTopAttackers(),
                                                           loadServerIpForBlocklist()])],
    events:     ['Loading events…',    () => loadEvents()],
    bruteforce: ['Loading brute force…', () => loadBruteForce()],
    settings:   ['Loading settings…',  () => Promise.all([loadSettings(),
                                                          loadUpdateSettings(),
                                                          loadStorageStats()])],
    botshield:  ['Loading bot shield…', () => Promise.all([loadBotShield(),
                                                          loadHttpFlood()])],
    cms:        ['Loading CMS Guard…', () => loadCMSGuard()],
    wpscan:     ['Loading WP database…', () => loadWPScan()],
    mailqueue:  ['Loading mail queue…', () => loadMailQueue()],
    mailguard:  ['Loading spam monitor…', () => Promise.all([loadMailGuard(),
                                                             loadMailSettings(),
                                                             loadFlaggedAttachments()])],
    // The one that was missing. Both halves: the daemon's own status, and the
    // systemd unit -- loadMonitor() does not fetch the service, which is why
    // that panel said "Checking…" even after a manual refresh.
    // Three loaders, not one. loadMonitor() fetches the daemon's status,
    // loadServiceStatus() the systemd unit, and loadMonitorDetections() the
    // table -- which nothing called at all, so "RECENT DETECTIONS" sat on
    // "Loading…" even after the page dispatch was fixed.
    monitor:    ['Loading monitor…',   () => Promise.all([loadMonitor(),
                                                          loadServiceStatus(),
                                                          loadMonitorDetections(),
                                                          loadMonitorLog()])],
    rootkit:    ['Loading rootkit scan…', () => loadRootkit()],
    integrity:  ['Loading file integrity…', () => loadIntegrity()],
    logs:       ['Loading logs…',      () => loadLogs()],
    php:        ['Loading PHP hardening…', () => loadPHPHardening()],
  };

  const entry = PAGE_LOADERS[name];
  if (entry) {
    // Not awaited: the page is already on screen and the overlay is the
    // feedback. A rejected loader must not stop the splash being dismissed
    // below, or a single failing endpoint leaves the whole UI covered.
    API.withBusy(entry[0], entry[1]).catch(err => {
      console.error('page load failed:', name, err);
      toast('Could not load this page: '
            + (err && err.message ? err.message : err), 'error', 8000);
    });
  }

  // The page is on screen now, so the splash has done its job. Its loading
  // marks cover the data still arriving.
  dismissSplash();
}

// ── Utilities ─────────────────────────────────────────────────────────────────
function reltime(ts) {
  const diff = Math.floor(Date.now() / 1000 - ts);
  if (diff < 60)    return `${diff}s ago`;
  if (diff < 3600)  return `${Math.floor(diff/60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
  return `${Math.floor(diff/86400)}d ago`;
}

function fmtBytes(b) {
  if (b < 1024)     return `${b} B`;
  if (b < 1048576)  return `${(b/1024).toFixed(1)} KB`;
  return `${(b/1048576).toFixed(1)} MB`;
}

function fmtNum(n) {
  return Number(n).toLocaleString();
}

function sevBadge(sev) {
  return `<span class="sev sev-${sev}">${sev.toUpperCase()}</span>`;
}

// The element lookup every handler uses.
//
// This existed only as a `const g` inside two functions, so any module-scope
// code calling g() threw ReferenceError the moment it ran -- silently, inside
// an event handler. Three shipped features did nothing at all because of it:
// the custom-scan account picker, adopting an already-running scan, and the
// brute-force ladder preview. Defined once, here, where everything can see it.
function g(id) { return document.getElementById(id); }

function openModal(id)  { document.getElementById(id)?.classList.remove('hidden'); }
function closeModal(id) { document.getElementById(id)?.classList.add('hidden'); }

// ── In-app confirm / show ───────────────────────────────────────────────────
//
// window.confirm() and window.alert() are not reliable here. Once a page has
// shown a few, Chrome and Firefox offer "prevent this page from creating
// additional dialogs"; after that confirm() returns false and alert() does
// nothing at all, silently, with no error. Every handler shaped like
//
//     if (!confirm('Really?')) return;
//
// then becomes a button that does nothing when clicked, which is exactly how
// two controls in this product shipped dead.
//
// These also allow real markup in the body, which matters for an action that
// needs to show WHICH messages it is about to send.
let _uiDialogResolve = null;

function uiDialogResolve(result) {
  closeModal('ui-dialog');
  const fn = _uiDialogResolve;
  _uiDialogResolve = null;
  if (fn) fn(result);
}

/**
 * @param {{title:string, body:string, pre?:string, ok?:string,
 *          danger?:boolean, cancel?:string|null}} o
 * @returns {Promise<boolean>}
 */
function uiConfirm(o) {
  return new Promise(resolve => {
    // A dialog already open would otherwise leave the previous promise
    // pending forever, which is a hang rather than a cancel.
    if (_uiDialogResolve) { uiDialogResolve(false); }

    g('uid-title').textContent = o.title || 'Confirm';
    g('uid-body').innerHTML    = o.body || '';

    const pre = g('uid-pre');
    if (o.pre) { pre.textContent = o.pre; pre.classList.remove('hidden'); }
    else       { pre.textContent = '';    pre.classList.add('hidden'); }

    const ok = g('uid-ok');
    ok.textContent = o.ok || 'OK';
    ok.className   = 'btn btn-sm ' + (o.danger ? 'btn-danger' : 'btn-primary');

    const cancel = g('uid-cancel');
    if (o.cancel === null) { cancel.classList.add('hidden'); }
    else { cancel.classList.remove('hidden'); cancel.textContent = o.cancel || 'Cancel'; }

    _uiDialogResolve = resolve;
    openModal('ui-dialog');
    ok.focus();
  });
}

/** Show something and wait for acknowledgement. Replaces alert(). */
function uiAlert(o) {
  return uiConfirm({ title: o.title, body: o.body || '', pre: o.pre,
                     ok: o.ok || 'Close', cancel: null });
}

// ── Dashboard ─────────────────────────────────────────────────────────────────
async function checkForUpdates(forceLive = false) {
  if (Demo.active) {
    showUpdateButton({ update_available: true, latest_version: '3.11.0' });
    return;
  }
  try {
    const res = forceLive
      ? await API.updateCheck()
      : await API.updateStatus();
    if (!res?.success) return;
    const d = res.data;
    const banner  = document.getElementById('update-banner');
    const dot     = document.getElementById('sidebar-update-dot');
    const newVer  = document.getElementById('update-new-version');
    const curVer  = document.getElementById('update-cur-version');
    const relLink = document.getElementById('update-release-link');

    showUpdateButton(d);

    if (d.update_available) {
      if (banner)  { banner.style.display  = 'flex'; }
      if (dot)     { dot.style.display     = 'block'; }
      if (newVer)  newVer.textContent  = 'v' + d.latest_version;
      if (curVer)  curVer.textContent  = 'v' + d.current_version;
      // A link with no destination is worse than no link: it looks like a
      // feature and does nothing. The href defaults to "#" in the markup, so
      // without this the button sat there dead whenever the manifest carried
      // no notes url.
      if (relLink) {
        if (d.release_url) {
          relLink.href = d.release_url;
          relLink.style.display = '';
        } else {
          relLink.removeAttribute('href');
          relLink.style.display = 'none';
        }
      }
    } else {
      if (banner)  banner.style.display  = 'none';
      if (dot)     dot.style.display     = 'none';
    }

    // An unreachable release channel is NOT "up to date". Without this the
    // dashboard shows a clean dot on a server that has not been able to ask
    // about updates for weeks -- which is the state an unpatched install sits
    // in, looking healthy the whole time.
    const chk = g('dash-update-error');
    if (chk) {
      chk.style.display = d.check_error ? 'block' : 'none';
      chk.textContent   = d.check_error || '';
    }
  } catch (_) {}
}

// ── Updating ────────────────────────────────────────────────────────────────
//
// This used to be a toast telling the operator to SSH in and run update.sh,
// while POST update/run -- which starts exactly that script, detached, with
// locking -- already existed in the API and was called by nothing. So the
// product shipped a working one-click updater that no button reached.
//
// It is started DETACHED on the server side: the update rsyncs over the PHP
// serving the request, so a synchronous call is killed partway through and
// leaves a half-applied install with nothing to report it. That means the
// response here says "started", not "finished", and the progress comes from
// polling a state file update.sh writes outside the install directory.

let updatePoll = null;

async function runUpdate() {
  const st = await API.updateAuto();
  const d  = (st && st.data) || {};

  if (d.can_launch === false) {
    // shell_exec is disabled -- possibly by this product's own PHP hardening.
    // Say so and give the command, rather than reporting a launch that cannot
    // have happened.
    toast('This server\'s PHP cannot start background processes. Run: '
        + 'bash /usr/local/serverscrub/update.sh --yes', 'warning', 12000);
    return;
  }

  const to = d.latest_version ? 'v' + d.latest_version : 'the latest version';
  if (!confirm('Update ServerScrub to ' + to + ' now?\n\n'
             + 'The dashboard and API restart during the update. Scans and the '
             + 'real-time monitor are stopped and started again. If the new '
             + 'version fails to answer, the updater rolls back by itself.')) {
    return;
  }

  const r = await API.updateRun();
  if (!r || r.success === false) {
    toast((r && r.error) || 'Could not start the update', 'error', 8000);
    return;
  }
  toast('Update started. This page will reconnect when it finishes.', 'info', 8000);
  pollUpdate();
}

// Poll the state file until the run ends.
//
// The API goes away mid-update, so a failed request here is EXPECTED and must
// not be reported as a failed update. Only the state file decides the outcome.
function pollUpdate() {
  if (updatePoll) clearInterval(updatePoll);
  let misses = 0;

  updatePoll = setInterval(async () => {
    let d = null;
    try {
      const r = await API.updateAuto();
      d = (r && r.data) || null;
    } catch (_) { d = null; }

    if (!d) {
      // The services are restarting. Keep waiting; two minutes of silence is
      // the point at which something has actually gone wrong.
      if (++misses > 40) {
        clearInterval(updatePoll); updatePoll = null;
        toast('Lost contact with the API during the update. Check '
            + 'logs/update.log on the server.', 'warning', 12000);
      }
      return;
    }
    misses = 0;

    const run = d.run || {};
    setText('upd-phase', run.phase || '');
    setText('upd-message', run.message || '');

    if (run.running) return;

    clearInterval(updatePoll); updatePoll = null;

    if (run.status === 'success') {
      toast('Updated to v' + (run.to_version || d.current_version)
          + '. Reloading…', 'success', 6000);
      setTimeout(() => location.reload(), 2500);
    } else if (run.status === 'rolled_back') {
      toast('The update failed and was rolled back to v'
          + (run.from_version || '?') + '. Nothing was lost. See '
          + 'logs/update.log.', 'warning', 15000);
      loadUpdateSettings();
    } else if (run.status === 'failed' || run.status === 'stalled') {
      toast('Update ' + run.status + ': ' + (run.message || 'see logs/update.log'),
            'error', 15000);
      loadUpdateSettings();
    }
  }, 3000);
}

// ── Automatic updates ───────────────────────────────────────────────────────

async function loadUpdateSettings() {
  const r = await API.updateAuto();
  const d = (r && r.data) || {};

  const on = g('au-enabled');
  if (on) on.checked = !!d.auto_enabled;
  const maj = g('au-major');
  if (maj) maj.checked = !!d.auto_major;
  const t = g('au-time');
  if (t) t.value = d.auto_time || '04:30';

  setText('au-current', d.current_version ? 'v' + d.current_version : '—');
  setText('au-latest',  d.latest_version  ? 'v' + d.latest_version  : '—');
  setText('au-checked', d.checked_at
      ? new Date(d.checked_at * 1000).toLocaleString()
      : 'never');
  // The reason it will or will not act, verbatim from the server. A panel that
  // says "automatic updates: on" while something is quietly blocking every
  // attempt is the failure this line exists to prevent.
  setText('au-next', d.next_action || '');

  setText('au-last-ok', d.last_ok
      ? new Date(d.last_ok * 1000).toLocaleString() : 'never');

  const warn = g('au-paused');
  if (warn) {
    warn.style.display = d.paused ? 'flex' : 'none';
    setText('au-paused-text', d.paused
      ? d.failures + ' consecutive failures — automatic updates are paused. '
        + 'Read logs/update.log, then resume.'
      : '');
  }

  const err = g('au-error');
  if (err) {
    err.style.display = d.check_error ? 'block' : 'none';
    setText('au-error-text', d.check_error || '');
  }
}

async function saveUpdateSettings() {
  const r = await API.updateSetAuto({
    auto_update:       g('au-enabled') ? g('au-enabled').checked : true,
    auto_update_major: g('au-major')   ? g('au-major').checked   : false,
    autoupdate_time:   g('au-time')    ? g('au-time').value      : '04:30',
  });
  if (r && r.success) {
    toast('Saved', 'success');
    await loadUpdateSettings();
  } else {
    toast((r && r.error) || 'Could not save', 'error');
  }
}

async function resumeAutoUpdates() {
  const r = await API.updateClearFails();
  if (r && r.success) {
    toast('Automatic updates resumed', 'success');
    await loadUpdateSettings();
  } else {
    toast((r && r.error) || 'Could not resume', 'error');
  }
}

/* ══ THE TOPBAR STATUS PILL ═══════════════════════════════════════════════════
 *
 * It was static markup. `<div class="status-pill" id="top-status">` with a
 * green dot and the word "Protected", on EVERY page, and `grep top-status
 * app.js` returned nothing at all -- no code had ever updated it. Observed in
 * a browser: a fresh install said "Protected" above the scanner card's own
 * grey "Not yet scanned", and an API answering 500 said "Protected" above the
 * card's own "API unreachable".
 *
 * Same class as MODE = 'On', action = 'block' on 148,551 events, Coverage
 * 98.7% and "944 Java Attack / Disabled" -- all four of which were removed.
 * This one survived every pass because it lived in the HTML rather than in the
 * JS, so reading app.js could never surface it.
 *
 * It is driven from the SAME figures as the scanner card, and it has the same
 * four states, because two badges on one screen disagreeing is how the
 * original defect was finally noticed:
 *
 *   down    the API did not answer. Nothing is being reported, and the pill
 *           says so rather than keeping the last good answer on screen.
 *   unknown the threat count could not be read from the response.
 *   never   nothing has been scanned yet. Zero open threats across zero scans
 *           is not a clean bill of health.
 *   threat  open threats, with the count.
 *   clean   a scan ran and nothing is open. The only green state, and the only
 *           one that pulses.
 */
function setTopStatus(state, text, title) {
  const pill = document.getElementById('top-status');
  if (!pill) { return; }
  pill.className = 'status-pill sp-' + state;
  pill.title = title || '';
  const span = document.getElementById('top-status-text');
  if (span) { span.textContent = text; }
}

/**
 * The pill's state for one scanner-stats payload.
 *
 * Deliberately the same two inputs the card uses -- the open-threat count and
 * whether any scan has ever finished -- read the same way: a count is a number
 * or it is unknown, and `|| 0` is what made undefined, a failed fetch and a
 * real zero indistinguishable.
 */
function topStatusFor(sc) {
  const threats = Number.isFinite(sc?.active) ? sc.active : null;
  if (threats === null) {
    return ['unknown', 'Status unknown',
            'The open-threat count could not be read from the server.'];
  }
  if (!sc?.last_scan?.finished_at) {
    return ['never', 'Not yet scanned',
            'Nothing has been scanned on this server yet, so there is nothing '
            + 'to report either way.'];
  }
  if (threats > 0) {
    return ['threat', fmtNum(threats) + ' threat' + (threats > 1 ? 's' : '') + ' open',
            'Open threats across every scan. Scanner > Threats lists them.'];
  }
  return ['clean', 'No open threats', 'The last scan finished and nothing is open.'];
}

/** Apply the pill from a payload the caller already has. No extra request. */
function applyTopStatus(sc) {
  const [state, text, title] = topStatusFor(sc);
  setTopStatus(state, text, title);
}

/**
 * Refresh the pill on a page that does not load dashboard stats.
 *
 * The pill is in the topbar, so it is on every page, while the figures behind
 * it arrive only when the dashboard loads. Without this it would hold the last
 * answer -- or "Checking…" for ever on a panel opened straight onto the
 * firewall page.
 *
 * Throttled to once every 15 seconds: scanner/stats is four indexed counts and
 * one row, but it has no business firing on every click of the nav bar. A GET
 * does not raise the busy overlay, so the refresh is invisible unless it
 * changes something.
 */
let _topStatusAt = 0;
async function refreshTopStatus(force) {
  const now = Date.now();
  if (!force && now - _topStatusAt < 15000) { return; }
  _topStatusAt = now;

  if (Demo.active) { applyTopStatus(Demo.mockDashStats()?.scanner); return; }

  const r = await API.scanStats();
  if (!r?.success) {
    setTopStatus('down', 'API unreachable',
                 (r && (r.detail || r.error)) || 'The ServerScrub API did not answer.');
    return;
  }
  applyTopStatus(r.data);
}

async function refreshDashboard() {
  checkForUpdates();   // non-blocking — uses cached result

  // The Real-Time Monitor widget on this page was only ever filled in by
  // toggleMonitor(), so on a fresh dashboard it kept whatever the markup
  // shipped with -- a green "Active" badge -- and the module-level
  // monitorRunning stayed false. The button reads "Stop" from the HTML while
  // the code believes nothing is running, so the first click calls START.
  // Reported as "I cannot turn it off": it was doing the opposite.
  loadMonitorStats();
  const data = Demo.active
    ? Demo.mockDashStats()
    : await API.dashStats();

  // A failed load must never leave the page asserting a security posture. The
  // markup ships with "Protected" pre-rendered, so returning silently here left
  // a green tick and an empty dashboard on a server whose API was answering 501
  // to every request — the single most misleading thing this product could do.
  if (!data?.success) {
    const icon   = document.getElementById('dash-scan-icon');
    const status = document.getElementById('dash-scan-status');
    const badge  = document.getElementById('dash-scan-badge');
    const meta   = document.getElementById('dash-scan-meta');
    const info   = document.getElementById('dash-server-info');

    if (icon)   icon.textContent = '⛔';
    if (status) { status.textContent = 'Status unknown'; status.style.color = 'var(--red)'; }
    if (badge)  { badge.className = 'badge badge-red'; badge.textContent = 'API unreachable'; }
    // The topbar pill too, or the page carries a green "Protected" beside its
    // own "API unreachable" -- which is exactly what it did.
    setTopStatus('down', 'API unreachable',
                 (data && (data.detail || data.error))
                 || 'The ServerScrub API did not answer.');
    // Prefer the server's detail over the generic line: pointing the user at a
    // log file they then have to go and read is a worse answer than the error.
    if (meta)   meta.textContent = (data && (data.detail || data.error))
                                   || 'Could not reach the ServerScrub API.';
    if (info)   info.textContent = 'Could not reach the API — protection status cannot be confirmed.';

    ['stat-files','stat-threats','stat-fw','stat-waf'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.textContent = '—';
    });
    return;
  }

  // Server info
  const s = data.server;
  document.getElementById('dash-server-info').textContent =
    `${s?.hostname || 'server'} · PHP ${s?.php_version || '?'} · Load: ${(s?.load?.[0] || 0).toFixed(2)}`;

  // Stat cards
  const sc = data.scanner;
  const fw = data.firewall;
  const waf = data.waf;

  document.getElementById('stat-files').textContent    = fmtNum(sc?.files_scanned || 0);
  document.getElementById('stat-threats').textContent  = fmtNum(sc?.total_threats || 0);
  document.getElementById('stat-fw').textContent       = fmtNum(fw?.blocked_today || 0);
  document.getElementById('stat-waf').textContent      = fmtNum(waf?.events_today || 0);

  document.getElementById('stat-files-sub').textContent   = 'Total scanned';
  document.getElementById('stat-threats-sub').textContent = `${sc?.active || 0} active`;
  document.getElementById('stat-fw-sub').textContent      = `${fmtNum(fw?.blocked_ips || 0)} blocked IPs`;
  document.getElementById('stat-waf-sub').textContent     = 'Today';

  // Update sidebar badges
  const sbT = document.getElementById('sb-threats');
  if (sbT) { sbT.textContent = sc?.active || 0; sbT.style.display = sc?.active ? '' : 'none'; }
  const sbE = document.getElementById('sb-events');
  if (sbE) sbE.textContent = data.events?.filter(e => !e.resolved).length || 0;

  /* ── SCANNER STATUS CARD ────────────────────────────────────────────────
   *
   * This card showed, at the same moment, on the same card:
   *
   *     ⚠️ 1 Active Threat
   *     Last scan: 12s ago · [zero] new threats
   *     1,339 Scanned   1,339 Clean   0 Quarantined   0 Deleted
   *
   * The count beside "Last scan" was a hardcoded zero in this file, while
   * `lastJob.threats_found` was already being read at four other call sites.
   * `1,339 Clean` was the file count minus two ALL-TIME threat counts, so a
   * file that is open as a threat right now was counted as clean. `0 Deleted`
   * was a literal too, and the coverage percentage was a constant — ninety
   * eight point seven, chosen by `total > 0 ? <constant> : 0` — a figure no
   * part of this product has ever measured.
   *
   * The two numbers above are deliberately spelled out rather than quoted:
   * tests/test_dashboard_scan_card.php asserts that neither literal appears
   * anywhere in this function, comments included, because a commented-out
   * constant is one uncomment away from being on screen again.
   *
   * The two headline figures do measure different things, and that is not the
   * fault: "Active Threats" is what is open NOW, across every scan;
   * `threats_found` is what the LAST scan found. Both can be true together, so
   * each now says which it is, and neither is a constant.
   */
  const lastJob = sc?.last_scan;
  const scanIcon   = document.getElementById('dash-scan-icon');
  const scanStatus = document.getElementById('dash-scan-status');
  const scanMeta   = document.getElementById('dash-scan-meta');
  const scanBadge  = document.getElementById('dash-scan-badge');

  // `sc?.active || 0` treated undefined, a failed fetch and a genuine zero as
  // the same thing and painted all three green. A dashboard that could not
  // read the threat count must not look like a clean bill of health.
  const threats = Number.isFinite(sc?.active) ? sc.active : null;

  if (threats === null) {
    scanIcon.textContent = '❔';
    scanStatus.textContent = 'Unknown';
    scanStatus.style.color = 'var(--txt2)';
    scanBadge.className = 'badge badge-gray';
    scanBadge.textContent = 'No data';
    scanStatus.title = 'The threat count could not be read from the server.';
  } else if (threats > 0) {
    scanIcon.textContent = '⚠️';
    scanStatus.textContent = `${fmtNum(threats)} Active Threat${threats > 1 ? 's' : ''}`;
    scanStatus.style.color = 'var(--red)';
    scanBadge.className = 'badge badge-red';
    scanBadge.textContent = 'Threats Found';
    scanStatus.title = 'Open threats across every scan, not just the last one.';
  } else if (!lastJob?.finished_at) {
    /* ZERO OPEN THREATS ACROSS ZERO SCANS IS NOT A CLEAN BILL OF HEALTH.
     *
     * This branch used to be the green tick, so a freshly installed server
     * rendered "✅ Protected" directly above its own "Last scan: never" —
     * "never looked" painted identically to "looked and found nothing", and
     * the tick is what an operator reads, not the grey line under it. It is
     * also the first thing every new customer sees.
     *
     * The comment on the threats === null branch above states the principle;
     * this is the same case, one step earlier. */
    scanIcon.textContent = '🔍';
    scanStatus.textContent = 'Not yet scanned';
    scanStatus.style.color = 'var(--txt2)';
    scanBadge.className = 'badge badge-gray';
    scanBadge.textContent = 'No scan yet';
    scanStatus.title = 'Nothing has been scanned on this server yet, so there is '
                     + 'nothing to report either way. Run a scan.';
  } else {
    scanIcon.textContent = '✅';
    scanStatus.textContent = 'Protected';
    scanStatus.style.color = 'var(--green)';
    scanBadge.className = 'badge badge-green';
    scanBadge.textContent = 'Protected';
    // Green is earned by a scan that ran and found nothing, and by nothing else.
    scanStatus.title = 'No open threats, as of the last scan.';
  }

  // One source for both badges: the card and the pill cannot disagree if they
  // are computed from the same two figures by the same code.
  applyTopStatus(sc);

  const ls = sc?.last_scan_stats || null;
  if (!lastJob?.finished_at) {
    scanMeta.textContent = 'Last scan: never';
  } else {
    const found = Number.isFinite(ls?.threats_found) ? ls.threats_found
                : (Number.isFinite(lastJob.threats_found) ? lastJob.threats_found : null);
    scanMeta.textContent = `Last scan: ${reltime(lastJob.finished_at)} · `
      + (found === null ? '— found by that scan'
                        : `${fmtNum(found)} found by that scan`);
  }

  /* Coverage is files examined against files that exist, and nothing in this
   * product counts the second number — so there is no percentage to show. It
   * is left blank rather than filled in, and the bar stays empty rather than
   * drawing the reassuring constant it used to. */
  const covBar = document.getElementById('dash-coverage-bar');
  const covPct = document.getElementById('dash-coverage-pct');
  if (covBar) { covBar.style.width = '0%'; }
  if (covPct) {
    covPct.textContent = '—';
    covPct.title = 'Not measured: the product counts the files it examined, '
                 + 'not how many exist to examine.';
  }

  /* All four figures are from the LAST SCAN now, which is what the words next
   * to them say. "Clean" is files it examined with no finding; quarantined and
   * deleted are that scan's own findings by their current state. Mixing one
   * scan's file count with all-time threat counts is what produced
   * "1,339 Clean" beside an open threat. */
  const dash = (el, v) => {
    const node = document.getElementById(el);
    if (node) { node.textContent = Number.isFinite(v) ? fmtNum(v) : '—'; }
  };
  const total = ls ? ls.files_scanned : (Number.isFinite(sc?.files_scanned) ? sc.files_scanned : null);
  dash('fs-scanned', total);
  dash('fs-clean',   ls ? ls.clean : null);
  dash('fs-quar',    ls ? ls.quarantined : null);
  dash('fs-del',     ls ? ls.deleted : null);

  // Threat breakdown
  const byType = sc?.by_type || [];
  Charts.threatBars(document.getElementById('dash-threat-breakdown'), byType);

  // Kept so the alerts panel can be built from what is already known rather
  // than a second round of requests.
  State.lastDash = data;
  loadOverview();

  // Brute force counts beside the chart that has always drawn the series.
  const bf = data.bruteforce;
  if (bf) {
    setText('dash-bf-24h',     fmtNum(bf.attempts_24h || 0));
    setText('dash-bf-blocked', fmtNum(bf.blocked      || 0));
  }

  // Timeline chart
  if (data.timeline?.length) {
    const dates = data.timeline.map(d => d.date);
    const svgEl = document.getElementById('timeline-chart');
    if (svgEl) {
      Charts.timeline(svgEl, dates, [
        { values: data.timeline.map(d => d.waf_blocks),  color: '#3b82f6', label: 'WAF Blocks' },
        { values: data.timeline.map(d => d.brute_force), color: '#f59e0b', label: 'Brute Force' },
        { values: data.timeline.map(d => d.malware),     color: '#ef4444', label: 'Malware' },
      ]);
    }
  }

  // Events table
  renderEventsTable(data.events || [], 'dash-events-body');
  const unresolved = (data.events || []).filter(e => !e.resolved).length;
  document.getElementById('dash-events-badge').textContent = `${unresolved} unresolved`;

  // Sparklines (fake trend data for now)
  Charts.sparkline(document.getElementById('spark-files'),   [45,52,48,61,58,64,70,68,72,80,76,84], '#3b82f6');
  Charts.sparkline(document.getElementById('spark-threats'), [2,5,3,8,4,12,7,15,9,11,6,8],          '#ef4444');
  Charts.sparkline(document.getElementById('spark-fw'),      [30,45,38,55,42,60,52,48,65,58,72,61], '#f59e0b');
  Charts.sparkline(document.getElementById('spark-waf'),     [92,94,91,95,93,97,95,98,96,99,98,99], '#22c55e');
}

function renderEventsTable(events, tbodyId) {
  const tbody = document.getElementById(tbodyId);
  if (!tbody) return;

  // The dashboard shows a trimmed version of this table with no checkbox and
  // no Description; only the full Security Events page has them.
  const full = tbodyId === 'events-body';
  const cols = full ? 8 : 6;

  if (!events.length) {
    tbody.innerHTML = `<tr><td colspan="${cols}" style="text-align:center;color:var(--txt3);padding:20px">No events found</td></tr>`;
    if (full) updateEventBulkBar();
    return;
  }

  // Every one of these fields comes from a request someone else made -- a
  // request path, a user agent, an attacker-chosen target. Interpolating them
  // raw put an attacker's markup into the page of the operator reviewing their
  // attack, which is about the worst place for it in a security product.
  tbody.innerHTML = events.map(e => `
    <tr>
      ${full ? `<td><input type="checkbox" class="event-check" value="${Number(e.id) || 0}"
                     onchange="updateEventBulkBar()" ${e.resolved ? 'disabled' : ''}></td>` : ''}
      <td>${sevBadge(e.severity)}</td>
      <td class="primary">${esc(e.type)}</td>
      <td class="mono">${esc(e.source_ip) || '—'}</td>
      <td class="mono">${esc(e.target) || '—'}</td>
      ${full ? `<td class="dim" style="max-width:320px;overflow:hidden;text-overflow:ellipsis">${esc(e.description)}</td>` : ''}
      <td class="dim">${reltime(e.timestamp)}</td>
      <td>
        ${e.resolved
          ? '<span class="badge badge-gray">Resolved</span>'
          : `<button class="btn btn-ghost btn-xs" onclick="resolveEvent(${Number(e.id) || 0})">Resolve</button>`
        }
      </td>
    </tr>`).join('');

  if (full) updateEventBulkBar();
}

// ── Bulk resolve ─────────────────────────────────────────────────────────────
function selectedEventIds() {
  return Array.from(document.querySelectorAll('.event-check:checked'))
              .map(c => parseInt(c.value, 10))
              .filter(n => n > 0);
}

function toggleAllEvents(master) {
  // Resolved rows are disabled, so this selects every unresolved event shown.
  document.querySelectorAll('.event-check:not(:disabled)')
          .forEach(c => { c.checked = master.checked; });
  updateEventBulkBar();
}

function updateEventBulkBar() {
  const ids   = selectedEventIds();
  const count = document.getElementById('event-bulk-count');
  if (count) {
    count.textContent = ids.length + ' selected';
    count.style.color = ids.length ? 'var(--primary)' : 'var(--txt2)';
  }
  const btn = document.getElementById('event-bulk-resolve');
  if (btn) btn.disabled = ids.length === 0;

  const master = document.getElementById('event-check-all');
  if (master) {
    const all = document.querySelectorAll('.event-check:not(:disabled)').length;
    master.checked       = all > 0 && ids.length === all;
    master.indeterminate = ids.length > 0 && ids.length < all;
  }
}

async function bulkResolveEvents() {
  const ids = selectedEventIds();
  if (!ids.length) { toast('Select one or more events first', 'error'); return; }

  const btn = document.getElementById('event-bulk-resolve');
  if (btn) { btn.disabled = true; btn.textContent = 'Resolving…'; }

  const res = Demo.active ? { success: true, resolved: ids.length }
                          : await API.post('events/resolve-bulk', { ids });

  if (btn) { btn.textContent = '✓ Resolve selected'; }

  if (res?.success) {
    toast(`Resolved ${res.resolved ?? ids.length} event(s)`, 'success');
    await loadEvents();
    refreshDashboard();
  } else {
    toast(res?.error || 'Could not resolve the selected events', 'error');
    if (btn) btn.disabled = false;
  }
}

async function resolveAllEvents() {
  const res = Demo.active ? { success: true, resolved: 0 }
                          : await API.post('events/resolve-all', {});
  if (res?.success) {
    toast(`Resolved ${res.resolved ?? 0} event(s)`, 'success');
    await loadEvents();
    refreshDashboard();
  } else {
    toast(res?.error || 'Could not resolve events', 'error');
  }
}

// ── Scanner ───────────────────────────────────────────────────────────────────
async function startScan() {
  openPage('scanner');
  const type = document.getElementById('scan-type-sel')?.value || 'quick';

  // A custom scan names accounts. Refusing to start with none selected is
  // better than quietly scanning everything, which is what a path default
  // would do.
  let accounts = [];
  if (type === 'custom') {
    accounts = scanAccountsSelected();
    // Pressing Start Scan with Custom chosen and nothing ticked reopens the
    // dialog rather than failing: the operator plainly meant to pick.
    if (!accounts.length) {
      openScanAccounts();
      return;
    }
  }

  const res = Demo.active
    ? { success: true, job_id: 999 }
    : await API.startScan('/home', type, accounts);

  if (!res?.success) {
    toast(res?.error || 'Failed to start scan', 'error');
    return;
  }

  State.scanJobId = res.job_id;
  document.getElementById('scan-progress-card').style.display = '';
  setScanButton(true);
  // And into the log immediately, as 'running'. The log is the answer to
  // "what is this server doing"; a scan missing from it for its whole
  // duration is the one time that answer matters most.
  loadScanJobs();

  // Name the target straight away rather than waiting for the first poll two
  // seconds later: the moment an operator most wants to know what they just
  // launched is the moment they launched it. The poll then replaces this with
  // the server's own description of the job.
  const tw = g('scan-live-target-wrap');
  const te = g('scan-live-target');
  if (tw && te) {
    // Paths, matching what the server reports two seconds later. The picker
    // already holds each account's home directory, so the label does not have
    // to say "alice" now and "/home/alice" the moment the first poll lands.
    const homes = (_scanAccounts || [])
      .filter(a => accounts.includes(a.user))
      .map(a => a.home);
    const label = type === 'custom'
      ? (homes.length <= 3
          ? homes.join(', ')
          : homes.slice(0, 3).join(', ') + ' and ' + (homes.length - 3) + ' more')
      : (type === 'quick' ? 'web roots' : 'the whole server');
    te.textContent = label;
    te.title = homes.join(', ');
    tw.style.display = '';
  }
  const txt0 = g('scan-progress-text');
  if (txt0) txt0.textContent = 'Scanning…';
  State._scanStallTicks = 0;

  if (Demo.active) {
    simulateDemoScan();
    return;
  }

  followScan(State.scanJobId);
}

// Follow a running scan to completion, updating the progress card.
function followScan(jobId) {
  State.scanJobId = jobId;
  if (State.scanInterval) clearInterval(State.scanInterval);
  State.scanInterval = setInterval(async () => {
    const st = await API.scanStatus(State.scanJobId);
    if (!st?.success) return;
    const job = st.data?.job;
    if (!job) return;

    // There is no honest percentage to show. A scan walks the filesystem
    // without counting it first, so the total is unknown until the scan ends —
    // and the previous code filled that gap with Math.random(), which is why a
    // scan that had examined ZERO files displayed "51%". Fabricating progress
    // in a security product is worse than admitting the total is unknown.
    //
    // So: an indeterminate bar while running, and real counters beside it. The
    // file count IS known and IS truthful, which makes it the useful signal.
    const bar  = document.getElementById('scan-progress-bar');
    const pctEl = document.getElementById('scan-progress-pct');
    const done = !['running', 'pending', 'queued', 'cancelling'].includes(job.status);

    if (done) {
      bar.classList.remove('indeterminate');
      bar.style.width = '100%';
      pctEl.textContent = '100%';
    } else {
      // Width is set by the animation, not by a made-up number.
      bar.classList.add('indeterminate');
      bar.style.width = '';
      pctEl.textContent = fmtNum(job.files_scanned || 0) + ' files';
    }

    document.getElementById('scan-live-files').textContent = fmtNum(job.files_scanned || 0);
    document.getElementById('scan-live-threats').textContent = job.threats_found || 0;
    document.getElementById('scan-live-status').textContent = job.status;

    // What this scan is actually working on. A custom scan of three accounts
    // used to look identical to a full scan of the whole server: the job row
    // has always carried the path, and the card simply never showed it.
    const tgt  = st.data?.target;
    const wrap = g('scan-live-target-wrap');
    const tEl  = g('scan-live-target');
    if (wrap && tEl && tgt?.label) {
      tEl.textContent = tgt.label;
      // The full list on hover, since the label is abbreviated past three.
      tEl.title = (tgt.paths || []).join('\n');
      wrap.style.display = '';
    }

    // A running job whose file count never moves is stuck, not working. Say so
    // rather than animating a bar forever: the scan runs detached, so the UI
    // cannot see it die.
    if (!done) {
      if (State._lastScanFiles === (job.files_scanned || 0)) {
        State._scanStallTicks = (State._scanStallTicks || 0) + 1;
      } else {
        State._scanStallTicks = 0;
      }
      State._lastScanFiles = job.files_scanned || 0;

      // The warning has to come back down again.
      //
      // This was set once and never cleared, so a scan that paused briefly --
      // loading the ClamAV signature database, or working through one large
      // file -- displayed "the scan process may not be running" for the rest
      // of its life, while the counter beside it climbed past five thousand
      // files. A warning that contradicts the number next to it trains an
      // operator to ignore both.
      //
      // The log file is named exactly, too: logs/scanner.log has never
      // existed. Each worker writes to logs/scan_<job>.log.
      const txt = document.getElementById('scan-progress-text');
      if (txt) {
        if (State._scanStallTicks >= 15) {               // ~30s of no movement
          txt.textContent = 'No new files scanned for 30s \u2014 the scan process may '
                          + 'have stopped. Check ' + (st.data?.log || 'the scan log') + '.';
        } else {
          txt.textContent = 'Scanning\u2026';
        }
      }
    }

    // ANY ending is an ending.
    //
    // This checked only 'done' and 'error'. The backend also writes
    // 'cancelled', 'skipped' and 'interrupted' -- the last when a worker dies
    // and reapStaleJobs() closes the row out. None of those cleared the
    // interval, so the UI polled a finished job for ever and never showed it
    // complete. Listing the ACTIVE states instead means a status added later
    // is treated as finished rather than looping silently.
    const ACTIVE = ['running', 'pending', 'queued', 'cancelling'];
    if (!ACTIVE.includes(job.status)) {
      clearInterval(State.scanInterval);
      State.scanInterval = null;
      State.scanInterval = null;
      State.scanJobId = null;
      setScanButton(false);
      document.getElementById('scan-spinner').textContent = job.status === 'done' ? '✅' : '❌';
      document.getElementById('scan-progress-text').textContent =
        `Scan complete — ${job.threats_found || 0} threats found`;
      loadThreats();
      // The scan that just ended is a row in the log now. Leaving it out until
      // the operator reloads the page is how a log stops being a log.
      loadScanJobs();
      toast(`Scan complete. ${job.threats_found || 0} threats found.`, job.threats_found ? 'error' : 'success');
    }
  }, 2000);
}

function simulateDemoScan() {
  let pct = 0;
  const interval = setInterval(() => {
    pct = Math.min(100, pct + Math.floor(Math.random() * 8) + 2);
    document.getElementById('scan-progress-bar').style.width = `${pct}%`;
    document.getElementById('scan-progress-pct').textContent = `${pct}%`;
    document.getElementById('scan-live-files').textContent = fmtNum(Math.floor(pct / 100 * 1284930));
    document.getElementById('scan-live-threats').textContent = pct > 60 ? 5 : 0;
    document.getElementById('scan-live-status').textContent = pct < 100 ? 'Running…' : 'Done';
    if (pct >= 100) {
      clearInterval(interval);
      setScanButton(false);
      document.getElementById('scan-spinner').textContent = '✅';
      document.getElementById('scan-progress-text').textContent = 'Scan complete — 5 threats found';
      loadThreats();
      toast('Scan complete. 5 threats found.', 'error');
    }
  }, 200);
}

// Stop the scan on the SERVER, not just the progress bar in front of it.
//
// This used to clear the polling interval, hide the card and toast "Scan
// stopped" -- and tell the server nothing at all. The scan carried on at full
// speed with clamscan running flat out, while the UI reported that it had been
// stopped. Reported as "the stop button is not stopping clamscan"; it was not
// stopping anything.
// Adopt a scan that is already running.
//
// Called on every visit to the Scanner page. A scan started by the nightly
// cron, by another admin, or before a reload is now shown with its Stop
// button, instead of the page pretending nothing is happening.
async function adoptRunningScan() {
  if (Demo.active) return;
  let res;
  try { res = await API.scanActive(); } catch (e) { return; }

  // Why the scheduled scan is not running, if it is not. Rendered BEFORE the
  // early return below: the case that matters is the one where there is no job
  // to adopt and the operator is asking why the daily scan has not fired.
  renderScanScheduleNotice(res);

  const job = res?.data;
  if (!job || !job.id) return;
  if (State.scanJobId === job.id && State.scanInterval) return;   // already following

  State.scanJobId = job.id;
  const card = g('scan-progress-card');
  if (card) card.style.display = '';
  setScanButton(true);
  const st = g('scan-live-status');
  if (st) st.textContent = job.status === 'cancelling' ? 'Stopping\u2026' : 'Running';
  followScan(job.id);
}

// Why the scheduled scan is not running, on the page where it is asked.
//
// A scheduled scan that cannot start because one is already running is a
// CORRECT refusal, and the scheduler has always logged it and left the task
// due so it retries in fifteen minutes. On the production server that happened
// every quarter hour for two days behind a scan row whose worker was long
// dead, and the panel said nothing at all: the Scanner page showed a scan
// "running" and the Dashboard showed a schedule that was fine. Two days of
// silent refusals is the part of that incident that made it undiagnosable.
//
// The card is built here rather than in index.html because it exists only when
// there is something to say. Nothing in it is interactive.
function renderScanScheduleNotice(res) {
  const page = g('page-scanner');
  if (!page) return;

  const job     = res?.data;
  const ref     = res?.refusal;
  const paused  = !!res?.paused;
  const rec     = res?.reconcile;
  // Liveness that could not be established is reported as unknown, never as
  // health: the same rule as the rest of the product.
  const unknown = !!(rec && rec.available === false && Number(rec.candidates) > 0);

  const age = s => {
    const n = Number(s) || 0;
    if (n <= 0) return 'an unknown time';
    if (n < 3600) return Math.floor(n / 60) + 'm';
    if (n < 86400) return Math.floor(n / 3600) + 'h ' + Math.floor((n % 3600) / 60) + 'm';
    return Math.floor(n / 86400) + 'd ' + Math.floor((n % 86400) / 3600) + 'h';
  };

  const lines = [];
  if (paused && job && job.id) {
    lines.push('<div><b style="color:var(--amber)">Scan paused for a backup.</b> '
      + 'Job ' + Number(job.id) + ' is waiting for the backup to finish, not stalled — '
      + 'it resumes on its own and is not counted as stuck.</div>');
  }
  if (ref && Number(ref.at) > 0) {
    /* The blocking job is described in the tense the server can defend.
     *
     * This said "(blocked by job 12467, in progress for 2d 9h)" from four
     * stored settings, with the age counting up, for a job the product had
     * already closed out -- and for one that did not exist at all. The age is
     * only sent when the job is genuinely still in progress; when it is not,
     * the card says what became of it instead of implying it is still there. */
    let blocker = '';
    if (Number(ref.job) > 0 && ref.job_live) {
      blocker = ' <span class="dim">(blocked by job ' + Number(ref.job)
              + ', in progress for ' + esc(age(ref.job_age)) + ')</span>';
    } else if (Number(ref.job) > 0) {
      blocker = ' <span class="dim">(job ' + Number(ref.job) + ' is no longer running'
              + (ref.job_status ? ' — it ended as ' + esc(String(ref.job_status)) : '')
              + '; the next scheduled tick will start a scan)</span>';
    }
    lines.push('<div><b style="color:var(--amber)">The scheduled scan did not start.</b> '
      + 'Last refused ' + esc(reltime(Number(ref.at))) + ': ' + esc(String(ref.reason || ''))
      + blocker
      + '</div>');
  }
  if (unknown) {
    lines.push('<div><b style="color:var(--amber)">Scan liveness could not be '
      + 'determined.</b> ' + esc(String(rec.reason || ''))
      + ' — ' + Number(rec.candidates) + ' in-progress job(s) were left exactly as '
      + 'they are rather than guessed at.</div>');
  }

  let el = g('scan-schedule-notice');
  if (!lines.length) {
    if (el && el.parentNode) el.parentNode.removeChild(el);
    return;
  }
  if (!el) {
    el = document.createElement('div');
    el.id = 'scan-schedule-notice';
    el.className = 'card mb-5';
    el.style.borderLeft = '3px solid var(--amber)';
    const card = g('scan-progress-card');
    if (card && card.parentNode === page) page.insertBefore(el, card);
    else page.appendChild(el);
  }
  el.innerHTML = '<div class="card-body" style="font-size:.8rem;display:grid;gap:6px">'
               + lines.join('') + '</div>';
}

// ---- Custom scan: which accounts ------------------------------------------
// "Custom Path" was a free-text directory box, which is not how an operator
// thinks about a shared server: they think in accounts. Choosing Custom opens
// a dialog listing every account with a checkbox.
let _scanAccounts = null;

async function openScanAccounts() {
  openModal('scan-accounts-modal');
  const list = g('scan-accounts-list');
  if (!list) return;

  if (_scanAccounts === null) {
    list.innerHTML = '<div class="dim">Loading accounts\u2026</div>';
    try {
      const res = await API.scanAccounts();
      _scanAccounts = res?.data || [];
    } catch (e) {
      _scanAccounts = [];
    }
  }
  renderScanAccounts();
}

function renderScanAccounts() {
  const list = g('scan-accounts-list');
  if (!list) return;

  const accounts = _scanAccounts || [];
  if (!accounts.length) {
    list.innerHTML = '<div class="dim">No accounts found under the configured scan paths.</div>';
    scanAccountsCount();
    return;
  }

  // Keep what is already ticked across a filter change, or filtering would
  // quietly discard a selection the operator had already made.
  const picked = new Set(scanAccountsSelected());
  const q = (g('scan-accounts-filter')?.value || '').trim().toLowerCase();
  const shown = q ? accounts.filter(a => a.user.toLowerCase().includes(q)) : accounts;

  if (!shown.length) {
    list.innerHTML = '<div class="dim">No account matches that filter.</div>';
    scanAccountsCount();
    return;
  }

  list.innerHTML = shown.map(a => `
    <label style="display:flex;align-items:center;gap:8px;padding:7px 9px;border:1px solid var(--border);border-radius:7px;cursor:pointer">
      <input type="checkbox" class="scan-acct" value="${esc(a.user)}"
             ${picked.has(a.user) ? 'checked' : ''} onchange="scanAccountsCount()">
      <span style="min-width:0">
        <span class="mono" style="display:block;overflow:hidden;text-overflow:ellipsis">${esc(a.user)}</span>
        <span class="dim" style="font-size:.7rem">${a.has_web ? 'has public_html' : 'no web root'}</span>
      </span>
    </label>`).join('');
  scanAccountsCount();
}

function scanAccountsSelected() {
  return Array.from(document.querySelectorAll('.scan-acct:checked')).map(c => c.value);
}

function scanAccountsCount() {
  const n = scanAccountsSelected().length;
  const el = g('scan-accounts-count');
  if (el) el.textContent = n + ' selected';
  const go = g('scan-accounts-go');
  if (go) go.disabled = (n === 0);      // nothing selected is not a scan
}

function scanAccountsAll(on) {
  document.querySelectorAll('.scan-acct').forEach(c => { c.checked = !!on; });
  scanAccountsCount();
}

// Start the scan from inside the dialog, which is where the selection is.
function startScanFromPicker() {
  if (!scanAccountsSelected().length) {
    toast('Select at least one account to scan', 'error');
    return;
  }
  closeModal('scan-accounts-modal');
  startScan();
}

// Choosing Custom opens the dialog; choosing anything else is a plain scan.
function onScanTypeChange() {
  const type = g('scan-type-sel')?.value || 'quick';
  if (type === 'custom') openScanAccounts();
}

// The toolbar button, in whichever of its two states applies.
//
// While a scan runs it IS the stop control. It previously read "Scanning..."
// and was disabled, which left the only way to stop a scan as a ghost button
// at the far right of the progress row -- the least visible element on the
// page, for the one action an operator urgently wants during a scan that is
// loading the server.
//
// Five separate places set this button's label and disabled state by hand,
// which is how it came to disagree with itself. They all call this now.
function setScanButton(running) {
  const btn = g('scan-btn');
  if (!btn) return;
  btn.disabled = false;
  if (running) {
    btn.textContent = '\u25A0 Stop Scan';
    btn.classList.remove('btn-primary');
    btn.classList.add('btn-danger');
    btn.title = 'Stop the scan in progress';
  } else {
    btn.textContent = '\u25B6 Start Scan';
    btn.classList.remove('btn-danger');
    btn.classList.add('btn-primary');
    btn.title = '';
  }
}

// What the toolbar button does depends on what it currently says.
function onScanButton() {
  if (State.scanJobId && State.scanInterval) { stopScan(State.scanJobId); return; }
  startScan();
}

async function stopScan(jobId) {
  const btn = g('scan-stop-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Stopping…'; }

  const res = Demo.active
    ? { success: true, message: 'Scan stopped.' }
    : await API.post('scanner/stop', jobId ? { job_id: jobId } : {});

  if (btn) { btn.disabled = false; btn.textContent = '\u25A0 Stop Scan'; }

  if (!res?.success) {
    // Leave the progress card up on failure: hiding it would imply the scan
    // had stopped, which is the behaviour being fixed.
    toast(res?.error || 'Could not stop the scan', 'error');
    return;
  }

  clearInterval(State.scanInterval);
  State.scanInterval = null;
  State.scanJobId = null;
  setScanButton(false);
  const card = document.getElementById('scan-progress-card');
  if (card) card.style.display = 'none';

  // Say what actually happened. A clamscan the kernel had not reaped yet is
  // worth mentioning rather than glossing over with a flat "stopped".
  let msg = res.message || 'Scan stopped.';
  if (res.stragglers) {
    msg += ' ' + res.stragglers + ' clamscan process(es) are still finishing.';
  }
  toast(msg, res.stragglers ? 'info' : 'success');

  loadThreats();
  refreshDashboard();
}

// The scanner page's "auto-quarantine off" line was hard-coded in the markup
// and only ever corrected by loadSettings(), which runs on the Settings page.
// Open the Scanner page directly and it stated the default regardless of the
// real setting -- so the toggle looked like it did nothing.
async function loadScannerQuarantineState() {
  const el = document.getElementById('scanner-quar-state');
  if (!el) return;

  const res = Demo.active ? { success: true, data: { auto_quarantine: '0' } }
                          : await API.getSettings();
  if (!res?.success) { el.textContent = 'auto-quarantine state unknown'; return; }

  const on = (res.data?.auto_quarantine ?? '0') === '1';
  el.textContent = on ? 'auto-quarantine on' : 'auto-quarantine off';
  el.style.color = on ? 'var(--ok, #22c55e)' : 'var(--txt3)';
  el.title = on
    ? 'Detected files are moved to the quarantine directory automatically.'
    : 'Threats are recorded but files are left in place. Turn this on in Settings.';
}

/* The scan log.
 *
 * There was no scan history on this side at all. The page showed the scan
 * running at this moment and the threats it had found, and nothing about any
 * scan before it -- so "did last night's sweep run, and did it finish?" had no
 * answer short of opening the database. The customer-facing plugin has had a
 * scan log for some time; the administrator of the server did not.
 *
 * requested_by is shown as-is here. On the customer page it is deliberately
 * replaced by a role, because a scan of /home appears in every account's log
 * and the name on it is often somebody else's. Root is the one place the
 * actual name is both safe and useful.
 */
function scanTriggerLabel(by) {
  by = String(by || '');
  if (by === '@schedule') return ['Scheduled scan', 'var(--txt2)'];
  if (by === '@operator') return ['WHM (this interface)', 'var(--txt2)'];
  if (by === '@cli')      return ['Command line', 'var(--txt2)'];
  /* Anything else is an account name: the customer pressed the button in
   * cPanel. Empty means the job predates the column being recorded -- "—" is
   * honest, and guessing "scheduled" would be wrong for every scan an
   * operator ever started by hand. */
  if (by === '')          return ['—', 'var(--txt3)'];
  return [by + ' (cPanel user)', 'var(--txt1)'];
}

/* The Threats count, as a way in rather than a dead number.
 *
 * The scan log said a scan found 3 and stopped there. The threats table is
 * server-wide and ordered by time, so learning WHICH 3 meant reading past
 * every other finding from that night -- the one question the column invites
 * was the one it could not answer.
 *
 * Zero stays plain text. A link that opens an empty dialog is worse than no
 * link: it promises something and then wastes the click.
 */
function threatCountCell(j) {
  const n = Number(j.threats_found || 0);
  if (!n) { return '<span style="color:var(--green)">0</span>'; }
  return '<a href="#" style="color:var(--red);font-weight:600;text-decoration:underline"'
       + ' title="Show the files this scan flagged"'
       + ' onclick="showScanThreats(' + Number(j.id) + ',event);return false">' + n + '</a>';
}

/* What a scan found, in the app.
 *
 * Asked for explicitly as a dialog inside the app rather than a new tab or
 * window: the operator is partway through reading a log, and losing that
 * position to see three filenames is a bad trade.
 */
async function showScanThreats(jobId, ev) {
  if (ev) { ev.preventDefault(); }
  openModal('scan-threats-modal');
  const list = document.getElementById('stm-list');
  const sub  = document.getElementById('stm-sub');
  if (sub)  { sub.textContent = 'Scan #' + jobId; }
  if (list) { list.innerHTML = '<div class="dim" style="padding:14px">Loading…</div>'; }

  const res = Demo.active ? Demo.mockScanThreats(jobId)
                          : await API.get('scanner/threats?job_id=' + encodeURIComponent(jobId));
  const rows = res?.data || [];

  if (!list) { return; }
  if (!rows.length) {
    // Not an error. The rows may have been purged, or the count may predate
    // threats being linked to the scan that found them.
    list.innerHTML = '<div class="dim" style="padding:14px">No stored detail for this scan. '
                   + 'The findings may have been cleared since.</div>';
    return;
  }
  if (sub) { sub.textContent = 'Scan #' + jobId + ' — ' + rows.length + ' finding(s)'; }

  /* What happened to the file is the half of the question that the Threats
   * page does not answer either: "detected" and "detected, quarantined, and
   * here is where the copy went" are very different things to be told. */
  const WHAT = {
    quarantined: ['Quarantined', 'var(--amber)'],
    deleted:     ['Deleted',     'var(--red)'],
    cleaned:     ['Cleaned',     'var(--green)'],
    ignored:     ['Marked not malware', 'var(--txt2)'],
    restored:    ['Restored',    'var(--txt2)'],
    active:      ['Still on disk — no action taken', 'var(--red)'],
  };

  list.innerHTML = rows.map(t => {
    const st = String(t.status || 'active').toLowerCase();
    const [what, colour] = WHAT[st] || [st || 'unknown', 'var(--txt2)'];
    const sev = String(t.severity || '').toLowerCase();
    const sevCol = (sev === 'critical' || sev === 'high') ? 'var(--red)'
                 : (sev === 'medium' ? 'var(--amber)' : 'var(--txt3)');
    return '<div style="border:1px solid var(--bd);border-radius:8px;padding:12px;margin-bottom:10px">'
      // The full path, selectable and wrapped. A truncated path is unusable:
      // the operator's next step is to go and look at the file.
      + '<div class="mono" style="font-size:.8rem;word-break:break-all;margin-bottom:8px">'
      +   esc(t.file_path || '(path not recorded)') + '</div>'
      + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;font-size:.76rem">'
      +   '<div><span class="dim">Detected as</span><br>' + esc(t.threat_name || t.threat_type || 'unknown') + '</div>'
      +   '<div><span class="dim">Severity</span><br><span style="color:' + sevCol + '">'
      +     esc(t.severity || '?') + '</span></div>'
      +   '<div><span class="dim">What happened</span><br><span style="color:' + colour + '">'
      +     esc(what) + '</span></div>'
      +   '<div><span class="dim">Detected</span><br>' + esc(reltime(Number(t.detected_at) || 0)) + '</div>'
      + '</div>'
      // Where the copy went, when there is one. Without it "quarantined" is a
      // claim the operator cannot check.
      + (t.action_taken
          ? '<div class="dim" style="font-size:.74rem;margin-top:8px">Action: '
            + esc(t.action_taken) + '</div>'
          : '')
      + (t.hash
          ? '<div class="dim mono" style="font-size:.7rem;margin-top:4px">sha256 ' + esc(t.hash) + '</div>'
          : '')
      + '</div>';
  }).join('');
}

/* Scanner-log paging.
 *
 * Deliberately the same shape as the WAF events paging above: same sizes,
 * same sessionStorage-backed preference, same reset-to-first-page rules. The
 * scan log used to fetch a fixed newest-50 with no way to see that anything
 * older existed, which is the same defect the WAF table had.
 *
 * 0 means "All", and the API bounds it -- see the jobs route. A reading
 * preference, so sessionStorage, and every access is wrapped because it
 * throws in a private window.
 */
const SCANLOG_PAGE_KEY = 'sg.scanlog.pagesize';
const SCANLOG_PAGE_SIZES = [50, 100, 200, 500, 0];
const ScanLogPage = { offset: 0, total: 0 };

function scanLogPageSize() {
  let n = NaN;
  try { n = parseInt(sessionStorage.getItem(SCANLOG_PAGE_KEY) || '', 10); }
  catch (e) { n = NaN; }
  // Explicit isNaN rather than `|| 0`: 0 IS a valid size here ("All"), and a
  // falsy-check would silently turn a stored "All" back into 50.
  return SCANLOG_PAGE_SIZES.includes(n) ? n : 50;
}

function scanLogSetPageSize(v) {
  const n = SCANLOG_PAGE_SIZES.includes(Number(v)) ? Number(v) : 50;
  try { sessionStorage.setItem(SCANLOG_PAGE_KEY, String(n)); } catch (e) { /* not fatal */ }
  document.querySelectorAll('.scanlog-page-size').forEach(sel => { sel.value = String(n); });
  // Page 3 of 50 is not page 3 of 500, and landing past the end shows an
  // empty table on a server with plenty of history.
  ScanLogPage.offset = 0;
  loadScanJobs();
}

function scanLogPage(dir) {
  const size = scanLogPageSize();
  if (!size) return;                       // "All" is one page; nowhere to go
  ScanLogPage.offset = Math.max(0, ScanLogPage.offset + dir * size);
  loadScanJobs();
}

async function loadScanJobs() {
  const body = document.getElementById('scanlog-body');
  if (!body) return;

  const size = scanLogPageSize();
  document.querySelectorAll('.scanlog-page-size').forEach(sel => {
    sel.value = String(size);
  });

  const res  = Demo.active
    ? Demo.mockScanJobs()
    : await API.get('scanner/jobs?limit=' + size + '&offset=' + ScanLogPage.offset);

  /* The response used to be a bare array and is now {items,total,...}. Both
   * shapes are accepted: a browser holding a cached app.js against a freshly
   * updated backend, or the reverse, must not render an empty log. */
  const d     = res?.data;
  const jobs  = Array.isArray(d) ? d : (d?.items || []);
  const total = Array.isArray(d) ? jobs.length : Number(d?.total || 0);
  const capped = !Array.isArray(d) && !!d?.capped;
  ScanLogPage.total = total;

  const note     = document.getElementById('scanlog-note');
  const pageNote = document.getElementById('scanlog-page-note');
  const prev     = document.getElementById('scanlog-prev');
  const next     = document.getElementById('scanlog-next');

  // Buttons reflect where we are BEFORE the empty check, so a page past the
  // end still offers a way back rather than stranding the operator.
  if (prev) prev.disabled = !size || ScanLogPage.offset <= 0;
  if (next) next.disabled = !size || (ScanLogPage.offset + size) >= total;

  if (!jobs.length) {
    body.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--txt3);padding:20px">'
                   + (total ? 'No scans on this page' : 'No scans have run yet')
                   + '</td></tr>';
    if (note) note.textContent = '';
    if (pageNote) pageNote.textContent = total ? ('0 of ' + total) : '';
    return;
  }

  const first = ScanLogPage.offset + 1;
  const last  = ScanLogPage.offset + jobs.length;
  if (note) note.textContent = total + ' scan(s) recorded';
  if (pageNote) {
    pageNote.textContent = capped
      ? ('showing the newest ' + jobs.length + ' of ' + total
         + ' \u2014 too many to show at once')
      : (first + '\u2013' + last + ' of ' + total);
  }

  const COLOR = { done: 'var(--green)', running: 'var(--amber)',
                  pending: 'var(--amber)', cancelling: 'var(--amber)',
                  error: 'var(--red)', interrupted: 'var(--red)' };

  body.innerHTML = jobs.map(j => {
    const [who, whoColor] = scanTriggerLabel(j.requested_by);
    const started = Number(j.started_at) || 0;
    const ended   = Number(j.finished_at) || 0;
    /* A running scan has no finished_at, so its elapsed time is measured
     * against now -- otherwise the one row anybody is actually watching is
     * the one row with no duration on it. */
    const until = ended > started ? ended
                : (['running', 'pending', 'cancelling'].includes(j.status)
                   ? Math.floor(Date.now() / 1000) : 0);
    const secs  = until > started ? until - started : 0;
    const took  = !secs ? '—'
                : secs < 60 ? secs + 's'
                : secs < 3600 ? Math.floor(secs / 60) + 'm'
                : Math.floor(secs / 3600) + 'h ' + Math.floor((secs % 3600) / 60) + 'm';

    /* A custom scan's path is a comma-separated list of homes and can be
     * hundreds of characters. The column says how many; the full list is the
     * title, for whoever needs it. */
    const path  = String(j.scan_path || '');
    const parts = path ? path.split(',') : [];
    const scope = parts.length > 1 ? parts.length + ' accounts'
                : (path || '—');

    return '<tr>' +
      '<td class="dim">' + esc(reltime(started)) + '</td>' +
      '<td style="color:' + whoColor + '">' + esc(who) + '</td>' +
      '<td>' + esc(j.scan_type || '') + '</td>' +
      '<td class="mono" title="' + esc(path) + '">' + esc(scope) + '</td>' +
      // "cancelled" with nothing behind it is unreadable: our own updater
      // stops every running scan, and that looked identical to an operator
      // stopping one on purpose.
      '<td style="color:' + (COLOR[j.status] || 'var(--txt3)') + '"' +
        (j.stop_reason ? ' title="' + esc(j.stop_reason) + '"' : '') + '>' +
        esc(j.status || '') +
        (j.stop_reason ? ' <span class="dim" style="font-size:.72rem">(' + esc(j.stop_reason) + ')</span>' : '') +
      '</td>' +
      '<td>' + Number(j.files_scanned || 0).toLocaleString() + '</td>' +
      '<td>' + threatCountCell(j) + '</td>' +
      '<td class="dim">' + esc(took) + '</td>' +
      '</tr>';
  }).join('');
}

// Paging for the Detected Threats table.
//
// Deliberately the same sizes, the same control order and the same wording as
// the scan log and the WAF events table. Three tables that page differently
// are three things to learn.
const THREATS_PAGE_SIZES = [50, 100, 200, 500, 0];   // 0 = All
const THREATS_PAGE_KEY   = 'sg_threats_page_size';
const ThreatsPage = { offset: 0, total: 0 };

function threatsPageSize() {
  // 0 is a valid choice, so `parseInt(...) || 50` is wrong: it would turn a
  // saved "All" back into 50 on every load, which reads as the setting not
  // saving.
  let n = NaN;
  try { n = parseInt(sessionStorage.getItem(THREATS_PAGE_KEY) || '', 10); }
  catch (e) { n = NaN; }
  return THREATS_PAGE_SIZES.includes(n) ? n : 50;
}

function threatsSetPageSize(v) {
  const n = parseInt(v, 10);
  if (!THREATS_PAGE_SIZES.includes(n)) { return; }
  try { sessionStorage.setItem(THREATS_PAGE_KEY, String(n)); } catch (e) {}
  // Page 3 of 50 is not page 3 of 500, and the old offset would land past the
  // end of the list.
  ThreatsPage.offset = 0;
  loadThreats();
}

function threatsPage(dir) {
  const size = threatsPageSize();
  if (!size) { return; }            // "All" is one page; there is nowhere to go
  const next = ThreatsPage.offset + (dir * size);
  if (next < 0 || next >= ThreatsPage.total) { return; }
  ThreatsPage.offset = next;
  loadThreats();
}

// Changing the status filter is a new list, so it starts at the first page.
function threatsFilterChanged() {
  ThreatsPage.offset = 0;
  loadThreats();
}

async function loadThreats() {
  loadScannerQuarantineState();
  const filter = document.getElementById('threat-filter')?.value || '';
  const size   = threatsPageSize();
  const res = Demo.active
    ? Demo.mockThreats()
    : await API.threats(filter, size, ThreatsPage.offset);

  const tbody = document.getElementById('threats-body');
  if (!tbody) return;

  const threats = res?.data || [];

  // OUTSTANDING findings, not rows on screen.
  //
  // This was `threats.length`. With the filter on "All" that counts resolved
  // findings too, so clearing all five ai-bolit files left a red "5" sitting
  // beside five rows that each said "Not malware" -- indistinguishable from
  // the action having silently failed.
  //
  // The number comes from the server, which counts status='active' the same
  // way the dashboard and the sidebar do. Deriving it here from the rows we
  // happen to have would be a SECOND definition of "outstanding", and it would
  // be wrong whenever a filter is applied or there are more than 200 findings.
  const outstanding = Number(res?.meta?.active ?? threats.length) || 0;

  // ── Paging footer ───────────────────────────────────────────────────────
  //
  // `total` is how many rows match the CURRENT FILTER, which is not the same
  // number as `active` (outstanding findings, filter-independent). Conflating
  // them is how "last 50" came to read as a total on the scan log.
  ThreatsPage.total = Number(res?.meta?.total ?? threats.length) || 0;
  (function renderThreatsPager() {
    const size  = threatsPageSize();
    const total = ThreatsPage.total;
    const note  = g('threats-page-note');
    const prev  = g('threats-prev');
    const next  = g('threats-next');
    const sel   = document.querySelector('.threats-page-size');
    if (sel && String(sel.value) !== String(size)) { sel.value = String(size); }
    if (note) {
      if (!total) {
        note.textContent = '';
      } else if (!size) {
        note.textContent = res?.meta?.capped
          // Showing a prefix and calling it everything is the one thing "All"
          // must never do.
          ? `Showing the newest ${threats.length} of ${total} — too many to show at once`
          : `Showing all ${total}`;
      } else {
        const from = total ? ThreatsPage.offset + 1 : 0;
        const to   = Math.min(ThreatsPage.offset + size, total);
        note.textContent = `${from}–${to} of ${total}`;
      }
    }
    if (prev) { prev.disabled = !size || ThreatsPage.offset <= 0; }
    if (next) { next.disabled = !size || (ThreatsPage.offset + size) >= total; }
  })();

  const cb = g('threat-count-badge');
  if (cb) {
    cb.textContent = outstanding;
    // Red means "something needs you". Zero outstanding is not an alert, and
    // leaving it red is how a cleared scanner still reads as a compromised one.
    cb.className = outstanding > 0 ? 'badge badge-red' : 'badge badge-gray';
    cb.title = outstanding > 0
      ? outstanding + ' finding(s) still need attention'
      : 'Nothing outstanding. Rows below may include findings already '
      + 'quarantined, deleted or judged not malware.';
  }

  // Keep the sidebar in step, from the same number.
  //
  // The sidebar badge is written by refreshDashboard(), which only runs when
  // the Dashboard page is opened -- so it went stale after EVERY threat
  // action, not just this one: quarantine and delete left it overstated too.
  // Updating it from the response we already have costs no extra request,
  // which matters because loadThreats() is polled while a scan runs.
  const sbT = g('sb-threats');
  if (sbT) {
    sbT.textContent = outstanding;
    sbT.style.display = outstanding > 0 ? '' : 'none';
  }

  // id -> file path, so an action can resolve a path WITHOUT it ever being
  // interpolated into markup. A path can contain quotes, spaces, backslashes
  // and non-ASCII; there is no safe way to put one in an onclick attribute,
  // and the attempt is what broke the exclude button.
  State.threatPaths = {};
  threats.forEach(t => {
    const tid = Number(t.id);
    if (tid) State.threatPaths[tid] = t.file_path || '';
  });

  if (!threats.length) {
    tbody.innerHTML = '<tr><td colspan="10" style="text-align:center;color:var(--txt3);padding:28px">No threats found. Run a scan to check your server.</td></tr>';
    const masterEmpty = document.getElementById('threat-check-all');
    if (masterEmpty) { masterEmpty.checked = false; masterEmpty.indeterminate = false; }
    updateBulkBar();
    return;
  }

  // Every value below is escaped. A file path is attacker-controlled -- naming
  // a file is exactly the kind of thing malware does -- and interpolating it
  // raw into innerHTML made the threats table an XSS sink in the dashboard of
  // a security product. The View button reads such a file deliberately, which
  // makes getting this right more important, not less.
  tbody.innerHTML = threats.map(t => {
    const path  = String(t.file_path || '');
    const short = path.split('/').slice(-2).join('/');
    const id    = parseInt(t.id, 10) || 0;

    return `
    <tr>
      <td style="width:34px">
        <input type="checkbox" class="threat-check" data-id="${id}"
               onchange="updateBulkBar()" aria-label="Select ${esc(short)}">
      </td>
      <td>${sevBadge(t.severity)}</td>
      <td class="mono primary" style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(path)}">
        ${esc(short)}
      </td>
      <td class="mono" style="color:var(--blue);font-size:.75rem">${esc(t.cpanel_user || '—')}</td>
      <td class="mono" style="color:var(--red)">${esc(t.threat_name || '')}</td>
      <td><span class="badge badge-amber">${esc(t.threat_type || '')}</span></td>
      <td class="dim">${fmtBytes(t.size || 0)}</td>
      <td class="dim">${reltime(t.detected_at)}</td>
      <td>${threatStatusBadge(t.status)}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-ghost btn-xs" onclick="viewThreatFile(${id})"
                title="View contents (does not run the file)">👁</button>
        <!-- "Not malware" -- the moment the operator is looking at a finding
             is the only moment they have the context to judge it wrong, so the
             exclusion is one click from here rather than buried in settings.
             Takes the ID, like every other button in this row. It used to
             interpolate the path through JSON.stringify(), which emits DOUBLE
             quotes into a double-quoted attribute: the attribute terminated at
             the first one and the handler was never bound, so the button did
             nothing at all. A path must never be inlined into an attribute. -->
        <button class="btn btn-ghost btn-xs" onclick="markNotMalware(${id})"
                title="Not malware — keep scanning this file, but stop reporting it while its contents are unchanged">🚫</button>
        ${t.status === 'active' ? `
          <button class="btn btn-ghost btn-xs" onclick="quarantineThreat(${id})" title="Quarantine">🔒</button>
          <button class="btn btn-danger btn-xs" onclick="deleteThreat(${id})" title="Delete file">🗑</button>
        ` : ''}
        ${t.status === 'quarantined' ? `
          <button class="btn btn-ghost btn-xs" onclick="restoreThreat(${id})" title="Restore">↺</button>
        ` : ''}
      </td>
    </tr>`;
  }).join('');

  const master = document.getElementById('threat-check-all');
  if (master) { master.checked = false; master.indeterminate = false; }
  updateBulkBar();
}

function threatStatusBadge(status) {
  const map = {
    active:      '<span class="badge badge-red">Active</span>',
    quarantined: '<span class="badge badge-amber">Quarantined</span>',
    deleted:     '<span class="badge badge-gray">Deleted</span>',
    restored:    '<span class="badge badge-blue">Restored</span>',
    // Judged by an operator. Green, because it is a resolved finding and not
    // an outstanding one -- a cleared file sitting in a red "Active" row is
    // exactly what made the old buttons look broken.
    not_malware: '<span class="badge badge-green" title="An operator judged this '
               + 'file safe. It is still scanned; it will be reported again if '
               + 'its contents change.">Not malware</span>',
  };
  return map[status] || `<span class="badge badge-gray">${esc(status || '')}</span>`;
}

async function quarantineThreat(id) {
  const res = Demo.active ? { success: true } : await API.quarantineThreat(id);
  if (res?.success) { toast('File quarantined', 'success'); loadThreats(); return; }
  // "Quarantine failed" with no reason is what made this look like a mystery.
  // The API now explains itself -- cross-device move, unwritable directory, an
  // immutable file -- so show that.
  toast('Quarantine failed: ' + ((res && (res.error || res.detail)) || 'no reason given'),
        'error', 10000);
}

async function restoreThreat(id) {
  if (!confirm('Restore this file from quarantine?')) return;
  const res = Demo.active ? { success: true } : await API.restoreThreat(id);
  if (res?.success) { toast('File restored', 'success'); loadThreats(); }
  else toast('Restore failed', 'error');
}

async function deleteThreat(id) {
  if (!confirm('Permanently delete this file? This cannot be undone.')) return;
  const res = Demo.active ? { success: true } : await API.deleteThreat(id);
  if (res?.success) { toast('File deleted', 'success'); loadThreats(); }
  else toast('Delete failed', 'error');
}

async function updateSignatures() {
  toast('Updating signatures…', 'info');
  const res = Demo.active ? { success: true } : await API.updateSigs();
  if (res?.success) toast('Signatures updated', 'success');
  else toast('Update failed', 'error');
}

// ── Firewall ──────────────────────────────────────────────────────────────────
// Loaded in stages, newest-first, with each panel drawn as its data arrives.
//
// All three were fetched together and rendered together, so the slowest
// decided when ANY of them appeared -- the page sat entirely blank until the
// last one landed. Staging them means the numbers at the top are on screen
// while the tables are still coming, and a slow panel can no longer hold up
// the ones that are ready.
//
// The overlay is up for the whole sequence, which is what stops the page being
// clicked into a queue of overlapping work while it fills in.
async function loadFirewall() {
  return API.withBusy('Loading firewall…', () => loadFirewallStages());
}

async function loadFirewallStages() {
  // Stage 1 — the three counts. Indexed queries, so this is the one that is
  // reliably quick, and it is what the eye goes to first.
  const stats = Demo.active
    ? { success: true, data: { blocked_ips: 382, active_rules: 14, blocked_today: 8241 } }
    : await API.fwStats().catch(() => null);

  if (stats?.success) {
    document.getElementById('fw-stat-rules').textContent   = fmtNum(stats.data?.active_rules || 0);
    document.getElementById('fw-stat-blocked').textContent = fmtNum(stats.data?.blocked_ips  || 0);
    document.getElementById('fw-stat-today').textContent   = fmtNum(stats.data?.blocked_today || 0);
    // "iptables active" was printed unconditionally -- including when the
    // count could not be taken at all, which reads as a working firewall.
    const csf = stats.data?.csf_status || {};
    // Three states, not two: measured, measured-and-failed, and not yet
    // measured. The probe runs in the scheduler now, so a freshly installed
    // server has no reading for the first few minutes -- saying "0 rules"
    // there would read as "no firewall".
    const ipt = stats.data?.probe_pending
      ? 'iptables: not measured yet'
      : (stats.data?.iptables_unknown
          ? 'iptables status unavailable (busy)'
          : 'iptables: ' + fmtNum(stats.data?.iptables_rules || 0) + ' rule(s)');
    document.getElementById('fw-status-line').textContent =
      `CSF ${csf.installed ? '✓ installed' : '✗ not found'}`
      + (csf.installed && csf.running === false ? ' (lfd not running)' : '')
      + ' · ' + ipt;
  }

  // Stage 2 — the rules table, ONE PAGE of it. Rendering every rule is what
  // made this page unusable on a server with 343,000 of them.
  await loadFirewallRules();

  // Stage 3 — recently blocked addresses. Last because it is the panel you
  // look at after the counts and the rules, so it is the one that can afford
  // to arrive last.
  const blocked = Demo.active
    ? { success: true, data: [] }
    : await API.fwBlocked().catch(() => null);

  const recentEl = document.getElementById('fw-recent-blocked');
  if (recentEl && blocked?.data?.length) {
    recentEl.innerHTML = blocked.data.slice(0, 8).map(b => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border)">
        <span class="mono" style="font-size:.72rem">${b.ip_address}</span>
        <div style="display:flex;gap:6px;align-items:center">
          <span class="dim" style="font-size:.65rem">${reltime(b.blocked_at)}</span>
          <button class="btn btn-ghost btn-xs" onclick="unblockIP('${b.ip_address}')">Unblock</button>
        </div>
      </div>`).join('');
  } else if (recentEl) {
    recentEl.innerHTML = '<div class="dim" style="font-size:.78rem">No recently blocked IPs</div>';
  }

  // Geo block grid. Awaited: it reads the saved list over the API now, and an
  // un-awaited failure here is what used to escape this function.
  await renderGeoGrid();
}

function actionBadge(action) {
  const map = {
    ACCEPT: 'badge-green', DROP: 'badge-red',
    REJECT: 'badge-red',   LIMIT: 'badge-amber',
  };
  return `<span class="badge ${map[action] || 'badge-gray'}">${action}</span>`;
}

async function blockIP() {
  const ip = document.getElementById('fw-ip-input')?.value?.trim();
  const reason = document.getElementById('fw-ip-reason')?.value?.trim() || 'Manual block';
  if (!ip) { toast('Enter an IP address', 'error'); return; }

  const res = Demo.active ? { success: true } : await API.fwBlockIP(ip, reason, false);
  if (res?.success) { toast(`${ip} blocked`, 'success'); loadFirewall(); }
  else toast(res?.error || 'Block failed', 'error');
}

async function allowIP() {
  const ip = document.getElementById('fw-ip-input')?.value?.trim();
  if (!ip) { toast('Enter an IP address', 'error'); return; }
  const res = Demo.active ? { success: true } : await API.fwAllowIP(ip, '');
  if (res?.success) { toast(`${ip} allowed`, 'success'); }
  else toast('Failed', 'error');
}

async function unblockIP(ip) {
  const res = Demo.active ? { success: true } : await API.fwUnblockIP(ip);
  if (res?.success) { toast(`${ip} unblocked`, 'success'); loadFirewall(); }
  else toast('Unblock failed', 'error');
}

async function toggleRule(id, enabled) {
  const res = Demo.active ? { success: true } : await API.fwToggleRule(id, enabled);
  if (!res?.success) toast('Failed to toggle rule', 'error');
}

async function deleteRule(id) {
  if (!confirm('Delete this firewall rule?')) return;
  const res = Demo.active ? { success: true } : await API.fwDeleteRule(id);
  if (res?.success) { toast('Rule deleted', 'success'); loadFirewall(); }
  else toast('Failed', 'error');
}

async function reloadFirewall() {
  const res = Demo.active ? { success: true } : await API.fwReload();
  if (res?.success) toast('Firewall reloaded', 'success');
  else toast('Reload failed', 'error');
}

function openAddRuleModal() { openModal('add-rule-modal'); }

async function submitAddRule() {
  const rule = {
    name:      document.getElementById('rule-name')?.value,
    direction: document.getElementById('rule-dir')?.value,
    protocol:  document.getElementById('rule-proto')?.value,
    port:      document.getElementById('rule-port')?.value,
    action:    document.getElementById('rule-action')?.value,
    source_ip: document.getElementById('rule-source')?.value,
    comment:   document.getElementById('rule-comment')?.value,
  };
  if (!rule.name) { toast('Rule name required', 'error'); return; }

  const res = Demo.active ? { success: true } : await API.fwAddRule(rule);
  if (res?.success) {
    toast('Rule added', 'success');
    closeModal('add-rule-modal');
    loadFirewall();
  } else toast(res?.error || 'Failed', 'error');
}

const GEO_COUNTRIES = [
  ['AF','Afghanistan'],['BY','Belarus'],['CN','China'],['CU','Cuba'],
  ['IR','Iran'],['IQ','Iraq'],['KP','North Korea'],['LY','Libya'],
  ['RU','Russia'],['SD','Sudan'],['SY','Syria'],['VE','Venezuela'],
  ['UA','Ukraine'],['MM','Myanmar'],['YE','Yemen'],['ZW','Zimbabwe'],
  ['NG','Nigeria'],['PK','Pakistan'],['BD','Bangladesh'],['ID','Indonesia'],
  ['VN','Vietnam'],['IN','India'],['BR','Brazil'],['MX','Mexico'],
];

// The country grid, and the state it is allowed to be in.
//
// 'unknown' is the important one. renderGeoGrid() used to read the saved list
// with Database?.setting?.(...) -- a PHP class, in the browser. `?.` does not
// guard an UNDECLARED identifier, so it threw ReferenceError on every load of
// the Firewall page, the exception escaped loadFirewallStages(), and the grid
// rendered with nothing selected. That is indistinguishable, on screen, from
// "this server blocks no countries" -- and one click on Save Geo Rules then
// posted the empty selection, wiped CC_DENY and reported success in green.
//
// So the grid now has three states, and the one it must never do again is
// show an authoritative-looking empty selection it did not load.
let GeoLoaded = 'unknown';

async function renderGeoGrid() {
  const grid = document.getElementById('geo-block-grid');
  if (!grid) return;

  let saved = [];
  if (Demo.active) {
    GeoLoaded = 'loaded';
  } else {
    const res = await API.fwGeoGet().catch(() => null);
    if (res?.success && Array.isArray(res.countries)) {
      saved = res.countries;
      GeoLoaded = 'loaded';
      State.geoSelected = new Set(saved);
      // CSF holding something different from the panel is worth saying out
      // loud: one of the two was changed by something that is not us.
      if (Array.isArray(res.csf_countries)
          && res.csf_countries.slice().sort().join(',') !== saved.slice().sort().join(',')) {
        toast('CSF’s CC_DENY does not match the saved list — saving here will overwrite it', 'warn');
      } else if (res.csf_error) {
        toast('Could not read CSF’s own list: ' + res.csf_error, 'warn');
      }
    } else {
      GeoLoaded = 'failed';
      grid.innerHTML = '<div class="dim" style="grid-column:1/-1;font-size:.78rem">'
        + 'Could not load the current country block list'
        + (res?.error ? ' (' + esc(String(res.error)) + ')' : '')
        + '. The grid is not shown, because an empty grid would look like '
        + '&ldquo;no countries are blocked&rdquo; and saving it would erase them.</div>';
      return;
    }
  }

  grid.innerHTML = GEO_COUNTRIES.map(([cc, name]) => {
    const sel = State.geoSelected.has(cc);
    return `
      <div onclick="toggleGeo('${cc}', this)"
           style="padding:8px 10px;border-radius:8px;cursor:pointer;font-size:.72rem;
                  border:1px solid ${sel ? 'var(--red)' : 'var(--border)'};
                  background:${sel ? 'var(--red-dim)' : 'var(--card2)'};
                  color:${sel ? 'var(--red)' : 'var(--txt2)'};
                  user-select:none;transition:all .15s"
           data-cc="${cc}" data-sel="${sel ? '1' : '0'}">
        <div style="font-weight:700">${cc}</div>
        <div style="font-size:.6rem;margin-top:2px;opacity:.7">${name}</div>
      </div>`;
  }).join('');
}

function toggleGeo(cc, el) {
  const sel = el.dataset.sel === '1';
  el.dataset.sel = sel ? '0' : '1';
  el.style.border  = sel ? '1px solid var(--border)' : '1px solid var(--red)';
  el.style.background = sel ? 'var(--card2)' : 'var(--red-dim)';
  el.style.color   = sel ? 'var(--txt2)' : 'var(--red)';
  sel ? State.geoSelected.delete(cc) : State.geoSelected.add(cc);
}

async function saveGeoBlock() {
  // Never write a list the page did not manage to read. The payload for "the
  // operator deselected everything" and the payload for "the grid failed" are
  // the same empty array, and the second one erased a production server's
  // country blocks.
  if (GeoLoaded !== 'loaded') {
    toast('Not saving: the current country list never loaded, so saving would '
        + 'erase it. Reload the page.', 'error');
    return;
  }

  const countries = [...State.geoSelected];
  let clearAll = false;
  if (!countries.length) {
    clearAll = confirm('This removes every country block on the server. Continue?');
    if (!clearAll) return;
  }

  const res = Demo.active ? { success: true }
                          : await API.fwGeoBlock(countries, clearAll);
  if (res?.success) {
    // "saved" and "in force" are different claims. CSF not being installed
    // means nothing is actually blocked, and the toast says which it is.
    toast(res.enforced === false
            ? `Geo block list saved (${countries.length}) — ${res.warning || 'not enforced'}`
            : `Geo block saved (${countries.length} countries)`,
          res.enforced === false ? 'warn' : 'success');
    renderGeoGrid();
  } else {
    toast(res?.error || 'Failed to save', 'error');
  }
}

// ── WAF ───────────────────────────────────────────────────────────────────────
// Explain an empty WAF table.
//
// "No attacks were blocked" and "nothing is reading a ModSecurity log" look
// identical as a blank table, and the second was true on every install:
// ingestModSecLog() was reachable only from an API route nothing called, so
// waf_events stayed empty for ever. The banner names which it is.
async function loadWafIngestState() {
  const banner = document.getElementById('waf-ingest-banner');
  if (!banner) return;

  const res = await API.wafIngestStatus();
  if (!res?.success) { banner.style.display = 'none'; return; }
  const d = res.data || {};

  const title  = document.getElementById('waf-ingest-title');
  const detail = document.getElementById('waf-ingest-detail');

  if (!d.log_found) {
    banner.style.display = '';
    if (title) title.textContent = 'No ModSecurity audit log found';
    if (detail) {
      detail.textContent =
        'Nothing can be reported until ModSecurity is writing an audit log this '
        + 'server can read. Looked in: ' + (d.candidates || []).join(', ')
        + '. If ModSecurity logs somewhere else, set waf_audit_log_override in Settings.';
    }
    return;
  }

  // Found, but never read — the state every install was in.
  if (!d.last_run) {
    banner.style.display = '';
    if (title) title.textContent = 'ModSecurity log found but not yet read';
    if (detail) {
      detail.textContent = d.log_path + ' (' + fmtNum(d.log_size || 0)
        + ' bytes). It is read every 15 minutes from now on; use the button to '
        + 'read it immediately.';
    }
    return;
  }

  // Working. Only worth saying something if it is finding nothing at all.
  if ((d.total_events || 0) === 0) {
    banner.style.display = '';
    if (title) title.textContent = 'Reading the log, no events recorded yet';
    if (detail) {
      detail.textContent = 'Reading ' + d.log_path + '. No ModSecurity events have '
        + 'been logged yet — that is normal on a quiet server, or if ModSecurity '
        + 'is in DetectionOnly with no rules matching.';
    }
    return;
  }
  banner.style.display = 'none';
}

async function wafIngestNow() {
  const res = await API.wafIngest();
  if (!res?.success) { toast(res?.error || 'Could not read the log', 'error'); return; }
  toast('Read ' + (res.ingested || 0) + ' new event(s)', 'success');
  loadWafIngestState();
  loadWAF();
}

/* One spelling of the mode for the whole page.
 *
 * The engine reports 'on' | 'detectiononly' | 'off' | 'unknown'. "Unknown" is
 * displayed as such rather than smoothed into "On": not being able to read
 * the config is a thing the operator needs to see, not a thing to guess past.
 */
function wafModeLabel(mode) {
  const m = String(mode || 'unknown').toLowerCase();
  if (m === 'on')            { return 'Blocking'; }
  if (m === 'detectiononly') { return 'Detection only'; }
  if (m === 'off')           { return 'Off'; }
  return 'Unknown';
}

async function loadWAF() {
  loadWafIngestState();
  const [stats, cats] = await Promise.all([
    Demo.active ? Demo.mockWAFStats() : API.wafStats(),
    API.wafCats(),
  ]);

  if (stats?.success) {
    const d = stats.data;
    document.getElementById('waf-stat-total').textContent    = fmtNum(d.total_events || 0);
    document.getElementById('waf-stat-today').textContent    = fmtNum(d.events_today || 0);
    document.getElementById('waf-stat-top-rule').textContent = d.top_rules?.[0]?.rule_id || '—';
    /* THE TILE WAS THE WORD "On", HARD-CODED. It read nothing, so it said
     * "On" while the engine below it said "detectiononly" -- and it would
     * have said "On" with ModSecurity not installed at all. In a security
     * product the tile that says whether the firewall is enforcing is the
     * last place to print a constant. */
    setText('waf-stat-mode', wafModeLabel(d.mode));
  }

  loadWAFEvents();

  // CRS Categories
  /* THE WHOLE PANEL WAS A HARDCODED ARRAY in WAF.php -- sixteen categories,
   * exact rule counts and an Active/Disabled badge on each, rendered the same
   * on a server with CRS 4.7.0, with CRS 3.x and with no CRS at all. It is
   * read from the installed rule files now, and when they cannot be read the
   * panel says that instead of filling the space with numbers. "Could not
   * read" must not look like an answer. */
  const catContainer = document.getElementById('waf-categories');
  if (catContainer) {
    const d = cats?.data;
    const list = Array.isArray(d) ? d : (d?.categories || []);
    if (!cats?.success) {
      catContainer.innerHTML = '<div style="font-size:.72rem;color:var(--txt3)">'
        + 'The OWASP CRS categories could not be read from the server.</div>';
    } else if (!list.length) {
      catContainer.innerHTML = '<div style="font-size:.72rem;color:var(--txt3)">'
        + esc(d?.reason || 'No OWASP CRS rule files could be read, so there are no category '
            + 'counts to show.') + '</div>';
    } else {
      catContainer.innerHTML = list.map(c => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
        <div>
          <div style="font-size:.78rem;font-weight:600">${esc(c.id)} — ${esc(c.name)}</div>
          <div style="font-size:.65rem;color:var(--txt3)">${fmtNum(c.rules || 0)} rules read from ${esc((c.files || []).join(', '))}${c.excluded ? ' · ' + fmtNum(c.excluded) + ' excluded by you' : ''}</div>
        </div>
        <span class="badge ${c.loaded ? 'badge-green' : 'badge-gray'}">${c.loaded ? 'Included' : 'Not included'}</span>
      </div>`).join('')
      + '<div style="font-size:.62rem;color:var(--txt3);padding-top:8px">'
      + 'Counted from ' + esc(d?.crs_path || 'the installed rule files')
      + (d?.crs_version ? ' (CRS ' + esc(d.crs_version) + ')' : '')
      + '. "Included" means our configuration loads the file — the mode tile above is what '
      + 'says whether the engine is enforcing.</div>';
    }
  }
}

// ── WAF event paging ────────────────────────────────────────────────────────
//
// Mirrors Bot Shield's pager on purpose: the same control in two places should
// behave the same way and be learned once. Page size is a reading preference,
// so it lives in sessionStorage, and every access is wrapped because it throws
// in a private window.
const WAF_PAGE_KEY = 'sg.waf.pagesize';
const WAF_PAGE_SIZES = [50, 100, 200, 500];
const WafPage = { offset: 0, total: 0 };

function wafPageSize() {
  let n = 0;
  try { n = parseInt(sessionStorage.getItem(WAF_PAGE_KEY) || '', 10) || 0; }
  catch (e) { n = 0; }
  return WAF_PAGE_SIZES.includes(n) ? n : 50;
}

function wafSetPageSize(v) {
  const n = WAF_PAGE_SIZES.includes(Number(v)) ? Number(v) : 50;
  try { sessionStorage.setItem(WAF_PAGE_KEY, String(n)); } catch (e) { /* not fatal */ }
  document.querySelectorAll('.waf-page-size').forEach(sel => { sel.value = String(n); });
  // Page 3 of 50 is not page 3 of 500, and landing past the end would show an
  // empty table on a server with 148,551 events.
  WafPage.offset = 0;
  loadWAFEvents();
}

/* Changing the severity filter resets to the first page.
 *
 * Page 20 of everything is not page 20 of the critical events: keeping the
 * offset across a filter change lands past the end of the filtered set and
 * shows an empty table, which reads as "no critical events" when there are
 * plenty. */
function wafFilterChanged() {
  WafPage.offset = 0;
  loadWAFEvents();
}

function wafEventsPage(dir) {
  WafPage.offset = Math.max(0, WafPage.offset + dir * wafPageSize());
  loadWAFEvents();
}

/* What ModSecurity actually did with the request.
 *
 * 'unknown' is rendered as a dash, not as "Blocked". Every row written before
 * 4.33.0 carries it, because the old code stored the literal string 'block'
 * on every event without ever reading the audit log -- so on an engine in
 * DetectionOnly those rows claimed a block that never happened. A dash with
 * an explanation is the honest rendering of a value nobody ever observed. */
function wafActionBadge(a) {
  const v = String(a || 'unknown').toLowerCase();
  const MAP = {
    blocked:    ['badge-red',   'Blocked',    'The request was denied; it never reached the site'],
    dropped:    ['badge-red',   'Dropped',    'The connection was dropped without a response'],
    redirected: ['badge-amber', 'Redirected', 'The request was redirected away'],
    detected:   ['badge-amber', 'Logged',     'The rule matched and the request was SERVED anyway — detection only'],
  };
  const hit = MAP[v];
  if (!hit) {
    return '<span class="dim" title="Not recorded. Events from before v4.33.0 '
         + 'stored a fixed value instead of what the WAF did, so this one '
         + 'cannot be trusted and is not shown.">&mdash;</span>';
  }
  return '<span class="badge ' + hit[0] + '" title="' + esc(hit[2]) + '">'
       + hit[1] + '</span>';
}

async function loadWAFEvents() {
  const sev = document.getElementById('waf-sev-filter')?.value || '';
  document.querySelectorAll('.waf-page-size').forEach(sel => {
    sel.value = String(wafPageSize());
  });

  const res = Demo.active
    ? { success: true, data: { items: [], total: 0 } }
    : await API.wafEvents(sev, wafPageSize(), WafPage.offset);

  const tbody = document.getElementById('waf-events-body');
  if (!tbody) return;

  // The response used to be a bare array and is now an items-plus-total
  // object. Both shapes are
  // accepted: a browser holding a cached app.js against a freshly updated
  // backend, or the reverse, should degrade to one unpaged page rather than
  // to an empty table.
  const d = (res && res.data) || {};
  const events = Array.isArray(d) ? d : (d.items || []);
  WafPage.total = Array.isArray(d) ? events.length : Number(d.total || 0);

  if (!events.length) {
    // An offset past the end is a navigation mistake, not an empty log, and
    // saying "no events" there would be wrong.
    if (WafPage.offset > 0) {
      WafPage.offset = 0;
      return loadWAFEvents();
    }
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--txt3);padding:24px">No WAF events. Events are ingested from ModSecurity audit log.</td></tr>';
    botPagerNote('wafEvents', WafPage, 0);
    return;
  }
  // Keyed by id so the dialog can render from what is already loaded, without
  // a second request and without putting the row's data into the markup.
  _wafEvents = {};
  events.forEach(e => { _wafEvents[String(e.id)] = e; });

  // EVERY field here comes from an attacker-controlled HTTP request: the URI,
  // the rule message quoting the matched data, the user agent. Interpolating
  // them raw into innerHTML -- which is what this did -- means a request
  // crafted to contain markup runs as script in the dashboard of whoever reads
  // the log. A security product's own attack log is the last place that should
  // be true.
  tbody.innerHTML = events.map(e => `
    <tr class="waf-row" tabindex="0" role="button"
        style="cursor:pointer"
        onclick="showWafEvent('${esc(String(e.id))}')"
        onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();showWafEvent('${esc(String(e.id))}')}"
        title="Show full details">
      <td>${sevBadge(e.severity)}</td>
      <td class="mono">${esc(e.rule_id)}</td>
      <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(e.rule_msg)}</td>
      <td class="mono">${esc(e.ip_address) || '<span class="dim">—</span>'}</td>
      <td class="mono" style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(e.uri)}</td>
      <td>${wafActionBadge(e.action)}</td>
      <td class="dim">${esc(reltime(e.timestamp))}</td>
    </tr>`).join('');

  botPagerNote('wafEvents', WafPage, events.length);
}

// ── WAF event detail ────────────────────────────────────────────────────────
let _wafEvents = {};
let _wafEventShown = null;

function showWafEvent(id) {
  const e = _wafEvents[String(id)];
  if (!e) return;
  _wafEventShown = e;

  const put = (elId, val, mono) => {
    const el = document.getElementById(elId);
    if (!el) return;
    // textContent, not innerHTML: same attacker-controlled data as the table.
    el.textContent = (val === null || val === undefined || val === '') ? '—' : String(val);
    if (mono) el.classList.add('mono');
  };

  const sev = document.getElementById('wem-sev');
  if (sev) sev.innerHTML = sevBadge(e.severity);   // our own markup, fixed set

  put('wem-rule',   e.rule_id);
  put('wem-msg',    e.rule_msg);
  put('wem-ip',     e.ip_address);
  put('wem-method', e.method);
  put('wem-host',   e.host);
  // The dialog showed e.action raw, which for every row written before
  // 4.33.0 is the invented string 'block' -- stated as fact in the one field
  // that says whether the request was stopped. Rendered through the same
  // badge as the table so the two cannot disagree, and so 'unknown' reads as
  // a dash rather than as the word "unknown".
  const act = document.getElementById('wem-action');
  if (act) { act.innerHTML = wafActionBadge(e.action); }
  put('wem-when',   e.timestamp ? new Date(e.timestamp * 1000).toLocaleString()
                                + ' (' + reltime(e.timestamp) + ')' : '—');
  put('wem-uri',    e.uri);

  // Hide the user-agent block entirely when there is none, rather than showing
  // an empty box: these rows predate the parser learning to read it.
  const uaWrap = document.getElementById('wem-ua-wrap');
  if (uaWrap) uaWrap.style.display = e.user_agent ? '' : 'none';
  put('wem-ua', e.user_agent);

  // Nothing to block or look up without a source address.
  ['wem-block', 'wem-lookup'].forEach(b => {
    const el = document.getElementById(b);
    if (el) el.disabled = !e.ip_address;
  });

  openModal('waf-event-modal');
}

async function blockWafEventIp() {
  const e = _wafEventShown;
  if (!e?.ip_address) return;
  const res = await API.fwBlockIP(e.ip_address,
    'WAF rule ' + (e.rule_id || '') + ' - ' + (e.rule_msg || ''), false);
  if (res?.success) {
    toast('Blocked ' + e.ip_address, 'success');
    closeModal('waf-event-modal');
  } else {
    toast(res?.error || 'Could not block that address', 'error');
  }
}

function lookupWafEventIp() {
  const e = _wafEventShown;
  if (!e?.ip_address) return;
  closeModal('waf-event-modal');
  openPage('iprep');
  const input = document.getElementById('iprep-ip-input');
  if (input) { input.value = e.ip_address; checkIP(); }
}

function copyWafEvent() {
  const e = _wafEventShown;
  if (!e) return;
  const text = [
    'Rule ID:    ' + (e.rule_id    || '—'),
    'Message:    ' + (e.rule_msg   || '—'),
    'Severity:   ' + (e.severity   || '—'),
    'Source IP:  ' + (e.ip_address || '—'),
    'Method:     ' + (e.method     || '—'),
    'Host:       ' + (e.host       || '—'),
    'URI:        ' + (e.uri        || '—'),
    'User agent: ' + (e.user_agent || '—'),
    'Action:     ' + (e.action     || '—'),
    'When:       ' + (e.timestamp ? new Date(e.timestamp * 1000).toISOString() : '—'),
  ].join('\n');

  const done = () => toast('Event details copied', 'success');
  if (navigator.clipboard?.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else {
    fallbackCopy(text, done);
  }
}

function fallbackCopy(text, done) {
  // clipboard API needs a secure context; WHM is often reached over a hostname
  // with a self-signed certificate, where it is unavailable.
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); done(); }
  catch (_) { toast('Could not copy to the clipboard', 'error'); }
  document.body.removeChild(ta);
}

/* The page header's Apply Mode.
 *
 * It called a different endpoint from the WAF Engine card's own selector, and
 * that endpoint wrote a different file -- the vendor config, rather than the
 * serverscrub-waf.conf that Apache actually honours. It could not fail: the
 * edit was guarded by is_readable and the method returned success whether or
 * not anything was written. So pressing it reported "WAF mode set to On"
 * while the card directly below went on reading the real file and saying
 * detectiononly. Two controls for one setting, disagreeing in public.
 *
 * Now both go through setWafEngineMode(): one endpoint, one file, validated
 * before Apache is reloaded, and the card is re-read afterwards so what is on
 * screen is what is on disk. */
async function setWAFMode() {
  const sel = document.getElementById('waf-mode-sel');
  const mode = (sel && sel.value) || '';
  if (!mode) { return; }
  // The engine endpoint speaks lower case.
  await setWafEngineMode(mode.toLowerCase());
}

// ── Dashboard overview ─────────────────────────────────────────────────────
//
// Headline figures for the period, against the period before it. A number on
// its own says nothing about direction; the comparison is what makes it worth
// the space.

function ovDelta(d) {
  // null means there was nothing to compare against -- a first month, or a
  // metric that has only just started being collected. "+100%" would be a
  // fabrication, and "0%" would claim nothing changed.
  if (d === null || d === undefined) {
    return '<span class="dim" style="font-size:.72rem">no earlier period</span>';
  }
  const up   = d > 0;
  const flat = Math.abs(d) < 0.005;
  if (flat) return '<span class="dim" style="font-size:.72rem">no change</span>';
  // More blocked attacks is not bad news, so neither direction is coloured as
  // good or bad here -- it is a direction, not a verdict.
  return '<span style="font-size:.74rem;color:var(--txt2)">'
       + (up ? '\u25b2 ' : '\u25bc ') + Math.abs(d).toFixed(2) + '%</span>';
}

async function loadOverview() {
  const daysEl = document.getElementById('ov-days');
  const days   = parseInt(daysEl?.value, 10) || 30;

  const cards = document.getElementById('ov-cards');
  if (cards && !cards.children.length) { cards.innerHTML = loadingMark('Loading figures…'); }

  const res = await API.overview(days).catch(() => null);
  if (!res?.success) {
    if (cards) cards.innerHTML = '<div class="dim" style="font-size:.82rem">'
      + 'Could not load the overview.</div>';
    return;
  }
  const d = res.data;

  // ── Headline cards ──────────────────────────────────────────────────────
  if (cards) {
    cards.innerHTML = d.cards.map(c => `
      <div class="card" style="position:relative;overflow:hidden">
        <div class="card-body" style="display:flex;align-items:center;gap:14px">
          <img src="${assetUrl('images/icon.png')}" alt="" aria-hidden="true"
               style="width:62px;height:62px;object-fit:contain;opacity:.13;flex:none">
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:baseline;gap:9px;flex-wrap:wrap">
              <div style="font-size:1.9rem;font-weight:800;letter-spacing:-.02em">${fmtNum(c.value)}</div>
              ${ovDelta(c.delta)}
            </div>
            <div class="dim" style="font-size:.76rem;margin-top:2px">${esc(c.label)}</div>
          </div>
          <div style="text-align:right;flex:none">
            <div style="font-weight:700;font-size:.95rem">${fmtNum(c.overall)}</div>
            <div class="dim" style="font-size:.66rem">Overall</div>
          </div>
        </div>
      </div>`).join('');
  }

  // ── Donut: what the period was made of ──────────────────────────────────
  const slices = [
    { label: 'Web attacks',   value: d.cards[1].value, color: '#3b82f6' },
    { label: 'Threats',       value: d.cards[0].value, color: '#ef4444' },
    { label: 'Blocked IPs',   value: d.cards[2].value, color: '#22c55e' },
  ];
  const total = slices.reduce((a, s) => a + s.value, 0);
  const donut = document.getElementById('ov-donut');
  if (donut && typeof Charts !== 'undefined' && Charts.donut) {
    Charts.donut(donut, slices, { value: fmtNum(total), caption: `last ${d.days} days` });
  }
  const legend = document.getElementById('ov-donut-legend');
  if (legend) {
    legend.innerHTML = slices.map(s => `
      <div style="display:flex;align-items:center;gap:7px">
        <span style="width:9px;height:9px;border-radius:2px;background:${s.color};flex:none"></span>
        <span style="flex:1">${esc(s.label)}</span>
        <span class="dim">${fmtNum(s.value)}</span>
      </div>`).join('');
  }

  // ── This period against the last, as bars ───────────────────────────────
  const cmp = document.getElementById('ov-compare');
  if (cmp) {
    const mx = Math.max(...d.cards.map(c => Math.max(c.value, c.prev)), 1);
    cmp.innerHTML = d.cards.map(c => `
      <div style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;font-size:.76rem;margin-bottom:5px">
          <span>${esc(c.label)}</span>
        </div>
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:3px">
          <div style="flex:1;height:9px;border-radius:5px;background:var(--card2,#1b2029);overflow:hidden">
            <div style="width:${(c.value / mx) * 100}%;height:100%;background:#3b82f6"></div>
          </div>
          <span style="font-size:.74rem;min-width:62px;text-align:right">${fmtNum(c.value)}</span>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="flex:1;height:9px;border-radius:5px;background:var(--card2,#1b2029);overflow:hidden">
            <div style="width:${(c.prev / mx) * 100}%;height:100%;background:#64748b"></div>
          </div>
          <span class="dim" style="font-size:.74rem;min-width:62px;text-align:right">${fmtNum(c.prev)}</span>
        </div>
      </div>`).join('')
      + `<div style="display:flex;gap:16px;font-size:.72rem;margin-top:4px">
           <span style="display:flex;align-items:center;gap:6px">
             <span style="width:9px;height:9px;border-radius:2px;background:#3b82f6"></span>This period</span>
           <span style="display:flex;align-items:center;gap:6px">
             <span style="width:9px;height:9px;border-radius:2px;background:#64748b"></span>Previous</span>
         </div>`;
  }

  // ── Per-day charts ──────────────────────────────────────────────────────
  const wafTitle = document.getElementById('ov-waf-title');
  if (wafTitle) wafTitle.textContent = `Web attacks blocked — ${d.days} days`;

  const wafChart = document.getElementById('ov-waf-chart');
  if (wafChart && typeof Charts !== 'undefined' && Charts.bars) {
    Charts.bars(wafChart, d.series.labels,
      [{ values: d.series.waf, color: '#3b82f6', label: 'Web attacks' }]);
  }
  const thChart = document.getElementById('ov-threat-chart');
  if (thChart && typeof Charts !== 'undefined' && Charts.bars) {
    Charts.bars(thChart, d.series.labels, [
      { values: d.series.threats, color: '#ef4444', label: 'Malware' },
      { values: d.series.brute,   color: '#f59e0b', label: 'Failed logins' },
    ]);
  }

  // ── Summary ─────────────────────────────────────────────────────────────
  const sum = document.getElementById('ov-summary');
  if (sum) {
    sum.innerHTML = d.summary.map(r => `
      <div onclick="openPage('${esc(r.page)}')"
           style="display:flex;align-items:center;justify-content:space-between;
                  padding:13px 18px;border-bottom:1px solid var(--line,#2d333a);
                  cursor:pointer;font-size:.84rem">
        <span>${esc(r.label)}</span>
        <span style="font-weight:800;font-size:1.05rem;
                     color:${r.value > 0 ? 'var(--amber,#f59e0b)' : 'var(--txt2)'}">${fmtNum(r.value)}</span>
      </div>`).join('');
  }

  renderOverviewAlerts();
}

// Alerts, built from what the dashboard already knows rather than a second
// round of requests.
function renderOverviewAlerts() {
  const el = document.getElementById('ov-alerts');
  if (!el) return;
  const items = [];

  const push = (tone, text, page) => items.push({ tone, text, page });

  if (State.lastDash?.firewall && State.lastDash.firewall.active_rules === 0) {
    push('red', 'No firewall rules are active', 'firewall');
  }
  if (State.lastMonitor && !State.lastMonitor.running) {
    push('red', 'Real-time monitoring is not running', 'monitor');
  } else if (State.lastMonitor?.suspended) {
    // Names the process as still up, and names what is holding it. The bare
    // version read as an outage next to a Services panel reporting the unit
    // healthy -- which is the same mismatch the monitor page had.
    push('amber', 'Real-time scanning is paused while '
                + (State.lastMonitor.suspend_reason || 'a backup')
                + ' runs — the service is still running', 'monitor');
  }
  if (State.lastDash?.scanner?.last_scan) {
    const age = (Date.now() / 1000) - Number(State.lastDash.scanner.last_scan);
    if (age > 7 * 86400) { push('amber', 'No scan in over a week', 'scanner'); }
  }

  el.innerHTML = items.length
    ? items.map(i => `
        <div onclick="openPage('${esc(i.page)}')"
             style="display:flex;align-items:center;gap:11px;padding:12px 14px;border-radius:9px;
                    cursor:pointer;font-size:.82rem;
                    background:${i.tone === 'red' ? 'rgba(239,68,68,.12)' : 'rgba(245,158,11,.12)'};
                    border:1px solid ${i.tone === 'red' ? 'rgba(239,68,68,.32)' : 'rgba(245,158,11,.32)'}">
          <span style="font-size:1rem">${i.tone === 'red' ? '\u26d4' : '\u26a0\ufe0f'}</span>
          <span style="flex:1">${esc(i.text)}</span>
        </div>`).join('')
    : '<div class="dim" style="font-size:.82rem;padding:6px 0">Nothing needs attention.</div>';
}

// ── Brute Force ────────────────────────────────────────────────────────────────
//
// The dashboard has charted a "Brute Force" series since it was written, and
// nothing ever produced the data for it. These read what the detector now
// records.

async function loadBruteForce() {
  const [statsRes, tlRes, offRes, tgtRes] = await Promise.all([
    API.bfStats().catch(() => null),
    API.bfTimeline(14).catch(() => null),
    API.bfOffenders().catch(() => null),
    API.bfTargets().catch(() => null),
  ]);

  const d = statsRes?.data;
  if (d) {
    setText('bf-24h',       fmtNum(d.attempts_24h || 0));
    setText('bf-7d',        fmtNum(d.attempts_7d  || 0));
    setText('bf-offenders', fmtNum(d.offenders    || 0));
    setText('bf-blocked',   fmtNum(d.blocked      || 0));

    const state = document.getElementById('bf-state');
    if (state) {
      state.textContent = d.enabled
        ? (d.auto_block ? 'detecting and blocking automatically' : 'detecting only')
        : 'detection is switched off';
      state.style.color = d.enabled ? 'var(--ok, #22c55e)' : 'var(--amber, #f59e0b)';
    }

    // Settings, filled from what the server actually has rather than from
    // whatever the markup shipped with.
    const chk = (id, v) => { const e = document.getElementById(id); if (e) e.checked = !!v; };
    const val = (id, v) => { const e = document.getElementById(id); if (e) e.value = v; };
    chk('bf-set-enabled', d.enabled);
    chk('bf-set-block',   d.auto_block);
    val('bf-set-threshold', d.threshold || 5);
    val('bf-set-window',    Math.round((d.window || 600) / 60));
    // The ladder, in hours, which is how the policy is written.
    val('bf-set-ladder', (d.ladder_secs || [10800, 21600, 86400, 0])
          .map(x => x === 0 ? '0' : String(x / 3600)).join(', '));
    // Write-only until 4.16.1: both were posted by Save and never sent back,
    // so the form could not show them. The allow-list box looked empty (its
    // placeholder is a pair of documentation addresses, which reads like a
    // configured list) and retention always showed the markup's 7 — so
    // changing the threshold silently emptied the allow list and reset the
    // retention.
    // Kept for the banner, which must be able to say "CSF is in TESTING mode"
    // without re-fetching.
    State.bfCsf = d.csf || {};

    // Say plainly what else is defending this box. The panel used to imply it
    // was the only thing between the server and the internet, which on a
    // cPanel server running lfd and cPHulk is simply untrue — and it is why
    // "Not blocked" read as "nothing is protecting you".
    const peers = g('bf-peers');
    if (peers) {
      const bits = [];
      const csf = d.csf || {};
      if (csf.installed) {
        bits.push('CSF/lfd' + (csf.testing ? ' (TESTING mode — blocks do not hold)' : '')
                  + (csf.deny_count ? ' · ' + fmtNum(csf.deny_count) + ' denied' : ''));
      }
      const hulk = d.cphulk || {};
      if (hulk.installed) {
        bits.push('cPHulk' + (hulk.enabled === false ? ' (disabled)'
                            : hulk.enabled === true ? '' : ' (state unknown)'));
      }
      peers.textContent = bits.length
        ? 'Also defending this server: ' + bits.join('  ·  ')
        : 'No other brute-force defence detected on this server.';
      peers.style.color = (csf.testing || !bits.length) ? 'var(--amber)' : 'var(--txt3)';
    }

    val('bf-set-retention', d.retention_days || 7);
    val('bf-set-whitelist', d.whitelist || '');

    // And state plainly what is allow-listed, because an empty box and a box
    // showing a grey example look the same at a glance.
    const wl = g('bf-whitelist-effective');
    if (wl) {
      const list = String(d.whitelist || '').split(',')
                     .map(x => x.trim()).filter(Boolean);
      wl.textContent = list.length
        ? 'Never blocked: ' + list.join(', ')
        : 'Nothing is allow-listed — every address can be blocked, including '
          + 'the one you are connected from.';
      wl.style.color = list.length ? 'var(--txt3)' : 'var(--amber)';
    }

    const prev = g('bf-ladder-preview');
    if (prev) {
      prev.textContent = (d.ladder || []).length
        ? ' Currently: ' + d.ladder.join(' → ') : '';
    }

    // Which logs are actually being read. An empty table means "nothing is
    // attacking you" or "we are reading nothing", and those look identical.
    const src = document.getElementById('bf-sources');
    if (src) {
      src.innerHTML = Object.entries(d.sources || {}).map(([k, v]) => `
        <div style="display:flex;gap:10px;align-items:center;font-size:.78rem">
          <span style="width:16px;color:${v.log_found ? 'var(--ok,#22c55e)' : 'var(--amber,#f59e0b)'}">
            ${v.log_found ? '\u2713' : '\u2717'}</span>
          <span style="min-width:150px">${esc(v.label)}</span>
          <span class="mono dim" style="flex:1">${esc(v.log_path || 'no readable log found')}</span>
          <span class="dim">${fmtNum(v.attempts_24h || 0)} in 24h</span>
        </div>`).join('');
    }
  }

  const tl = tlRes?.data || [];
  const svg = document.getElementById('bf-chart');
  if (svg && tl.length && typeof Charts !== 'undefined' && Charts.timeline) {
    Charts.timeline(svg, tl.map(x => x.date), [
      { values: tl.map(x => x.attempts), color: '#f59e0b', label: 'Failed logins' },
      { values: tl.map(x => x.blocked),  color: '#ef4444', label: 'Blocked' },
    ]);
  }

  // Offenders. Every value here comes from a log line written by whoever is
  // attacking the server, so all of it is escaped.
  const tb = document.getElementById('bf-offenders-body');
  if (tb) {
    const rows = offRes?.data || [];
    if (!rows.length) {
      tb.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--txt3);padding:22px">'
        + 'No offending addresses. Either nothing has crossed the threshold, or no '
        + 'authentication log could be read — the Log sources panel below says which.</td></tr>';
    } else {
      // When blocking is broken it is broken for EVERY address, so say it
      // once, loudly, at the top -- rather than stamping the same red badge on
      // twenty rows, which buries the one fact that matters.
      bfBlockAlert(rows);

      tb.innerHTML = rows.map(r => `
        <tr>
          <td class="mono">${esc(r.ip_address)}</td>
          <td>${esc(r.service)}</td>
          <td><b>${fmtNum(r.attempts)}</b></td>
          <td class="dim" style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
              title="${esc(r.usernames || '')}">${esc(r.usernames || '—')}</td>
          <td class="dim">${esc(reltime(r.last_seen))}</td>
          <td>${bfStatusBadge(r)}</td>
          <td style="white-space:nowrap">${bfRowActions(r)}</td>
        </tr>`).join('');
    }
  }

  const tgt = document.getElementById('bf-targets');
  if (tgt) {
    const rows = tgtRes?.data || [];
    tgt.innerHTML = rows.length
      ? rows.map(r => `
          <div style="display:flex;justify-content:space-between;gap:10px;font-size:.8rem;padding:4px 0">
            <span class="mono">${esc(r.username)}</span>
            <span class="dim">${fmtNum(r.attempts)}</span>
          </div>`).join('')
      : '<div class="dim" style="font-size:.8rem">No usernames recorded in the last 24 hours.</div>';
  }
}

async function bfScanNow() {
  const res = await API.bfScan();
  if (!res?.success) { toast(res?.error || 'Could not read the logs', 'error'); return; }
  const d = res.data || {};
  toast(d.enabled === false
    ? 'Detection is switched off'
    : `${d.collected || 0} failure(s) read, ${d.blocked || 0} address(es) blocked`,
    'success');
  loadBruteForce();
}

// How an offender's state reads in the table.
//
// "Watching" against two hundred failures was the complaint that prompted the
// escalation ladder: a status that never changes tells an operator the product
// is doing nothing. Each row now says which term is being served, how long is
// left, and -- while only watching -- what the next offence will cost, so the
// policy is visible from the list rather than buried in settings.
function bfTermLeft(secs) {
  if (secs === null || secs === undefined) return '';
  if (secs <= 0) return 'expiring';
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  if (h >= 24) return Math.floor(h / 24) + 'd ' + (h % 24) + 'h left';
  if (h > 0)   return h + 'h ' + m + 'm left';
  return m + 'm left';
}

function bfStatusBadge(r) {
  const strike = Number(r.offences || 0);
  const nth = strike > 0 ? ` &middot; offence ${strike}` : '';
  const dim = (t) => `<span class="dim" style="font-size:.72rem">${t}</span>`;

  if (Number(r.blocked)) {
    if (Number(r.permanent)) {
      return `<span class="badge badge-red">Blocked &middot; permanent</span>` + dim(nth);
    }
    return `<span class="badge badge-red">Blocked</span>`
         + dim(` ${esc(bfTermLeft(r.expires_in))}${nth}`);
  }

  // NOT blocked — and the reason matters more than the fact.
  //
  // Every one of these used to render as "Watching", which reads as a
  // deliberate choice to observe. Three of the four mean the product is not
  // acting, and one of them is an outright fault. An address with 398
  // port-scan hits sat in this table labelled "Watching", and nothing on the
  // page could tell you whether that was policy or a broken firewall.
  const why = esc(String(r.state_reason || ''));

  // Someone else is already blocking it. The server IS protected from this
  // address, which matters far more than whose rule did it — and saying
  // "Not blocked" here is how this module came to look useless on a box
  // where lfd had been doing the work all along.
  if (r.state === 'blocked_external') {
    const by = /lfd/i.test(String(r.state_reason || '')) ? 'lfd' : 'CSF';
    return `<span class="badge badge-green" title="${esc(String(r.state_reason || ''))}">`
         + `Blocked by ${by}</span>` + dim(nth);
  }
  // And the reason our own blocks will never stick for this address.
  if (r.state === 'allowlisted_csf') {
    return `<span class="badge badge-blue" title="${esc(String(r.state_reason || ''))}">`
         + `In csf.allow</span>`
         + dim(` &middot; CSF will not deny it${nth}`);
  }

  if (r.state === 'block_failed') {
    // The reason lives in the banner above the table, once. Repeating it on
    // every row made the column unreadable and the table twice as tall.
    return `<span class="badge badge-red" title="${why || 'The firewall refused the block'}">`
         + `Not blocked</span>` + dim(nth);
  }
  if (r.state === 'monitor_only') {
    return `<span class="badge badge-amber" title="This address earned a block, but `
         + `auto-block is switched off in Brute Force settings.">Would block</span>`
         + dim(` &middot; auto-block is off${nth}`);
  }
  if (r.state === 'allowlisted') {
    return `<span class="badge badge-blue" title="On your allow list — never blocked, `
         + `however it behaves.">Allow-listed</span>` + dim(nth);
  }

  // Genuinely still under the threshold. Say what the threshold IS, so
  // "watching" is a number rather than a mood.
  const t = Number(r.threshold || 0);
  const w = Number(r.window_mins || 0);
  const gate = t ? ` &middot; blocks at ${t} in ${w}m` : '';
  const next = r.next_term ? ` &middot; next: ${esc(String(r.next_term))}` : '';
  return `<span class="badge badge-amber" title="Below the auto-block threshold.">`
       + `Watching</span>` + dim(`${gate}${next}${nth}`);
}

// One message when the firewall is refusing blocks.
//
// "the firewall refused the block" on every row is noise: it is alarming,
// repetitive, and does not say what to DO. Collapsed into a single banner
// naming the reason and the usual cause, the per-row badge can stay short.
function bfBlockAlert(rows) {
  const box = g('bf-block-alert');
  if (!box) return;

  const failed = (rows || []).filter(r => r.state === 'block_failed');
  if (failed.length < 1) { box.classList.add('hidden'); return; }

  // If CSF is in TESTING mode, that is the answer and nothing else matters:
  // it writes every rule we ask for and a cron flushes them minutes later,
  // so "blocked" and "not blocked" are equally meaningless until it is off.
  const csf = (State.bfCsf || {});
  if (csf.testing) {
    box.innerHTML =
        `<div style="font-weight:700;color:var(--red);margin-bottom:5px">`
      + `CSF is in TESTING mode</div>`
      + `<div><code>TESTING = "1"</code> in <code>/etc/csf/csf.conf</code>. CSF `
      + `writes the rules it is given and a cron job flushes them a few minutes `
      + `later, so <strong>no block of any kind will hold</strong> — ours or `
      + `lfd's. Set <code>TESTING = "0"</code> and run <code>csf -r</code>.</div>`;
    box.classList.remove('hidden');
    return;
  }

  // The distinct reasons, because two different failures are two problems.
  const reasons = Array.from(new Set(
    failed.map(r => String(r.state_reason || '').trim()).filter(Boolean)));
  const noBackend = reasons.some(x => /no firewall backend/i.test(x));

  box.innerHTML =
      `<div style="font-weight:700;color:var(--red);margin-bottom:5px">`
    + `${failed.length} address${failed.length === 1 ? '' : 'es'} could not be blocked</div>`
    + (reasons.length
        ? `<div class="mono" style="font-size:.76rem;margin-bottom:7px">`
          + reasons.slice(0, 3).map(esc).join('<br>') + `</div>`
        : '')
    + (noBackend
        ? `<div>ServerScrub could not find a firewall to talk to. On a cPanel `
          + `server with CSF this is almost always because the panel process `
          + `runs without <code>/usr/sbin</code> on its PATH, which 4.16.2 `
          + `fixes. If it persists, check that <code>/etc/csf</code> exists and `
          + `that <code>csf -d &lt;ip&gt;</code> works from a root shell.</div>`
        : `<div>The firewall rejected these rules. The message above is the `
          + `firewall's own; running the equivalent command from a root shell `
          + `will usually reproduce it.</div>`)
    + `<div class="dim" style="margin-top:6px;font-size:.78rem">`
    + `Until this is resolved, detection is still running but `
    + `<strong>nothing is being blocked</strong>.</div>`;
  box.classList.remove('hidden');
}



// Spam Monitor's QUEUE and FROZEN cards cross to the Mail Queue section.
//
// The queue used to be duplicated inside Spam Monitor, which meant two
// listings of the same thing with different capabilities -- and the lesser one
// was the one an operator met first.
function goMailQueue(frozen) {
  const st = g('mq-state');
  if (st) { st.value = frozen ? 'frozen' : 'any'; }
  const item = document.querySelector('.sidebar-item[data-page="mailqueue"]');
  if (item) { item.click(); } else if (typeof showPage === 'function') { showPage('mailqueue'); }
}



// ── Firewall rules, paged ───────────────────────────────────────────────────
//
// This table used to render EVERY rule. On a live server that was 343,000 of
// them, turned into table markup in one innerHTML assignment — which is not
// slow, it is fatal: the tab stops responding long before the request
// finishes, and the page "takes forever to load" with no clue why.
//
// Nothing needs all of them at once. 100 a page, loaded on request, and a
// search — because with six figures of rules, paging to the one you want is
// not a realistic way to find it.
const FwRules = { offset: 0, limit: 100, total: 0, search: '' };
const FW_RULES_KEY = 'sg.firewall.rulesPageSize';
const FW_RULES_SIZES = [100, 250, 500];

function fwRulesPageSize() {
  let n = 0;
  try { n = parseInt(sessionStorage.getItem(FW_RULES_KEY) || '', 10) || 0; }
  catch (e) { n = 0; }
  return FW_RULES_SIZES.includes(n) ? n : 100;
}

function fwRulesSetSize(v) {
  const n = FW_RULES_SIZES.includes(Number(v)) ? Number(v) : 100;
  try { sessionStorage.setItem(FW_RULES_KEY, String(n)); } catch (e) { /* not fatal */ }
  FwRules.limit = n;
  // Page 3 of 100 is not page 3 of 500; landing past the end shows nothing.
  FwRules.offset = 0;
  loadFirewallRules();
}

function fwRulesPage(dir) {
  FwRules.offset = Math.max(0, FwRules.offset + dir * FwRules.limit);
  loadFirewallRules();
}

function fwRulesSearch() {
  FwRules.search = (g('fw-rules-search')?.value || '').trim();
  FwRules.offset = 0;
  loadFirewallRules();
}

function fwRulesReset() {
  const box = g('fw-rules-search');
  if (box) { box.value = ''; }
  FwRules.search = '';
  FwRules.offset = 0;
  loadFirewallRules();
}

/**
 * Fetch and render one page.
 *
 * Shows the product's own spinner while it runs. A table that simply sits
 * there is indistinguishable from one that has broken — which is precisely
 * how 343,000 rules presented itself.
 */
async function loadFirewallRules() {
  const tbody = g('fw-rules-body');
  if (!tbody) return;

  FwRules.limit = fwRulesPageSize();
  const sizeSel = g('fw-rules-size');
  if (sizeSel) { sizeSel.value = String(FwRules.limit); }

  tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:26px">'
    + '<span class="sg-spin" aria-hidden="true"></span>'
    + '<span class="dim" style="margin-left:9px">Loading rules…</span></td></tr>';

  const res = Demo.active
    ? Demo.mockFWRules()
    : await API.fwRules(FwRules.limit, FwRules.offset, FwRules.search)
              .catch(() => null);

  // Demo still returns a bare array; accept both rather than break it.
  const d = (res && res.data) || {};
  const rows = Array.isArray(d) ? d : (d.items || []);
  FwRules.total = Array.isArray(d) ? rows.length : Number(d.total || 0);

  setText('fw-rules-count', FwRules.total
    ? fmtNum(FwRules.total) + (FwRules.search ? ' matching' : ' rule(s)')
    : '');

  if (!res) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--red);'
                    + 'padding:20px">Could not load rules.</td></tr>';
    fwRulesNote(0);
    return;
  }
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--txt3);'
      + 'padding:20px">' + (FwRules.search
          ? 'No rule matches “' + esc(FwRules.search) + '”.'
          : 'No rules.') + '</td></tr>';
    fwRulesNote(0);
    return;
  }

  // esc() on every field. A rule name is operator input, and on a server with
  // an imported deny list it is whatever that list contained.
  tbody.innerHTML = rows.map(r => `
    <tr>
      <td class="primary">${esc(r.name || '')}</td>
      <td>${esc(r.direction || '')}</td>
      <td class="mono">${esc(r.protocol || '—')}</td>
      <td class="mono">${esc(r.port || 'any')}</td>
      <td>${actionBadge(r.action)}</td>
      <td>
        <label class="toggle">
          <input type="checkbox" ${r.enabled ? 'checked' : ''}
                 onchange="toggleRule(${Number(r.id) || 0}, this.checked)">
          <span class="toggle-slider"></span>
        </label>
      </td>
      <td>
        <button class="btn btn-ghost btn-xs" onclick="deleteRule(${Number(r.id) || 0})">✕</button>
      </td>
    </tr>`).join('');

  fwRulesNote(rows.length);
}

function fwRulesNote(shown) {
  const from = FwRules.total ? FwRules.offset + 1 : 0;
  setText('fw-rules-note', FwRules.total
    ? 'Showing ' + fmtNum(from) + '–' + fmtNum(FwRules.offset + shown)
      + ' of ' + fmtNum(FwRules.total)
    : '');
  const prev = g('fw-rules-prev'), next = g('fw-rules-next');
  if (prev) prev.disabled = FwRules.offset <= 0;
  if (next) next.disabled = FwRules.offset + shown >= FwRules.total;
}

// ── Bot Shield paging ───────────────────────────────────────────────────────
//
// Both tables used to fetch a fixed slab and render it. Recent Bot Events was
// the worse of the two: the server returned up to 100 rows and the renderer
// did `events.slice(0, 50)`, so a box with thousands of events showed fifty
// and said nothing. A table that shows part of the data without saying so
// invites the wrong conclusion — that there is nothing more to see.
//
// Page size is a READING preference, not server configuration, so it lives in
// sessionStorage: it survives moving around the panel, and it is gone when the
// browser session ends. Every access is wrapped, because sessionStorage throws
// in a private window and returns nothing with site data blocked — neither of
// which should break a table.
const BOT_PAGE_KEY = 'sg.botshield.pagesize';
const BOT_PAGE_SIZES = [50, 100, 200, 500];
const BotPage = { blocked: { offset: 0, total: 0 }, events: { offset: 0, total: 0 } };

function botPageSize() {
  let n = 0;
  try { n = parseInt(sessionStorage.getItem(BOT_PAGE_KEY) || '', 10) || 0; }
  catch (e) { n = 0; }
  // Clamped to the offered sizes, so a hand-edited value cannot ask the server
  // for something it will refuse anyway.
  return BOT_PAGE_SIZES.includes(n) ? n : 50;
}

function botSetPageSize(v) {
  const n = BOT_PAGE_SIZES.includes(Number(v)) ? Number(v) : 50;
  try { sessionStorage.setItem(BOT_PAGE_KEY, String(n)); } catch (e) { /* not fatal */ }
  // Both selectors show the same value: one setting, two places to change it.
  document.querySelectorAll('.bot-page-size').forEach(s => { s.value = String(n); });
  // A size change invalidates the current offsets — page 3 of 50 is not page 3
  // of 500, and landing past the end would show an empty table.
  BotPage.blocked.offset = 0;
  BotPage.events.offset = 0;
  loadBotBlocked();
  loadBotEvents();
}

function botSyncPageSelectors() {
  const n = String(botPageSize());
  document.querySelectorAll('.bot-page-size').forEach(s => { s.value = n; });
}

/* Shared by every paged table: Bot Shield's two, and the WAF event log.
 * Named for Bot Shield because that is where it was written; kept under that
 * name rather than renamed across four call sites for the sake of a prefix. */
function botPagerNote(prefix, state, shown) {
  const from = state.total ? state.offset + 1 : 0;
  setText(prefix + '-note', state.total
    ? 'Showing ' + fmtNum(from) + '–' + fmtNum(state.offset + shown)
      + ' of ' + fmtNum(state.total)
    : '');
  const prev = g(prefix + '-prev'), next = g(prefix + '-next');
  if (prev) prev.disabled = state.offset <= 0;
  if (next) next.disabled = state.offset + shown >= state.total;
}

function botBlockedPage(dir) {
  BotPage.blocked.offset = Math.max(0, BotPage.blocked.offset + dir * botPageSize());
  loadBotBlocked();
}

function botEventsPage(dir) {
  BotPage.events.offset = Math.max(0, BotPage.events.offset + dir * botPageSize());
  loadBotEvents();
}

async function loadBotBlocked() {
  const tbody = g('bot-blocked-body');
  if (!tbody) return;
  botSyncPageSelectors();

  const res = Demo.active
    ? { success: true, data: { items: [], total: 0 } }
    : await API.botBlocked(botPageSize(), BotPage.blocked.offset);

  const d = (res && res.data) || {};
  const rows = d.items || [];
  BotPage.blocked.total = Number(d.total || 0);

  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--txt3);'
                    + 'padding:20px">No blocked bots. Click "Analyze Logs".</td></tr>';
    botPagerNote('botBlocked', BotPage.blocked, 0);
    return;
  }

  // esc() on every field. These come from web logs, so the user-agent is
  // whatever a stranger sent — interpolating it raw put attacker-controlled
  // text straight into the page.
  tbody.innerHTML = rows.map((b, i) => `
    <tr>
      <td class="mono">${esc(b.ip_address || '')}</td>
      <td>
        <span class="badge badge-red" style="font-size:.65rem">${esc(b.threat_type || 'unclassified')}</span>
        <div class="dim" style="font-size:.68rem;margin-top:3px;line-height:1.3"
             title="${esc(b.user_agent || 'no user agent')}">${esc(b.description || '')}</div>
      </td>
      <td>${fmtNum(b.hits || 1)}</td>
      <td class="dim">${b.last_seen ? reltime(b.last_seen) : '-'}</td>
      <td><button class="btn btn-ghost btn-xs"
                  onclick="unblockBotAt(${i})">Unblock</button></td>
    </tr>`).join('');

  State.botBlockedRows = rows;
  botPagerNote('botBlocked', BotPage.blocked, rows.length);
}

async function loadBotEvents() {
  const tbody = g('bot-events-body');
  if (!tbody) return;
  botSyncPageSelectors();

  const res = Demo.active
    ? { success: true, data: { items: [], total: 0 } }
    : await API.botEvents(botPageSize(), BotPage.events.offset);

  const d = (res && res.data) || {};
  const rows = d.items || [];
  BotPage.events.total = Number(d.total || 0);

  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--txt3);'
                    + 'padding:20px">No events yet</td></tr>';
    botPagerNote('botEvents', BotPage.events, 0);
    return;
  }

  // No .slice() here. The server decides the page; truncating again in the
  // browser is how fifty of a hundred rows went missing without a word.
  tbody.innerHTML = rows.map(e => {
    const ua = String(e.user_agent || '-');
    return `
    <tr>
      <td class="mono">${esc(e.ip_address || '')}</td>
      <td class="mono" style="font-size:.7rem;max-width:200px;overflow:hidden;
          text-overflow:ellipsis;white-space:nowrap"
          title="${esc(ua)}">${esc(ua.slice(0, 50))}</td>
      <td title="${esc(e.description || '')}"><span class="badge badge-amber"
          style="font-size:.65rem">${esc(e.threat_type || 'unclassified')}</span></td>
      <td class="mono" style="font-size:.72rem">${esc(e.uri || '-')}</td>
      <td class="dim">${reltime(e.timestamp)}</td>
      <td><span class="badge ${e.action === 'block' ? 'badge-red' : 'badge-gray'}"
                style="font-size:.65rem">${esc(e.action || 'block')}</span></td>
    </tr>`;
  }).join('');

  botPagerNote('botEvents', BotPage.events, rows.length);
}

// Index, never an address interpolated into an attribute.
async function unblockBotAt(index) {
  const row = (State.botBlockedRows || [])[Number(index)];
  if (!row) { toast('Could not resolve that row — refresh', 'error'); return; }
  await unblockBot(row.ip_address);
}

// ── HTTP flood / scanner detection ──────────────────────────────────────────
//
// Built after a single address took all eight cores of a live server to load
// 22 with 1.2% idle while this product reported nothing. Every request it sent
// was a 404, so there were no failed logins, no malware on disk and no error
// spike — but on WordPress a 404 is a full PHP boot.
async function loadHttpFlood() {
  const r = await API.hfStatus();
  const d = (r && r.data) || {};

  const set = (id, v) => { const e = g(id); if (e) e.value = v; };
  const chk = (id, v) => { const e = g(id); if (e) e.checked = !!v; };
  chk('hf-enabled', d.enabled);
  chk('hf-monitor', d.monitor_only);
  set('hf-window',    d.window || 300);
  set('hf-miss',      d.miss_threshold || 100);
  set('hf-rate',      d.rate_threshold || 600);
  set('hf-endpoint',  d.endpoint_threshold || 200);
  set('hf-blocksecs', d.block_secs || 3600);

  const st = g('hf-state');
  if (st) {
    st.textContent = !d.enabled ? '— switched off'
      : (d.monitor_only ? '— monitor only, nothing is blocked'
                        : '— blocking enabled')
        + (d.logs_found ? ' · ' + d.logs_found + ' log(s)' : ' · no web logs found')
        + (d.last_run ? ' · last scan ' + reltime(d.last_run) : ' · never scanned');
    st.style.color = !d.enabled ? 'var(--txt3)'
      : (d.monitor_only || !d.logs_found) ? 'var(--amber)' : 'var(--ok)';
  }

  // State who can never be blocked. An automatic blocker that locks the
  // administrator out of the server it defends has done more damage than the
  // attack, so this is shown rather than assumed.
  const prot = g('hf-protected');
  if (prot) {
    const list = d.protected || {};
    const keys = Object.keys(list);
    prot.innerHTML = keys.length
      ? 'Never blocked: ' + keys.slice(0, 12).map(ip =>
          '<span class="mono" title="' + esc(list[ip]) + '">' + esc(ip) + '</span>').join(', ')
        + (keys.length > 12 ? ' and ' + (keys.length - 12) + ' more' : '')
      : '<span style="color:var(--amber)">Nothing is protected from blocking — '
        + 'add your own address to the Brute Force allow list before enabling '
        + 'blocking.</span>';
  }

  await hfAnalyse();
}

async function hfAnalyse() {
  const tb = g('hf-findings');
  if (!tb) return;
  const r = await API.hfAnalyse();
  const d = (r && r.data) || {};
  const rows = d.findings || [];
  State.hfFindings = rows;

  if (!rows.length) {
    tb.innerHTML = '<tr><td colspan="6" class="dim" style="text-align:center;padding:18px">'
      + 'Nothing above the thresholds in the last '
      + Math.round((d.window || 300) / 60) + ' minute(s)'
      + (d.scanned ? ' (' + fmtNum(d.scanned) + ' requests read from '
                     + (d.logs || 0) + ' log(s))' : '')
      + '.</td></tr>';
  } else {
    tb.innerHTML = rows.map((f, i) => {
      const badge = f.kind === 'scanner'
        ? '<span class="badge badge-red">scanner</span>'
        : '<span class="badge badge-amber">rate</span>';
      return '<tr>'
        + '<td class="mono">' + esc(f.ip) + '</td>'
        + '<td>' + badge + '</td>'
        + '<td style="font-size:.8rem">' + esc(f.reason) + '</td>'
        + '<td>' + fmtNum(f.vhosts || 0) + '</td>'
        + '<td>' + (d.monitor_only
            ? '<span class="badge badge-gray" title="Monitor only is on, so '
              + 'nothing is blocked">would block</span>'
            : '<span class="badge badge-blue">will block</span>') + '</td>'
        + '<td><button class="btn btn-ghost btn-xs" onclick="hfAllow(' + i + ')"'
        + ' title="Add to the Brute Force allow list so it is never blocked">'
        + 'Never block</button></td>'
        + '</tr>';
    }).join('');
  }

  const ep = g('hf-endpoints');
  if (ep) {
    const list = d.endpoints || [];
    ep.innerHTML = list.length
      ? list.map(e =>
          '<div style="padding:6px 0;border-bottom:1px solid var(--bd)">'
          + '<span class="mono">' + esc(e.path) + '</span> — '
          + '<strong>' + fmtNum(e.total) + '</strong> request(s) from '
          + fmtNum(e.sources) + ' address(es)'
          + '<div class="dim" style="font-size:.74rem">'
          + Object.keys(e.top || {}).slice(0, 6).map(ip =>
              esc(ip) + ' (' + e.top[ip] + ')').join(', ')
          + '</div></div>').join('')
      : '<span class="dim">None above the threshold. A distributed flood shows '
        + 'here even when no single address is busy enough to stand out.</span>';
  }
}

async function hfRun() {
  const btn = g('hf-run');
  if (btn) { btn.disabled = true; btn.textContent = 'Scanning…'; }
  const r = await API.hfRun();
  if (btn) { btn.disabled = false; btn.textContent = 'Scan logs now'; }

  if (!r || r.success === false) {
    toast((r && r.error) || 'Scan failed', 'error', 8000);
    return;
  }
  if (r.skipped) { toast(r.skipped, 'info', 6000); return; }

  const bits = [fmtNum(r.scanned || 0) + ' request(s) read'];
  if (r.findings)  bits.push(fmtNum(r.findings) + ' address(es) over threshold');
  if (r.blocked)   bits.push(fmtNum(r.blocked) + ' blocked');
  if (r.monitor_only && r.findings) bits.push('monitor only — nothing blocked');
  toast(bits.join(', '), r.blocked ? 'success' : 'info', 9000);

  // A refused block must never be silent. This product spent a week saying
  // "Watching" against addresses it had never managed to block.
  const failed = r.failed || [];
  if (failed.length) {
    await uiAlert({
      title: 'Addresses that could not be blocked',
      body: '<p style="margin:0 0 8px">The detection worked; the firewall did '
          + 'not accept the rule. The message below is the firewall\'s own.</p>',
      pre: failed.slice(0, 20).map(f => f.ip + '  ' + f.error).join('\n')
    });
  }
  await loadHttpFlood();
}

async function hfSave() {
  const num = (id, d) => parseInt(g(id)?.value, 10) || d;
  const r = await API.hfSave({
    hf_enabled:            g('hf-enabled')?.checked ? '1' : '0',
    hf_monitor_only:       g('hf-monitor')?.checked ? '1' : '0',
    hf_window:             String(num('hf-window', 300)),
    hf_miss_threshold:     String(num('hf-miss', 100)),
    hf_rate_threshold:     String(num('hf-rate', 600)),
    hf_endpoint_threshold: String(num('hf-endpoint', 200)),
    hf_block_secs:         String(num('hf-blocksecs', 3600)),
  });
  if (r && r.success) {
    toast('Saved', 'success');
    // Reload from the server: thresholds are clamped there, and the panel
    // must never display a value the detector is not actually using.
    await loadHttpFlood();
  } else {
    toast((r && r.error) || 'Could not save', 'error');
  }
}

// Index, never an address interpolated into an attribute.
async function hfAllow(index) {
  const f = (State.hfFindings || [])[Number(index)];
  if (!f) { toast('Could not resolve that row — refresh', 'error'); return; }

  const ok = await uiConfirm({
    title: 'Never block ' + f.ip + '?',
    ok: 'Add to allow list',
    body: '<p style="margin:0 0 8px">Adds it to the <strong>Brute Force allow '
        + 'list</strong>, which governs both modules, so it will not be blocked '
        + 'by either however it behaves.</p>'
        + '<p style="margin:0;color:var(--txt3);font-size:.8rem">'
        + esc(f.reason) + '</p>'
  });
  if (!ok) return;

  const cur = await API.bfStats();
  const existing = String((cur && cur.data && cur.data.whitelist) || '').trim();
  const next = existing ? existing + ', ' + f.ip : f.ip;
  const r = await API.bfSave({ bf_whitelist: next });
  if (r && r.success) {
    toast(f.ip + ' added to the allow list', 'success', 7000);
    await loadHttpFlood();
  } else {
    toast((r && r.error) || 'Could not update the allow list', 'error');
  }
}

// ── Mail Queue ──────────────────────────────────────────────────────────────
//
// A working queue manager, separate from Spam Monitor on purpose. Spam Monitor
// answers "who is sending too much, from which script". This answers "find me
// that one message among nine thousand and tell me whether it goes out".
//
// Filtering runs against a snapshot cached server-side, so refining a search or
// paging does not re-run `exim -bp`. A UI that re-reads the whole queue for
// every keystroke is unusable exactly when the queue is big enough to need
// searching.
const MQ = { offset: 0, limit: 100, matched: 0 };

function mqFilters(refresh) {
  return {
    direction: g('mq-direction')?.value || 'any',
    state:     g('mq-state')?.value || 'any',
    field:     g('mq-field')?.value || '',
    op:        g('mq-op')?.value || 'contains',
    text:      (g('mq-text')?.value || '').trim(),
    negate:    g('mq-negate')?.checked ? 1 : '',
    older:     parseInt(g('mq-older')?.value, 10) || 0,
    sort:      g('mq-sort')?.value || 'newest',
    limit:     MQ.limit,
    offset:    MQ.offset,
    refresh:   refresh ? 1 : '',
  };
}

async function loadMailQueue() {
  const r = await API.mqSummary();
  const d = (r && r.data) || {};
  setText('mq-stat-total',  fmtNum(d.total || 0));
  setText('mq-stat-in',     fmtNum(d.inbound || 0));
  setText('mq-stat-out',    fmtNum(d.outbound || 0));
  setText('mq-stat-frozen', fmtNum(d.frozen || 0));
  setText('mq-stat-bounce', (d.bounce || 0) + ' bounce(s)');
  setText('mq-stat-oldest', d.oldest_mins
    ? 'oldest ' + mqAge(d.oldest_mins) : ' ');

  const note = g('mq-snap-note');
  if (note) {
    if (d.error) {
      note.textContent = '— ' + d.error;
      note.style.color = 'var(--red)';
    } else if (!d.local_domains) {
      // Without /etc/localdomains we cannot tell inbound from outbound, and
      // guessing would be worse than saying so.
      note.textContent = '— /etc/localdomains is unreadable, so inbound and '
                       + 'outbound cannot be told apart';
      note.style.color = 'var(--amber)';
    } else {
      note.textContent = d.built_at
        ? '— snapshot ' + reltime(d.built_at) + (d.cached ? ' (cached)' : '')
        : '';
      note.style.color = '';
    }
  }
  await mqSearch(MQ.offset);
}

function mqAge(mins) {
  mins = Number(mins) || 0;
  if (mins >= 1440) return Math.floor(mins / 1440) + 'd';
  if (mins >= 60)   return Math.floor(mins / 60) + 'h';
  return mins + 'm';
}

async function mqSearch(offset) {
  MQ.offset = Math.max(0, Number(offset) || 0);
  const tb = g('mq-body');
  if (!tb) return;

  const r = await API.mqSearch(mqFilters(false));
  const d = (r && r.data) || {};
  const rows = d.messages || [];
  MQ.matched = d.matched || 0;

  setText('mq-count', d.error ? d.error
    : fmtNum(d.matched || 0) + ' of ' + fmtNum(d.total || 0) + ' matching');

  // A search that quietly examined only part of the queue would be worse than
  // one that refuses, so say when the cap was reached.
  const deep = g('mq-deep-note');
  if (deep) {
    deep.textContent = d.deep_truncated
      ? 'Subject search stopped after ' + fmtNum(d.deep_limit)
        + ' messages — narrow the other filters first'
      : '';
    deep.style.color = 'var(--amber)';
  }

  if (!rows.length) {
    tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--txt3);'
                 + 'padding:24px">' + (d.error ? esc(d.error) : 'No matching messages.')
                 + '</td></tr>';
    mqUpdateBar();
    mqPageNote(0);
    return;
  }

  State.mqRows = rows;
  tb.innerHTML = rows.map((m, i) => {
    const rcpt = m.recipients || [];
    const shown = rcpt.slice(0, 3).map(x =>
      (x.delivered
        // Already delivered for this message. Listing it as pending tells the
        // operator the opposite of the truth.
        ? '<span class="dim" title="already delivered">&check; ' + esc(x.address) + '</span>'
        : esc(x.address))).join('<br>');
    const more = rcpt.length > 3
      ? '<br><span class="dim">+' + (rcpt.length - 3) + ' more</span>' : '';
    const dir = m.direction === 'outbound'
      ? '<span class="badge badge-amber">out</span>'
      : m.direction === 'inbound'
        ? '<span class="badge badge-green">in</span>'
        : m.direction === 'mixed'
          ? '<span class="badge badge-blue">mixed</span>'
          : '<span class="badge badge-gray">?</span>';
    const state = m.frozen
      ? '<span class="badge badge-red">frozen</span>'
      : (m.bounce ? '<span class="badge badge-gray">bounce</span>'
                  : '<span class="badge badge-blue">queued</span>');
    return '<tr>'
      + '<td><input type="checkbox" class="mq-pick" value="' + esc(m.id) + '"'
        + ' data-frozen="' + (m.frozen ? '1' : '0') + '" onchange="mqUpdateBar()"></td>'
      + '<td>' + esc(m.age || '') + '</td>'
      + '<td>' + esc(m.size || '') + '</td>'
      + '<td class="mono" style="max-width:190px;overflow:hidden;text-overflow:ellipsis;'
        + 'white-space:nowrap" title="' + esc(m.sender || '') + '">' + esc(m.sender || '') + '</td>'
      + '<td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"'
        + ' title="' + esc(m.subject || '') + '">'
        + (m.subject ? esc(m.subject) : '<span class="dim">(no subject)</span>') + '</td>'
      + '<td style="max-width:220px;font-size:.8rem">' + shown + more + '</td>'
      + '<td>' + dir + '</td>'
      + '<td>' + state + '</td>'
      + '<td style="white-space:nowrap">'
        + '<button class="btn btn-ghost btn-xs" onclick="viewMessage(\'' + esc(m.id) + '\')"'
        + ' title="Sender, recipients, subject, attachments and the first 1,000 characters">View</button> '
        + '<button class="btn btn-ghost btn-xs" onclick="mqLog(' + i + ')"'
        + ' title="What the exim main log says about this message">Log</button>'
      + '</td>'
      + '</tr>';
  }).join('');

  mqUpdateBar();
  mqPageNote(rows.length);
}

function mqPageNote(shown) {
  const from = MQ.matched ? MQ.offset + 1 : 0;
  setText('mq-page-note', MQ.matched
    ? 'Showing ' + fmtNum(from) + '–' + fmtNum(MQ.offset + shown)
      + ' of ' + fmtNum(MQ.matched) : '');
  const prev = g('mq-prev'), next = g('mq-next');
  if (prev) prev.disabled = MQ.offset <= 0;
  if (next) next.disabled = MQ.offset + shown >= MQ.matched;
}

function mqPage(dir) {
  mqSearch(MQ.offset + dir * MQ.limit);
}

function mqReset() {
  ['mq-direction', 'mq-state', 'mq-field', 'mq-sort'].forEach(id => {
    const e = g(id); if (e) e.selectedIndex = 0;
  });
  const t = g('mq-text'); if (t) t.value = '';
  const o = g('mq-older'); if (o) o.value = '0';
  const n = g('mq-negate'); if (n) n.checked = false;
  mqSearch(0);
}

// The stat cards are filters, which is the quickest way to the answer most of
// the time: "show me what is stuck going out".
function mqQuick(which) {
  const dir = g('mq-direction'), st = g('mq-state');
  if (which === 'frozen') {
    if (dir) dir.value = 'any';
    if (st)  st.value = 'frozen';
  } else {
    if (dir) dir.value = which;
    if (st)  st.value = 'any';
  }
  mqSearch(0);
}

async function mqRefresh() {
  // Rebuild the server-side snapshot rather than reading the cached one.
  await API.mqSearch(mqFilters(true));
  await loadMailQueue();
}

function mqToggleAll(on) {
  document.querySelectorAll('.mq-pick').forEach(c => { c.checked = !!on; });
  mqUpdateBar();
}

function mqSelected() {
  return Array.from(document.querySelectorAll('.mq-pick:checked')).map(c => c.value);
}

function mqUpdateBar() {
  const ids = mqSelected();
  // BY CLASS, so a bulk action added later works without anyone editing this.
  document.querySelectorAll('.mq-action').forEach(b => { b.disabled = ids.length === 0; });
  setText('mq-selected', ids.length ? ids.length + ' selected' : '');
}

async function mqDeliver() {
  const picked = Array.from(document.querySelectorAll('.mq-pick:checked'));
  const ids = picked.map(c => c.value);
  if (!ids.length) { toast('Select some messages first', 'info'); return; }
  const frozen = picked.filter(c => c.dataset.frozen === '1').length;

  const ok = await uiConfirm({
    title: 'Deliver ' + ids.length + ' message(s) now?',
    ok: 'Deliver now',
    body: '<p style="margin:0 0 10px">Exim attempts delivery <strong>immediately</strong>, '
        + 'ignoring the retry schedule.</p>'
        + (frozen ? '<p style="margin:0 0 10px;color:var(--amber)"><strong>' + frozen
            + ' of these are frozen.</strong> Delivering a frozen message also '
            + '<strong>unfreezes</strong> it.</p>' : '')
        + '<p style="margin:0;color:var(--txt3);font-size:.8rem">These messages leave '
        + 'your server. Check the senders and recipients first.</p>'
  });
  if (!ok) return;

  toast('Attempting delivery of ' + ids.length + ' message(s)…', 'info', 4000);
  const r = await API.mqDeliver(ids);
  const d = (r && r.data) || {};
  if (!r || r.success === false) {
    toast((r && r.error) || 'Delivery refused', 'error', 9000); return;
  }
  if (d.error) { toast(d.error, 'error', 9000); return; }

  const bits = [];
  if (d.delivered) bits.push(fmtNum(d.delivered) + ' delivered');
  if (d.deferred)  bits.push(fmtNum(d.deferred) + ' still queued');
  if (d.skipped)   bits.push(fmtNum(d.skipped) + ' not attempted (time budget)');
  toast(bits.join(', ') || 'Nothing changed',
        d.delivered ? 'success' : 'warning', 10000);
  await loadMailQueue();
}

async function mqDelete() {
  const ids = mqSelected();
  if (!ids.length) { toast('Select some messages first', 'info'); return; }

  const ok = await uiConfirm({
    title: 'Permanently delete ' + ids.length + ' message(s)?',
    ok: 'Delete permanently',
    danger: true,
    body: '<p style="margin:0 0 10px">This removes them from the queue. '
        + '<strong>It cannot be undone.</strong></p>'
        + '<p style="margin:0;color:var(--txt3);font-size:.8rem">A queue that filled '
        + 'up with spam usually still contains real customer mail.</p>'
  });
  if (!ok) return;

  const r = await API.mqDelete(ids);
  const d = (r && r.data) || {};
  if (!r || r.success === false) {
    toast((r && r.error) || 'Delete refused', 'error', 9000); return;
  }
  const failed = (d.failed || []).length;
  toast('Deleted ' + fmtNum(d.deleted || 0) + ' message(s)'
      + (failed ? '; ' + failed + ' could not be removed' : ''),
        failed ? 'warning' : 'success', 8000);
  await loadMailQueue();
}

// What the main log says about one message. Index, never an id interpolated
// into an attribute beyond the plain alphanumeric message id.
async function mqLog(index) {
  const m = (State.mqRows || [])[Number(index)];
  if (!m) { toast('Could not resolve that row — search again', 'error'); return; }
  const r = await API.mqLog(m.id);
  const d = (r && r.data) || {};
  if (!d.success) { toast(d.error || 'Could not read the log', 'error'); return; }
  await uiAlert({
    title: 'Delivery log — ' + m.id,
    body: d.note
      ? '<p style="margin:0 0 8px;color:var(--amber)">' + esc(d.note) + '</p>'
      : '<p style="margin:0 0 8px;color:var(--txt3);font-size:.8rem">From '
        + esc(d.searched || '') + '</p>',
    pre: d.log || '(nothing)'
  });
}

// ── Spam Monitor tabs ───────────────────────────────────────────────────────
//
// The page was five stacked cards mixing live mail, policy and history, so the
// thing an operator came for was never on screen. The KPI row stays visible on
// every tab: those four numbers are the reason to open the page at all.
let MgTab = 'findings';
let MsgViewId = '';

function mgTab(name) {
  MgTab = name;
  document.querySelectorAll('.mg-tab').forEach(b => {
    b.classList.toggle('active', b.dataset.tab === name);
  });
  document.querySelectorAll('[data-mgtab]').forEach(card => {
    const mine = card.dataset.mgtab === name;
    // Cards that manage their own visibility (the queue and findings cards
    // stay hidden until they have something to show) must not be forced open
    // by a tab switch -- that is how an empty card ends up looking broken.
    if (!mine) { card.style.display = 'none'; return; }
    // An UNSET flag used to mean "show it", which revealed the queue card with
    // nothing in it: a card stuck on "Loading…" that nobody had asked to load.
    // Cards that start hidden now declare data-mg-hidden="1" in the markup.
    card.style.display = card.dataset.mgHidden === '1' ? 'none' : '';
  });
  if (name === 'logs') { loadFlaggedAttachments(); }
}

// Cards that hide themselves record it here, so a tab switch can honour it.
function mgSetCardHidden(id, hidden) {
  const el = g(id);
  if (!el) return;
  el.dataset.mgHidden = hidden ? '1' : '0';
  el.style.display = (hidden || el.dataset.mgtab !== MgTab) ? 'none' : '';
}

// ── One message, in enough detail to judge it ───────────────────────────────
async function viewMessage(id) {
  const r = await API.mgView(id);
  const d = (r && r.data) || {};
  if (!d.success) {
    toast(d.error || 'Could not read that message', 'error', 7000);
    return;
  }
  MsgViewId = id;

  const row = (label, value) =>
    '<div class="mv-field"><div class="mv-label">' + esc(label) + '</div>'
  + '<div>' + value + '</div></div>';

  const to = (d.to || []);
  g('mv-title').textContent = 'Message ' + id;
  g('mv-meta').innerHTML =
      row('From', '<span class="mono">' + esc(d.from || '—') + '</span>')
    + row('To', to.length
        ? to.slice(0, 12).map(x => '<span class="mono">' + esc(x) + '</span>').join('<br>')
          + (to.length > 12 ? '<br><span class="dim">+' + (to.length - 12) + ' more</span>' : '')
        : '<span class="dim">—</span>')
    + row('Subject', esc(d.subject || '—'))
    + row('Date', '<span class="dim">' + esc(d.date || '—') + '</span>')
    + (Object.keys(d.source || {}).length
        ? row('Sent by', '<span class="mono" style="font-size:.76rem">'
            + Object.keys(d.source).map(k => esc(k) + ': ' + esc(d.source[k])).join('<br>')
            + '</span>')
        : '');

  renderAttachments(d.attachments || [], d.flagged || {});

  g('mv-body').textContent = d.body || '(no text part)';
  g('mv-body-note').textContent = d.body_truncated
    ? '— first ' + (d.body || '').length + ' characters'
    : '';

  openModal('msgview-modal');
}

function renderAttachments(list, flagged) {
  const box = g('mv-attachments');
  if (!box) return;
  State.mvAttachments = list;
  State.mvFlagged = flagged;

  if (!list.length) {
    box.innerHTML = '<span class="dim">None</span>';
    return;
  }
  box.innerHTML = list.map((a, i) => {
    const isFlagged = !!flagged[a.filename];
    // A hash of a truncated attachment is not that attachment's hash, so we
    // say so rather than offering a fiction for somebody to act on later.
    const hash = a.truncated
      ? '<span class="dim" title="The message was larger than the 2 MB we read, so '
        + 'this attachment is incomplete and cannot be hashed">not hashed — message too large</span>'
      : (a.sha256
          ? '<span class="mono dim" title="' + esc(a.sha256) + '">'
            + esc(a.sha256.slice(0, 16)) + '</span>'
          : '<span class="dim">—</span>');
    return '<div style="display:flex;align-items:center;gap:10px;padding:7px 0;'
         + 'border-bottom:1px solid var(--bd)">'
         + '<div style="flex:1;min-width:0">'
         + '<div class="mono" style="word-break:break-all">' + esc(a.filename)
         + (a.suspicious
             ? ' <span class="badge badge-amber" title="The extension or type is one '
               + 'commonly used to deliver malware. A hint, not a verdict.">risky type</span>'
             : '')
         + (isFlagged ? ' <span class="badge badge-red">flagged</span>' : '')
         + '</div>'
         + '<div class="dim" style="font-size:.74rem">'
         + esc(a.content_type || '') + ' · ' + fmtBytes(a.bytes || 0) + ' · ' + hash
         + '</div></div>'
         + '<button class="btn btn-ghost btn-xs" onclick="toggleAttachmentFlag(' + i + ')">'
         + (isFlagged ? 'Unflag' : 'Flag as malicious') + '</button>'
         + '</div>';
  }).join('');
}

// Index, never a filename interpolated into an attribute. A filename can
// contain a quote, and that is exactly what killed the exclude button.
async function toggleAttachmentFlag(index) {
  const a = (State.mvAttachments || [])[Number(index)];
  if (!a) { toast('Could not resolve that attachment — reopen the message', 'error'); return; }

  if ((State.mvFlagged || {})[a.filename]) {
    const r = await API.mgUnflagAttachment(MsgViewId, a.filename);
    if (r && r.success) { toast('Flag withdrawn', 'success'); await viewMessage(MsgViewId); }
    else { toast((r && r.error) || 'Could not withdraw the flag', 'error'); }
    return;
  }

  const ok = await uiConfirm({
    title: 'Flag this attachment as malicious?',
    ok: 'Flag it',
    danger: true,
    body: '<p style="margin:0 0 8px"><span class="mono">' + esc(a.filename) + '</span></p>'
        + '<p style="margin:0 0 8px">This records the attachment and its sha256 so the '
        + 'malware scanner recognises the same bytes if they ever land on disk.</p>'
        + '<p style="margin:0;color:var(--txt3);font-size:.8rem">It does <strong>not</strong> '
        + 'alter the message — exim cannot cleanly strip one part from a queued mail, and a '
        + 'half-rewritten message is worse than a flagged one. Delete the whole message from '
        + 'the queue if that is what you want.</p>'
  });
  if (!ok) return;

  const r = await API.mgFlagAttachment(MsgViewId, a.filename, a.sha256 || '',
                                       a.content_type || '', a.bytes || 0);
  if (r && r.success) {
    toast('Flagged ' + a.filename, 'success', 7000);
    await viewMessage(MsgViewId);
  } else {
    toast((r && r.error) || 'Could not flag that attachment', 'error');
  }
}

async function loadFlaggedAttachments() {
  const tb = g('mg-flagged-body');
  if (!tb) return;
  const r = await API.mgFlagged();
  const rows = (r && r.data) || [];
  State.flaggedRows = rows;
  if (!rows.length) {
    tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--txt3);'
                 + 'padding:20px">Nothing flagged.</td></tr>';
    return;
  }
  tb.innerHTML = rows.map(f =>
      '<tr>'
    + '<td class="mono" style="max-width:200px;overflow:hidden;text-overflow:ellipsis"'
    + ' title="' + esc(f.filename) + '">' + esc(f.filename) + '</td>'
    + '<td class="dim">' + esc(f.content_type || '—') + '</td>'
    + '<td class="dim">' + fmtBytes(f.bytes || 0) + '</td>'
    + '<td class="mono dim" style="font-size:.72rem" title="' + esc(f.sha256 || '') + '">'
    + esc(String(f.sha256 || '—').slice(0, 14)) + '</td>'
    + '<td class="mono dim" style="font-size:.72rem">' + esc(f.message_id) + '</td>'
    + '<td class="dim">' + esc(f.flagged_by || '—') + '</td>'
    + '<td class="dim">' + reltime(f.flagged_at) + '</td>'
    + '<td><button class="btn btn-ghost btn-xs" onclick="unflagFromLog('
    + (Number(f.id) || 0) + ')">Unflag</button></td>'
    + '</tr>').join('');
}

async function unflagFromLog(id) {
  const row = (State.flaggedRows || []).find(x => Number(x.id) === Number(id));
  if (!row) { toast('Could not resolve that row — reload', 'error'); return; }
  const r = await API.mgUnflagAttachment(row.message_id, row.filename);
  if (r && r.success) { toast('Flag withdrawn', 'success'); loadFlaggedAttachments(); }
  else { toast((r && r.error) || 'Could not withdraw the flag', 'error'); }
}

// The action has to match the state.
//
// Every row offered "Release", including rows that were never blocked. On
// those, release() does not unblock anything -- it DELETES the strike history,
// which is close to the opposite of what an operator reading "Release" on an
// address with 398 port-scan hits would expect. A row that is not blocked
// needs a way to block it, not a way to forget it.
function bfRowActions(r) {
  const ip = esc(r.ip_address);
  if (Number(r.blocked)) {
    return `<button class="btn btn-ghost btn-xs" title="Unblock at the firewall and `
         + `clear its strike history" onclick="bfRelease('${ip}')">Release</button>`;
  }
  const forget = ` <button class="btn btn-ghost btn-xs" title="Forget this address and `
       + `its strike history. It is NOT blocked, so nothing is unblocked." `
       + `onclick="bfRelease('${ip}')">Forget</button>`;

  // No Block button on an allow-listed address. Offering one directly
  // contradicts the allow list the operator configured, and acting on it
  // would be undone by the next evaluation anyway.
  if (r.state === 'allowlisted') { return forget; }

  return `<button class="btn btn-ghost btn-xs" title="Block this address now, `
       + `without waiting for the threshold" onclick="bfBlockNow('${ip}')">Block</button>`
       + forget;
}

// Block on demand. The answer to "why is this still only being watched" should
// not have to be "go to the Firewall page and retype the address".
async function bfBlockNow(ip) {
  const ok = await uiConfirm({
    title: 'Block ' + ip + '?',
    ok: 'Block now',
    danger: true,
    body: '<p style="margin:0 0 8px">Adds a firewall block immediately, without '
        + 'waiting for the auto-block threshold.</p>'
        + '<p style="margin:0;color:var(--txt3);font-size:.8rem">Check it is not '
        + 'an address you reach this server from.</p>'
  });
  if (!ok) return;

  const res = await API.fwBlockIP(ip, 'Blocked by operator from Brute Force', false);
  if (res?.success) {
    toast('Blocked ' + ip, 'success');
  } else {
    // The reason, not just "failed" -- this is the same failure that used to
    // leave rows silently reading "Watching".
    toast(res?.error || 'The firewall refused that block', 'error', 9000);
  }
  loadBruteForce();
}

async function bfRelease(ip) {
  const res = await API.bfRelease(ip);
  if (res?.success) { toast('Released ' + ip, 'success'); loadBruteForce(); }
  else { toast(res?.error || 'Could not release that address', 'error'); }
}

async function bfSave() {
  const g = (id) => document.getElementById(id);
  const status = g('bf-save-status');

  // Minutes in the UI, seconds in the settings: an operator thinks in minutes
  // and the detector works in seconds.
  const payload = {
    bf_enabled:        g('bf-set-enabled')?.checked ? '1' : '0',
    bf_auto_block:     g('bf-set-block')?.checked   ? '1' : '0',
    bf_threshold:      String(g('bf-set-threshold')?.value || '10'),
    bf_window:         String((parseInt(g('bf-set-window')?.value, 10)   || 10) * 60),
    // Hours in, seconds out. A rung of 0 means permanent and ends the ladder;
    // anything unparseable is dropped rather than silently becoming 0, which
    // would turn a typo into a permanent block.
    bf_ladder: (g('bf-set-ladder')?.value || '3, 6, 24, 0')
                 .split(',')
                 .map(x => x.trim())
                 .filter(x => x !== '' && !isNaN(Number(x)))
                 .map(x => String(Math.max(0, Math.round(Number(x) * 3600))))
                 .join(',') || '10800,21600,86400,0',
    bf_retention_days: String(g('bf-set-retention')?.value || '7'),
    bf_whitelist:      (g('bf-set-whitelist')?.value || '').trim(),
  };

  const res = await API.saveSettings(payload);
  if (status) {
    status.textContent = res?.success ? 'Saved' : (res?.error || 'Could not save');
    status.style.color = res?.success ? 'var(--ok, #22c55e)' : 'var(--red)';
    setTimeout(() => { status.textContent = ''; }, 4000);
  }
  if (res?.success) loadBruteForce();
}

// ── IP Reputation ──────────────────────────────────────────────────────────────
async function checkIP() {
  const ip = document.getElementById('iprep-ip-input')?.value?.trim();
  if (!ip) { toast('Enter an IP address', 'error'); return; }

  const container = document.getElementById('iprep-result');
  container.innerHTML = '<div class="dim" style="font-size:.8rem">Checking…</div>';

  const res = Demo.active
    ? { success: true, data: { ip, score: 78, risk: 'high', country: 'RU', asn: 'AS12345 Demo ISP', rbl_hits: ['spamhaus', 'sorbs'] } }
    : await API.ipCheck(ip);

  if (!res?.success) { container.innerHTML = `<div style="color:var(--red)">${res?.error || 'Failed'}</div>`; return; }

  const d = res.data;
  const riskCol = { critical:'var(--red)', high:'var(--red)', medium:'var(--amber)', low:'var(--green)' }[d.risk] || 'var(--blue)';

  container.innerHTML = `
    <div class="card" style="padding:16px">
      <div style="display:flex;align-items:center;gap:16px;margin-bottom:14px">
        <div style="font-size:1.5rem;font-family:var(--font-mono);font-weight:800">${d.ip}</div>
        <span class="badge" style="background:${riskCol}20;color:${riskCol};border-color:${riskCol}40">
          ${d.risk?.toUpperCase()} RISK
        </span>
        <span class="badge badge-gray">${d.country || 'XX'}</span>
      </div>
      ${Charts.ipRiskGauge(d.score || 0)}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px;font-size:.78rem">
        <div><span class="dim">ASN: </span>${d.asn || '—'}</div>
        <div><span class="dim">RBL Hits: </span>${d.rbl_hits?.join(', ') || 'None'}</div>
      </div>
      <div style="display:flex;gap:8px;margin-top:14px">
        <button class="btn btn-danger btn-sm" onclick="blockIPDirect('${d.ip}')">Block this IP</button>
      </div>
    </div>`;
}

async function blockIPDirect(ip) {
  const res = Demo.active ? { success: true } : await API.fwBlockIP(ip, 'IP Reputation: High risk', false);
  if (res?.success) toast(`${ip} blocked`, 'success');
  else toast('Block failed', 'error');
}

async function loadTopAttackers() {
  const res = Demo.active ? Demo.mockIPAttackers() : await API.ipTopAttack();
  const tbody = document.getElementById('iprep-table-body');
  if (!tbody) return;

  const data = res?.data || [];
  if (!data.length) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--txt3);padding:24px">No data yet — IP reputation requires incoming events.</td></tr>';
    return;
  }

  tbody.innerHTML = data.map(r => {
    const rblHits = typeof r.rbl_hits === 'string' ? JSON.parse(r.rbl_hits || '[]') : (r.rbl_hits || []);
    const scoreCol = r.score >= 75 ? 'var(--red)' : r.score >= 50 ? 'var(--amber)' : 'var(--green)';
    return `
      <tr>
        <td class="mono primary">${r.ip_address}</td>
        <td><span class="cc-badge" style="background:var(--blue-dim);color:var(--blue2)">${r.country || 'XX'}</span></td>
        <td>
          <div style="display:flex;align-items:center;gap:8px">
            <div class="progress-bar" style="width:80px;height:6px">
              <div class="progress-fill" style="width:${r.score}%;background:${scoreCol}"></div>
            </div>
            <span style="font-family:var(--font-mono);font-size:.72rem;color:${scoreCol}">${r.score}</span>
          </div>
        </td>
        <td class="dim">${rblHits.join(', ') || '—'}</td>
        <td class="mono">${fmtNum(r.hits || 0)}</td>
        <td class="dim">${r.last_seen ? reltime(r.last_seen) : '—'}</td>
        <td>
          <button class="btn btn-danger btn-xs" onclick="blockIPDirect('${r.ip_address}')">Block</button>
        </td>
      </tr>`;
  }).join('');
}

// ── Events ────────────────────────────────────────────────────────────────────
async function loadEvents() {
  const sev = document.getElementById('events-sev-filter')?.value || '';
  const res = Demo.active
    ? { success: true, data: [], unresolved: 0 }
    : await API.events(sev);

  const tbody = document.getElementById('events-body');
  if (tbody) renderEventsTable(res?.data || [], 'events-body');

  const badge = document.getElementById('events-unresolved-badge');
  if (badge) badge.textContent = `${res?.unresolved || 0} unresolved`;
}

async function resolveEvent(id) {
  const res = Demo.active ? { success: true } : await API.resolveEvent(id);
  if (res?.success) {
    toast('Event resolved', 'success');
    await loadEvents();
    refreshDashboard();
  } else {
    // Previously the failure branch did not exist, so a resolve that changed
    // nothing looked identical to one that worked until the row reappeared.
    toast(res?.error || 'Could not resolve that event', 'error');
  }
}


// ── Log Analyzer ─────────────────────────────────────────────────────────────
let _logDaysLoaded = false;
let _logSearchTimer = null;

function debouncedLogSearch() {
  // Typing a path into the search box should not fire a request per keystroke.
  clearTimeout(_logSearchTimer);
  _logSearchTimer = setTimeout(loadLogs, 250);
}

async function loadLogs() {
  const dateEl   = document.getElementById('log-date');
  const levelEl  = document.getElementById('log-level');
  const searchEl = document.getElementById('log-search');
  const tbody    = document.getElementById('log-body');
  if (!tbody) return;

  // Populate the day picker once, from the days that actually have a log.
  if (!_logDaysLoaded && dateEl) {
    _logDaysLoaded = true;
    const daysRes = Demo.active
      ? { success: true, data: [{ date: new Date().toISOString().slice(0, 10), lines: 0 }] }
      : await API.get('logs/days');
    const days = daysRes?.data || [];
    if (days.length) {
      dateEl.innerHTML = days.map((d, i) =>
        `<option value="${esc(d.date)}">${esc(d.date)} (${fmtNum(d.lines || 0)} lines)${i === 0 ? ' — latest' : ''}</option>`
      ).join('');
    }
  }

  const params = new URLSearchParams();
  if (dateEl?.value)   params.set('date',   dateEl.value);
  if (levelEl?.value)  params.set('level',  levelEl.value);
  if (searchEl?.value) params.set('search', searchEl.value);
  params.set('lines', '500');

  const res = Demo.active
    ? { success: true, data: { entries: [], total: 0, counts: {} } }
    : await API.get('logs/query?' + params.toString());

  const d = res?.data || {};
  const entries = d.entries || [];
  const counts  = d.counts  || {};

  const setTxt = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  setTxt('log-stat-total', fmtNum(d.total || 0));
  setTxt('log-stat-error', fmtNum(counts.ERROR || 0));
  setTxt('log-stat-warn',  fmtNum(counts.WARN  || 0));
  setTxt('log-stat-info',  fmtNum(counts.INFO  || 0));
  setTxt('log-showing-badge', fmtNum(entries.length) + ' shown');

  if (!entries.length) {
    // Say which of the two reasons applies. "No entries" alone reads as a
    // broken page, which is how this module was reported in the first place.
    const filtered = (searchEl?.value || '') !== ''
                  || ((levelEl?.value || 'ALL') !== 'ALL');
    tbody.innerHTML = `<tr><td colspan="3" style="text-align:center;color:var(--txt3);padding:28px">${
      (d.total || 0) > 0 && filtered
        ? 'No entries match this filter — ' + fmtNum(d.total) + ' entries on this day.'
        : 'Nothing logged on this day yet.'
    }</td></tr>`;
    return;
  }

  tbody.innerHTML = entries.map(e => `
    <tr>
      <td class="mono dim" style="white-space:nowrap">${esc(e.time) || '—'}</td>
      <td>${logLevelBadge(e.level)}</td>
      <td class="mono" style="word-break:break-word;font-size:.75rem">${esc(e.message)}</td>
    </tr>`).join('');
}

function logLevelBadge(level) {
  const map = {
    ERROR: 'badge badge-red',
    WARN:  'badge badge-amber',
    INFO:  'badge badge-green',
    DEBUG: 'badge badge-gray',
  };
  // A line that did not parse still gets a row -- dropping it would hide
  // exactly the unusual output most worth reading.
  if (!level) return '<span class="badge badge-gray">raw</span>';
  return `<span class="${map[level] || 'badge badge-gray'}">${esc(level)}</span>`;
}

function downloadLogs() {
  const rows = Array.from(document.querySelectorAll('#log-body tr'))
    .map(tr => Array.from(tr.children).map(td => td.textContent.trim()).join('  '))
    .join('\n');
  if (!rows.trim()) { toast('Nothing to download', 'error'); return; }

  const day = document.getElementById('log-date')?.value || 'today';
  const blob = new Blob([rows], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `serverscrub-${day}.log`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(a.href);
}
// ── Settings ──────────────────────────────────────────────────────────────────
function updateCpuSliderLabel(val) {
  val = parseInt(val, 10);
  const labelEl = document.getElementById('cpu-limit-label');
  const descEl  = document.getElementById('cpu-limit-desc');
  if (labelEl) labelEl.textContent = val + '%';

  if (descEl) {
    // nice value: 100% → 0, 10% → 19
    const niceVal = Math.round(19 * (1 - val / 100));
    // scan sleep: 100% → 0ms, 10% → 550ms
    const sleepMs = Math.round(Math.max(0, (1 - val / 100) * 550));

    let label, color;
    if (val <= 25)      { label = 'Minimal — maximum headroom for web traffic'; color = '#10b981'; }
    else if (val <= 50) { label = 'Balanced — recommended for most servers';   color = '#3b82f6'; }
    else if (val <= 75) { label = 'Performance — faster scans, higher CPU';    color = '#f59e0b'; }
    else                { label = 'Maximum — fastest scans, unrestricted CPU';  color = '#ef4444'; }

    descEl.innerHTML =
      '<span style="color:' + color + ';font-weight:600">' + label + '</span><br>' +
      '<span style="color:var(--txt3)">Process priority: </span><code>nice ' + niceVal + '</code>' +
      ' &nbsp;·&nbsp; ' +
      '<span style="color:var(--txt3)">Scan throttle: </span><code>' + (sleepMs ? sleepMs + 'ms between files' : 'no throttle') + '</code>';
  }
}

function selectPollInterval(seconds) {
  [60, 300, 900].forEach(v => {
    const el = document.getElementById('poll-opt-' + v);
    if (!el) return;
    const active = v === seconds;
    el.style.borderColor    = active ? 'var(--primary)' : 'var(--border)';
    el.style.background     = active ? 'rgba(59,130,246,.08)' : '';
    const radio = el.querySelector('input[type=radio]');
    if (radio) radio.checked = active;
  });
}

async function loadSettings() {
  loadLicense();   // license card lives on this page

  const res = Demo.active
    ? { success: true, data: {
        scan_schedule: 'daily', scan_paths: '/home', auto_quarantine: '0',
        email_alerts: '1', alert_email: '', php_disable_funcs: 'exec,passthru,shell_exec,system',
        rate_limit_ssh: '5', rate_limit_http: '100',
        firewall_enabled: '1', waf_enabled: '1', bot_shield_enabled: '1', ip_rep_enabled: '1',
        cpu_limit_percent: '50', rt_poll_interval: '300',
        scan_time: '02:00', scan_day: '0', scan_type: 'full',
        sig_update_schedule: 'weekly', sig_update_day: '0',
        iprep_schedule: 'daily',
        sig_last_update: String(Math.floor(Date.now()/1000) - 3*86400),
        iprep_last_run:  String(Math.floor(Date.now()/1000) - 9*3600),
        iprep_last_count: '183',
      }}
    : await API.getSettings();

  if (!res?.success) return;
  const d = res.data;

  const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ''; };
  const chk = (id, val) => { const el = document.getElementById(id); if (el) el.checked = val === '1' || val === true; };

  set('set-scan-schedule', d.scan_schedule);
  set('set-scan-time',     d.scan_time || '02:00');
  set('set-scan-day',      d.scan_day  || '0');
  set('set-scan-type',     d.scan_type || 'full');
  set('set-sig-schedule',  d.sig_update_schedule || 'weekly');
  set('set-sig-day',       d.sig_update_day || '0');
  set('set-iprep-schedule',d.iprep_schedule || 'daily');
  set('set-scan-paths',    d.scan_paths);

  // Rootkit schedule — the scheduler has always read these; nothing set them.
  set('set-rootkit-schedule', d.rootkit_schedule || 'weekly');
  set('set-rootkit-time',     d.rootkit_time     || '05:00');
  set('set-rootkit-day',      d.rootkit_day      || '0');
  loadQuarantineInfo();

  // Real-time monitor resource profile
  selectRtProfile(d.rt_profile || 'balanced');
  set('set-rt-fps',      d.rt_max_files_per_sec || '25');
  set('set-rt-maxmb',    d.rt_max_file_size_mb  || '16');
  set('set-rt-nice',     d.rt_nice              || '10');
  set('set-rt-watches',  d.rt_max_watches       || '20000');
  set('set-rt-debounce', d.rt_debounce_seconds  || '5');
  set('set-rt-excludes', d.rt_exclude_dirs      || '');

  // Pause-during-backup
  const pauseEl = document.getElementById('set-rt-pause-backup');
  if (pauseEl) pauseEl.checked = (d.rt_pause_on_backup ?? '1') === '1';
  set('set-rt-backup-procs',  d.rt_backup_procs            || 'jetbackup,rsync');
  set('set-rt-backup-resume', d.rt_backup_resume_secs      || '60');
  set('set-rt-backup-max',    d.rt_backup_max_suspend_secs || '14400');
  const autoEl = document.getElementById('set-rt-autostart');
  if (autoEl) autoEl.checked = (d.rt_autostart_after_backup ?? '1') === '1';

  // Last-run readouts
  const ts = v => (v && +v) ? new Date(+v * 1000).toLocaleString() : 'never';
  const txt = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  txt('sig-last-update',  ts(d.sig_last_update));
  txt('iprep-last-run',   ts(d.iprep_last_run));
  txt('iprep-last-count', d.iprep_last_count || '0');
  txt('rootkit-last-run',      ts(d.rootkit_last_run));
  txt('rootkit-last-findings', d.rootkit_last_findings || '0');

  syncScheduleFields();
  chk('set-auto-quar',     d.auto_quarantine);

  // The scanner page used to state "auto-quarantine enabled" as static text,
  // which was wrong the moment the setting was off -- and it now ships off.
  const quarState = document.getElementById('scanner-quar-state');
  if (quarState) {
    quarState.textContent = d.auto_quarantine === '1'
      ? 'auto-quarantine on' : 'auto-quarantine off';
  }
  chk('set-email-alerts',  d.email_alerts);
  set('set-alert-email',   d.alert_email);
  set('set-php-disable',   d.php_disable_funcs);
  set('set-rate-ssh',      d.rate_limit_ssh);
  set('set-rate-http',     d.rate_limit_http);
  chk('set-fw-enabled',    d.firewall_enabled);
  chk('set-waf-enabled',   d.waf_enabled);
  chk('set-bot-enabled',   d.bot_shield_enabled);
  chk('set-iprep-enabled', d.ip_rep_enabled);

  // CPU slider
  const cpuVal = parseInt(d.cpu_limit_percent || '50', 10);
  const cpuSlider = document.getElementById('set-cpu-limit');
  if (cpuSlider) { cpuSlider.value = cpuVal; updateCpuSliderLabel(cpuVal); }

  // Poll interval selector
  const pollVal = parseInt(d.rt_poll_interval || '300', 10);
  selectPollInterval([60, 300, 900].includes(pollVal) ? pollVal : 300);
}

async function saveSettings() {
  const g = id => document.getElementById(id);
  const data = {
    scan_schedule:       g('set-scan-schedule')?.value,
    scan_time:           g('set-scan-time')?.value,
    scan_day:            g('set-scan-day')?.value,
    scan_type:           g('set-scan-type')?.value,
    sig_update_schedule: g('set-sig-schedule')?.value,
    sig_update_day:      g('set-sig-day')?.value,
    iprep_schedule:      g('set-iprep-schedule')?.value,
    scan_paths:          g('set-scan-paths')?.value,

    rt_profile:            g('set-rt-profile')?.value || 'balanced',
    rt_max_files_per_sec:  g('set-rt-fps')?.value      || '25',
    rt_max_file_size_mb:   g('set-rt-maxmb')?.value    || '16',
    rt_nice:               g('set-rt-nice')?.value     || '10',
    rt_max_watches:        g('set-rt-watches')?.value  || '20000',
    rt_debounce_seconds:   g('set-rt-debounce')?.value || '5',
    rt_exclude_dirs:       g('set-rt-excludes')?.value || '',
    auto_quarantine:    g('set-auto-quar')?.checked ? '1' : '0',
    email_alerts:       g('set-email-alerts')?.checked ? '1' : '0',
    alert_email:        g('set-alert-email')?.value,
    php_disable_funcs:  g('set-php-disable')?.value,
    rate_limit_ssh:     g('set-rate-ssh')?.value,
    rate_limit_http:    g('set-rate-http')?.value,
    firewall_enabled:   g('set-fw-enabled')?.checked ? '1' : '0',
    waf_enabled:        g('set-waf-enabled')?.checked ? '1' : '0',
    bot_shield_enabled: g('set-bot-enabled')?.checked ? '1' : '0',
    ip_rep_enabled:     g('set-iprep-enabled')?.checked ? '1' : '0',
    cpu_limit_percent:  g('set-cpu-limit')?.value || '50',
    rt_poll_interval:   document.querySelector('input[name="rt_poll_interval"]:checked')?.value || '300',
  };

  const res = Demo.active ? { success: true } : await API.saveSettings(data);
  if (res?.success) toast('Settings saved', 'success');
  else toast('Failed to save', 'error');
}


// ── Scanner settings ─────────────────────────────────────────────────────────
// A save control that belongs to the card it saves. The page-level "Save
// Changes" lives in a different card further up the page, so changing a scan
// schedule here left the operator with nothing to click and no way to tell
// whether the change had taken.
async function saveScannerSettings() {
  const g = id => document.getElementById(id);
  const status = g('scanner-settings-status');
  const data = {
    scan_schedule:       g('set-scan-schedule')?.value,
    scan_time:           g('set-scan-time')?.value,
    scan_day:            g('set-scan-day')?.value,
    scan_type:           g('set-scan-type')?.value,
    scan_paths:          g('set-scan-paths')?.value,
    sig_update_schedule: g('set-sig-schedule')?.value,
    sig_update_day:      g('set-sig-day')?.value,
    iprep_schedule:      g('set-iprep-schedule')?.value,
    auto_quarantine:     g('set-auto-quar')?.checked ? '1' : '0',
    rootkit_schedule:    g('set-rootkit-schedule')?.value,
    rootkit_time:        g('set-rootkit-time')?.value,
    rootkit_day:         g('set-rootkit-day')?.value,
  };

  if (status) { status.textContent = 'Saving…'; status.style.color = 'var(--txt3)'; }

  const res = Demo.active ? { success: true } : await API.saveSettings(data);

  if (res?.success) {
    // Read it back rather than trusting the button's own optimism: the
    // complaint was that a changed schedule did not appear to update anywhere,
    // and only a re-read can actually show that it did.
    await loadSettings();
    if (status) {
      status.textContent = 'Saved · scan runs ' + describeSchedule(data);
      status.style.color = 'var(--ok, #22c55e)';
    }
    toast('Scanner settings saved', 'success');
  } else {
    if (status) {
      status.textContent = res?.error || 'Save failed';
      status.style.color = 'var(--danger, #ef4444)';
    }
    toast(res?.error || 'Could not save scanner settings', 'error');
  }
}

function describeSchedule(d) {
  if (!d || d.scan_schedule === 'disabled') return 'never (disabled)';
  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const at = d.scan_time || '02:00';
  if (d.scan_schedule === 'daily')   return 'daily at ' + at;
  if (d.scan_schedule === 'weekly')  return days[+d.scan_day || 0] + 's at ' + at;
  if (d.scan_schedule === 'monthly') return 'monthly at ' + at;
  return String(d.scan_schedule || '');
}

// ── Quarantine location ──────────────────────────────────────────────────────
async function checkQuarantinePath() {
  const dir = document.getElementById('set-quar-dir')?.value?.trim();
  const badge = document.getElementById('quar-writable');
  if (!dir) { toast('Enter a quarantine path first', 'error'); return; }
  if (badge) { badge.textContent = 'checking…'; badge.className = 'badge badge-gray'; }

  const res = Demo.active ? { success: true, data: { writable: true } }
                          : await API.post('storage/quarantine-check', { path: dir });
  const d = res?.data || {};
  if (!badge) return;

  if (res?.success && d.writable) {
    badge.textContent = 'readable & writable';
    badge.className   = 'badge badge-green';
  } else {
    // Saying "not writable" without saying why leaves the operator guessing
    // between a missing directory, a permission problem and a full disk.
    badge.textContent = d.reason || res?.error || 'not writable';
    badge.className   = 'badge badge-red';
  }
}

async function moveQuarantineDir() {
  const dir = document.getElementById('set-quar-dir')?.value?.trim();
  if (!dir) { toast('Enter a quarantine path first', 'error'); return; }
  if (!confirm('Move quarantined files to:\n\n' + dir + '\n\nFiles are moved, never deleted.')) return;

  const res = Demo.active ? { success: true, data: { moved: 0 } }
                          : await API.post('storage/quarantine-move', { path: dir });
  if (res?.success) {
    toast('Quarantine moved (' + (res.data?.moved ?? 0) + ' file(s))', 'success');
    loadQuarantineInfo();
  } else {
    toast(res?.error || res?.data?.error || 'Could not move quarantine', 'error');
  }
}

async function loadQuarantineInfo() {
  const res = Demo.active
    ? { success: true, data: { dir: '/home/.serverscrub/quarantine', files: 0, human: '0 B', writable: true, on_root: false } }
    : await API.get('storage/quarantine-usage');
  const d = res?.data || {};

  const input = document.getElementById('set-quar-dir');
  if (input && !input.dataset.touched) input.value = d.dir || '';

  const usage = document.getElementById('quar-usage');
  if (usage) {
    usage.textContent = (d.files ?? 0) + ' file(s) · ' + (d.human ?? '0 B')
                      + (d.on_root ? ' · on the root partition' : '');
    usage.style.color = d.on_root ? 'var(--danger, #ef4444)' : 'var(--txt3)';
  }

  const badge = document.getElementById('quar-writable');
  if (badge) {
    badge.textContent = d.writable ? 'readable & writable' : 'not writable';
    badge.className   = d.writable ? 'badge badge-green' : 'badge badge-red';
  }
}

async function runRootkitNow() {
  toast('Rootkit scan started…', 'info');
  const res = Demo.active ? { success: true, data: { summary: { critical: 0, high: 0 } } }
                          : await API.post('rootkit/scan-builtin', {});
  if (res?.success) {
    const sum = res.data?.summary || {};
    toast('Rootkit scan finished — ' + (sum.critical || 0) + ' critical, ' + (sum.high || 0) + ' high', 'success');
    loadSettings();
  } else {
    toast(res?.error || 'Rootkit scan failed', 'error');
  }
}

// ── Real-Time Monitor ─────────────────────────────────────────────────────────
let monitorRunning = false;

/* One vocabulary for two facts that are not the same fact.
 *
 * Reported from a live server: the Monitor Status card said "Paused — rsync"
 * while the System Service card beside it said "Active", sub-state "running",
 * with a PID. Both were correct and the page never said which was which, so
 * they read as the product contradicting itself.
 *
 * They describe different things:
 *
 *   the SERVICE  — is the process up?            systemd's answer
 *   the SCANNING — is it inspecting files?       the daemon's own answer
 *
 * During a backup the daemon deliberately keeps running and stops scanning.
 * It does not exit, and it must not: a process that exited would need
 * restarting, would lose its inotify watches, and would leave nothing to
 * notice when the backup finished. The pause is a flag it sets on itself
 * (see monitor.py::_suspend), which is exactly why systemd still reports it
 * as healthy.
 *
 * So the words carry the subject. The service is "Running"; the scanning is
 * "Scanning" or "Scanning paused". Nothing says a bare "Active" any more,
 * because "active" is the word that invites the two to be compared.
 */
function scanStateLabel(d) {
  if (!d)            { return { text: 'Status unknown',  cls: 'badge-red'   }; }
  if (!d.running)    { return { text: '○ Stopped',       cls: 'badge-red'   }; }
  if (d.suspended)   {
    return { text: '⏸ Scanning paused' + (d.suspend_reason ? ' — ' + d.suspend_reason : ''),
             cls: 'badge-amber' };
  }
  if (d.stale)       { return { text: '● Running, no activity', cls: 'badge-amber' }; }
  return { text: '● Scanning', cls: 'badge-green' };
}

/* The service badge, which needs BOTH answers to avoid saying the misleading
 * half of the truth. Called from loadServiceStatus() and from loadMonitor(),
 * because on the monitor page those two run in parallel and either may land
 * first; whichever does, this renders from whatever is known so far.
 */
function renderServiceBadge() {
  const d = State.lastService;
  if (!d) { return; }
  const mon       = State.lastMonitor;
  const active    = d.active_state === 'active';
  const suspended = active && !!(mon && mon.running && mon.suspended);

  const badge = document.getElementById('svc-state-badge');
  if (badge) {
    if (!active) {
      badge.className   = 'badge ' + (d.active_state === 'failed' ? 'badge-red' : 'badge-yellow');
      badge.textContent = '○ ' + (d.active_state || 'Unknown');
    } else if (suspended) {
      // Still green. The service IS healthy -- that is the point being made.
      // Amber here would say the process has a problem, which it has not.
      badge.className   = 'badge badge-green';
      badge.textContent = '● Running · scanning paused';
    } else {
      badge.className   = 'badge badge-green';
      badge.textContent = '● Running';
    }
  }

  const note = document.getElementById('svc-pause-note');
  if (note) {
    if (suspended) {
      note.innerHTML = '<span>⏸</span><span><strong>The service is running.</strong> '
        + 'It stays up during a backup on purpose — only file scanning is paused, '
        + 'because ' + esc(mon.suspend_reason || 'a backup') + ' is running. Stopping the '
        + 'process instead would lose its watches and leave nothing to notice when the '
        + 'backup finished. Scanning resumes on its own.</span>';
      note.style.display = 'flex';
    } else {
      note.style.display = 'none';
    }
  }
}

async function loadMonitorStats() {
  const res = Demo.active ? Demo.mockMonitorStatus() : await API.monitorStatus();
  if (!res?.success) return;
  const d = res.data;
  monitorRunning = d.running;
  State.lastMonitor = d;

  const card = document.getElementById('rt-monitor-card');
  if (card) card.style.borderLeftColor = d.running ? 'var(--green)' : 'var(--red)';
  // A monitor can be running and yet doing nothing: wrong watch paths, a dead
  // loop, inotify watches exhausted. That state used to render as a green
  // "Active" badge beside counters stuck at zero, which is the least useful
  // thing the card could say. The daemon stamps rt_last_activity as it works,
  // so silence is measurable — report it.
  // The same words as the monitor page's badge, from the same function. Two
  // cards describing one fact in two vocabularies is how "Paused" here and
  // "Active" there came to sit on one screen.
  const badge = document.getElementById('rt-status-badge');
  if (badge) {
    const s = scanStateLabel(d);
    badge.className = 'badge ' + s.cls;
    badge.textContent = s.text;
  }
  renderServiceBadge();
  const icon = document.getElementById('rt-icon');
  if (icon) icon.textContent = !d.running ? '⏸' : (d.suspended ? '⏸' : (d.stale ? '⚠️' : '🔍'));

  if (card) {
    card.style.borderLeftColor = !d.running ? 'var(--red)'
                               : ((d.suspended || d.stale) ? 'var(--amber, #f59e0b)' : 'var(--green)');
  }

  // Say why, and for how long. A paused badge with no explanation is the kind
  // of thing that gets reported as the monitor being broken.
  const note = document.getElementById('rt-suspend-note');
  if (note) {
    if (d.suspended) {
      const mins = d.suspend_since ? Math.max(0, Math.round((Date.now() / 1000 - d.suspend_since) / 60)) : 0;
      note.textContent = 'Scanning is paused because ' + (d.suspend_reason || 'a backup')
                       + ' is running' + (mins ? ' (' + mins + ' min)' : '')
                       + (d.suspend_evidence ? ' — matched ' + d.suspend_evidence : '')
                       + '. Changes made now are not scanned in real time; the next '
                       + 'scheduled scan covers them.';
      note.style.display = '';
    } else if (d.last_gap_seconds > 0 && d.last_gap_end
               && (Date.now() / 1000 - d.last_gap_end) < 86400) {
      note.textContent = 'Resumed after a ' + Math.round(d.last_gap_seconds / 60)
                       + ' minute pause for a backup. Changes made during it were not '
                       + 'scanned in real time.';
      note.style.display = '';
    } else {
      note.style.display = 'none';
    }
  }

  const rtPaths  = document.getElementById('rt-paths');
  // "Watching ..." with nothing after it was the placeholder showing through.
  if (rtPaths) {
    const paths = (d.watch_paths || []).filter(Boolean);
    rtPaths.textContent = paths.length ? paths.join(', ') : 'no paths configured';
  }
  const rtEngine = document.getElementById('rt-engine');
  if (rtEngine) rtEngine.textContent = d.engine || 'polling';

  setText('rt-files-checked',  fmtNum(d.files_checked || 0));
  setText('rt-detections-24h', d.detections_24h || 0);
  setText('rt-detections-all', d.detections_all  || 0);

  const toggleBtn = document.getElementById('rt-toggle-btn');
  if (toggleBtn) {
    toggleBtn.textContent = d.running ? 'Stop' : 'Start';
    toggleBtn.disabled = false;
    toggleBtn.dataset.ready = '1';
  }

  const sbRt = document.getElementById('sb-rt-threats');
  if (sbRt) {
    sbRt.style.display = d.detections_24h > 0 ? '' : 'none';
    sbRt.textContent   = d.detections_24h || '';
  }
}

async function loadMonitor() {
  const res = Demo.active ? Demo.mockMonitorStatus() : await API.monitorStatus();

  // A failed load must not leave the page showing "Loading…".
  //
  // This returned silently, so an API error and a page that was never wired
  // looked identical -- both just sat on the placeholder text the markup
  // ships with. That is how the missing `monitor` dispatch went unnoticed:
  // the symptom was indistinguishable from a slow or failing endpoint.
  if (!res?.success) {
    const badge = document.getElementById('monitor-status-badge');
    if (badge) {
      badge.className = 'badge badge-red';
      badge.textContent = 'Status unknown';
    }
    ['mon-engine', 'mon-pid', 'mon-files', 'mon-det-24h', 'mon-det-all']
      .forEach(id => setText(id, '—'));
    const body = document.getElementById('rt-detections-body');
    if (body) {
      body.innerHTML = '<tr><td colspan="5" style="text-align:center;'
        + 'color:var(--red);padding:24px">Could not reach the monitor API — '
        + 'protection status cannot be confirmed.</td></tr>';
    }
    return;
  }
  const d = res.data;
  monitorRunning = d.running;
  // Needed by renderServiceBadge() and by the dashboard alerts, and this
  // loader did not set it -- only loadMonitorStats() did. On the monitor page
  // that one never runs, so the service card had no way to know the scanning
  // was paused.
  State.lastMonitor = d;

  // Running/stopped alone is not the whole truth. A daemon that is up but
  // scanning nothing, or deliberately paused for a backup, both rendered as a
  // green "Running" -- claiming protection that is not happening.
  const badge = document.getElementById('monitor-status-badge');
  if (badge) {
    const s = scanStateLabel(d);
    badge.className = 'badge ' + s.cls;
    badge.textContent = s.text;
  }
  // Either loader may land first on this page; re-render from what is known.
  renderServiceBadge();
  const pgBtn = document.getElementById('monitor-page-toggle');
  if (pgBtn) pgBtn.textContent = d.running ? 'Stop Monitor' : 'Start Monitor';

  setText('mon-engine',  d.engine || 'polling');
  setText('mon-pid',     d.pid    || '—');
  setText('mon-files',   fmtNum(d.files_checked || 0));
  setText('mon-det-24h', d.detections_24h || 0);
  setText('mon-det-all', d.detections_all  || 0);

  const pathsList = document.getElementById('mon-paths-list');
  if (pathsList) {
    pathsList.innerHTML = (d.watch_paths || []).map(p =>
      '<div style="display:flex;justify-content:space-between;align-items:center;' +
      'padding:6px 10px;background:var(--bg1);border-radius:6px;margin-bottom:6px;' +
      'font-size:.78rem;font-family:monospace">' +
      '<span style="color:var(--txt1)">' + p + '</span>' +
      '<button class="btn btn-ghost btn-sm" style="padding:2px 8px;font-size:.7rem" ' +
      'onclick="removeWatchPath(\'' + p + '\')">✕ Remove</button></div>'
    ).join('') || '<div style="color:var(--txt3);font-size:.8rem">No paths configured</div>';
  }

  renderMonResources(d);

  // Also refresh service panel
  loadServiceStatus();
  loadServiceLogs();
}


/* ══ Resource usage, on the monitor page ═════════════════════════════════ */

/** The limits a named profile stands for. Mirrors PROFILES in monitor.py. */
const MON_RES_PRESETS = {
  light:    { fps: 5,   mb: 4,  nice: 19, watches: 5000,   poll: 900, debounce: 10 },
  balanced: { fps: 25,  mb: 16, nice: 10, watches: 20000,  poll: 300, debounce: 5  },
  thorough: { fps: 100, mb: 50, nice: 5,  watches: 100000, poll: 120, debounce: 2  },
};

/**
 * Show what the DAEMON says is in force, not what the settings say.
 *
 * These differ for up to a minute after a save, because the daemon re-reads
 * its limits on a cycle, and they differ permanently when a value was out of
 * range and got clamped. Rendering the stored setting here would be the more
 * reassuring number and a false one -- the same mistake as a green "Running"
 * badge over a daemon that is scanning nothing.
 */
function renderMonResources(d) {
  if (!d || !document.getElementById('mon-res-card')) return;

  const eff   = d.effective_profile || d.profile || 'balanced';
  const asked = d.profile || 'balanced';
  const preset = MON_RES_PRESETS[eff] || MON_RES_PRESETS.balanced;

  setText('mon-res-eff-profile', eff.charAt(0).toUpperCase() + eff.slice(1));
  // Prefer what the daemon published over what the profile name implies. For
  // 'custom' the name implies nothing, and those are exactly the limits an
  // operator typed and most wants confirmed. The preset is only a fallback for
  // a daemon that has not reported yet (old build, or never started).
  const pick = (v, fallback) => (v > 0 ? String(v) : (fallback == null ? '—' : String(fallback)));
  const fb   = (eff === 'custom') ? null : preset;

  setText('mon-res-eff-rate', pick(d.effective_rate, fb && fb.fps));
  setText('mon-res-eff-poll', d.effective_poll > 0 ? fmtDuration(d.effective_poll)
                                                   : (fb ? fmtDuration(fb.poll) : '—'));
  setText('mon-res-eff-nice', (d.effective_nice != null && d.effective_nice >= 0)
                                ? String(d.effective_nice)
                                : (fb ? String(fb.nice) : '—'));

  // The watch count is the one number here that is measured rather than
  // configured, and a capped count means coverage is PARTIAL. Say so.
  const wEl = document.getElementById('mon-res-eff-watches');
  if (wEl) {
    const n   = d.watch_count || 0;
    const cap = d.effective_watch_max > 0 ? d.effective_watch_max
                                          : (fb ? fb.watches : 0);
    // In use OF the ceiling: the count alone cannot say whether it is close to
    // refusing more, which is the only thing this number is useful for.
    wEl.textContent = cap > 0 ? (fmtNum(n) + ' / ' + fmtNum(cap)) : fmtNum(n);
    wEl.style.color = d.watch_capped ? 'var(--red)' : '';
  }

  const badge = document.getElementById('mon-res-badge');
  if (badge) {
    if (d.watch_capped) {
      badge.className = 'badge badge-red';
      // Name the limit that is actually binding. "Watch limit reached" over a
      // count well below the configured ceiling reads as a stuck panel, which
      // is exactly how this was reported.
      badge.textContent = (d.watch_cap_reason === 'kernel')
        ? 'Kernel watch limit' : 'Watch ceiling reached';
    } else if (!d.running) {
      badge.className = 'badge';
      badge.textContent = 'Monitor stopped';
    } else {
      badge.className = 'badge badge-green';
      badge.textContent = eff === asked ? 'Limits applied' : 'Applying\u2026';
    }
  }

  const note = document.getElementById('mon-res-note');
  if (note) {
    const bits = [];
    if (d.watch_capped) {
      // ONE OF THESE, NOT BOTH.
      //
      // This used to name our setting and the host sysctl in the same
      // sentence, for every capped state. An operator whose ceiling was the
      // binding limit was sent to edit a sysctl that was fine; one whose
      // KERNEL was the limit raised our ceiling, saw the warning stay, and
      // reasonably concluded the setting did nothing. The daemon knows which
      // one refused, so say that one.
      if (d.watch_cap_reason === 'kernel') {
        bits.push('The HOST KERNEL refused more inotify watches at '
                + fmtNum(d.watch_count || 0) + ', below the ceiling set here, so some '
                + 'directories are NOT being watched. Raising the ceiling on this '
                + 'page will not help: fs.inotify.max_user_watches has to go up on '
                + 'the server, or the watch paths have to be narrower.');
      } else if (d.watch_cap_reason === 'ceiling') {
        bits.push('The watch ceiling set here was reached, so some directories are '
                + 'NOT being watched. Raise "Maximum inotify watches" below and save '
                + '\u2014 the monitor takes up the extra watches within a minute, with '
                + 'no restart.');
      } else {
        bits.push('More inotify watches were refused, so some directories are NOT '
                + 'being watched. Raise the ceiling below, or '
                + 'fs.inotify.max_user_watches on the host, or narrow the watch paths.');
      }
    }
    if (eff !== asked) {
      bits.push('Settings ask for "' + asked + '" and the daemon reports "' + eff
              + '". It re-reads its limits about once a minute; if this does not '
              + 'converge, a value was out of range and was clamped.');
    }
    if ((d.engine || '') === 'polling') {
      bits.push('This host is in polling mode, not inotify. Polling walks and '
              + 'stats every file under every watched path on each interval, '
              + 'which is the expensive one \u2014 the polling interval is the '
              + 'setting with the most effect here.');
    }
    note.textContent = bits.join(' ');
    note.style.color = d.watch_capped ? 'var(--red)' : 'var(--txt3)';
  }

  renderCpuCapMode(d);
  loadMonResourceValues(_monResForce);
  _monResForce = false;
}

/* Set for one pass by refreshMonitorPage(), so the controls are re-read from
 * the server on an explicit Refresh and left alone on the timer. */
let _monResForce = false;

/**
 * What the page's Refresh button runs.
 *
 * It used to call loadMonitor() alone, which refreshes the STATUS and leaves
 * every control showing whatever it was last filled with. After saving a
 * limit that is the one thing it needed to do.
 */
async function refreshMonitorPage() {
  _monResForce = true;
  await loadMonitor();
}

/**
 * Say which mechanism is holding the CPU ceiling, in plain words.
 *
 * 'nice' is not a ceiling. Rendering "50%" beside it without saying so is the
 * same class of dishonesty as a green badge over a daemon that is scanning
 * nothing: the number is real, the thing it implies is not.
 */
function renderCpuCapMode(d) {
  const el = document.getElementById('mon-res-cap-mode');
  if (!el) return;

  const pct  = d.cpu_limit_percent || 50;
  const mode = d.cpu_cap_mode || 'nice';
  const box  = document.getElementById('mon-res-hardcap');
  if (box) box.checked = !!d.cpu_cap_enabled;

  if (mode === 'quota') {
    el.textContent = 'In force: cgroup CPU quota at ' + pct + '% of one core. '
                   + 'Enforced by the kernel whether the server is busy or idle.';
    el.style.color = 'var(--green)';
  } else if (mode === 'cpulimit') {
    el.textContent = 'In force: cpulimit at ' + pct + '%. A ceiling, but applied '
                   + 'from userspace by suspending the process, so it is less '
                   + 'precise than a cgroup quota.';
    el.style.color = 'var(--green)';
  } else if (mode === 'off') {
    el.textContent = 'Not enforced \u2014 the quota is switched off above, so ' + pct
                   + '% is a scheduling priority only. A scan can still use a '
                   + 'whole idle core.';
    el.style.color = 'var(--txt3)';
  } else {
    el.textContent = 'NOT a ceiling on this host \u2014 only nice is in force, so '
                   + pct + '% sets priority and caps nothing. A scan will take a '
                   + 'core that nothing else wants. systemd-run would not accept '
                   + 'a CPU quota here (no systemd, not root, or the cgroup '
                   + 'hierarchy refused it); installing cpulimit is the '
                   + 'alternative.';
    el.style.color = 'var(--amber)';
  }
}

/** Seconds as something readable, for the row above the controls. */
function fmtDuration(secs) {
  const n = parseInt(secs, 10);
  if (!isFinite(n) || n <= 0) return '\u2014';
  if (n % 3600 === 0) return (n / 3600) + ' h';
  if (n % 60 === 0)   return (n / 60) + ' min';
  return n + ' s';
}

let _monResLoaded = false;

/**
 * Fill the controls from stored settings.
 *
 * Guarded by default because loadMonitor() runs on a timer, and re-filling on
 * every tick would overwrite a number the operator is part-way through
 * typing. `force` is for the explicit Refresh button, which must mean refresh
 * EVERYTHING: the complaint that produced this was saving a value, pressing
 * Refresh, and seeing the old one -- the guard made the button a no-op for
 * precisely the controls the operator had just changed.
 */
async function loadMonResourceValues(force) {
  if (_monResLoaded && !force) return;
  _monResLoaded = true;

  const res = Demo.active ? null : await API.getSettings();
  if (!res?.success) return;
  const d = res.data || {};
  const put = (id, v) => { const e = document.getElementById(id); if (e && v != null) e.value = v; };

  put('mon-res-fps',      d.rt_max_files_per_sec);
  put('mon-res-maxmb',    d.rt_max_file_size_mb);
  put('mon-res-nice',     d.rt_nice);
  put('mon-res-watches',  d.rt_max_watches);
  put('mon-res-poll',     d.rt_poll_interval);
  put('mon-res-debounce', d.rt_debounce_seconds);
  put('mon-res-excludes', d.rt_exclude_dirs);
  put('mon-res-cpu',      d.cpu_limit_percent);
  setText('mon-res-cpu-val', d.cpu_limit_percent || '50');

  selectMonResProfile(d.rt_profile || 'balanced', true);
}

/** Highlight a profile and show the numbers it stands for. */
function selectMonResProfile(name, quiet) {
  const hidden = document.getElementById('mon-res-profile');
  if (hidden) hidden.value = name;

  document.querySelectorAll('.mon-res-opt').forEach(el => {
    const on = el.getAttribute('data-profile') === name;
    el.style.borderColor = on ? 'var(--primary)' : 'var(--border)';
    el.style.background  = on ? 'rgba(124,92,255,.08)' : 'transparent';
  });

  const preset = MON_RES_PRESETS[name];
  if (preset) {
    // The individual limits always show what the chosen profile actually
    // does, so the two halves of this card cannot disagree about what is
    // about to be saved.
    const put = (id, v) => { const e = document.getElementById(id); if (e) e.value = v; };
    put('mon-res-fps', preset.fps);
    put('mon-res-maxmb', preset.mb);
    put('mon-res-nice', preset.nice);
    put('mon-res-watches', preset.watches);
    put('mon-res-poll', preset.poll);
    put('mon-res-debounce', preset.debounce);
  } else if (!quiet) {
    const det = document.getElementById('mon-res-details');
    if (det) det.open = true;
  }
}

/** Editing any individual limit means the operator wants Custom. */
function monResEdited() {
  const hidden = document.getElementById('mon-res-profile');
  if (hidden && hidden.value !== 'custom') {
    selectMonResProfile('custom', true);
    if (typeof toast === 'function') {
      toast('Switched to Custom \u2014 your values will be saved', 'info');
    }
  }
}

/**
 * The CPU cap is not one of the monitor's profile limits.
 *
 * Wiring this to monResEdited() would flip the profile to Custom for a control
 * that has nothing to do with the profile -- quietly discarding the preset the
 * operator had chosen as a side effect of ticking an unrelated box.
 */
function monResCapToggled() {
  const box = document.getElementById('mon-res-hardcap');
  const el  = document.getElementById('mon-res-cap-mode');
  if (!box || !el) return;
  if (!box.checked) {
    el.textContent = 'Will not be enforced once applied — the percentage '
                   + 'becomes a scheduling priority only.';
    el.style.color = 'var(--txt3)';
  } else {
    el.textContent = 'Will be enforced once applied, if this host accepts a '
                   + 'CPU quota. The line here reports which mechanism won '
                   + 'after the next scan batch.';
    el.style.color = 'var(--txt3)';
  }
}

/** Live label for the CPU ceiling slider. */
function monResCpuInput() {
  const el = document.getElementById('mon-res-cpu');
  if (el) setText('mon-res-cpu-val', el.value);
}

/**
 * Write the limits, then read back what was stored.
 *
 * The POST is not the confirmation: the daemon clamps anything out of range,
 * so echoing the typed number would claim a limit that is not in force.
 */
async function saveMonitorResources() {
  const btn    = document.getElementById('mon-res-save-btn');
  const status = document.getElementById('mon-res-save-status');
  const g      = (id) => document.getElementById(id);

  const payload = {
    rt_profile:           g('mon-res-profile')?.value  || 'balanced',
    rt_max_files_per_sec: g('mon-res-fps')?.value       || '25',
    rt_max_file_size_mb:  g('mon-res-maxmb')?.value     || '16',
    rt_nice:              g('mon-res-nice')?.value      || '10',
    rt_max_watches:       g('mon-res-watches')?.value   || '20000',
    rt_poll_interval:     g('mon-res-poll')?.value      || '300',
    rt_debounce_seconds:  g('mon-res-debounce')?.value  || '5',
    rt_exclude_dirs:      g('mon-res-excludes')?.value  || '',
    cpu_limit_percent:    g('mon-res-cpu')?.value       || '50',
    // Whether that percentage is a ceiling or just a priority.
    scan_cpu_hard_cap:    g('mon-res-hardcap')?.checked ? '1' : '0',
    // The probe result is cleared so the next scan re-tests the mechanism:
    // turning the cap on must not be answered from a 'none' cached on a host
    // that has since been given systemd or cpulimit.
    scan_cpu_cap_probe:   '',
  };

  if (btn) { btn.disabled = true; btn.textContent = 'Applying\u2026'; }
  if (status) { status.textContent = ''; status.style.color = 'var(--txt3)'; }

  const res = Demo.active ? { success: true } : await API.saveSettings(payload);

  if (btn) { btn.disabled = false; btn.textContent = 'Apply Limits'; }

  if (!res?.success) {
    const why = (res && (res.detail || res.error)) || 'the server did not say why';
    if (status) { status.textContent = 'Not applied \u2014 ' + why; status.style.color = 'var(--red)'; }
    toast('Limits not applied: ' + why, 'error', 7000);
    return;
  }

  // Read back the stored values, which may have been clamped.
  await loadMonResourceValues(true);

  if (status) {
    status.textContent = 'Applied. The monitor picks these up within a minute '
                       + '\u2014 no restart needed.';
    status.style.color = 'var(--green)';
  }
  toast('Resource limits applied', 'success');

  // The row above reports what the DAEMON is doing, and the daemon re-reads
  // its settings on a cycle -- so right after a save it still describes the
  // previous ones. Refresh it, and say plainly that the numbers above lag by
  // up to a minute rather than letting them look stuck.
  refreshMonitorPage();
}

let _monitorBusy = false;

async function toggleMonitor() {
  // systemctl start/stop takes seconds, and the daemon needs a moment more to
  // write its PID file. The button used to fire and return immediately, so it
  // felt dead, a second click could race the first, and the state it flipped to
  // was assumed rather than confirmed -- which is why it looked unreliable.
  if (_monitorBusy) return;

  // Refuse to act on a guess. monitorRunning starts false, so a click before
  // the first status load would start a monitor whose button says "Stop".
  const rtBtn = document.getElementById('rt-toggle-btn');
  if (rtBtn && rtBtn.dataset.ready !== '1' && !Demo.active) {
    toast('Still reading the monitor status — try again in a moment', 'info');
    loadMonitorStats();
    return;
  }

  _monitorBusy = true;

  const starting = !monitorRunning;
  const buttons  = ['rt-toggle-btn', 'monitor-page-toggle']
    .map(id => document.getElementById(id)).filter(Boolean);
  const original = buttons.map(b => b.textContent);
  buttons.forEach(b => { b.disabled = true; b.textContent = starting ? 'Starting…' : 'Stopping…'; });

  const fn  = starting ? API.monitorStart : API.monitorStop;
  const res = Demo.active ? { success: true } : await fn();

  const restore = () => {
    buttons.forEach((b, i) => { b.disabled = false; b.textContent = original[i]; });
    _monitorBusy = false;
  };

  if (res?.success) {
    // Confirm with the server rather than assuming. systemd reports the unit
    // started before the daemon has finished coming up, so the first poll can
    // legitimately disagree with what we just asked for.
    let confirmed = false;
    for (let attempt = 0; attempt < 6 && !confirmed; attempt++) {
      await new Promise(r => setTimeout(r, 700));
      const st = await API.monitorStatus();
      if (st?.success && st.data && st.data.running === starting) {
        confirmed = true;
        monitorRunning = starting;
      }
    }

    restore();
    loadMonitor();
    loadMonitorStats();

    if (confirmed) {
      toast(starting ? 'Monitor started' : 'Monitor stopped', 'success');
    } else {
      // The command was accepted and the state did not follow. Saying so beats
      // a success toast over a monitor that is not running.
      toast(starting
        ? 'Start was accepted but the monitor is not running yet — check Details'
        : 'Stop was accepted but the monitor is still running — check Details',
        'error', 8000);
    }
    return;
  }

  restore();
  {
    // "Action failed" tells the operator nothing. The API explains itself --
    // the daemon script missing, systemd refusing, the unit not installed --
    // and that explanation is what makes the difference actionable.
    const why = (res && (res.error || res.message)) || 'no reason given by the server';
    toast('Monitor: ' + why, 'error', 7000);
    console.error('toggleMonitor failed:', res);
  }
}

async function loadMonitorDetections() {
  const res   = Demo.active ? Demo.mockMonitorDetections() : await API.monitorDetections(50);
  const tbody = document.getElementById('rt-detections-body');
  if (!tbody || !res?.success) return;
  const rows = res.data || [];
  tbody.innerHTML = rows.length === 0
    ? '<tr><td colspan="5" style="text-align:center;color:var(--txt3);padding:24px">No real-time detections</td></tr>'
    : rows.map(r =>
        '<tr>' +
        '<td>' + sevBadge(r.severity) + '</td>' +
        '<td style="font-family:monospace;font-size:.75rem;word-break:break-all">' + r.file_path + '</td>' +
        '<td><span class="badge badge-red" style="font-size:.7rem">' + r.threat_name + '</span></td>' +
        '<td><span class="sev sev-' + (r.status === 'quarantined' ? 'medium' : 'critical') + '">' + r.status + '</span></td>' +
        '<td style="color:var(--txt3)">' + reltime(r.detected_at) + '</td>' +
        '</tr>'
      ).join('');
}

async function loadMonitorLog() {
  if (Demo.active) {
    const el = document.getElementById('monitor-log');
    if (el) el.textContent =
      '[2024-01-15 14:22:01] INFO  Monitor started (inotify engine)\n' +
      '[2024-01-15 14:22:01] INFO  Watching: /home /var/www /tmp\n' +
      '[2024-01-15 14:23:45] ALERT CRITICAL c99_shell: /home/user1/public_html/uploads/image.php\n' +
      '[2024-01-15 14:23:45] INFO  Auto-quarantined -> quarantine/2024-01-15/\n' +
      '[2024-01-15 15:01:18] ALERT HIGH eval_base64: /home/user2/public_html/tmp/update.php';
    return;
  }
  const res = await API.monitorLogs(100);
  const el  = document.getElementById('monitor-log');
  if (el && res?.success) el.textContent = res.data || '(no log entries)';
}

async function addWatchPath() {
  const input = document.getElementById('mon-new-path');
  const path  = input?.value?.trim();
  if (!path) return toast('Enter a path first', 'error');
  const res = Demo.active ? { success: true } : await API.monitorAddPath(path);
  if (res?.success) {
    toast('Now watching: ' + path, 'success');
    if (input) input.value = '';
    loadMonitor();
  } else {
    toast(res?.error || 'Failed to add path', 'error');
  }
}

async function removeWatchPath(path) {
  const res = Demo.active ? { success: true } : await API.monitorRemovePath(path);
  if (res?.success) { toast('Removed: ' + path, 'success'); loadMonitor(); }
  else toast('Failed to remove path', 'error');
}

async function installMonitorService() {
  const btn = document.getElementById('install-service-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Installing…'; }
  const res = Demo.active
    ? { success: true, data: { message: 'Service installed (demo mode)' } }
    : await API.monitorInstallService();
  if (res?.success) toast(res.data?.message || 'Service installed successfully', 'success');
  else toast(res?.error || 'Installation failed', 'error');
  if (btn) { btn.disabled = false; btn.textContent = 'Install as System Service'; }
  loadMonitor();
  loadServiceStatus();
}

// ── Systemd Service Status Panel ─────────────────────────────────────────────

async function loadServiceStatus() {
  const res = Demo.active
    ? { success: true, data: {
        installed: true, enabled: true, active: true,
        active_state: 'active', sub_state: 'running',
        since: Math.floor(Date.now() / 1000) - 3600,
        main_pid: 1234, memory_mb: 18.4,
        description: 'ServerScrub Real-Time File Monitor',
        unit_file: '/etc/systemd/system/serverscrub-monitor.service'
      }}
    : await API.monitorServiceStatus();

  if (!res?.success) return;
  const d = res.data;
  State.lastService = d;

  // The badge needs the daemon's answer as well as systemd's, so it is
  // rendered in one place that has both.
  renderServiceBadge();

  // Info cells
  setText('svc-installed',  d.installed ? (d.unit_file || 'Yes') : 'Not installed');
  setText('svc-enabled',    d.enabled   ? 'Enabled (auto-start on boot)' : 'Disabled');
  setText('svc-since',      d.since     ? new Date(d.since * 1000).toLocaleString() : '—');
  setText('svc-pid',        d.main_pid  ? String(d.main_pid) : '—');
  setText('svc-mem',        d.memory_mb ? d.memory_mb + ' MB' : '—');
  setText('svc-substate',   d.sub_state || '—');

  // Auto-start toggle
  const toggle = document.getElementById('svc-autostart-toggle');
  if (toggle) toggle.checked = !!d.enabled;

  // Install strip — hide once installed
  const strip = document.getElementById('svc-install-strip');
  if (strip) strip.style.display = d.installed ? 'none' : '';
}

async function svcAction(action) {
  const validActions = ['start', 'stop', 'restart'];
  if (!validActions.includes(action)) return;

  if (Demo.active) {
    toast('Service ' + action + 'ed (demo)', 'success');
    return;
  }

  const fn = {
    start:   API.monitorStart,
    stop:    API.monitorStop,
    restart: API.monitorRestart
  }[action];

  const res = await fn();
  if (res?.success) {
    toast('Service ' + action + 'ed', 'success');
    setTimeout(() => { loadMonitor(); loadServiceStatus(); }, 800);
  } else {
    toast(res?.error || 'Action failed', 'error');
  }
}

async function toggleServiceAutostart(checked) {
  if (Demo.active) {
    toast(checked ? 'Auto-start enabled (demo)' : 'Auto-start disabled (demo)', 'success');
    return;
  }
  const res = checked ? await API.monitorEnableService() : await API.monitorDisableService();
  if (res?.success) toast(checked ? 'Auto-start enabled' : 'Auto-start disabled', 'success');
  else {
    toast(res?.error || 'Failed to update auto-start', 'error');
    // Revert toggle on failure
    const toggle = document.getElementById('svc-autostart-toggle');
    if (toggle) toggle.checked = !checked;
  }
}

async function loadServiceLogs() {
  if (Demo.active) {
    const el = document.getElementById('svc-journal-log');
    if (el) el.textContent =
      '2024-01-15T14:22:01+0000 serverscrub-monitor[1234]: INFO  Monitor started\n' +
      '2024-01-15T14:22:01+0000 serverscrub-monitor[1234]: INFO  inotify engine active\n' +
      '2024-01-15T14:22:01+0000 serverscrub-monitor[1234]: INFO  Watching /home\n' +
      '2024-01-15T15:30:00+0000 serverscrub-monitor[1234]: ALERT c99_shell detected';
    return;
  }
  const sel   = document.getElementById('svc-log-lines');
  const lines = parseInt(sel?.value || '50', 10);
  const res   = await API.monitorServiceLogs(lines);
  const el    = document.getElementById('svc-journal-log');
  if (el) {
    if (res?.success && Array.isArray(res.data) && res.data.length > 0) {
      el.textContent = res.data.join('\n');
    } else {
      el.textContent = '(no journal entries — service may not have run yet)';
    }
  }
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

// ── Storage Management ────────────────────────────────────────────────────────
async function loadStorageStats() {
  if (Demo.active) {
    populateStorageUI({
      quarantine: { path: '/usr/local/serverscrub/quarantine', size_bytes: 4718592, files: 7, writable: true },
      logs:       { path: '/usr/local/serverscrub/logs', size_bytes: 2097152, files: 12,
                    writable: true, monitor_log_bytes: 1048576 },
      database:   { path: '/usr/local/serverscrub/database/serverscrub.db', size_bytes: 8388608,
                    rows: { waf_events: 94441, security_events: 12803, threats: 47, cron_log: 342 } },
      defaults:   { quarantine_dir: '/home/.serverscrub/quarantine',
                    log_dir: '/usr/local/serverscrub/logs' },
      settings:   { quarantine_dir: '', log_dir: '', log_retention_days: 30,
                    quarantine_retention_days: 90, db_max_waf_events: 100000,
                    db_max_security_events: 50000, db_max_cron_log: 1000, monitor_log_max_mb: 50 },
    });
    return;
  }
  const res = await API.storageStats();
  if (res?.success) populateStorageUI(res.data);
  else toast('Could not load storage stats', 'error');
}

function populateStorageUI(d) {
  const q  = d.quarantine || {};
  const l  = d.logs       || {};
  const db = d.database   || {};
  const s  = d.settings   || {};

  // Quarantine card
  const qs = document.getElementById('stor-quar-size');
  if (qs) qs.textContent = fmtBytes(q.size_bytes || 0);
  const qf = document.getElementById('stor-quar-files');
  if (qf) qf.textContent = q.files || 0;
  const qst = document.getElementById('stor-quar-status');
  if (qst) qst.textContent = q.writable ? '✓ Writable' : '✕ Read-only';
  // Where quarantine IS, and what "blank" would mean — both from the server.
  //
  // The placeholder used to be the string /usr/local/serverscrub/quarantine,
  // written into the markup. That is only the last-resort default: config.php
  // prefers /home/.serverscrub or /var/.serverscrub whenever either is
  // writable, so on a cPanel box quarantine lives under /home and this card
  // named the wrong partition on every such server.
  const def = d.defaults || {};
  const qPath = document.getElementById('stor-quar-path');
  if (qPath) qPath.textContent = q.path || def.quarantine_dir || '—';
  const qdInput = document.getElementById('stor-quar-dir');
  if (qdInput) {
    if (s.quarantine_dir !== undefined) qdInput.value = s.quarantine_dir;
    if (def.quarantine_dir) qdInput.placeholder = def.quarantine_dir;
  }
  const qRange = document.getElementById('stor-quar-days-range');
  if (qRange) {
    qRange.value = s.quarantine_retention_days || 90;
    const qv = document.getElementById('stor-quar-days-val');
    if (qv) qv.textContent = (s.quarantine_retention_days || 90) + ' days';
  }

  // Logs card
  const ls = document.getElementById('stor-log-size');
  if (ls) ls.textContent = fmtBytes(l.size_bytes || 0);
  const lf = document.getElementById('stor-log-files');
  if (lf) lf.textContent = l.files || 0;
  const lm = document.getElementById('stor-log-monitor');
  if (lm) lm.textContent = fmtBytes(l.monitor_log_bytes || 0);
  const lPath = document.getElementById('stor-log-path');
  if (lPath) lPath.textContent = l.path || def.log_dir || '—';
  const ldInput = document.getElementById('stor-log-dir');
  if (ldInput) {
    if (s.log_dir !== undefined) ldInput.value = s.log_dir;
    if (def.log_dir) ldInput.placeholder = def.log_dir;
  }
  const lRange = document.getElementById('stor-log-days-range');
  if (lRange) {
    lRange.value = s.log_retention_days || 30;
    const lv = document.getElementById('stor-log-days-val');
    if (lv) lv.textContent = (s.log_retention_days || 30) + ' days';
  }
  const mRange = document.getElementById('stor-mon-mb-range');
  if (mRange) {
    mRange.value = s.monitor_log_max_mb || 50;
    const mv = document.getElementById('stor-mon-mb-val');
    if (mv) mv.textContent = (s.monitor_log_max_mb || 50) + ' MB';
  }

  // Database card
  const dbs = document.getElementById('stor-db-size');
  if (dbs) dbs.textContent = fmtBytes(db.size_bytes || 0);
  const dbw = document.getElementById('stor-db-waf');
  if (dbw) dbw.textContent = fmtNum(db.rows?.waf_events || 0);
  const dse = document.getElementById('stor-db-sec');
  if (dse) dse.textContent = fmtNum(db.rows?.security_events || 0);
  const dbt = document.getElementById('stor-db-threats');
  if (dbt) dbt.textContent = fmtNum(db.rows?.threats || 0);
  const dbc = document.getElementById('stor-db-cron');
  if (dbc) dbc.textContent = fmtNum(db.rows?.cron_log || 0);
  const mwInput = document.getElementById('stor-db-max-waf');
  if (mwInput && s.db_max_waf_events !== undefined) mwInput.value = s.db_max_waf_events;
  const msInput = document.getElementById('stor-db-max-sec');
  if (msInput && s.db_max_security_events !== undefined) msInput.value = s.db_max_security_events;
}

async function saveStorageSettings() {
  const g = id => document.getElementById(id);
  const data = {
    quarantine_dir:            g('stor-quar-dir')?.value?.trim()  || '',
    log_dir:                   g('stor-log-dir')?.value?.trim()   || '',
    log_retention_days:        parseInt(g('stor-log-days-range')?.value    || '30'),
    quarantine_retention_days: parseInt(g('stor-quar-days-range')?.value   || '90'),
    monitor_log_max_mb:        parseInt(g('stor-mon-mb-range')?.value      || '50'),
    db_max_waf_events:         parseInt(g('stor-db-max-waf')?.value        || '100000'),
    db_max_security_events:    parseInt(g('stor-db-max-sec')?.value        || '50000'),
  };
  const res = Demo.active ? { success: true } : await API.storageSaveSettings(data);
  if (res?.success) toast('Storage settings saved', 'success');
  else toast(res?.error || 'Save failed', 'error');
}

async function runStoragePrune() {
  const btn = document.getElementById('btn-stor-prune');
  if (btn) { btn.disabled = true; btn.textContent = 'Running…'; }
  const res = Demo.active
    ? { success: true, data: { quarantine_deleted: 2, logs_deleted: 14, waf_pruned: 5000, events_pruned: 1200 } }
    : await API.storagePrune();
  if (btn) { btn.disabled = false; btn.textContent = 'Run Cleanup Now'; }
  if (res?.success) {
    const d = res.data || {};
    const msg = `Cleanup done — Quarantine: ${d.quarantine_deleted||0} files, Logs: ${d.logs_deleted||0} files, WAF rows pruned: ${d.waf_pruned||0}, Event rows pruned: ${d.events_pruned||0}`;
    toast(msg, 'success');
    loadStorageStats();
  } else {
    toast(res?.error || 'Prune failed', 'error');
  }
}

// ── Change Admin Password (Standalone mode only) ──────────────────────────────
async function changeAdminPassword() {
  const u  = document.getElementById('chpw-user')?.value?.trim();
  const p  = document.getElementById('chpw-pass')?.value;
  const p2 = document.getElementById('chpw-pass2')?.value;
  if (!u || !p) return toast('Fill in all fields', 'error');
  if (p !== p2)  return toast('Passwords do not match', 'error');
  if (p.length < 8) return toast('Password too short (min 8 chars)', 'error');
  const res = Demo.active ? { success: true } : await API.changePassword(u, p);
  if (res?.success) {
    toast('Credentials updated — please log in again', 'success');
    document.getElementById('chpw-user').value = '';
    document.getElementById('chpw-pass').value = '';
    document.getElementById('chpw-pass2').value = '';
  } else {
    toast(res?.error || 'Update failed', 'error');
  }
}

// ── Bot Shield ────────────────────────────────────────────────────────────────
async function loadBotShield() {
  // The two paged tables fetch their own page, so a page change does not
  // re-request the stats and the whitelist along with it.
  const [statsRes, whiteRes] = await Promise.all([
    Demo.active ? { success: true, data: { bots_blocked_today: 142, total_blocked: 1048, whitelisted: 6, requests_analyzed: 284901 } } : API.botStats(),
    Demo.active ? { success: true, data: [] } : API.botWhitelist(),
  ]);
  if (statsRes?.success) {
    const d = statsRes.data;
    document.getElementById('bot-stat-today').textContent    = fmtNum(d?.bots_blocked_today || 0);
    document.getElementById('bot-stat-total').textContent    = fmtNum(d?.total_blocked || 0);
    document.getElementById('bot-stat-white').textContent    = fmtNum(d?.whitelisted || 0);
    document.getElementById('bot-stat-analyzed').textContent = fmtNum(d?.requests_analyzed || 0);
  }
  renderBotWhitelist(whiteRes?.data || []);
  await Promise.all([loadBotBlocked(), loadBotEvents()]);
}

function renderBotWhitelist(items) {
  const el = document.getElementById('bot-whitelist-list');
  if (!el) return;
  if (!items.length) { el.innerHTML = '<div class="dim">No whitelist entries. Good bots (Googlebot etc.) are detected automatically.</div>'; return; }
  el.innerHTML = items.map(w => `
    <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid var(--border)">
      <span class="mono" style="font-size:.78rem">${w.pattern}</span>
      <button class="btn btn-ghost btn-xs" onclick="removeBotWhitelist(${w.id})">x</button>
    </div>`).join('');
}

async function runBotScan() {
  toast('Analyzing access logs for bots...', 'info');
  const res = Demo.active
    ? { success: true, data: { bots_found: 23, bots_blocked: 18, duration_ms: 1240 } }
    : await API.botScan();
  if (res?.success) {
    const d = res.data || {};
    toast(`Analysis done - ${d.bots_found||0} bots found, ${d.bots_blocked||0} blocked`, 'success');
    loadBotShield();
  } else toast(res?.error || 'Analysis failed', 'error');
}

async function unblockBot(ip) {
  if (!confirm('Unblock bot IP ' + ip + '?')) return;
  const res = Demo.active ? { success: true } : await API.botUnblock(ip);
  if (res?.success) { toast(ip + ' unblocked', 'success'); loadBotShield(); }
  else toast('Unblock failed', 'error');
}

async function addBotWhitelist() {
  const pattern = document.getElementById('bot-white-pattern')?.value?.trim();
  if (!pattern) { toast('Enter a pattern', 'error'); return; }
  const res = Demo.active ? { success: true } : await API.botAddWhitelist(pattern, '');
  if (res?.success) {
    toast(pattern + ' whitelisted', 'success');
    document.getElementById('bot-white-pattern').value = '';
    loadBotShield();
  } else toast('Add failed', 'error');
}

async function removeBotWhitelist(id) {
  const res = Demo.active ? { success: true } : await API.botRemoveWhitelist(id);
  if (res?.success) { toast('Removed from whitelist', 'success'); loadBotShield(); }
  else toast('Remove failed', 'error');
}

// ── CMS Guard ─────────────────────────────────────────────────────────────────
async function loadCMSGuard() {
  const [statsRes, installsRes] = await Promise.all([
    Demo.active ? { success: true, data: { total_installs: 4, wordpress: 3, joomla: 1, drupal: 0, outdated: 2, installs_with_issues: 3, last_scan_at: Math.floor(Date.now()/1000), ever_scanned: true } } : API.cmsStats(),
    Demo.active ? { success: true, data: [
      { id:1, cms_type:'wordpress', version:'6.2.1', cpanel_user:'alice', install_path:'/home/alice/public_html', issues:'["xmlrpc_enabled","login_exposed"]', outdated:1, status:'warning' },
      { id:2, cms_type:'wordpress', version:'6.4.2', cpanel_user:'bob',   install_path:'/home/bob/public_html',   issues:'[]', outdated:0, status:'ok' },
      { id:3, cms_type:'joomla',    version:'4.2.0', cpanel_user:'carol', install_path:'/home/carol/public_html', issues:'["outdated_version"]', outdated:1, status:'warning' },
    ]} : API.cmsInstalls(),
  ]);

  if (statsRes?.success) {
    const d = statsRes.data;
    // The API returns total_installs. This read d.total — the key the DEMO
    // fixture uses — so the counter showed 0 no matter how many sites were
    // found. The demo shape and the real shape had drifted apart, and only the
    // demo was ever looked at. Both are accepted now; test_cmsguard.php asserts
    // the real one exists.
    const total = d?.total_installs ?? d?.total ?? 0;
    document.getElementById('cms-stat-total').textContent    = fmtNum(total);
    document.getElementById('cms-stat-outdated').textContent = fmtNum(d?.outdated || 0);
    document.getElementById('cms-stat-issues').textContent   = fmtNum(d?.installs_with_issues || 0);
    document.getElementById('cms-stat-wp').textContent       = fmtNum(d?.wordpress || 0);
  }

  const installs = installsRes?.data || [];
  const badge = document.getElementById('cms-count-badge');
  if (badge) badge.textContent = installs.length + ' found';

  const tbody = document.getElementById('cms-installs-body');
  if (!tbody) return;
  if (!installs.length) {
    // Distinguish "nothing here" from "we have not looked yet". A server with
    // WordPress on it showing "0 websites" reads as a broken product; saying no
    // scan has run reads as a next step.
    const everScanned = statsRes?.data?.ever_scanned;
    const msg = everScanned
      ? 'No CMS installations found. Scan again if you have added sites since '
        + (statsRes.data.last_scan_at ? reltime(statsRes.data.last_scan_at) : 'the last scan') + '.'
      : 'No scan has run yet — click "Scan Server" to discover CMS installations.';
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--txt3);padding:28px">'
                    + esc(msg) + '</td></tr>';
    return;
  }
  // install_path, version and cpanel_user were interpolated raw. A hosting
  // customer chooses their own directory names, so that is markup supplied by
  // someone else rendered into the server administrator's page.
  tbody.innerHTML = installs.map(c => {
    let issues = [];
    try {
      const parsed = JSON.parse(c.issues || '[]');
      // Stored either as slugs or as {type,message} objects depending on age.
      issues = (Array.isArray(parsed) ? parsed : [])
        .map(i => (i && typeof i === 'object') ? (i.type || '') : String(i))
        .filter(Boolean);
    } catch (_) {}

    const icons    = { wordpress: 'WP', joomla: 'JM', drupal: 'DR' };
    const cmsLabel = icons[c.cms_type] || c.cms_type || '?';
    const version  = c.version || 'unknown';
    const target   = c.target_version || '';

    return '<tr>' +
      '<td><span class="badge badge-blue" style="font-size:.7rem">' + esc(cmsLabel) + '</span></td>' +
      '<td class="mono" style="color:' + (c.outdated ? 'var(--amber)' : 'var(--green)') + '">' +
        esc(version) + (c.outdated ? ' ↓' : '') + '</td>' +
      // Showing what it was judged against: "6.5 !" on its own is a verdict
      // the operator has no way to check or disagree with.
      '<td class="mono dim">' + (target ? esc(target) : '—') + '</td>' +
      '<td>' + cmsRiskBadge(c.risk, c.outdated) + '</td>' +
      '<td class="mono" style="color:var(--blue)">' + (esc(c.cpanel_user) || '—') + '</td>' +
      '<td class="mono" style="font-size:.72rem;max-width:180px;overflow:hidden;text-overflow:ellipsis" title="' +
        esc(c.install_path) + '">' + esc(c.install_path) + '</td>' +
      '<td>' + (issues.length
        ? issues.map(i => '<span class="badge badge-amber" style="font-size:.62rem;margin:1px">' +
            esc(i.replace(/_/g, ' ')) + '</span>').join('')
        : '<span class="badge badge-green" style="font-size:.62rem">None</span>') + '</td>' +
      '<td>' + (c.status === 'ok'
        ? '<span class="badge badge-green">OK</span>'
        : '<span class="badge badge-amber">Issues</span>') + '</td>' +
      '<td><button class="btn btn-ghost btn-xs" onclick="recheckCMS(' + (Number(c.id) || 0) + ')">Recheck</button></td>' +
      '</tr>';
  }).join('');
}

function cmsRiskBadge(risk, outdated) {
  // Fall back to the outdated flag for rows written before risk existed,
  // rather than rendering an empty cell that reads as "no risk".
  const level = risk || (outdated ? 'medium' : 'ok');
  const map = {
    high:    ['badge badge-red',   'At risk'],
    medium:  ['badge badge-amber', 'Outdated'],
    low:     ['badge badge-gray',  'Minor'],
    ok:      ['badge badge-green', 'Current'],
    unknown: ['badge badge-gray',  'Unknown'],
  };
  const [cls, label] = map[level] || map.unknown;
  return '<span class="' + cls + '">' + label + '</span>';
}

async function runCMSScan() {
  toast('Scanning server for CMS installations...', 'info');
  const btn = document.getElementById('cms-scan-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Scanning...'; }
  const res = Demo.active
    ? { success: true, data: { found: 4, wordpress: 3, joomla: 1, issues_found: 3 } }
    : await API.cmsScan();
  if (btn) { btn.disabled = false; btn.textContent = 'Scan Server'; }
  if (res?.success) {
    const d = res.data || {};
    toast('Scan complete - ' + (d.found||0) + ' installs found, ' + (d.issues_found||0) + ' with issues', 'success');
    loadCMSGuard();
  } else toast(res?.error || 'Scan failed', 'error');
}

async function recheckCMS(id) {
  const res = Demo.active ? { success: true } : await API.cmsCheck(id);
  if (res?.success) { toast('Re-check complete', 'success'); loadCMSGuard(); }
  else toast('Check failed', 'error');
}

// ── Rootkit Scanner ───────────────────────────────────────────────────────────
async function loadRootkit() {
  const [statusRes, scansRes] = await Promise.all([
    Demo.active ? { success: true, data: { rkhunter_available: true, chkrootkit_available: false } } : API.rootkitStatus(),
    Demo.active ? { success: true, data: [] } : API.rootkitScans(),
  ]);

  if (statusRes?.success) {
    const d = statusRes.data;
    const rkIcon = document.getElementById('rk-rkhunter-icon');
    const rkSt   = document.getElementById('rk-rkhunter-status');
    const ckIcon = document.getElementById('rk-chkrootkit-icon');
    const ckSt   = document.getElementById('rk-chkrootkit-status');
    if (rkIcon) rkIcon.textContent = d?.rkhunter_available ? 'OK' : 'X';
    if (rkSt)   rkSt.textContent   = d?.rkhunter_available ? 'Available' : 'Not installed';
    if (ckIcon) ckIcon.textContent = d?.chkrootkit_available ? 'OK' : 'X';
    if (ckSt)   ckSt.textContent   = d?.chkrootkit_available ? 'Available' : 'Not installed';

    // "Not installed" on its own left the operator to work out what to do
    // about it. The installer fits these now, so if they are still missing
    // something went wrong -- say what, and what covers the gap meanwhile.
    const note = document.getElementById('rk-tools-note');
    if (note) {
      const missing = [];
      if (!d?.rkhunter_available)   missing.push('rkhunter');
      if (!d?.chkrootkit_available) missing.push('chkrootkit');
      if (missing.length) {
        note.style.display = '';
        note.textContent =
          missing.join(' and ') + ' could not be installed on this server. '
          + 'Scans still run: the built-in engine needs neither and covers the '
          + 'same checks. To retry, run  serverscrub install-rootkit-tools  as root.';
      } else {
        note.style.display = 'none';
      }
    }
  }

  const scans = scansRes?.data || [];
  const tbody = document.getElementById('rootkit-history-body');
  if (tbody) {
    if (!scans.length) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--txt3);padding:20px">No scan history</td></tr>';
    } else {
      tbody.innerHTML = scans.map(s => '<tr>' +
        '<td class="mono">' + s.tool + '</td>' +
        '<td class="dim">' + reltime(s.finished_at || s.started_at) + '</td>' +
        '<td style="color:' + (s.warnings_count > 0 ? 'var(--amber)' : 'var(--green)') + '">' + s.warnings_count + '</td>' +
        '<td style="color:' + (s.infected_count > 0 ? 'var(--red)' : 'var(--green)') + '">' + s.infected_count + '</td>' +
        '<td><button class="btn btn-ghost btn-xs" onclick="viewRootkitFindings(' + s.id + ')">View</button></td>' +
        '</tr>').join('');
      const last = scans[0];
      const badge = document.getElementById('rk-last-badge');
      if (badge) {
        badge.textContent = last.infected_count > 0 ? last.infected_count + ' INFECTED' :
          last.warnings_count > 0 ? last.warnings_count + ' Warnings' : 'Clean';
        badge.className = 'badge ' + (last.infected_count > 0 ? 'badge-red' : last.warnings_count > 0 ? 'badge-amber' : 'badge-green');
      }
      const resultEl = document.getElementById('rk-last-result');
      if (resultEl) resultEl.textContent = 'Tool: ' + last.tool + ' | Scanned: ' + reltime(last.finished_at||last.started_at) + ' | Warnings: ' + last.warnings_count + ' | Infected: ' + last.infected_count;
    }
  }
}

async function runRootkitScan() {
  const tool = document.getElementById('rootkit-tool-sel')?.value || 'rkhunter';
  const btn  = document.getElementById('rootkit-scan-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Scanning...'; }
  toast('Running ' + tool + ' scan - this may take a few minutes...', 'info');
  const res = Demo.active
    ? { success: true, data: { tool: tool, warnings_count: 2, clean_count: 167, infected_count: 0 } }
    : await API.rootkitScan(tool);
  if (btn) { btn.disabled = false; btn.textContent = 'Start Scan'; }
  if (res?.success) {
    const d = res.data || {};
    toast(tool + ' scan complete - ' + (d.warnings_count||0) + ' warnings, ' + (d.infected_count||0) + ' infected', d.infected_count > 0 ? 'error' : 'success');
    loadRootkit();
  } else toast(res?.error || 'Scan failed - tool may not be installed', 'error');
}

async function viewRootkitFindings(scanId) {
  const res = Demo.active ? { success: true, data: [] } : await API.rootkitFindings(scanId);
  const container = document.getElementById('rk-findings-list');
  if (!container) return;
  const findings = res?.data || [];
  if (!findings.length) { container.innerHTML = '<div class="dim" style="font-size:.78rem">No findings for this scan.</div>'; return; }
  container.innerHTML = '<div class="label" style="font-size:.72rem;margin-bottom:8px">Findings</div>' +
    findings.map(f => '<div style="display:flex;gap:10px;align-items:flex-start;padding:6px 0;border-bottom:1px solid var(--border)">' +
      '<span class="badge ' + (f.finding_type==='infected' ? 'badge-red' : f.finding_type==='warning' ? 'badge-amber' : 'badge-green') + '" style="font-size:.62rem;white-space:nowrap">' + f.finding_type + '</span>' +
      '<div><div style="font-size:.75rem;font-weight:600;color:var(--txt2)">' + (f.category||'General') + '</div>' +
      '<div style="font-size:.72rem;color:var(--txt3);margin-top:2px">' + f.description + '</div></div>' +
      '</div>').join('');
}

// ── File Integrity ────────────────────────────────────────────────────────────
async function loadIntegrity() {
  const [statsRes, pathsRes] = await Promise.all([
    Demo.active ? { success: true, data: { total_monitored: 0, clean: 0, modified: 0, new_files: 0, missing: 0 } } : API.integrityStats(),
    Demo.active ? { success: true, data: [] } : API.integrityPaths(),
  ]);

  if (statsRes?.success) {
    const d = statsRes.data;
    document.getElementById('int-stat-total').textContent    = fmtNum(d?.total_monitored || 0);
    document.getElementById('int-stat-clean').textContent    = fmtNum(d?.clean || 0);
    document.getElementById('int-stat-modified').textContent = fmtNum(d?.modified || 0);
    document.getElementById('int-stat-issues').textContent   =
      fmtNum((d?.new_files ?? d?.new_count ?? 0) + (d?.missing ?? d?.missing_count ?? 0));
  }

  const paths = pathsRes?.data || [];
  const pathEl = document.getElementById('int-paths-list');
  if (pathEl) {
    pathEl.innerHTML = paths.length
      ? paths.map(p => '<div class="mono" style="font-size:.75rem;padding:3px 0;color:var(--txt2)">/ ' + (p.path||p) + ' <span class="dim">(' + fmtNum(p.count||0) + ' files)</span></div>').join('')
      : '<div class="dim">No baseline created yet</div>';
  }

  loadIntegrityChanges('');
}

async function loadIntegrityChanges(status) {
  const res = Demo.active ? { success: true, data: [] } : await API.integrityChanges(status);
  const changes = res?.data || [];
  const badge = document.getElementById('int-changes-badge');
  if (badge) badge.textContent = changes.length + ' changes';

  const tbody = document.getElementById('integrity-changes-body');
  if (!tbody) return;
  if (!changes.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--txt3);padding:28px">No changes detected - system is clean</td></tr>';
    return;
  }
  const stMap = { modified: 'badge-amber', new: 'badge-blue', missing: 'badge-red', acknowledged: 'badge-gray' };
  tbody.innerHTML = changes.map(c => '<tr>' +
    '<td><span class="badge ' + (stMap[c.status]||'badge-gray') + '">' + c.status + '</span></td>' +
    '<td class="mono" style="font-size:.72rem;max-width:260px;overflow:hidden;text-overflow:ellipsis" title="' + c.file_path + '">' + c.file_path + '</td>' +
    '<td class="dim">' + fmtBytes(c.size||0) + '</td>' +
    '<td class="mono" style="font-size:.72rem">' + (c.owner||'-') + '</td>' +
    '<td class="dim">' + (c.last_check ? reltime(c.last_check) : '-') + '</td>' +
    '<td>' + (c.status !== 'acknowledged' ? '<button class="btn btn-ghost btn-xs" onclick="acknowledgeIntegrityChange(' + c.id + ')">Acknowledge</button>' : '') + '</td>' +
    '</tr>').join('');
}

async function createBaseline() {
  const path = document.getElementById('int-baseline-path')?.value?.trim() || '/home';
  toast('Creating baseline for ' + path + '...', 'info');
  const res = Demo.active ? { success: true, data: { files: 12847 } } : await API.integrityBaseline(path);
  const d = res?.data || {};
  // An error is reported in data.error, not only at the top level: a path that
  // does not exist came back as success:true with an error inside it, so a
  // typo'd path produced a cheerful "0 files hashed".
  if (res?.success && !d.error) {
    toast('Baseline created — ' + fmtNum(d.files ?? d.hashed ?? 0) + ' files hashed', 'success');
    loadIntegrity();
  } else toast(d.error || res?.error || 'Baseline failed', 'error');
}

async function runIntegrityCheck() {
  toast('Running integrity check...', 'info');
  const res = Demo.active ? { success: true, data: { changed: 0 } } : await API.integrityCheck('');
  if (res?.success) {
    const d = res.data || {};
    // d.modified / d.missing / d.new are ARRAYS of the affected files. Adding
    // them as if they were counts produced "[object Object]" arithmetic and a
    // reported 0, so a check that found real tampering said everything was
    // fine. The API now also returns scalar counts; prefer those.
    const changed = d.changed ?? (
      (d.modified_count || 0) + (d.new_count || 0) + (d.missing_count || 0)
    );
    toast('Check complete — ' + fmtNum(changed) + ' change(s) detected',
          changed ? 'error' : 'success');
    loadIntegrity();
  } else toast(res?.error || 'Check failed', 'error');
}

async function acknowledgeIntegrityChange(id) {
  const res = Demo.active ? { success: true } : await API.integrityAck(id);
  if (res?.success) { toast('Change acknowledged', 'success'); loadIntegrityChanges(''); }
  else toast('Acknowledge failed', 'error');
}

// ── PHP Hardening ─────────────────────────────────────────────────────────────
async function loadPHPHardening() {
  const [statsRes, recsRes, settingsRes, accountsRes] = await Promise.all([
    Demo.active ? { success: true, data: { critical: 1, high: 3, medium: 2, already_hardened: 4 } } : API.phpStats(),
    Demo.active ? { success: true, data: [
      { setting:'allow_url_include', current_value:'On', recommended_value:'Off', severity:'critical', description:'Remote file inclusion attack vector', can_apply:true },
      { setting:'display_errors',    current_value:'On', recommended_value:'Off', severity:'high',     description:'Exposes error details to users', can_apply:true },
      { setting:'allow_url_fopen',   current_value:'On', recommended_value:'Off', severity:'high',     description:'Allows remote file access', can_apply:true },
      { setting:'expose_php',        current_value:'On', recommended_value:'Off', severity:'medium',   description:'Reveals PHP version in headers', can_apply:true },
    ]} : API.phpRecs(),
    Demo.active ? { success: true, data: { expose_php:'On', display_errors:'On', allow_url_fopen:'On', allow_url_include:'On', disable_functions:'', 'session.cookie_httponly':'0' } } : API.phpSettings(),
    State.installMode !== 'standalone'
      ? (Demo.active ? { success: true, data: [{ username:'alice', php_version:'8.1', hardened:false },{ username:'bob', php_version:'8.2', hardened:true }] } : API.phpAccounts())
      : { success: true, data: [] },
  ]);

  if (statsRes?.success) {
    const d = statsRes.data;
    document.getElementById('php-stat-critical').textContent = d?.critical || 0;
    document.getElementById('php-stat-high').textContent     = d?.high || 0;
    document.getElementById('php-stat-medium').textContent   = d?.medium || 0;
    document.getElementById('php-stat-ok').textContent       = d?.already_hardened || 0;
  }

  const recs = recsRes?.data || [];
  const recsEl = document.getElementById('php-recs-list');
  if (recsEl) {
    if (!recs.length) {
      recsEl.innerHTML = '<div style="padding:20px;text-align:center;color:var(--green)">PHP is well configured - no issues found!</div>';
    } else {
      const sevClass = { critical:'badge-red', high:'badge-amber', medium:'badge-blue', low:'badge-gray' };
      recsEl.innerHTML = recs.map(r => '<div style="display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border)">' +
        '<span class="badge ' + (sevClass[r.severity]||'badge-gray') + '" style="white-space:nowrap;font-size:.65rem">' + r.severity.toUpperCase() + '</span>' +
        '<div style="flex:1">' +
          '<div style="font-weight:700;font-size:.82rem;font-family:var(--font-mono)">' + r.setting + '</div>' +
          '<div style="font-size:.75rem;color:var(--txt2);margin-top:2px">' + r.description + '</div>' +
          '<div style="font-size:.72rem;color:var(--txt3);margin-top:4px">Current: <code style="background:rgba(239,68,68,.1);color:var(--red);padding:1px 4px;border-radius:3px">' + r.current_value + '</code> &rarr; Recommended: <code style="background:rgba(34,197,94,.1);color:var(--green);padding:1px 4px;border-radius:3px">' + r.recommended_value + '</code></div>' +
        '</div>' +
        (r.can_apply ? '<button class="btn btn-primary btn-xs" onclick="applyPHPSetting(\'' + r.setting + '\',\'' + r.recommended_value + '\')">Apply</button>' : '') +
        '</div>').join('');
    }
  }

  const settings = settingsRes?.data || {};
  const tbody = document.getElementById('php-settings-body');
  if (tbody && Object.keys(settings).length) {
    const dangerKeys = ['allow_url_include','allow_url_fopen','display_errors','expose_php','register_globals'];
    tbody.innerHTML = Object.entries(settings).map(([k, v]) => {
      const isDanger = ['On','1'].includes(String(v)) && dangerKeys.includes(k);
      return '<tr><td class="mono" style="font-size:.75rem">' + k + '</td><td class="mono" style="color:' + (isDanger ? 'var(--red)' : 'var(--txt2)') + ';font-size:.75rem">' + (v||'(empty)') + '</td></tr>';
    }).join('');
  }

  const accounts = accountsRes?.data || [];
  const accTbody = document.getElementById('php-accounts-body');
  if (accTbody) {
    accTbody.innerHTML = accounts.length
      ? accounts.map(a => '<tr>' +
          '<td class="mono">' + (a.username||a.user||'-') + '</td>' +
          '<td class="mono">' + (a.php_version||'Default') + '</td>' +
          '<td>' + (a.hardened ? '<span class="badge badge-green">Yes</span>' : '<span class="badge badge-gray">No</span>') + '</td>' +
          '<td><button class="btn btn-ghost btn-xs" onclick="applyAccountHardening(\'' + (a.username||a.user) + '\')">Harden</button></td>' +
          '</tr>').join('')
      : '<tr><td colspan="4" style="text-align:center;color:var(--txt3);padding:20px">No accounts found</td></tr>';
  }
}

async function applyPHPSetting(setting, value) {
  const data = {};
  data[setting] = value;
  const res = Demo.active ? { success: true } : await API.phpApply(data);
  if (res?.success) { toast(setting + ' applied', 'success'); loadPHPHardening(); }
  else toast(res?.error || 'Apply failed - may require root', 'error');
}

async function applyAllRecommendations() {
  if (Demo.active) { toast('Applied 4 settings (demo)', 'success'); return; }
  const recsRes = await API.phpRecs();
  const safe = (recsRes?.data || []).filter(x => x.can_apply)
    .reduce((acc, x) => { acc[x.setting] = x.recommended_value; return acc; }, {});
  const res = await API.phpApply(safe);
  if (res?.success) {
    const d = res.data || {};
    toast('Applied ' + (d.applied||0) + ' settings, ' + (d.failed||0) + ' failed', 'success');
    loadPHPHardening();
  } else toast(res?.error || 'Apply failed', 'error');
}

async function applyAccountHardening(account) {
  toast('Hardening ' + account + '...', 'info');
  const settings = { display_errors:'Off', allow_url_include:'Off', expose_php:'Off', 'session.cookie_httponly':'1' };
  const res = Demo.active ? { success: true, data: { applied: 4 } } : await API.phpApplyAccount(account, settings);
  if (res?.success) { toast(account + ' hardened', 'success'); loadPHPHardening(); }
  else toast(res?.error || 'Harden failed', 'error');
}

/* ══════════════════════════════════════════════════════════════════════════════
   License
   ══════════════════════════════════════════════════════════════════════════════
   The API returns 402 + needs_license on any gated route. api.js calls
   onLicenseBlocked() centrally so every page behaves the same way rather than
   each rendering its own generic error. */

let _licenseBlockedShown = false;

function onLicenseBlocked(payload) {
  // Only interrupt once per page load — a dashboard fires several parallel
  // requests and would otherwise stack identical banners.
  if (_licenseBlockedShown) return;
  _licenseBlockedShown = true;

  // Show the activation screen rather than a red toast plus a jump to Settings.
  // A licence that has not been entered yet is an expected setup step, not a
  // fault, and presenting it as an error makes a working install look broken.
  showActivateScreen({
    status:  (payload && payload.license_state) || 'Unlicensed',
    message: (payload && payload.error) || '',
  });
}

function _licenseBadgeClass(status) {
  switch (status) {
    case 'Active':    return 'badge badge-green';
    case 'Expired':
    case 'Suspended':
    case 'Invalid':   return 'badge badge-red';
    case 'Unknown':   return 'badge badge-amber';
    default:          return 'badge badge-gray';
  }
}

async function loadLicense() {
  const badge   = document.getElementById('license-badge');
  const summary = document.getElementById('license-summary');
  const meta    = document.getElementById('license-meta');
  if (!badge) return;

  const res = Demo.active
    ? { license: { status:'Active', valid:true, ui_allowed:true, protection_allowed:true,
                   degraded:false, message:'License active.', expires:'2027-08-08',
                   checked_at: Math.floor(Date.now()/1000) - 2*86400,
                   domain:'srv1.example.com', ip:'203.0.113.10' } }
    : await API.get('license/status');
  const lic = res && res.license;
  if (!lic) {
    badge.className = 'badge badge-gray';
    badge.textContent = 'Unavailable';
    if (summary) summary.textContent = 'Could not read license status.';
    return;
  }

  badge.className   = _licenseBadgeClass(lic.status);
  badge.textContent = lic.status + (lic.degraded ? ' (degraded)' : '');
  if (summary) summary.textContent = lic.message || '';

  // The "no secret configured" warning was removed in 3.23.0. The WHMCS
  // Licensing Addon v3.1 signs with an empty secret, so an unset
  // SG_LICENSE_SECRET is the normal state, not a fault -- warning about it
  // would fire on every correctly configured server.
  const warn = document.getElementById('license-config-warning');
  if (warn) { warn.classList.add('hidden'); }

  if (meta) {
    meta.classList.remove('hidden');
    const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v || '—'; };
    set('license-status-val', lic.status);
    set('license-expires-val', lic.expires);
    set('license-checked-val',
        lic.checked_at ? new Date(lic.checked_at * 1000).toLocaleString() : 'never');
  }
}

function _licenseError(msg) {
  const box = document.getElementById('license-error');
  if (!box) return;
  if (!msg) { box.classList.add('hidden'); box.textContent = ''; return; }
  box.classList.remove('hidden');
  box.textContent = msg;
}

async function activateLicense() {
  const input = document.getElementById('license-key-input');
  const key   = input ? input.value.trim() : '';
  _licenseError('');

  if (!key) { _licenseError('Enter a license key first.'); return; }

  const res = await API.post('license/activate', { key });
  if (res && res.success) {
    toast('License activated', 'success');
    if (input) input.value = '';
    _licenseBlockedShown = false;   // allow a fresh prompt if it lapses again
    await loadLicense();
    // Re-run whatever page the user is on now that the gate has lifted
    if (typeof refreshDashboard === 'function') refreshDashboard();
  } else {
    _licenseError((res && res.error) || 'Activation failed.');
    await loadLicense();
  }
}

async function refreshLicense() {
  _licenseError('');
  const res = await API.post('license/refresh');
  if (res && res.success) {
    toast('License re-checked', 'success');
    _licenseBlockedShown = false;
  } else {
    _licenseError((res && res.error) || 'Re-check failed.');
  }
  await loadLicense();
}


/* ── Schedule field visibility ────────────────────────────────────────────────
   Only show the inputs a given schedule actually uses. Leaving "day of week"
   visible on a daily schedule invites the user to set a value that is silently
   ignored, and then to report it as a bug. */
function syncScheduleFields() {
  const vis = (id, on) => { const e = document.getElementById(id); if (e) e.style.display = on ? '' : 'none'; };
  const val = id => document.getElementById(id)?.value;

  const scan = val('set-scan-schedule');
  vis('wrap-scan-time', scan === 'daily' || scan === 'weekly');
  vis('wrap-scan-day',  scan === 'weekly');

  vis('wrap-sig-day', val('set-sig-schedule') === 'weekly');
}

['set-scan-schedule', 'set-sig-schedule'].forEach(id => {
  document.addEventListener('change', e => {
    if (e.target && e.target.id === id) syncScheduleFields();
  });
});

async function updateSignaturesNow() {
  toast('Updating virus definitions…', 'info');
  const res = await API.updateSigs();
  if (res && res.success) {
    toast('Virus definitions updated', 'success');
    loadSettings();
  } else {
    toast((res && res.error) || 'Definition update failed', 'error');
  }
}

/* ══════════════════════════════════════════════════════════════════════════════
   Self-update
   ══════════════════════════════════════════════════════════════════════════════
   The update replaces the very code that serves the API, so this cannot be a
   single request-and-wait. The server starts the updater detached and writes
   progress to a file outside the install directory; the UI polls that.

   The important consequence: mid-update the API is BEING OVERWRITTEN, so polls
   will fail — connection refused, 502, half-written PHP. Those are expected, not
   errors, and must not abort the flow. Only a long unbroken run of failures
   means something is actually wrong. */

let _updPoll = null;
let _updFails = 0;
let _updStarted = 0;

function _el(id) { return document.getElementById(id); }

function showUpdateButton(info) {
  const btn = _el('update-now-btn');
  if (!btn) return;
  if (info && info.update_available) {
    _el('update-btn-version').textContent = 'v' + (info.latest_version || '?');
    btn.classList.remove('hidden');
  } else {
    btn.classList.add('hidden');
  }
}

function _setProgress(pct, msg, title) {
  const f = _el('update-bar-fill'), p = _el('update-pct'),
        m = _el('update-msg'),      t = _el('update-title');
  if (f) f.style.width = Math.max(0, Math.min(100, pct)) + '%';
  if (p) p.textContent = Math.round(pct) + '%';
  if (m && msg) m.textContent = msg;
  if (t && title) t.textContent = title;
}

async function startUpdate() {
  if (Demo.active) { _demoUpdate(); return; }

  const overlay = _el('update-overlay');
  overlay.classList.remove('hidden');
  _el('update-close').classList.add('hidden');
  _el('update-spinner').className = 'update-spinner';
  _setProgress(1, 'Starting update…', 'Updating ServerScrub');

  const res = await API.post('update/run', {});
  if (!res || !res.success) {
    // 409 means one is already running — attach to it rather than failing.
    if (res && res.data && res.data.status === 'running') {
      _pollUpdate();
      return;
    }
    _updateFailed((res && res.error) || 'Could not start the update.');
    return;
  }

  _updFails = 0;
  _updStarted = Date.now();
  _pollUpdate();
}

function _pollUpdate() {
  clearInterval(_updPoll);
  _updPoll = setInterval(async () => {
    let d = null;
    try {
      const r = await API.get('update/progress');
      d = r && r.data;
    } catch (_) { d = null; }

    if (!d) {
      // Expected while the API's own files are being replaced. Give it a long
      // rope — 40 polls at 2s is over a minute of tolerated unavailability —
      // before calling it a failure.
      if (++_updFails > 40) {
        clearInterval(_updPoll);
        _updateFailed('Lost contact with the server. Check logs/update.log.');
      }
      return;
    }
    _updFails = 0;

    _setProgress(d.percent || 0, d.message || '');

    if (d.status === 'success') {
      clearInterval(_updPoll);
      _el('update-spinner').className = 'update-spinner done';
      _setProgress(100, d.message || 'Update complete', 'Updated successfully');
      _el('update-close').classList.remove('hidden');
      // Give the services a moment to come back before reloading.
      setTimeout(finishUpdate, 2500);
    } else if (d.status === 'rolled_back') {
      clearInterval(_updPoll);
      _el('update-spinner').className = 'update-spinner failed';
      _setProgress(100,
        d.message || 'Rolled back to the previous version. Your data is intact.',
        'Update failed — rolled back');
      _el('update-close').classList.remove('hidden');
    } else if (d.status === 'failed') {
      clearInterval(_updPoll);
      _updateFailed(d.message || 'The update failed.');
    }
  }, 2000);
}

function _updateFailed(msg) {
  clearInterval(_updPoll);
  _el('update-spinner').className = 'update-spinner failed';
  _setProgress(100, msg, 'Update failed');
  _el('update-close').classList.remove('hidden');
}

function finishUpdate() {
  // Full reload, not just a data refresh: the JS and CSS themselves have been
  // replaced on disk, so the running page is the OLD build talking to the NEW
  // backend. Reloading is the only way to get a consistent pair.
  window.location.reload();
}

/* Demo-mode walkthrough so the flow can be reviewed without a real update. */
function _demoUpdate() {
  const overlay = _el('update-overlay');
  overlay.classList.remove('hidden');
  _el('update-close').classList.add('hidden');
  _el('update-spinner').className = 'update-spinner';
  const steps = [
    [5,  'Checking for updates…'],
    [15, 'Downloading v3.11.0…'],
    [30, 'Backing up your data…'],
    [45, 'Snapshotting current version…'],
    [55, 'Applying v3.11.0…'],
    [75, 'Restoring your settings and data…'],
    [85, 'Running database migrations…'],
    [100,'Update complete'],
  ];
  let i = 0;
  const t = setInterval(() => {
    if (i >= steps.length) {
      clearInterval(t);
      _el('update-spinner').className = 'update-spinner done';
      _setProgress(100, 'Updated to v3.11.0', 'Updated successfully');
      _el('update-close').classList.remove('hidden');
      return;
    }
    _setProgress(steps[i][0], steps[i][1]);
    i++;
  }, 900);
}


/* HTML-escape before interpolating into innerHTML.
   Not optional here: blocklist "reason" text derives from DNS answers, and
   rootkit findings embed filesystem paths — an attacker who can create a file
   named `<img onerror=...>` would otherwise get script execution in the
   admin's browser, from inside the tool meant to detect them. */
function esc(v) {
  if (v === null || v === undefined) return '';
  return String(v)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* ══════════════════════════════════════════════════════════════════════════════
   Blocklist matrix
   ══════════════════════════════════════════════════════════════════════════════
   Every list is shown separately rather than as one score, because delisting
   requires knowing WHICH service lists you — a single number cannot tell an
   operator where to go. */

// Check every address this server sends from, not just the first one.
async function checkAllServerIps() {
  const tbody   = document.getElementById('srv-ips-body');
  const summary = document.getElementById('srv-ips-summary');
  if (!tbody) return;

  tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--txt3);padding:18px">Querying blocklists for every server address… this takes a few seconds per address.</td></tr>';
  if (summary) { summary.textContent = 'checking…'; summary.className = 'badge badge-gray'; }

  const res = Demo.active
    ? { success: true, data: { checked: 1, listed: 0, worst_score: 0,
        ips: [{ ip: '203.0.113.10', checked: 25, listed: 0, score: 0, risk: 'clean' }] } }
    : await API.get('iprep/check-server-ips');

  if (!res?.success) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--txt3);padding:18px">${
      esc(res?.error || 'Could not check the server addresses')}</td></tr>`;
    if (summary) { summary.textContent = 'check failed'; summary.className = 'badge badge-amber'; }
    return;
  }

  const d   = res.data || {};
  const ips = d.ips || [];

  if (summary) {
    summary.textContent = d.listed
      ? `${d.listed} of ${d.checked} listed`
      : `${d.checked} address(es) clean`;
    summary.className = d.listed ? 'badge badge-red' : 'badge badge-green';
  }

  if (!ips.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--txt3);padding:18px">No public IPv4 address detected on this host.</td></tr>';
    return;
  }

  tbody.innerHTML = ips.map(r => {
    const listed = Number(r.listed || 0);
    const verdict = r.error
      ? '<span class="badge badge-amber">lookup failed</span>'
      : listed
        ? '<span class="badge badge-red">listed</span>'
        : '<span class="badge badge-green">clean</span>';
    return `
      <tr>
        <td class="mono primary">${esc(r.ip)}</td>
        <td>${fmtNum(r.checked || 0)}</td>
        <td>${listed ? fmtNum(listed) : '—'}</td>
        <td>${fmtNum(r.score || 0)}</td>
        <td>${verdict}</td>
        <td><button class="btn btn-ghost btn-xs"
                    onclick="inspectServerIp('${esc(r.ip)}')">Details</button></td>
      </tr>`;
  }).join('');
}

// Load one address into the per-list matrix below, so "listed" can be acted on.
function inspectServerIp(ip) {
  const input = document.getElementById('bl-ip');
  if (input) { input.value = ip; }
  runBlocklistCheck();
}

async function loadServerIpForBlocklist() {
  const input = document.getElementById('bl-ip');
  if (!input || input.value.trim()) return;
  if (Demo.active) { input.value = '203.0.113.10'; input.placeholder = ''; return; }
  const res = await API.get('iprep/server-ips');
  const ips = (res && res.data) || [];
  input.value = ips[0] || '';
  input.placeholder = ips.length ? '' : 'enter an IP address';
}

function _blBadge(status) {
  return status === 'listed'  ? 'badge badge-red'
       : status === 'refused' ? 'badge badge-amber'
       : 'badge badge-green';
}

async function runBlocklistCheck() {
  const ipEl = document.getElementById('bl-ip');
  const ip   = ipEl ? ipEl.value.trim() : '';
  if (!ip) { toast('Enter an IP address to check', 'error'); return; }

  document.getElementById('bl-progress').classList.remove('hidden');
  document.getElementById('bl-empty').classList.add('hidden');
  document.getElementById('bl-results').classList.add('hidden');

  const res = Demo.active ? _demoBlocklists(ip)
                          : await API.get('iprep/blocklists?ip=' + encodeURIComponent(ip));

  document.getElementById('bl-progress').classList.add('hidden');
  const d = res && res.data;
  if (!d || d.error) {
    document.getElementById('bl-empty').classList.remove('hidden');
    toast((d && d.error) || 'Blocklist check failed', 'error');
    return;
  }

  const badge = document.getElementById('bl-summary');
  badge.textContent = d.listed
    ? d.listed + ' of ' + d.checked + ' lists — ' + d.risk
    : 'Clean on all ' + d.checked + ' lists';
  badge.className = d.listed
    ? (d.risk === 'critical' || d.risk === 'high' ? 'badge badge-red' : 'badge badge-amber')
    : 'badge badge-green';

  // Listed entries first. An operator opening this page needs the problems, not
  // to scroll past two dozen clean rows to find them.
  const rank = s => s === 'listed' ? 0 : s === 'refused' ? 1 : 2;
  const rows = d.results.slice().sort(
    (a, b) => rank(a.status) - rank(b.status) || b.weight - a.weight);

  document.getElementById('bl-tbody').innerHTML = rows.map(function (r) {
    const hl = r.status === 'listed' ? ' style="background:var(--red-dim)"' : '';
    const link = r.site
      ? '<a href="' + esc(r.site) + '" target="_blank" rel="noopener" class="btn btn-ghost btn-xs">Delist</a>'
      : '—';
    return '<tr' + hl + '>'
      + '<td class="primary">' + esc(r.name)
      + '<div style="font-size:.68rem;color:var(--txt3)">' + esc(r.zone) + '</div></td>'
      + '<td><span class="badge badge-gray">' + esc(r.category) + '</span></td>'
      + '<td><span class="' + _blBadge(r.status) + '">' + esc(r.status) + '</span></td>'
      + '<td style="font-size:.75rem">' + esc(r.reason || '—') + '</td>'
      + '<td>' + link + '</td></tr>';
  }).join('');

  document.getElementById('bl-results').classList.remove('hidden');
}

function _demoBlocklists(ip) {
  const mk = (name, zone, cat, w, status, reason) =>
    ({ name, zone, category: cat, weight: w, status,
       listed: status === 'listed', reason, site: 'https://example.org/delist' });
  return { success: true, data: {
    ip, checked: 25, listed: 2, score: 33, risk: 'medium',
    results: [
      mk('Spamhaus ZEN', 'zen.spamhaus.org', 'composite', 25, 'listed', 'PBL — not a legitimate mail sender'),
      mk('UCEPROTECT L1', 'dnsbl-1.uceprotect.net', 'spam', 12, 'listed', 'Listed (127.0.0.2)'),
      mk('Barracuda BRBL', 'b.barracudacentral.org', 'spam', 18, 'refused', 'The list refused this query'),
      mk('SpamCop', 'bl.spamcop.net', 'spam', 18, 'clean', null),
      mk('SORBS Aggregate', 'dnsbl.sorbs.net', 'composite', 12, 'clean', null),
      mk('CBL / abuseat', 'cbl.abuseat.org', 'exploit', 20, 'clean', null),
      mk('Blocklist.de', 'bl.blocklist.de', 'exploit', 15, 'clean', null),
      mk('PSBL', 'psbl.surriel.com', 'spam', 10, 'clean', null),
    ] } };
}

/* ── Built-in rootkit engine ───────────────────────────────────────────────── */

async function runBuiltinRootkitScan() {
  toast('Running built-in rootkit scan…', 'info');
  const res = Demo.active ? _demoRootkit() : await API.post('rootkit/scan-builtin', {});
  const d = res && res.data;
  if (!d) { toast('Built-in scan failed', 'error'); return; }

  document.getElementById('rk-builtin-card').classList.remove('hidden');

  const crit = d.summary.critical || 0;
  const high = d.summary.high || 0;
  const badge = document.getElementById('rk-builtin-badge');
  badge.textContent = d.clean ? 'Clean' : crit + ' critical · ' + high + ' high';
  badge.className   = d.clean ? 'badge badge-green'
                    : (crit ? 'badge badge-red' : 'badge badge-amber');

  document.getElementById('rk-builtin-meta').textContent =
    d.checks + ' checks in ' + d.duration + 's · ' + d.findings.length + ' finding(s)';
  document.getElementById('rk-builtin-clean').classList.toggle('hidden', !d.clean);

  const order = { critical: 0, high: 1, medium: 2, low: 3 };
  const rows = d.findings.slice().sort((a, b) => order[a.severity] - order[b.severity]);

  document.getElementById('rk-builtin-tbody').innerHTML = rows.map(function (f) {
    return '<tr>'
      + '<td><span class="sev sev-' + esc(f.severity) + '">' + esc(f.severity) + '</span></td>'
      + '<td class="primary" style="font-size:.78rem">' + esc(f.finding) + '</td>'
      + '<td style="font-size:.73rem;color:var(--txt3)">' + esc(f.explanation) + '</td>'
      + '</tr>';
  }).join('');

  toast(d.clean ? 'No critical findings' : (crit + high) + ' significant finding(s)',
        d.clean ? 'success' : 'error');
}

function _demoRootkit() {
  return { success: true, data: {
    checks: 11, duration: 2.4, clean: false,
    summary: { critical: 1, high: 1, medium: 1, low: 0 },
    findings: [
      { severity: 'critical', finding: '/etc/ld.so.preload is populated: /lib/.so/libx.so',
        explanation: 'This forces a library into every dynamically linked process — the standard userland rootkit hook.' },
      { severity: 'high', finding: 'Unexpected SUID root binary: /usr/local/bin/.hst',
        explanation: 'A SUID root binary outside the known set grants privilege escalation to any user.' },
      { severity: 'medium', finding: 'sshd permits direct root login',
        explanation: 'PermitRootLogin yes lets an attacker brute-force root directly.' },
    ] } };
}

/* ══════════════════════════════════════════════════════════════════════════════
   WAF engine provisioning
   ══════════════════════════════════════════════════════════════════════════════
   WAF.php only reads ModSecurity's config and audit log, so with ModSecurity
   absent the page reported status and protected nothing. This installs and
   manages the engine from the dashboard. */

async function loadWafEngine() {
  const badge = document.getElementById('waf-engine-badge');
  if (!badge) return;

  const res = Demo.active ? _demoWafEngine() : await API.get('waf/engine-status');
  const d = res && res.data;
  if (!d) {
    badge.className = 'badge badge-gray';
    badge.textContent = 'Unavailable';
    return;
  }

  // ready, the badge and the sentence all come from the engine now.
  //
  // This card read `modsecurity_installed && crs_installed`, where
  // crs_installed only meant a DIRECTORY existed -- so with an empty rule set
  // tree it rendered, simultaneously, "WAF ENGINE Installed", "ModSecurity is
  // installed and logging matches", and a CRS line reading "vunknown" with
  // "holds no rule files that could be read" beneath it. A rule engine with no
  // rules inspects nothing. Claiming it is logging matches is the same failure
  // as setMode() reporting success for a config Apache had rejected, which
  // took 132 accounts down for two minutes on 7 Nov.
  const ready = !!d.ready;
  badge.className = ready
    ? (d.mode === 'on' ? 'badge badge-green' : 'badge badge-amber')
    : 'badge badge-red';
  badge.textContent = !d.modsecurity_installed      ? 'Not installed'
                    : !d.rules_loaded               ? 'No rules loaded'
                    : (d.managed_by_us && !d.include_present) ? 'Not in force'
                    : d.mode === 'on'               ? 'Blocking'
                    : d.mode === 'detectiononly'    ? 'Detection only'
                    : d.mode === 'off'              ? 'Engine off'
                    : 'Mode unknown';

  const summary = document.getElementById('waf-engine-summary');
  summary.textContent = d.claim
    || 'The state of the WAF engine could not be established.';

  document.getElementById('waf-engine-meta').classList.remove('hidden');
  const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  // "installed, version unknown" rather than "installed " plus whatever rpm
  // printed on stdout -- which is how the words "package
  // ea-apache24-mod_security2 is not installed" came to be displayed as a
  // version.
  set('waf-ms-val',  d.modsecurity_installed
                       ? (d.modsecurity_version
                            ? 'installed ' + d.modsecurity_version
                            : 'installed, version unknown')
                       : 'not installed');
  set('waf-crs-val', !d.crs_tree_present
                       ? 'not installed'
                       : (d.rules_loaded
                            ? 'v' + (d.crs_version || '?')
                              + ' — ' + d.crs_rule_files + ' rule file(s)'
                            : 'directory present, NO rule files'));
  set('waf-mode-val', d.mode === 'unknown' ? '—' : wafModeLabel(d.mode));

  // Offer install only when it can actually succeed — a button that always
  // fails is worse than no button.
  const btn = document.getElementById('waf-install-btn');
  const sel = document.getElementById('waf-mode-select');
  btn.classList.toggle('hidden', ready || !d.can_install);
  sel.classList.toggle('hidden', !ready);
  if (ready) sel.value = d.mode === 'unknown' ? 'detectiononly' : d.mode;

  // The header selector shows the SAME mode. It used to sit on whatever it
  // was left on, so after a failed Apply it still displayed the mode the
  // operator had asked for while the card below displayed the real one --
  // the two controls visibly contradicting each other, which is what was
  // reported. Its values are capitalised; the engine reports lower case.
  const head = document.getElementById('waf-mode-sel');
  if (head && d.mode && d.mode !== 'unknown') {
    const CAP = { on: 'On', detectiononly: 'DetectionOnly', off: 'Off' };
    if (CAP[d.mode]) { head.value = CAP[d.mode]; }
  }

  if (!ready && !d.can_install) {
    summary.textContent += ' (No supported package manager was found, so this '
                        +  'server cannot be provisioned automatically.)';
  }
}

async function installWafEngine() {
  const btn = document.getElementById('waf-install-btn');
  const log = document.getElementById('waf-install-log');
  btn.disabled = true;
  btn.textContent = 'Installing…';
  log.classList.remove('hidden');
  log.textContent = 'Installing ModSecurity and the OWASP Core Rule Set. This can take a minute…';

  const res = Demo.active ? _demoWafInstall() : await API.post('waf/engine-install', {});
  const d = res && res.data;

  const lines = ((d && d.steps) || []).map(s => (s.ok ? '[ok]   ' : '[fail] ') + s.message);
  if (d && d.error)  lines.push('[fail] ' + d.error);
  if (d && d.note)   lines.push('', d.note);
  log.textContent = lines.join('\n') || 'No output.';

  btn.disabled = false;
  btn.textContent = 'Install ModSecurity + OWASP CRS';

  if (res && res.success) {
    toast('WAF engine installed — running in detection only', 'success');
  } else {
    toast((res && res.error) || 'WAF installation failed', 'error');
  }
  loadWafEngine();
}

async function setWafEngineMode(mode) {
  // Blocking mode can turn away real visitors if a rule misfires, so it is
  // confirmed rather than applied on a stray change event.
  if (mode === 'on' && !confirm(
      'Switch the WAF to blocking mode?\n\n'
    + 'Requests matching a rule will be rejected. Review the audit log first — '
    + 'a false positive will turn away legitimate visitors.')) {
    loadWafEngine();
    return;
  }
  const res = Demo.active ? { success: true } : await API.post('waf/engine-mode', { mode });
  const okay = !!(res && res.success);
  toast(okay ? 'WAF mode set to ' + wafModeLabel(mode)
             : ((res && res.error) || 'Could not change mode'),
        okay ? 'success' : 'error');

  // Both views of the mode are re-read from the server, not assumed. The old
  // code refreshed the card only, so the header selector and the Mode tile
  // kept showing whatever they had been showing -- which is how a failed
  // change looked exactly like a successful one.
  await loadWafEngine();
  if (typeof loadWAF === 'function') { await loadWAF(); }
}

function _demoWafEngine() {
  return { success: true, data: {
    modsecurity_installed: false, modsecurity_version: null,
    crs_installed: false, crs_tree_present: false, crs_rule_files: 0,
    rules_loaded: false, ready: false,
    claim: 'No web application firewall engine is active on this server. '
         + 'ServerScrub can install and configure ModSecurity with the OWASP '
         + 'Core Rule Set.',
    crs_path: null, crs_version: null,
    mode: 'unknown', apache: 'ea4', package_manager: 'dnf',
    can_install: true, managed_by_us: false, include_present: false } };
}

function _demoWafInstall() {
  return { success: true, data: { success: true, steps: [
    { ok: true, message: 'Installed ea-apache24-mod_security2' },
    { ok: true, message: 'Installed OWASP CRS 4.7.0' },
    { ok: true, message: 'Wrote ServerScrub WAF config (DetectionOnly)' },
    { ok: true, message: 'Apache configuration validated' },
    { ok: true, message: 'Apache reloaded — WAF active in DetectionOnly' },
  ], note: 'Running in DetectionOnly: attacks are logged, not blocked. '
         + 'Review the audit log, then switch to blocking.' } };
}

/* ══════════════════════════════════════════════════════════════════════════════
   Activation gate
   ══════════════════════════════════════════════════════════════════════════════
   Anyone may install; the product asks to be licensed here. This replaces the
   previous behaviour, which surfaced the 402 as a red error toast and dropped
   the user into Settings — that reads like a fault rather than the expected
   next step after installing.

   The screen is shown ahead of the dashboard rather than on top of a broken
   one, so no panel ever renders half-empty against a refused API. */

function showActivateScreen(lic) {
  const el = document.getElementById('activate-screen');
  if (!el) return;

  const sub = document.getElementById('activate-sub');
  const line = document.getElementById('activate-status-line');

  if (lic && lic.status && lic.status !== 'Unlicensed') {
    // An explicit verdict deserves its own wording — "enter your key" is wrong
    // advice for a key that exists but has expired.
    const msg = {
      Expired:   'This licence has expired. Renew it, then re-check.',
      Suspended: 'This licence is suspended. Please contact support.',
      Invalid:   'This licence key is not valid for this server.',
      Unknown:   'The licence server could not be reached, so the licence could not be confirmed.',
    }[lic.status] || (lic.message || '');
    if (sub) sub.textContent = msg;
  }
  if (line && lic && lic.status) {
    line.textContent = ' Current status: ' + lic.status + '.';
  }

  el.classList.remove('hidden');
  const input = document.getElementById('activate-key');
  if (input) setTimeout(() => input.focus(), 150);
}

function hideActivateScreen() {
  const el = document.getElementById('activate-screen');
  if (el) el.classList.add('hidden');
}

function _activateError(msg) {
  const box = document.getElementById('activate-error');
  if (!box) return;
  if (!msg) { box.classList.add('hidden'); box.textContent = ''; return; }
  box.classList.remove('hidden');
  box.textContent = msg;
}

async function submitActivation() {
  const input = document.getElementById('activate-key');
  const btn   = document.getElementById('activate-btn');
  const key   = input ? input.value.trim() : '';
  _activateError('');

  if (!key) { _activateError('Enter your licence key.'); return; }

  btn.disabled = true;
  btn.textContent = 'Activating…';

  const res = Demo.active ? { success: true } : await API.post('license/activate', { key });

  btn.disabled = false;
  btn.textContent = 'Activate';

  if (res && res.success) {
    hideActivateScreen();
    toast('Licence activated — protection is on', 'success');
    // Reload rather than refresh in place: every page was blocked while
    // unlicensed, so their state is stale or empty.
    setTimeout(() => window.location.reload(), 700);
  } else {
    _activateError((res && res.error) || 'Activation failed. Check the key and try again.');
  }
}

async function recheckActivation() {
  _activateError('');
  const res = Demo.active ? { success: true } : await API.post('license/refresh', {});
  if (res && res.success) {
    hideActivateScreen();
    setTimeout(() => window.location.reload(), 500);
  } else {
    _activateError((res && res.error) || 'Still not licensed.');
  }
}

/**
 * Called once after sign-in, before the dashboard loads.
 * Returns true when the app may proceed.
 */
async function enforceLicenseGate() {
  if (Demo.active) return true;
  const res = await API.get('license/status');
  const lic = res && res.license;
  // A licence check that cannot complete must not lock a paying customer out of
  // their own dashboard, so an unreadable response is allowed through — the API
  // itself still returns 402 on anything gated, so nothing is actually exposed.
  if (!lic) return true;
  if (lic.protection_allowed) {
    // Trial counts as allowed, but the operator must be told it is running out
    // — otherwise protection stops one day with no warning given.
    if (lic.trial) showTrialBanner(lic.trial_days_left);
    return true;
  }
  showActivateScreen(lic);
  return false;
}


/* Trial banner. Shown only while the initial grace period is active — a licence
   that lapses without warning looks like a fault rather than an expiry. */
function showTrialBanner(daysLeft) {
  const el = document.getElementById('trial-banner');
  if (!el) return;
  const d = document.getElementById('trial-days');
  if (d) d.textContent = daysLeft === 1 ? '1 day' : daysLeft + ' days';
  el.classList.remove('hidden');
}


/**
 * Choose a real-time monitor resource profile.
 *
 * The custom fields are only shown for 'custom': presenting six numeric inputs
 * to someone who picked "Light" invites them to change one and wonder why the
 * profile no longer matches what it says.
 */
function selectRtProfile(name) {
  const hidden = document.getElementById('set-rt-profile');
  if (hidden) hidden.value = name;

  document.querySelectorAll('.rt-profile-opt').forEach(el => {
    const on = el.getAttribute('data-profile') === name;
    el.style.borderColor = on ? 'var(--primary)' : 'var(--border)';
    el.style.background  = on ? 'rgba(124,92,255,.08)' : 'transparent';
  });

  // The limit fields stay visible for every profile: they show what the chosen
  // profile actually does, and hiding them behind a "Custom" click made the
  // section read as preset-only. Editing any of them switches to Custom
  // automatically, so a typed value is never silently discarded because the
  // profile was left on a preset.
  const custom = document.getElementById('rt-custom-fields');
  if (custom) {
    custom.classList.remove('hidden');
    custom.style.opacity = (name === 'custom') ? '1' : '.72';
  }

  const preset = {
    light:    { fps: 5,   mb: 4,  nice: 19, watches: 5000,   debounce: 10 },
    balanced: { fps: 25,  mb: 16, nice: 10, watches: 20000,  debounce: 5  },
    thorough: { fps: 100, mb: 50, nice: 5,  watches: 100000, debounce: 2  },
  }[name];

  if (preset) {
    // Show the numbers the preset stands for, so the two halves of this card
    // can never disagree about what is in force.
    const put = (id, v) => { const e = document.getElementById(id); if (e) e.value = v; };
    put('set-rt-fps', preset.fps);
    put('set-rt-maxmb', preset.mb);
    put('set-rt-nice', preset.nice);
    put('set-rt-watches', preset.watches);
    put('set-rt-debounce', preset.debounce);
  }
}

/** Any edit to a limit means the operator wants Custom. */
function rtLimitEdited() {
  const hidden = document.getElementById('set-rt-profile');
  if (hidden && hidden.value !== 'custom') {
    selectRtProfile('custom');
    if (typeof toast === 'function') {
      toast('Switched to Custom — your values will be saved', 'info');
    }
  }
}


/**
 * Save only the real-time monitor settings.
 *
 * These were previously committed by the page-level "Save Changes" button at the
 * top of Settings, which means editing a limit here and then leaving the section
 * to commit it -- with no confirmation that these particular values were the
 * ones that landed. Asked for more than once, and I fixed the wrong thing first.
 *
 * Reads back what the server stored rather than trusting the POST, so the
 * confirmation reflects the clamped values actually in force.
 */
async function saveMonitorSettings() {
  const btn    = document.getElementById('rt-save-btn');
  const status = document.getElementById('rt-save-status');
  const g      = (id) => document.getElementById(id);

  const payload = {
    rt_profile:            g('set-rt-profile')?.value  || 'balanced',
    rt_max_files_per_sec:  g('set-rt-fps')?.value      || '25',
    rt_max_file_size_mb:   g('set-rt-maxmb')?.value    || '16',
    rt_nice:               g('set-rt-nice')?.value     || '10',
    rt_max_watches:        g('set-rt-watches')?.value  || '20000',
    rt_debounce_seconds:   g('set-rt-debounce')?.value || '5',
    rt_exclude_dirs:       g('set-rt-excludes')?.value || '',
    cpu_limit_percent:     g('set-cpu-limit')?.value   || '50',
    rt_poll_interval:
      document.querySelector('input[name="rt_poll_interval"]:checked')?.value || '300',

    // Pause-during-backup. These live in this card, so they save with it --
    // a control whose save button is somewhere else is the complaint that
    // produced this button in the first place.
    rt_pause_on_backup:          g('set-rt-pause-backup')?.checked ? '1' : '0',
    rt_backup_procs:             (g('set-rt-backup-procs')?.value || '').trim() || 'jetbackup,rsync',
    rt_backup_resume_secs:       g('set-rt-backup-resume')?.value || '60',
    rt_backup_max_suspend_secs:  g('set-rt-backup-max')?.value    || '14400',
    rt_autostart_after_backup:   g('set-rt-autostart')?.checked ? '1' : '0',
  };

  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
  if (status) { status.textContent = ''; status.style.color = 'var(--txt3)'; }

  const res = Demo.active ? { success: true } : await API.saveSettings(payload);

  if (btn) { btn.disabled = false; btn.textContent = 'Save Monitor Settings'; }

  if (!res?.success) {
    const why = (res && (res.detail || res.error)) || 'the server did not say why';
    if (status) { status.textContent = 'Not saved — ' + why; status.style.color = 'var(--red)'; }
    toast('Monitor settings not saved: ' + why, 'error', 7000);
    return;
  }

  // Read back what was actually stored. A value outside the accepted range is
  // clamped by the daemon, so echoing the typed number would be a small lie.
  const check = Demo.active ? null : await API.getSettings();
  if (check?.success) {
    const d = check.data || {};
    if (g('set-rt-fps'))      g('set-rt-fps').value      = d.rt_max_files_per_sec || payload.rt_max_files_per_sec;
    if (g('set-rt-maxmb'))    g('set-rt-maxmb').value    = d.rt_max_file_size_mb  || payload.rt_max_file_size_mb;
    if (g('set-rt-nice'))     g('set-rt-nice').value     = d.rt_nice              || payload.rt_nice;
    if (g('set-rt-watches'))  g('set-rt-watches').value  = d.rt_max_watches       || payload.rt_max_watches;
    if (g('set-rt-debounce')) g('set-rt-debounce').value = d.rt_debounce_seconds  || payload.rt_debounce_seconds;
  }

  if (status) {
    status.textContent = 'Saved. The monitor picks this up within a minute — no restart needed.';
    status.style.color = 'var(--green)';
  }
  toast('Monitor settings saved', 'success');
}


/* ══════════════════════════════════════════════════════════════════════════════
   Refresh, bulk actions and the file viewer
   ══════════════════════════════════════════════════════════════════════════════ */

/**
 * Run a loader with visible feedback.
 *
 * Every Refresh button called a real function that really did refetch -- which
 * is why the handler check passed and I reported it fixed. But nothing on
 * screen changed: on an idle server the numbers are identical, so a working
 * refresh and a dead button look exactly the same. Reported twice as "refresh
 * does not work", and both times it was the feedback that was missing, not the
 * fetch.
 */
async function doRefresh(btn, fn) {
  if (!btn || btn.disabled) { return; }

  const original = btn.innerHTML;
  btn.disabled = true;
  // The spinning ring, not just a word: see .btn-spin. The label stays
  // too, because an icon alone does not say what is happening.
  btn.innerHTML = '<span class="btn-spin"></span>Refreshing\u2026';

  const started = Date.now();
  let failed = false;
  try {
    await fn();
  } catch (e) {
    failed = true;
    console.error('refresh failed:', e);
    toast('Refresh failed: ' + (e && e.message ? e.message : e), 'error', 6000);
  }

  // A refresh that returns instantly still has to be seen to have happened.
  const elapsed = Date.now() - started;
  if (elapsed < 350) { await new Promise(r => setTimeout(r, 350 - elapsed)); }

  btn.disabled = false;
  btn.innerHTML = original;

  if (!failed) {
    const t = new Date().toLocaleTimeString();
    btn.title = 'Last refreshed ' + t;
    const stamp = document.getElementById('refresh-stamp');
    if (stamp) { stamp.textContent = 'Updated ' + t; }
    toast('Updated ' + t, 'success', 2000);
  }
}

// ── Threat selection ─────────────────────────────────────────────────────────

/** Ids currently ticked in the threats table. */
function selectedThreatIds() {
  return Array.from(document.querySelectorAll('.threat-check:checked'))
    .map(el => parseInt(el.getAttribute('data-id'), 10))
    .filter(n => !isNaN(n) && n > 0);
}

function toggleAllThreats(masterEl) {
  const on = !!(masterEl && masterEl.checked);
  document.querySelectorAll('.threat-check').forEach(el => { el.checked = on; });
  updateBulkBar();
}

/** Keep the bulk bar and the master checkbox in step with the rows. */
function updateBulkBar() {
  const ids   = selectedThreatIds();
  const bar   = document.getElementById('threat-bulk-bar');
  const count = document.getElementById('threat-bulk-count');
  const all   = document.querySelectorAll('.threat-check');
  const master = document.getElementById('threat-check-all');

  if (count) {
    count.textContent = ids.length + ' selected';
    count.style.color = ids.length ? 'var(--primary)' : 'var(--txt2)';
  }

  // The bar stays put and the BUTTONS enable instead. Hiding the whole thing
  // until a selection existed made the feature undiscoverable: someone looking
  // for a way to delete several files at once sees nothing to click, and
  // concludes it was never built.
  // BY CLASS, not a hardcoded id list.
  //
  // This named two buttons explicitly. A third bulk action was added with the
  // threat-bulk-btn class, on the assumption the class was what drove this --
  // so it was never enabled, stayed disabled from the markup, and did nothing
  // when clicked. The control existed, its handler existed, its API route
  // existed, and it was dead.
  //
  // Selecting by class means a bulk button added tomorrow works without
  // anybody remembering to edit this line.
  document.querySelectorAll('.threat-bulk-btn').forEach(b => {
    b.disabled = ids.length === 0;
  });
  if (bar) { bar.classList.remove('hidden'); }
  if (master) {
    master.checked = all.length > 0 && ids.length === all.length;
    // Partial selection is neither ticked nor empty, and saying so avoids the
    // master box claiming everything is selected when only some rows are.
    master.indeterminate = ids.length > 0 && ids.length < all.length;
  }
}

/**
 * Quarantine or delete every selected threat.
 *
 * Confirmed first, because both are destructive and delete is irreversible.
 * Per-file results are reported rather than one pass/fail for the batch: with
 * fifty files selected, "some failed" is not something anyone can act on.
 */
async function bulkThreatAction(action) {
  const ids = selectedThreatIds();
  if (!ids.length) { toast('Nothing selected', 'info'); return; }

  const verb = action === 'delete' ? 'Delete' : 'Quarantine';
  const warn = action === 'delete'
    ? '\n\nThis permanently removes the files. It cannot be undone.'
    : '\n\nFiles are moved into quarantine and can be restored.';
  if (!confirm(verb + ' ' + ids.length + ' selected file(s)?' + warn)) { return; }

  const btns = Array.from(document.querySelectorAll('.threat-bulk-btn'));
  btns.forEach(b => { b.disabled = true; });

  const res = Demo.active
    ? { success: true, ok: ids.length, failed: 0, results: [] }
    : await API.bulkThreats(ids, action);

  btns.forEach(b => { b.disabled = false; });

  if (!res) {
    toast('No response from the server', 'error', 6000);
    return;
  }

  const ok     = res.ok || 0;
  const failed = res.failed || 0;

  if (failed === 0) {
    toast(verb + 'd ' + ok + ' file(s)', 'success');
  } else {
    // Name the first few failures with their reasons. A count alone tells the
    // operator nothing about what to do next.
    const reasons = (res.results || [])
      .filter(r => !r.success)
      .slice(0, 3)
      .map(r => '#' + r.id + ': ' + (r.error || 'unknown reason'));
    toast(ok + ' succeeded, ' + failed + ' failed — ' + reasons.join(' | '),
          'error', 12000);
    console.error('bulk ' + action + ' failures:', res.results);
  }

  const master = document.getElementById('threat-check-all');
  if (master) { master.checked = false; master.indeterminate = false; }
  updateBulkBar();
  loadThreats();
}

// ── Safe file viewer ─────────────────────────────────────────────────────────

/**
 * Show what is inside an infected file, without running it.
 *
 * The content is read on the server with file_get_contents -- never included or
 * evaluated -- and inserted here with textContent, not innerHTML. A payload
 * full of markup or script is therefore displayed as characters and cannot act
 * inside the dashboard.
 */
async function viewThreatFile(id) {
  const overlay = document.getElementById('file-view-overlay');
  const body    = document.getElementById('file-view-content');
  const meta    = document.getElementById('file-view-meta');
  const title   = document.getElementById('file-view-title');
  if (!overlay || !body) { return; }

  overlay.classList.remove('hidden');
  body.textContent = 'Loading\u2026';
  if (meta)  { meta.textContent = ''; }
  if (title) { title.textContent = 'File contents'; }

  const res = Demo.active
    ? { success: true, path: '/home/demo/shell.php', size: 42, binary: false,
        sha256: 'demo', content: '<?php // demo only', truncated: false }
    : await API.viewThreat(id);

  if (!res || !res.success) {
    body.textContent = (res && (res.error || res.detail)) || 'Could not read the file.';
    return;
  }

  if (title) { title.textContent = res.path || 'File contents'; }

  if (meta) {
    const parts = [fmtNum(res.size || 0) + ' bytes'];
    if (res.sha256)    { parts.push('sha256 ' + String(res.sha256).slice(0, 16) + '\u2026'); }
    if (res.truncated) { parts.push('showing the first 256 KB'); }
    if (res.binary)    { parts.push('binary file'); }
    meta.textContent = parts.join(' \u00b7 ');
  }

  // textContent, deliberately. This is hostile input being shown to an admin.
  body.textContent = res.binary
    ? 'This is a binary file. Its contents are not shown as text; the SHA-256 above identifies it.'
    : (res.content || '(empty file)');
}

function closeFileView() {
  const overlay = document.getElementById('file-view-overlay');
  if (overlay) { overlay.classList.add('hidden'); }
}

// ════════════════════════════════════════════════════════════════════════════
// WordPress Database Scanner
// ════════════════════════════════════════════════════════════════════════════
//
// NO REMEDIATION BUTTON, BY DESIGN. Nothing on this page deletes a row. The
// findings are judgements about a customer's users, options and posts, and
// they are wrong often enough to matter: on the server this module was built
// from, an account matching three of the rogue-admin signals turned out to be
// the client's real administrator logging in through a VPN. So the operator is
// shown what was found, what it means and what to do, and marks it done once
// they have acted.

function wpSevBadge(sev) {
  const cls = { critical: 'badge-red', high: 'badge-amber',
                medium: 'badge-blue' }[sev] || 'badge-gray';
  return '<span class="badge ' + cls + '">' + esc(sev || 'low') + '</span>';
}

async function loadWPScan() {
  const st = await API.wpdbStats();
  const d  = (st && st.data) || {};

  setText('wpscan-stat-critical', d.critical ?? 0);
  setText('wpscan-stat-high',     d.high     ?? 0);
  setText('wpscan-stat-medium',   d.medium   ?? 0);
  // "Never", not a dash. A sweep that has never run and a sweep that found
  // nothing look identical on this page otherwise, and the whole point of this
  // module is to stop reporting silence as health.
  setText('wpscan-stat-last',
          d.last_run ? new Date(d.last_run * 1000).toLocaleString() : 'Never');

  const res  = await API.wpdbFindings(200);
  const rows = (res && res.data) || [];
  const body = g('wpscan-findings-body');
  if (!body) return;

  const badge = g('wpscan-count-badge');
  if (badge) badge.textContent = rows.length + ' open';

  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="7" style="text-align:center;'
      + 'color:var(--txt3);padding:28px">'
      + (d.last_run
          ? 'No open findings. Last swept '
            + esc(new Date(d.last_run * 1000).toLocaleString()) + '.'
          : 'Not swept yet \u2014 click "Scan Databases".')
      + '</td></tr>';
    return;
  }

  body.innerHTML = rows.map(r =>
      '<tr>'
    + '<td>' + wpSevBadge(r.severity) + '</td>'
    + '<td><code>' + esc(r.finding_type || '') + '</code></td>'
    + '<td>' + esc(r.cpanel_user || '\u2014') + '</td>'
    + '<td style="max-width:200px;overflow:hidden;text-overflow:ellipsis" title="'
      + esc(r.install_path || '') + '">' + esc(r.install_path || '') + '</td>'
    + '<td style="max-width:300px">' + esc(r.what || '') + '</td>'
    + '<td style="max-width:300px;color:var(--txt2)">' + esc(r.action || '') + '</td>'
    + '<td style="white-space:nowrap">'
    + '<button class="btn btn-ghost btn-sm" onclick="resolveWPFinding('
      + Number(r.id) + ', \'resolved\')">Done</button> '
    + '<button class="btn btn-ghost btn-sm" onclick="resolveWPFinding('
      + Number(r.id) + ', \'accepted\')" '
      + 'title="Expected on this site \u2014 stop reporting it">Accept</button>'
    + '</td></tr>').join('');
}

async function runWPScan() {
  const btn = g('wpscan-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Scanning...'; }

  // The budget is sent, and it is why the result can say "incomplete". One
  // connection and six queries per install; a server with 503 installs will
  // not finish inside an HTTP request, so the sweep stops at the budget and
  // the next run resumes where it stopped. Saying so is the point -- a partial
  // sweep reported as a finished one reads as "your server is clean".
  try {
    const r = await API.wpdbSweep(240);
    const d = (r && r.data) || {};
    if (!r || r.success === false) {
      toast(r && r.error ? r.error : 'Sweep failed', 'error');
    } else {
      /* NOTHING SCANNED IS NOT A CLEAN RESULT. A sweep that found no
       * installs at all used to toast "Read 0 of 0 installs - 0 new
       * finding(s)" in green, which is indistinguishable from a server
       * with nothing wrong. It was the only visible symptom of a key-name
       * bug that skipped every WordPress install on the server. */
      if (!(d.installs || 0)) {
        toast('No WordPress installs were found to scan. Check that '
            + 'scan_paths covers the sites, then run the CMS scan.',
              'warning', 8000);
        await loadWPScan();
        return;
      }
      let msg = 'Read ' + (d.scanned || 0) + ' of ' + (d.installs || 0)
              + ' installs \u2014 ' + (d.findings || 0) + ' new finding(s)';
      if (d.complete === false) {
        msg += '; budget reached, resumes where it stopped';
      }
      // Errors are surfaced, never folded into the finding count. A sweep that
      // could not read half the installs and a server with nothing wrong both
      // report zero findings.
      const errs = (d.errors && d.errors.length) || 0;
      if (errs) msg += '; ' + errs + ' install(s) could not be read';
      toast(msg, (d.complete === false || errs) ? 'warning' : 'success');
    }
    await loadWPScan();
  } catch (e) {
    toast('Sweep failed: ' + (e && e.message ? e.message : e), 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Scan Databases'; }
  }
}

async function resolveWPFinding(id, status) {
  const r = await API.wpdbResolve(id, status);
  if (r && r.success) {
    toast(status === 'accepted' ? 'Accepted for this site' : 'Marked done', 'success');
    await loadWPScan();
  } else {
    toast((r && r.error) || 'Could not update the finding', 'error');
  }
}

// ════════════════════════════════════════════════════════════════════════════
// Outbound Mail
// ════════════════════════════════════════════════════════════════════════════
//
// There is no "clear the queue" button here and there will not be one. During
// the incident this page was built for, 92,954 of 93,255 queued messages were
// a relay -- which still left 301 that a customer was waiting for. Emptying a
// queue is the operator's call, made with exim, after they know whose mail is
// in it.

function mgSev(sev) {
  const cls = { critical: 'badge-red', high: 'badge-amber',
                medium: 'badge-blue' }[sev] || 'badge-gray';
  return '<span class="badge ' + cls + '">' + esc(sev || 'low') + '</span>';
}

async function loadMailGuard() {
  const r = await API.mgStatus();
  const d = (r && r.data) || {};

  // A queue that could not be read shows as "unknown", never as 0. Those mean
  // opposite things, and a panel reading "0 queued" on a server whose exim
  // cannot be reached is the most misleading thing this page could say.
  if (d.queue_readable) {
    setText('mg-stat-queue', fmtNum(d.queue));
    setText('mg-stat-queue-sub', 'threshold ' + fmtNum(d.queue_threshold));
  } else {
    setText('mg-stat-queue', 'unknown');
    setText('mg-stat-queue-sub', 'could not read exim');
  }
  setText('mg-stat-frozen', (d.frozen >= 0) ? fmtNum(d.frozen) : 'unknown');
  setText('mg-stat-limit', fmtNum(d.hourly_threshold) + '/hr');

  const f = d.findings || [];
  setText('mg-stat-findings', f.length);

  const card = g('mg-findings-card');
  const fbody = g('mg-findings-body');
  mgSetCardHidden('mg-findings-card', !f.length);
  if (fbody) {
    fbody.innerHTML = f.map(x =>
        '<tr><td>' + mgSev(x.severity) + '</td>'
      + '<td style="max-width:360px">' + esc(x.what || '') + '</td>'
      + '<td style="max-width:360px;color:var(--txt2)">' + esc(x.action || '') + '</td>'
      + '</tr>').join('');
  }

  // Why mail is not going out. Rendered before the senders table because a
  // stuck queue is more urgent than who filled it.
  const dely = d.delivery || [];
  const dcard = g('mg-delivery-card');
  mgSetCardHidden('mg-delivery-card', !dely.length);
  const dbadge = g('mg-delivery-badge');
  if (dbadge) dbadge.textContent = dely.length;
  const dbody = g('mg-delivery-body');
  if (dbody) {
    dbody.innerHTML = dely.map(x =>
        '<tr>'
      + '<td>' + fmtNum(x.n) + '</td>'
      + '<td>' + (x.code ? '<code>' + esc(x.code) + '</code>' : '\u2014') + '</td>'
      + '<td>' + esc(x.meaning || esc(x.kind || '')) + '</td>'
      + '<td style="max-width:320px;font-size:.8rem;color:var(--txt2)">'
        + esc(x.reason || '') + '</td>'
      + '<td style="max-width:300px;font-size:.8rem">' + esc(x.advice || '') + '</td>'
      + '</tr>').join('');
  }

  const rows = d.top || [];
  const badge = g('mg-count-badge');
  if (badge) badge.textContent = rows.length;

  const body = g('mg-senders-body');
  if (!body) return;
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="7" style="text-align:center;'
      + 'color:var(--txt3);padding:28px">Nothing recorded in the last 24 hours.'
      + '</td></tr>';
    return;
  }

  body.innerHTML = rows.map(r => {
    // "How" matters more than the count: a script burst and an authenticated
    // burst need completely different fixes.
    const how = r.source === 'smtp_auth'
      ? '<span class="badge badge-amber" title="A real mailbox password was '
        + 'used, so the credentials leaked">password</span>'
      : (r.source === 'script'
          ? '<span class="badge badge-blue" title="Injected locally by a script '
            + 'on the server">script</span>'
          : '<span class="badge badge-gray">' + esc(r.source || '?') + '</span>');
    const acct = esc(r.account || '');
    return '<tr>'
      + '<td>' + acct + '</td>'
      + '<td>' + how + '</td>'
      + '<td style="max-width:260px;overflow:hidden;text-overflow:ellipsis" title="'
        + esc(r.script || '') + '">' + esc(r.script || '\u2014') + '</td>'
      + '<td>' + fmtNum(r.sent) + '</td>'
      + '<td>' + fmtNum(r.recipients) + '</td>'
      + '<td>' + fmtNum(r.failed) + '</td>'
      + '<td style="white-space:nowrap">'
      + (r.account && r.account !== '(unattributed)'
          ? '<button class="btn btn-ghost btn-sm" onclick="throttleAccount(\''
            + acct + '\')">Cap rate</button>'
          : '')
      + '</td></tr>';
  }).join('');
}

async function runMailScan() {
  const btn = g('mg-scan-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Reading...'; }
  try {
    const r = await API.mgScan();
    const d = (r && r.data) || {};
    if (d.skipped) {
      toast(d.skipped, 'warning', 9000);
    } else {
      toast('Read ' + fmtNum(d.read) + ' bytes of mail log, '
          + fmtNum(d.arrivals) + ' message(s), '
          + fmtNum(d.findings) + ' finding(s)',
            d.findings ? 'warning' : 'success', 8000);
    }
    await loadMailGuard();
  } catch (e) {
    toast('Could not read the mail log: ' + (e && e.message ? e.message : e), 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Read mail log now'; }
  }
}

// The limit is ASKED FOR, never defaulted. The right cap for a newsletter is
// not the right cap for a contact form, and this caps a real business's mail.
async function throttleAccount(account) {
  const v = prompt('Cap ' + account + ' to how many messages per hour?\n\n'
    + 'This sets cPanel\'s own per-account limit, so cPanel enforces and '
    + 'reports it. Reversible: set it higher again.\n\n'
    + 'Mail over the cap is rejected, so pick a number this account can live '
    + 'with while you fix the cause.', '1000');
  if (v === null) return;

  const n = parseInt(v, 10);
  if (!Number.isFinite(n) || n < 1) {
    toast('Enter a number of messages per hour', 'error');
    return;
  }
  const r = await API.mgThrottle(account, n);
  const d = (r && r.data) || {};
  if (d.success) {
    toast(account + ' capped at ' + fmtNum(n) + ' messages/hour', 'success', 7000);
    await loadMailGuard();
  } else {
    toast(d.error || (r && r.error) || 'Could not set the limit', 'error', 9000);
  }
}

// ── Spam Monitor settings ───────────────────────────────────────────────────
//
// The ranges come FROM THE SERVER and are shown next to each field, because the
// server clamps these values and a panel that lets someone type 10 and then
// silently uses 50 is worse than one that refuses. If a value is adjusted on
// save, the reason is shown and the field is corrected to what will actually
// be used.

async function loadMailSettings() {
  const r = await API.mgSettings();
  const d = (r && r.data) || {};
  const ranges = d.ranges || {};

  const on = g('mg-set-enabled');
  if (on) on.checked = !!d.enabled;

  const put = (id, val) => { const el = g(id); if (el) el.value = val ?? ''; };
  put('mg-set-hourly', d.hourly);
  put('mg-set-queue',  d.queue);
  put('mg-set-frozen', d.frozen);
  put('mg-set-retain', d.retain_days);
  put('mg-set-exempt', d.exempt);

  const hint = (id, key, suffix) => {
    const el = g(id);
    const rg = ranges[key];
    if (el && rg) {
      el.textContent = 'Between ' + fmtNum(rg[0]) + ' and ' + fmtNum(rg[1])
                     + (suffix ? ' ' + suffix : '');
    }
  };
  hint('mg-hint-hourly', 'hourly',
       '\u2014 the relay that prompted this ran at about 1,690/hour');
  hint('mg-hint-queue',  'queue',  '\u2014 93,255 queued is not a busy day');
  hint('mg-hint-frozen', 'frozen',
       '\u2014 a spike usually means deliveries are being refused');
  hint('mg-hint-retain', 'retain_days', '');
}

async function saveMailSettings() {
  const num = id => {
    const el = g(id);
    if (!el || el.value === '') return undefined;
    const n = parseInt(el.value, 10);
    return Number.isFinite(n) ? n : undefined;
  };

  const payload = {
    enabled:     g('mg-set-enabled') ? g('mg-set-enabled').checked : true,
    hourly:      num('mg-set-hourly'),
    queue:       num('mg-set-queue'),
    frozen:      num('mg-set-frozen'),
    retain_days: num('mg-set-retain'),
    exempt:      g('mg-set-exempt') ? g('mg-set-exempt').value : '',
  };
  Object.keys(payload).forEach(k => {
    if (payload[k] === undefined) delete payload[k];
  });

  const r = await API.mgSaveSettings(payload);
  const d = (r && r.data) || {};
  if (!r || r.success === false) {
    toast((r && r.error) || 'Could not save settings', 'error');
    return;
  }

  // Anything the server adjusted is reported, not hidden. Otherwise the field
  // would show one number while the detector used another.
  const adj = d.rejected || {};
  const keys = Object.keys(adj);
  if (keys.length) {
    toast('Saved, with changes: '
        + keys.map(k => k + ' ' + adj[k]).join('; '), 'warning', 12000);
  } else {
    toast('Settings saved', 'success');
  }

  // Reload from the server so the form shows the EFFECTIVE values.
  await loadMailSettings();
  await loadMailGuard();
}

// ── Mail queue viewer ───────────────────────────────────────────────────────
//
// There is no "empty the queue" button and there will not be one. During the
// incident this page was built after, 92,954 of 93,255 queued messages were a
// relay -- which still left 301 that a real customer was waiting for. So
// messages are listed, inspected, selected, and deleted by id.
//
// The list is a PAGE, not the queue: `exim -bp` on 93,000 messages is megabytes
// of text, and rendering all of it would hang the browser on exactly the server
// that needs this most.


/**
 * Signatures switched off by name.
 *
 * A suppressed signature is a hole in the defence, so the panel shows the hole:
 * every suppression, how many files it has hidden since, when it last hid one,
 * who added it and why. One that nobody can see is indistinguishable from a
 * scanner that has stopped working -- and on 10 Nov the alternative to this
 * card was turning ClamAV off on a 132-account server.
 */
async function loadSuppressions() {
  const r = await API.sigSuppressions();
  const body = g('sigsup-tbody');
  const sum  = g('sigsup-summary');
  if (!body) { return; }

  if (!r?.success) {
    // Not an empty list: "could not read" and "none" are different answers,
    // and the dangerous one must not render as the safe one.
    body.innerHTML = '<tr><td colspan="6" class="dim">The suppression list '
                   + 'could not be read, so it is not known whether any '
                   + 'signature is switched off.</td></tr>';
    if (sum) { sum.textContent = 'unknown'; }
    return;
  }

  const d = r.data || {};
  const items = d.items || [];
  if (sum) {
    sum.textContent = items.length === 0
      ? 'none — every signature is reporting'
      : items.length + ' suppressed · ' + fmtNum(d.hits || 0) + ' file(s) hidden since';
  }
  if (items.length === 0) {
    body.innerHTML = '<tr><td colspan="6" class="dim">No signatures are '
                   + 'suppressed. Every signature is reported.</td></tr>';
    return;
  }
  body.innerHTML = items.map(x => '<tr>'
    + '<td style="font-family:var(--font-mono);font-size:.72rem">' + esc(x.name) + '</td>'
    + '<td>' + fmtNum(x.hits || 0) + '</td>'
    + '<td>' + (x.last_hit_at ? esc(reltime(x.last_hit_at)) : '—') + '</td>'
    + '<td>' + esc(x.created_by || '') + '</td>'
    + '<td>' + esc(x.reason || '') + '</td>'
    + '<td><button class="btn btn-ghost btn-sm" onclick="unsuppressSignature(' + Number(x.id)
    + ')">Put back</button></td>'
    + '</tr>').join('');
}

async function unsuppressSignature(id) {
  if (!confirm('Report this signature again? Anything it matches will be '
             + 'treated as a finding from the next scan.')) { return; }
  const r = await API.sigUnsuppress(Number(id));
  if (!r?.success) {
    toast('Could not remove the suppression: ' + (r?.error || 'unknown error'), 'error');
    return;
  }
  toast('Signature is reporting again', 'success');
  loadSuppressions();
}

async function loadExclusions() {
  const r = await API.exclList();
  const d = (r && r.data) || {};

  const b = g('excl-builtin');
  if (b) b.textContent = (d.builtin || []).join(' · ');

  const t = g('excl-raw');
  if (t) t.value = d.raw || '';
}

async function saveExclusions() {
  const t = g('excl-raw');
  const r = await API.exclSave(t ? t.value : '');
  const d = (r && r.data) || {};
  if (r && r.success) {
    const n = (d.user || []).length;
    toast(n + ' exclusion(s) saved. They apply to the next scan and to the '
        + 'real-time monitor within a minute.', 'success', 7000);
    await loadExclusions();
  } else {
    toast((r && r.error) || 'Could not save exclusions', 'error');
  }
}

// Check a rule BEFORE trusting it, rather than finding out at the next scan.
async function testExclusion() {
  const el = g('excl-test');
  const out = g('excl-test-result');
  const path = el ? el.value.trim() : '';
  if (!path) { if (out) out.textContent = ''; return; }

  const r = await API.exclTest(path);
  const d = (r && r.data) || {};
  if (!out) return;
  if (d.excluded) {
    out.style.color = 'var(--amber)';
    out.textContent = 'Not scanned — excluded by '
      + (d.by === 'built-in' ? 'a built-in rule' : '"' + d.by + '"');
  } else {
    out.style.color = 'var(--green)';
    out.textContent = 'This path WOULD be scanned';
  }
}

// ── "Not malware" verdicts ──────────────────────────────────────────────────
//
// This replaced a pair of handlers that added PATH EXCLUSIONS. Two things were
// wrong with those, and both mattered:
//
//   1. They were silently dead. Both opened with prompt() or confirm(). This
//      plugin runs inside cPanel's iframe, and an iframe without allow-modals
//      makes those return null immediately -- which the code read as
//      "cancelled" and returned on. No error, no console entry, nothing. The
//      button simply did nothing, every time.
//
//   2. Excluding was the wrong remedy anyway. Silencing five findings against
//      ai-bolit by excluding /opt/ai-bolit/ also hides anything an attacker
//      drops in there afterwards -- a permanent blind spot bought to tidy a
//      table. A verdict keeps the file under scan and lapses the instant its
//      bytes change.
//
// The exclusion list is still there for operators who genuinely do want a path
// skipped. It is just no longer what this button does.

// Which findings the open dialog is about. Module scope, so the modal's
// confirm button can read it without inlining anything into markup.
let NotMalwarePending = [];

function openNotMalware(ids) {
  const list = ids
    .map(i => ({ id: i, path: (State.threatPaths || {})[i] || '' }))
    .filter(x => x.path);

  if (!list.length) {
    toast('Could not resolve those file paths — reload the page and try again',
          'error');
    return;
  }

  NotMalwarePending = list;

  const box = g('nmm-files');
  if (box) {
    box.innerHTML = list
      .map(x => '<div style="padding:2px 0;word-break:break-all">' + esc(x.path) + '</div>')
      .join('');
  }
  const cnt = g('nmm-count');
  if (cnt) {
    cnt.textContent = list.length === 1
      ? '1 file' : list.length + ' files';
  }
  const note = g('nmm-note');
  if (note) { note.value = ''; }

  openModal('notmalware-modal');
}

// One row.
function markNotMalware(id) { openNotMalware([Number(id)]); }

// Bulk. Five findings from one vendor tree is the normal case -- that is
// exactly what ai-bolit produced -- so clearing them one dialog at a time is
// the wrong shape of work.
function markSelectedNotMalware() {
  const ids = selectedThreatIds();
  if (!ids.length) {
    toast('Tick the rows you want to clear first', 'info');
    return;
  }
  openNotMalware(ids);
}

async function confirmNotMalware() {
  const list = NotMalwarePending.slice();
  if (!list.length) { closeModal('notmalware-modal'); return; }

  const note = (g('nmm-note')?.value || '').trim();
  const btn  = g('nmm-go');
  if (btn) { btn.disabled = true; btn.textContent = 'Working…'; }

  const res = await API.verdictClearMany(list.map(x => x.id), note);

  if (btn) { btn.disabled = false; btn.textContent = 'Mark not malware'; }
  closeModal('notmalware-modal');
  NotMalwarePending = [];

  if (!res) {
    toast('No response from the server', 'error', 6000);
    return;
  }
  if (res.success === false) {
    toast(res.error || 'Could not record those verdicts', 'error', 7000);
    return;
  }

  const ok     = res.ok || 0;
  const failed = res.failed || 0;

  if (failed === 0) {
    toast(ok + ' file(s) marked not malware. They stay under the scanner and '
        + 'will be reported again if their contents change.', 'success', 8000);
  } else {
    // Name the failures with their reasons. A bare count is not actionable:
    // the usual cause is that the file was deleted or quarantined between the
    // scan and the click, which needs a different action entirely.
    const why = (res.results || [])
      .filter(r => !r.ok)
      .slice(0, 4)
      .map(r => (r.path || ('#' + r.id)) + ': ' + (r.error || 'failed'))
      .join('\n');
    toast('Marked ' + ok + ', could not mark ' + failed + '.\n' + why,
          'warn', 11000);
  }

  await loadThreats();
  await loadVerdicts();
}

// ── The list of what has been cleared ───────────────────────────────────────
//
// Operators need to audit this: a verdict list nobody can read is how a
// "temporary" clearance becomes permanent. The important column is State --
// a verdict whose file has since changed is DORMANT, the file is being
// reported again, and that is invisible in a plain list of paths.
async function loadVerdicts() {
  const tb = g('verdict-tbody');
  if (!tb) return;

  const r = await API.verdictList();
  const d = (r && r.data) || {};
  const rows = d.verdicts || [];
  const st   = d.stats || {};

  const sum = g('verdict-summary');
  if (sum) {
    sum.textContent = rows.length
      ? fmtNum(st.active || 0) + ' active'
        + ((st.drifted || 0) ? ', ' + fmtNum(st.drifted) + ' lapsed (file changed)' : '')
        + ((st.missing || 0) ? ', ' + fmtNum(st.missing) + ' gone from disk' : '')
      : '';
  }

  if (!rows.length) {
    tb.innerHTML = '<tr><td colspan="7" class="dim">'
      + 'Nothing marked yet. Use <strong>Not malware</strong> on a finding you '
      + 'have checked and believe is safe.</td></tr>';
    return;
  }

  tb.innerHTML = rows.map(v => {
    const id   = Number(v.id) || 0;
    const path = String(v.file_path || '');
    let state;
    if (!v.file_exists) {
      state = '<span class="badge badge-gray" title="The file is no longer on disk, '
            + 'so this verdict matches nothing">Gone</span>';
    } else if (v.drifted) {
      state = '<span class="badge badge-amber" title="The file has changed since it '
            + 'was cleared, so it is being scanned and reported again">Lapsed</span>';
    } else {
      state = '<span class="badge badge-green" title="Contents unchanged since '
            + 'it was cleared">Active</span>';
    }
    return `
    <tr>
      <td class="mono" style="max-width:300px;overflow:hidden;text-overflow:ellipsis;
                              white-space:nowrap" title="${esc(path)}">${esc(path)}</td>
      <td class="mono" style="color:var(--txt3);font-size:.75rem">${esc(v.threat_name || '—')}</td>
      <td class="mono dim" style="font-size:.72rem"
          title="${esc(v.sha256 || '')}">${esc(String(v.sha256 || '').slice(0, 12))}</td>
      <td class="dim">${esc(v.created_by || '—')}</td>
      <td class="dim">${reltime(v.created_at)}</td>
      <td>${state}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-ghost btn-xs" onclick="revokeVerdict(${id})"
                title="Withdraw this verdict — the file becomes reportable again">Undo</button>
      </td>
    </tr>`;
  }).join('');
}

async function revokeVerdict(id) {
  const r = await API.verdictRevoke(Number(id));
  if (r && r.success) {
    toast('Verdict withdrawn. ' + (r.path || 'The file')
        + ' will be reported again if it still matches a signature.',
          'success', 7000);
    await loadVerdicts();
    await loadThreats();
  } else {
    toast((r && r.error) || 'Could not withdraw that verdict', 'error');
  }
}

// Kept so the exclusion list still has a bulk path, now that the threat-table
// button no longer points at it.
async function excludeSelectedThreats() {
  const ids = selectedThreatIds();
  if (!ids.length) {
    toast('Tick the rows you want excluded first', 'info');
    return;
  }

  const paths = ids
    .map(i => (State.threatPaths || {})[i] || '')
    .filter(Boolean);
  if (!paths.length) {
    toast('Could not resolve those file paths — reload and try again', 'error');
    return;
  }

  // Collapse to parent folders. Ticking five files from one directory should
  // produce ONE rule, not five -- otherwise the exclusion list becomes its own
  // unreadable mess within a week.
  const folders = Array.from(new Set(
    paths.map(p => p.replace(/\/[^/]*$/, '') || p)));

  const r = await API.exclAddMany(folders);
  const d = (r && r.data) || {};
  if (r && r.success) {
    toast('Excluded ' + fmtNum(d.added ?? folders.length) + ' folder(s). '
        + 'Now ' + fmtNum((d.user || []).length) + ' exclusion rule(s) in total.',
          'success', 8000);
    await loadThreats();
    await loadExclusions();
  } else {
    toast((r && r.error) || 'Could not add those exclusions', 'error');
  }
}
