#!/usr/bin/env python3
"""
ServerScrub - Real-Time File Monitor Daemon
Watches filesystem paths for new/modified PHP files and scans for malware.
Uses inotify_simple if available, falls back to polling.

Started by: RealTimeMonitor::start() (PHP) or systemd unit
Environment: SG_ROOT must be set (defaults to 2 dirs up from this script)
"""

import os, re, sys, time, signal, logging, sqlite3, shutil, datetime
from pathlib import Path
from typing import Optional, List, Dict

SG_ROOT  = os.environ.get('SG_ROOT', str(Path(__file__).resolve().parent.parent.parent))
SG_DB    = os.path.join(SG_ROOT, 'database', 'serverscrub.db')
PID_FILE = '/var/run/serverscrub-monitor.pid'

# force= requires Python 3.8. RHEL-family servers -- which is what cPanel runs
# on -- ship 3.6, where this raises ValueError before the daemon does anything
# at all. systemd still reported the unit as started, because the process did
# launch, so the dashboard said "Monitor started" over a daemon that had already
# died and was being restarted in a loop.
#
# The equivalent without force=: drop any handlers configured by an import, then
# configure normally.
for _h in list(logging.root.handlers):
    logging.root.removeHandler(_h)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [sg-monitor] %(levelname)s %(message)s',
    datefmt='%Y-%m-%dT%H:%M:%S',
    stream=sys.stdout,
)
log = logging.getLogger('sg')

_running = True
def _on_sig(sig, frame):
    global _running
    log.info('Signal %s - shutting down', sig)
    _running = False
signal.signal(signal.SIGTERM, _on_sig)
signal.signal(signal.SIGINT,  _on_sig)

def write_pid():
    try:
        open(PID_FILE, 'w').write(str(os.getpid()))
        os.chmod(PID_FILE, 0o644)
    except Exception as e:
        log.warning('PID write failed: %s', e)

def remove_pid():
    try:
        os.path.exists(PID_FILE) and os.unlink(PID_FILE)
    except: pass

def db_connect():
    conn = sqlite3.connect(SG_DB, timeout=15, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=10000")
    return conn

def db_get(conn, key, default=''):
    try:
        r = conn.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
        return str(r['value']) if (r and r['value'] is not None) else default
    except: return default

def db_set(conn, key, value):
    try:
        conn.execute(
            "INSERT INTO settings(key,value,updated_at) VALUES(?,?,strftime('%s','now')) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
            (key, value))
        conn.commit()
    except Exception as e:
        log.debug('db_set %s: %s', key, e)

# -- CPU throttle ----------------------------------------------------------------
# Maps the user-facing cpu_limit_percent setting (Settings -> CPU usage limit)
# to process priority and inter-scan sleeps. Restored after the v3.3.7 rewrite
# dropped it while the UI/DB kept the setting.
DEFAULT_CPU_LIMIT = 50   # percent
_SCAN_SLEEP = 0.0        # set in main() from the CPU limit

def cpu_to_nice(cpu_pct):
    """Map CPU % (10-100) to a nice value (19-0). Lower % = lower priority."""
    cpu_pct = max(10, min(100, int(cpu_pct)))
    return round(19 * (1.0 - cpu_pct / 100.0))

def cpu_to_scan_sleep(cpu_pct):
    """Seconds to sleep between file scans in inotify mode.
       10% -> 0.50s, 50% -> 0.28s, 100% -> 0s."""
    cpu_pct = max(10, min(100, int(cpu_pct)))
    return max(0.0, (1.0 - cpu_pct / 100.0) * 0.55)

def get_cpu_limit(conn):
    """Read cpu_limit_percent from settings; clamp to 10-100."""
    try:
        return max(10, min(100, int(db_get(conn, 'cpu_limit_percent', str(DEFAULT_CPU_LIMIT)))))
    except (ValueError, TypeError):
        return DEFAULT_CPU_LIMIT

def get_poll_interval(conn):
    """Poll interval (seconds) for polling mode -- rt_poll_interval setting,
       default 300 (5 min), clamped to >= 10."""
    try:
        return max(10, int(db_get(conn, 'rt_poll_interval', '300') or '300'))
    except (ValueError, TypeError):
        return 300

# -- Resource profiles -----------------------------------------------------------
# Real-time monitoring was reported as putting excessive load on a live server.
# The throttle that existed only slowed the gap BETWEEN file scans; it did
# nothing about the three things that actually cost:
#
#   1. Polling mode walks every watched path and stats every file, every
#      interval, holding a path->mtime dict for the whole tree. On a shared host
#      with /home that is the dominant cost by a wide margin.
#   2. inotify adds one watch per directory with no ceiling. Tens of thousands
#      of watches is both kernel memory and a long startup walk, and exceeding
#      max_user_watches failed silently, leaving partial coverage nobody knew
#      about.
#   3. Every event reads the whole file and runs the pattern set over it, with
#      no ceiling on events per second and no coalescing of repeats.
#
# So the limits are explicit, named, and settable. A profile sets them all at
# once; 'custom' leaves whatever the user chose.

PROFILES = {
    # name        nice  files/s  max MB  poll s  watches  debounce s
    'light':     (19,     5,       4,     900,     5000,   10),
    'balanced':  (10,    25,      16,     300,    20000,    5),
    'thorough':  ( 5,   100,      50,     120,   100000,    2),
}
DEFAULT_PROFILE = 'balanced'

DEFAULT_EXCLUDES = {'node_modules', '.git', '__pycache__', '.svn', 'cache',
                    '.cache', 'vendor', 'backup', 'backups', '.trash'}


def load_profile(conn):
    """Effective resource limits, re-read from settings on every reload tick."""
    name = (db_get(conn, 'rt_profile', DEFAULT_PROFILE) or DEFAULT_PROFILE).strip().lower()
    base = PROFILES.get(name, PROFILES[DEFAULT_PROFILE])
    nice_v, fps, mb, poll, watches, debounce = base

    def num(key, fallback, lo, hi):
        try:
            return max(lo, min(hi, int(db_get(conn, key, str(fallback)) or fallback)))
        except (ValueError, TypeError):
            return fallback

    if name == 'custom':
        nice_v   = num('rt_nice',              10,  0, 19)
        fps      = num('rt_max_files_per_sec', 25,  1, 1000)
        mb       = num('rt_max_file_size_mb',  16,  1, 512)
        poll     = num('rt_poll_interval',    300, 10, 86400)
        watches  = num('rt_max_watches',    20000, 100, 500000)
        debounce = num('rt_debounce_seconds',   5,  0, 3600)

    extra = db_get(conn, 'rt_exclude_dirs', '') or ''
    excludes = set(DEFAULT_EXCLUDES)
    excludes.update(d.strip() for d in extra.split(',') if d.strip())

    return {
        'profile': name if name in PROFILES or name == 'custom' else DEFAULT_PROFILE,
        'nice': nice_v,
        'files_per_sec': fps,
        'max_file_size': mb * 1024 * 1024,
        'poll_interval': poll,
        'max_watches': watches,
        'debounce': debounce,
        'excludes': excludes,
    }


class RateLimiter:
    """Token bucket over files examined per second.

    A fixed sleep between scans cannot express "no more than N files a second":
    it makes every scan slower whether or not anything is happening, and it
    still lets a burst of ten thousand events through back to back. This caps
    the rate and costs nothing while idle.
    """

    def __init__(self, per_sec):
        self.rate = max(1, int(per_sec))
        self.allowance = float(self.rate)
        self.last = time.time()

    def update(self, per_sec):
        per_sec = max(1, int(per_sec))
        if per_sec != self.rate:
            self.rate = per_sec
            self.allowance = min(self.allowance, float(per_sec))

    def take(self):
        """Block just long enough to stay under the limit."""
        now = time.time()
        self.allowance += (now - self.last) * self.rate
        self.last = now
        if self.allowance > self.rate:
            self.allowance = float(self.rate)
        if self.allowance < 1.0:
            time.sleep((1.0 - self.allowance) / self.rate)
            self.allowance = 0.0
            self.last = time.time()
        else:
            self.allowance -= 1.0


class Debouncer:
    """Suppress repeat events for the same path within a window.

    An editor writing a file, a deploy, or a log rotation produces several
    CREATE/MODIFY events for one path in quick succession. Scanning it each time
    is pure waste: the content is read and pattern-matched again for no new
    information.
    """

    def __init__(self, seconds):
        self.window = max(0, int(seconds))
        self.seen = {}

    def update(self, seconds):
        self.window = max(0, int(seconds))

    def should_skip(self, path):
        if self.window <= 0:
            return False
        now = time.time()
        last = self.seen.get(path)
        if last is not None and (now - last) < self.window:
            return True
        self.seen[path] = now
        if len(self.seen) > 20000:      # bounded: this must not become a leak
            cutoff = now - self.window
            self.seen = {k: v for k, v in self.seen.items() if v > cutoff}
        return False


class BackupActivityDetector:
    """Is a backup or a bulk transfer running right now?

    JetBackup walks every account on the server and rsync streams the result
    off-box. Both touch enormous numbers of files, and a real-time scanner
    trying to keep up with that is competing with the backup for the same
    disks at exactly the moment the server can least afford it.

    While one is running the monitor suspends: it keeps reading inotify events
    so the kernel queue does not overflow, but throws them away instead of
    scanning. It resumes once the processes have been gone for a settling
    period.

    TWO THINGS THIS DELIBERATELY DOES NOT PRETEND
    ---------------------------------------------
    1. Suspending creates a blind spot. Events during the window are discarded,
       not queued -- queueing them would just move the same work to the moment
       the backup finishes. The gap is recorded and raised as a security event
       so it appears in the log rather than being silently absent.

    2. "Pause while rsync runs" is a trigger anyone on the box can pull. A
       process merely NAMED rsync is enough, so someone who can start a process
       can suppress monitoring. That is why the suspension is capped: past
       `rt_backup_max_suspend_secs` the monitor resumes regardless and says so.
       The cap is what stops a permanent pause; the event log is what makes an
       unusual one visible.
    """

    # Matched against the process name (/proc/<pid>/comm). Exact names, not
    # substrings: 'rsync' as a substring would also match a shell script called
    # rsync-my-photos, and more importantly would match far more than intended.
    # Names that mean WORK IS HAPPENING, not that software is installed.
    #
    # 'jetbackupd' used to be in this list and '/jetapps/' used to be a
    # command-line hint. Both were wrong in the same way: JetBackup runs a
    # permanent daemon, and every JetBackup process lives under /usr/local/
    # jetapps whether or not a backup is running. On any server with JetBackup
    # installed the monitor therefore suspended itself immediately and never
    # resumed -- real-time scanning was permanently off on exactly the servers
    # this feature was written for, while the dashboard said "Paused --
    # jetbackup" over an idle daemon sitting at 0% CPU.
    #
    # The test for anything added here is not "is it part of the backup
    # software" but "does its existence mean a backup is currently running".
    # 'jetbackup' stays: a process by that exact name is a JOB. 'jetbackupd'
    # is the daemon and lives in DEFAULT_EXCLUDES below. Keeping the name here
    # also keeps the command-line job detection alive, since that is gated on
    # JetBackup being something we care about at all.
    DEFAULT_NAMES = ('jetbackup', 'rsync')

    # Always-on processes that must never count as a running backup, whatever
    # else matches them. Applied to both the name and the command line.
    DEFAULT_EXCLUDES = ('jetbackupd', 'jetbackup5d', 'jetbackupmysqld')

    # Command-line fragments that indicate a backup TASK. An install path is
    # not one of these; a queue worker or a running job is.
    CMDLINE_HINTS = ('jetbackup5/core/queue', 'jetbackup/core/queue',
                     'jb5 backup', 'jetbackup backup')

    def __init__(self, conn):
        self.enabled = True
        self.names = set(self.DEFAULT_NAMES)
        self.check_every = 20
        self.resume_after = 60
        self.max_suspend = 14400
        self.suspended = False
        self.reason = ''
        self.evidence = ''
        self.excludes = set(self.DEFAULT_EXCLUDES)
        self.since = None
        self.clear_since = 0.0
        self.capped_out = False
        # None, not 0: the first poll must check immediately. Starting the
        # daemon in the middle of a nightly backup and then scanning hard for
        # the first check interval is precisely the load this avoids.
        self._last_check = None
        self._self_pids = self._own_pids()
        self.reload(conn)

    # ---- settings -------------------------------------------------------
    def reload(self, conn):
        self.enabled = (db_get(conn, 'rt_pause_on_backup', '1') or '1').strip() == '1'

        raw = (db_get(conn, 'rt_backup_procs', '') or '').strip()
        if raw:
            names = set()
            for part in raw.split(','):
                part = part.strip().lower()
                # A blank or '*' entry would match every process on the server
                # and suspend the monitor permanently.
                if part and part != '*':
                    names.add(part)
            self.names = names or set(self.DEFAULT_NAMES)
        else:
            self.names = set(self.DEFAULT_NAMES)

        raw_ex = (db_get(conn, 'rt_backup_exclude', '') or '').strip()
        if raw_ex:
            self.excludes = set(
                x.strip().lower() for x in raw_ex.split(',') if x.strip())
        else:
            self.excludes = set(self.DEFAULT_EXCLUDES)

        self.check_every  = self._num(conn, 'rt_backup_check_secs',       20,  5, 600)
        self.resume_after = self._num(conn, 'rt_backup_resume_secs',      60,  0, 3600)
        self.max_suspend  = self._num(conn, 'rt_backup_max_suspend_secs', 14400, 60, 86400)

    @staticmethod
    def _num(conn, key, fallback, lo, hi):
        try:
            return max(lo, min(hi, int(db_get(conn, key, str(fallback)) or fallback)))
        except (ValueError, TypeError):
            return fallback

    @staticmethod
    def _own_pids():
        """This process and its parent, so the monitor cannot detect itself."""
        pids = set()
        try:
            pids.add(os.getpid())
            pids.add(os.getppid())
        except Exception:
            pass
        return pids

    # ---- detection ------------------------------------------------------
    def find_running(self):
        """Names of matching processes, or an empty list.

        Reads /proc directly rather than shelling out to pgrep: this runs every
        20 seconds for the life of the daemon, and forking a process to ask
        whether the server is busy is a poor way to avoid loading the server.
        """
        found = []
        self.evidence = ''
        try:
            entries = os.listdir('/proc')
        except OSError:
            return found

        for entry in entries:
            if not entry.isdigit():
                continue
            pid = int(entry)
            if pid in self._self_pids:
                continue

            comm = ''
            try:
                with open('/proc/%d/comm' % pid, 'r') as fh:
                    comm = fh.read().strip().lower()
            except (IOError, OSError):
                continue

            # An always-on daemon is never evidence of a running backup.
            if comm in self.excludes:
                continue

            if comm in self.names:
                found.append(comm)
                if not self.evidence:
                    self.evidence = 'pid %d (%s)' % (pid, comm)
                continue

            # Only read the (larger) cmdline when the name alone was not
            # conclusive, and only when JetBackup is among the things we care
            # about -- there is no point paying for this on every process.
            if 'jetbackup' in self.names:
                try:
                    with open('/proc/%d/cmdline' % pid, 'rb') as fh:
                        cmd = fh.read().replace(b'\x00', b' ').decode('utf-8', 'replace').lower()
                except (IOError, OSError):
                    continue
                if not cmd:
                    continue
                if any(x in cmd for x in self.excludes):
                    continue
                if any(h in cmd for h in self.CMDLINE_HINTS):
                    found.append('jetbackup')
                    if not self.evidence:
                        self.evidence = 'pid %d (%s)' % (pid, cmd[:120])

        return found

    # ---- state machine --------------------------------------------------
    def poll(self, conn, now=None):
        """Update suspension state. Returns True while the monitor should idle."""
        now = now if now is not None else time.time()

        if not self.enabled:
            if self.suspended:
                self._resume(conn, now, 'the pause-during-backup setting was turned off')
            return False

        # The cap is checked before anything else: a detector that keeps seeing
        # a matching process must still let go eventually.
        if self.suspended and self.since is not None and (now - self.since) >= self.max_suspend:
            if not self.capped_out:
                self.capped_out = True
                log.warning('still suspended after %ds (%s) - resuming anyway; '
                            'monitoring will not stay off indefinitely',
                            int(now - self.since), self.reason)
                db_event(conn, 'monitor_suspend_capped',
                         'Real-time monitoring resumed after the maximum suspension of %ds '
                         'while "%s" was still running. A backup this long, or a process '
                         'holding that name open, is worth checking.'
                         % (self.max_suspend, self.reason))
            self._resume(conn, now, 'maximum suspension reached')
            return False

        if self._last_check is not None and (now - self._last_check) < self.check_every:
            return self.suspended
        self._last_check = now

        running = self.find_running()

        if running:
            self.clear_since = 0.0
            if not self.suspended:
                self._suspend(conn, now, ', '.join(sorted(set(running))))
            return True

        if not self.suspended:
            return False

        # Nothing matched. Wait out the settling period before resuming: rsync
        # in particular is often a series of short invocations, and flapping
        # the monitor between them costs more than staying down for another
        # minute.
        if self.clear_since == 0.0:
            self.clear_since = now
            return True
        if (now - self.clear_since) < self.resume_after:
            return True

        self._resume(conn, now, 'finished')
        return False

    def _suspend(self, conn, now, reason):
        self.suspended = True
        self.capped_out = False
        self.reason = reason
        self.since = now
        self.clear_since = 0.0
        log.info('suspending real-time scanning: %s running', reason)
        db_set(conn, 'rt_suspended', '1')
        db_set(conn, 'rt_suspend_reason', reason)
        db_set(conn, 'rt_suspend_since', str(int(now)))
        # What actually matched. "Paused -- jetbackup" with nothing behind it
        # is impossible to argue with when the operator can see no backup
        # running; the pid and command line make it checkable.
        db_set(conn, 'rt_suspend_evidence', self.evidence or reason)
        db_event(conn, 'monitor_suspended',
                 'Real-time scanning paused while %s is running. File changes during '
                 'this window are not scanned.' % reason)

    def _resume(self, conn, now, why):
        gap = int(now - self.since) if self.since is not None else 0
        was = self.reason or 'backup'
        self.suspended = False
        self.reason = ''
        self.clear_since = 0.0
        log.info('resuming real-time scanning after %ds (%s: %s)', gap, was, why)
        db_set(conn, 'rt_suspended', '0')
        db_set(conn, 'rt_suspend_reason', '')
        db_set(conn, 'rt_suspend_evidence', '')
        db_set(conn, 'rt_last_gap_seconds', str(gap))
        db_set(conn, 'rt_last_gap_end', str(int(now)))
        # Stated plainly: for that many seconds this server was not being
        # watched in real time, and the scheduled scan is what covers it.
        db_event(conn, 'monitor_resumed',
                 'Real-time scanning resumed after %ds paused for %s (%s). Changes made '
                 'during the pause were not scanned in real time; the next scheduled '
                 'scan covers them.' % (gap, was, why))
        self.since = None


def apply_io_priority():
    """Best-effort idle I/O priority.

    Real-time monitoring is background work: it should yield to the web server
    and the database rather than compete with them. nice() only covers CPU, and
    the cost here is mostly disk.
    """
    try:
        os.system('ionice -c3 -p %d >/dev/null 2>&1' % os.getpid())
    except Exception as e:
        log.debug('ionice failed: %s', e)


def apply_cpu_priority_nice(target):
    """Set an absolute nice value (best effort).

    os.nice() is RELATIVE and a process cannot lower its own niceness without
    privilege, so re-applying on reload can only ever raise it. Called on every
    profile change so lowering the load takes effect immediately; raising it
    again needs a restart, which is the safe direction to fail in.
    """
    try:
        current = os.nice(0)
        if target > current:
            os.nice(target - current)
    except Exception as e:
        log.debug('nice failed: %s', e)


def apply_cpu_priority(cpu_pct):
    """Lower process priority according to the CPU limit (best-effort)."""
    target = cpu_to_nice(cpu_pct)
    try:
        current = os.nice(0)
        if target > current:
            os.nice(target - current)
    except Exception as e:
        log.debug('nice failed: %s', e)
    log.info('CPU limit %d%% -> nice %d, scan_sleep %.2fs',
             cpu_pct, target, cpu_to_scan_sleep(cpu_pct))

def db_threat(conn, path, name, sev='high'):
    try:
        cur = conn.execute(
            "INSERT INTO threats(file_path,threat_name,threat_type,severity,status,detected_at)"
            " VALUES(?,?,?,?,?,strftime('%s','now'))",
            (path, name, 'realtime_detection', sev, 'active'))
        conn.commit()
        return cur.lastrowid or 0
    except Exception as e:
        log.warning('db_threat: %s', e)
        return 0

def db_event(conn, etype, msg):
    try:
        conn.execute("INSERT INTO security_events(type,severity,description) VALUES(?,?,?)",
                     (etype,'medium',msg))
        conn.commit()
    except: pass

PATTERNS = [
    ('eval_base64',    re.compile(rb'eval\s*\(\s*base64_decode\s*\(',    re.I)),
    ('eval_gzinflate', re.compile(rb'eval\s*\(\s*gzinflate\s*\(',        re.I)),
    ('eval_rot13',     re.compile(rb'eval\s*\(\s*str_rot13\s*\(',        re.I)),
    ('assert_b64',     re.compile(rb'assert\s*\(\s*base64_decode\s*\(',  re.I)),
    ('preg_eval',      re.compile(rb'preg_replace\s*\([\'"][^\'"]*\/e[\'"]', re.I)),
    ('c99_shell',      re.compile(rb'\$_(?:GET|POST|REQUEST|COOKIE|SERVER)\[.{0,30}?\]\s*\(\s*\$_(?:GET|POST|REQUEST|COOKIE)', re.I|re.S)),
    ('sys_shell',      re.compile(rb'\$_(?:GET|POST|REQUEST)\[.{0,30}?\]\s*;\s*(?:system|exec|passthru|shell_exec)', re.I|re.S)),
    ('rev_shell',      re.compile(rb'(?:bash|sh)\s+-i\s+>&?\s*/dev/tcp', re.I)),
    ('fsock_bd',       re.compile(rb'fsockopen\s*\(\s*\$_(?:GET|POST|REQUEST|COOKIE)', re.I)),
    ('xmrig',          re.compile(rb'stratum\+tcp://|xmrig|moneropool|minergate', re.I)),
    ('coinhive',       re.compile(rb'CoinHive\.Anonymous|coinhive\.min\.js', re.I)),
    ('long_b64',       re.compile(rb'[A-Za-z0-9+/]{500,}={0,2}')),
    ('hex_str',        re.compile(rb'[0-9a-fA-F]{200,}')),
]
SEV = {'c99_shell':'critical','rev_shell':'critical','fsock_bd':'critical',
       'eval_base64':'high','sys_shell':'high','assert_b64':'high'}
PHP_EXTS = {'.php','.php3','.php4','.php5','.php7','.phtml','.phps'}
MAX_SZ   = 52_428_800

# ── Conjunction rules ───────────────────────────────────────────────────────
#
# PATTERNS above asks one question per rule: "does this regex appear?" Every
# file that mattered during the October 2026 incident response answered no to
# all of them. Three of them, and why a single regex could never have worked:
#
#   - An upload backdoor whose only tell was hash_equals() against a 32-hex
#     constant sitting next to move_uploaded_file(). Each of those three
#     things appears in ordinary code; together they are a shell.
#
#   - A 456-byte mu-plugin, health-monitor.php, made entirely of documented
#     WordPress calls: read a query parameter, look up a token in usermeta,
#     call wp_set_auth_cookie(). No obfuscation to find. What condemns it is
#     where it lives and what it does together.
#
#   - A persistence loader in wp-content/db.php, a WordPress drop-in, which
#     loads before every plugin on every request.
#
# Mirrors backend/lib/Heuristics.php. The two must agree: an operator who sees
# a real-time alert and then runs a scan that finds nothing stops trusting
# both. When a rule changes in one, change it in the other.
HEUR = [
    # name, severity, all(), any(), none(), path or None
    ('upload_backdoor_hashkey', 'critical',
     [re.compile(rb'hash_equals\s*\(', re.I),
      re.compile(rb'[\'"][0-9a-fA-F]{32}[\'"]')],
     [re.compile(rb'move_uploaded_file\s*\(', re.I),
      re.compile(rb'file_put_contents\s*\(.{0,120}base64_decode', re.I | re.S)],
     [re.compile(rb'wp_verify_nonce\s*\(|check_admin_referer\s*\(', re.I),
      re.compile(rb'current_user_can\s*\(', re.I)],
     None),

    ('upload_backdoor_gifmask', 'critical',
     [re.compile(rb'\\x47\\x49\\x46\\x38\\x39\\x61')],
     [], [], None),

    ('auth_cookie_from_request', 'critical',
     [re.compile(rb'wp_set_auth_cookie\s*\(', re.I),
      re.compile(rb'\$_(?:GET|POST|REQUEST|COOKIE)\s*\['),
      re.compile(rb'usermeta|get_user_meta\s*\(|update_user_meta\s*\(', re.I)],
     [],
     [re.compile(rb'wp_verify_nonce\s*\(|check_admin_referer\s*\(', re.I)],
     None),

    ('auth_cookie_in_dropin', 'critical',
     [re.compile(rb'wp_set_auth_cookie\s*\(|wp_set_current_user\s*\(', re.I)],
     [], [],
     re.compile(r'/wp-content/mu-plugins/|'
                r'/wp-content/(?:db|object-cache|advanced-cache)\.php$')),

    ('admin_creator', 'critical',
     [re.compile(rb'wp_insert_user\s*\(|wp_create_user\s*\(', re.I),
      re.compile(rb'[\'"]administrator[\'"]', re.I)],
     [],
     [re.compile(rb'current_user_can\s*\(\s*[\'"](?:create_users|promote_users'
                 rb'|manage_options)', re.I)],
     None),

    ('self_deleting_script', 'critical',
     [re.compile(rb'@?unlink\s*\(\s*__FILE__\s*\)', re.I)],
     [], [], None),

    ('self_healing_dropper', 'critical',
     [re.compile(rb'get_option\s*\(|get_post_meta\s*\(|get_transient\s*\(', re.I),
      re.compile(rb'file_put_contents\s*\(|fwrite\s*\(', re.I)],
     [re.compile(rb'[\'"]<\?php'),
      re.compile(rb'base64_decode\s*\(', re.I),
      re.compile(rb'gzinflate\s*\(|gzuncompress\s*\(', re.I),
      re.compile(rb'openssl_decrypt\s*\(', re.I)],
     [re.compile(r'/wp-content/plugins/(?:w3-total-cache|wp-super-cache'
                 r'|litespeed-cache|wp-rocket|autoptimize|wp-optimize)/')],
     re.compile(r'/wp-content/(?:mu-plugins|plugins|themes)/|'
                r'/wp-content/(?:db|object-cache|advanced-cache)\.php$')),

    ('session_cookie_harvest', 'critical',
     [re.compile(rb'curl_exec\s*\(|fsockopen\s*\(|wp_remote_post\s*\(', re.I)],
     [re.compile(rb'SECURE_AUTH_COOKIE|LOGGED_IN_COOKIE|AUTH_COOKIE'),
      re.compile(rb'[\'"]session_tokens[\'"]')],
     [], None),

    ('payment_key_harvest', 'critical',
     [re.compile(rb'curl_exec\s*\(|fsockopen\s*\(|wp_remote_post\s*\(', re.I)],
     [re.compile(rb'STRIPE_(?:SECRET|KEY|API)', re.I),
      re.compile(rb'AWS_SECRET_ACCESS_KEY'),
      re.compile(rb'BRAINTREE_PRIVATE_KEY'),
      re.compile(rb'AUTHORIZE_NET_TRANSACTION_KEY')],
     [], None),

    ('php_in_uploads', 'high',
     [],
     [re.compile(rb'\$_(?:GET|POST|REQUEST|COOKIE|FILES|SERVER)\s*\['),
      re.compile(rb'\b(?:eval|assert|system|exec|passthru|shell_exec)\s*\(', re.I),
      re.compile(rb'base64_decode\s*\(', re.I),
      re.compile(rb'move_uploaded_file\s*\(', re.I)],
     [],
     re.compile(r'/wp-content/uploads/.*\.(?:php|phtml|php[3-7])$')),
]

# ── Sentinel paths ──────────────────────────────────────────────────────────
#
# THE MOST USEFUL THING IN THIS FILE.
#
# These positions in a WordPress install should not change without somebody
# knowing. A scanner cannot tell you a file is new -- it sees a filesystem,
# not a history. A daemon watching inotify can, and that is the one detection
# no amount of signature work replaces: health-monitor.php was 456 bytes of
# textbook WordPress code and no rule above would ever have fired on it, but
# a mu-plugin APPEARING on a site that had none is reportable on its own.
#
# wp-content/{db,object-cache,advanced-cache}.php load before every plugin on
# every request, including wp-login.php. Legitimate ones exist -- Redis and
# Memcached object caches, Query Monitor's db.php -- so this is reported, not
# acted on. "A drop-in appeared on this site twenty minutes ago" is something
# the operator can check in one look.
SENTINELS = [
    (re.compile(r'/wp-content/(?:db|object-cache|advanced-cache)\.php$'),
     'A WordPress drop-in appeared or changed. These load before every plugin '
     'on every request. If you did not install a Redis/Memcached cache or '
     'Query Monitor, read this file now.'),
    (re.compile(r'/wp-content/mu-plugins/[^/]+\.php$'),
     'A must-use plugin appeared or changed. mu-plugins load automatically and '
     'cannot be deactivated from the admin UI.'),
    (re.compile(r'/wp-config\.php$'),
     'wp-config.php changed. It loads before everything else, which makes it '
     'the most valuable injection point on a WordPress site.'),
    (re.compile(r'/wp-content/themes/[^/]+/functions\.php$'),
     'A theme functions.php changed. Expected after a theme update or an edit '
     'in the admin UI; otherwise worth reading.'),
]

# Files worth reading even though they are not named *.php. The persistence
# framework stashed an encrypted copy of itself at
# wp-content/uploads/.<64 hex>.cache -- hidden, no PHP extension, and so
# invisible to this daemon, which filtered on suffix before doing anything.
STASH = re.compile(r'/wp-content/(?:uploads|upgrade|cache)/'
                   r'.*/?\.[0-9a-f]{16,}(?:\.(?:cache|tmp|dat|bin))?$')


def interesting(path):
    """Is this path worth opening?

    Replaces a bare `suffix in PHP_EXTS` check. Still a string comparison --
    no syscall -- because it runs on every inotify event on the server.
    """
    low = path.replace('\\', '/')
    if os.path.splitext(low)[1].lower() in PHP_EXTS:
        return True
    if os.path.basename(low) in ('db.php', 'object-cache.php', 'advanced-cache.php'):
        return True
    return bool(STASH.search(low))


def heuristic(path, data):
    """Highest-severity conjunction rule matching this file, or None."""
    low = path.replace('\\', '/')
    best = None
    order = {'low': 0, 'medium': 1, 'high': 2, 'critical': 3}
    for name, sev, alls, anys, nones, pathre in HEUR:
        if pathre is not None and not pathre.search(low):
            continue
        if not alls and not anys:
            continue
        if any(not r.search(low if isinstance(r.pattern, str) else data)
               for r in alls):
            continue
        if anys and not any(r.search(low if isinstance(r.pattern, str) else data)
                            for r in anys):
            continue
        if any(r.search(low if isinstance(r.pattern, str) else data)
               for r in nones):
            continue
        if best is None or order[sev] > order[best[1]]:
            best = (name, sev)
    return best


def sentinel(path):
    """Why this path's appearance is worth telling the operator about."""
    low = path.replace('\\', '/')
    for rx, why in SENTINELS:
        if rx.search(low):
            return why
    return None

def scan(path, max_size=None):
    try:
        sz = os.path.getsize(path)
        limit = MAX_SZ if max_size is None else max_size
        # Reading a 40MB file to regex it costs far more than the detection is
        # worth; the size ceiling is a user-visible resource control now.
        if sz == 0 or sz > limit: return None
        data = open(path,'rb').read()
        # Conjunction rules first. When both fire, the heuristic names
        # something the operator can act on ("an authenticated upload shell")
        # where the flat pattern says "long_b64".
        h = heuristic(path, data)
        if h: return ('SG.WP.' + h[0], h[1])
        for n, p in PATTERNS:
            if p.search(data): return ('SG.RT.' + n, SEV.get(n, 'medium'))
    except (PermissionError, OSError): pass
    return None

_chk = 0; _thr = 0

def handle(conn, path, limits=None, limiter=None, debouncer=None):
    global _chk, _thr

    if debouncer is not None and debouncer.should_skip(path):
        return
    if limiter is not None:
        limiter.take()

    _chk += 1
    hit = scan(path, limits['max_file_size'] if limits else None)

    # A sentinel position changed. Reported whether or not anything matched,
    # because the detection IS the change: a mu-plugin or a drop-in appearing
    # is worth a look even when the file is clean, and the worst backdoor found
    # on this server in October 2026 was clean by every test we had.
    #
    # Never auto-quarantined. Redis object caches and theme edits land here
    # too, and deleting a customer's object-cache.php because it was written to
    # is worse than the thing this is watching for.
    why = sentinel(path)
    if why and not _seen_before(path):
        db_event(conn, 'wp_sentinel', '%s: %s' % (path, why))
        log.warning('SENTINEL %s -- %s', path, why)

    if not hit: return
    t, sev = hit
    _thr += 1

    # Has this exact path been dealt with before? If so the file has COME BACK,
    # and that is a different and worse finding: something else on the site
    # rebuilt it. On this server a mu-plugin was deleted and returned twice,
    # because wp-config.php and two drop-ins were each able to recreate it, and
    # each round of deletion was reported as a success.
    if _seen_before(path):
        sev = 'critical'
        t = t + '.recurring'
        log.error('RECURRENCE %s -- previously removed and has returned; '
                  'an executor elsewhere on this site is rebuilding it', path)
        db_event(conn, 'wp_recurrence',
                 '%s was removed before and has returned. Deleting it again '
                 'will not help: find what recreated it -- check wp-config.php, '
                 'wp-content/db.php, object-cache.php and advanced-cache.php.'
                 % path)

    tid = db_threat(conn, path, t, sev)
    log.warning('THREAT %s -> %s (id=%s sev=%s)', path, t, tid, sev)
    db_event(conn, 'realtime_threat', '%s in %s' % (t, path))
    if db_get(conn,'auto_quarantine') == '1' and tid:
        quarantine(conn, path, tid)


def _seen_before(path):
    """Was a threat already recorded at this exact path and acted on?

    Opens its own short-lived connection rather than taking one as an
    argument, so the call sites stay readable; the query is indexed and runs
    only when something has already matched or a sentinel fired, not on every
    event.
    """
    try:
        c = db_connect()
        if c is None:
            return False
        row = c.execute(
            "SELECT 1 FROM threats WHERE file_path = ? "
            "AND status IN ('quarantined','deleted','resolved') LIMIT 1",
            (path,)).fetchone()
        c.close()
        return row is not None
    except Exception:
        # A failed lookup must not be read as "never seen". Treating it as
        # not-seen only loses the escalation; treating it as seen would mark
        # every first detection a recurrence.
        return False

def quarantine(conn, path, tid):
    day  = datetime.date.today().strftime('%Y-%m-%d')
    base = db_get(conn,'quarantine_dir') or os.path.join(SG_ROOT,'quarantine')
    qd   = os.path.join(base, day)
    try:
        os.makedirs(qd, 0o700, exist_ok=True)
        dest = os.path.join(qd, os.path.basename(path) + f'_{tid}.quarantine')
        shutil.move(path, dest)
        open(path+'.serverscrub_removed','w').write(
            f'Quarantined by ServerScrub at {datetime.datetime.now()}\nID:{tid}\nOrig:{path}\n')
        conn.execute("UPDATE threats SET status='quarantined',action_taken='quarantine',"
                     "resolved_at=strftime('%s','now') WHERE id=?", (tid,))
        conn.commit()
        log.info('Quarantined %s', path)
    except Exception as e:
        log.warning('Quarantine failed %s: %s', path, e)

def flush(conn):
    global _running
    db_set(conn,'rt_files_checked',str(_chk))
    db_set(conn,'rt_threats_found', str(_thr))
    db_set(conn,'rt_last_activity', str(int(time.time())))

    # Re-verify while running. Checking only at startup would let a licence that
    # lapses (or is revoked) keep the daemon alive indefinitely, since this
    # process can run for weeks.
    allowed, why = license_ok(conn)
    if not allowed:
        log.error('License no longer valid (%s) — stopping monitor', why)
        db_set(conn, 'rt_monitor_status', 'unlicensed')
        _running = False


# ── License gate ──────────────────────────────────────────────────────────────
# The daemon cannot validate a signed local key itself — that logic lives in
# PHP (License.php) and re-implementing the crypto here would mean two
# implementations to keep in sync and two chances to get it wrong. Instead PHP
# publishes its decision into the settings table and the daemon reads it.
#
# The staleness check matters: if PHP has not run for longer than FLAG_MAX_AGE
# the flag is treated as untrustworthy rather than as permission. Otherwise a
# customer could license once, delete the cron that refreshes the flag, and the
# daemon would keep running on a permission that is never re-verified.
FLAG_MAX_AGE = 3 * 86400          # 3 days — cron refreshes it hourly

def license_ok(conn):
    """(allowed, reason)"""
    ok    = db_get(conn, 'license_protection_ok', '')
    at    = db_get(conn, 'license_flag_at', '0')
    state = db_get(conn, 'license_status', 'Unknown')
    try:
        age = time.time() - int(at or 0)
    except ValueError:
        age = FLAG_MAX_AGE + 1

    if ok != '1':
        return False, f'license status: {state}'
    if age > FLAG_MAX_AGE:
        return False, (f'license flag is {int(age/86400)}d old — not re-verified. '
                       'Is the ServerScrub cron still installed?')
    return True, state

def watch_paths(conn):
    raw = db_get(conn,'scan_paths','/home')
    return [p.strip() for p in raw.split(',') if p.strip() and os.path.isdir(p.strip())]

SKIP = {'node_modules','.git','__pycache__','.svn'}

def run_inotify(conn, paths, limits):
    import inotify_simple
    fl = inotify_simple.flags.CREATE | inotify_simple.flags.MODIFY | inotify_simple.flags.MOVED_TO
    ino = inotify_simple.INotify()
    wds = {}
    capped = False

    for base in paths:
        for root, dirs, _ in os.walk(base, followlinks=False):
            dirs[:] = [d for d in dirs
                       if d not in limits['excludes'] and not d.startswith('.')]
            if len(wds) >= limits['max_watches']:
                capped = True
                break
            try:
                wd = ino.add_watch(root, fl)
                wds[wd] = root
            except (PermissionError, FileNotFoundError):
                pass
            except OSError as e:
                # ENOSPC means the kernel's max_user_watches is exhausted. This
                # used to be swallowed with everything else, leaving the monitor
                # silently watching a fraction of the tree while reporting
                # itself healthy.
                log.error('inotify watch limit reached (%s). Watching %d dirs only. '
                          'Raise fs.inotify.max_user_watches or lower rt_max_watches.',
                          e, len(wds))
                capped = True
                break
        if capped:
            break

    log.info('inotify: %d dirs (cap %d)%s', len(wds), limits['max_watches'],
             ' - CAPPED' if capped else '')
    db_set(conn, 'rt_watch_count', str(len(wds)))
    db_set(conn, 'rt_watch_capped', '1' if capped else '0')

    limiter   = RateLimiter(limits['files_per_sec'])
    debouncer = Debouncer(limits['debounce'])
    backups   = BackupActivityDetector(conn)

    tick = 0
    last_reload = time.time()

    while _running:
        try: evts = ino.read(timeout=2000)
        except Exception as e:
            if _running: log.warning('inotify err: %s', e)
            break

        # Events are still READ while suspended, and then dropped.
        #
        # Not reading them would leave the kernel queue to overflow, and an
        # overflowed queue does not resume cleanly: inotify reports IN_Q_OVERFLOW
        # and the watches are no longer trustworthy. Draining costs almost
        # nothing; it is scanning each file that costs, and that is what stops.
        if backups.poll(conn):
            if tick:
                flush(conn)
                tick = 0
            continue

        # Settings must take effect without a restart: an administrator whose
        # server is under load should not have to restart the monitor to calm
        # it down.
        if time.time() - last_reload >= 60:
            fresh = load_profile(conn)
            if fresh != limits:
                limits = fresh
                limiter.update(limits['files_per_sec'])
                debouncer.update(limits['debounce'])
                apply_cpu_priority_nice(limits['nice'])
                log.info('resource profile reloaded: %s', limits['profile'])
            backups.reload(conn)
            last_reload = time.time()

        for ev in evts:
            if not ev.name: continue
            dp = wds.get(ev.wd,'')
            if not dp: continue
            fp = os.path.join(dp, ev.name)
            # interesting() replaces the bare suffix check: drop-ins and the
            # hidden hex-named payload stash have to get through it.
            if not interesting(fp): continue
            handle(conn, fp, limits, limiter, debouncer)
            tick += 1
            if tick >= 50: flush(conn); tick = 0
    ino.close()

def run_polling(conn, paths, limits):
    """Fallback when inotify is unavailable.

    This is where the load came from. The previous implementation walked every
    watched path and stat()ed every file on each pass, holding a path->mtime
    dict for the entire tree and a second copy while diffing. Against /home on a
    shared host that is millions of stat calls per interval, permanently.

    Three changes: only files we would ever scan are tracked (a PHP monitor has
    no use for the mtime of a JPEG), the tracked set is bounded and says so when
    it fills, and the walk yields between directories so it cannot monopolise a
    core.
    """
    interval = limits['poll_interval']
    log.info('polling: %s every %ds (tracking PHP files only)', paths, interval)

    max_tracked = 200000

    def snap(lim):
        out = {}
        truncated = False
        for b in paths:
            for r, ds, fs in os.walk(b, followlinks=False):
                ds[:] = [d for d in ds
                         if d not in lim['excludes'] and not d.startswith('.')]
                for f in fs:
                    # Filter BEFORE stat(): the extension check is a string
                    # comparison, the stat is a syscall. The old order paid the
                    # syscall for every file on the server.
                    if not interesting(os.path.join(r, f)):
                        continue
                    if len(out) >= max_tracked:
                        truncated = True
                        break
                    fp = os.path.join(r, f)
                    try: out[fp] = os.path.getmtime(fp)
                    except OSError: pass
                if truncated:
                    break
                # Yield to the rest of the system between directories.
                time.sleep(0)
            if truncated:
                break
        if truncated:
            log.warning('polling: tracking capped at %d files. Narrow scan_paths '
                        'or install inotify_simple for event-driven monitoring.',
                        max_tracked)
        return out

    prev = snap(limits)
    last_fl = time.time()
    limiter   = RateLimiter(limits['files_per_sec'])
    debouncer = Debouncer(limits['debounce'])
    backups   = BackupActivityDetector(conn)

    while _running:
        slept = 0
        while slept < interval and _running:
            time.sleep(min(5, interval - slept)); slept += 5
        if not _running: break

        fresh = load_profile(conn)
        if fresh != limits:
            limits = fresh
            interval = limits['poll_interval']
            limiter.update(limits['files_per_sec'])
            debouncer.update(limits['debounce'])
            apply_cpu_priority_nice(limits['nice'])
            log.info('resource profile reloaded: %s', limits['profile'])
        backups.reload(conn)

        # Polling is the heavier of the two modes -- a full walk of every
        # watched path -- so running one alongside a backup is the worst case
        # this whole feature exists to avoid.
        #
        # prev is deliberately NOT refreshed while suspended. Refreshing it
        # would silently adopt every change the backup window made as the new
        # baseline, so a file planted during the pause would never be reported.
        # Leaving it stale means the first pass after resuming compares against
        # the state from before the backup and picks those changes up.
        if backups.poll(conn):
            continue

        curr = snap(limits)
        for fp, mt in curr.items():
            if fp not in prev or prev[fp] < mt:
                handle(conn, fp, limits, limiter, debouncer)
        prev = curr
        if time.time() - last_fl >= 30: flush(conn); last_fl = time.time()

def main():
    global _SCAN_SLEEP
    write_pid()
    log.info('ServerScrub RT Monitor starting PID=%d SG_ROOT=%s', os.getpid(), SG_ROOT)
    conn = None
    try:
        conn = db_connect()

        # Clear any suspension left over from a previous life.
        #
        # The suspend flags live in the database and only this daemon writes
        # them. A daemon that is killed or restarted while suspended never
        # reaches its resume path, so the flags stay set for ever -- and the
        # new daemon starts with suspended=False in memory, so it never clears
        # them either. The dashboard then shows "Paused" indefinitely over a
        # monitor that is scanning perfectly well.
        #
        # A daemon that has just started is not suspended, by definition. The
        # first detector poll re-establishes the truth within seconds.
        if db_get(conn, 'rt_suspended', '0') == '1':
            log.info('clearing stale suspension flag left by a previous run')
            db_set(conn, 'rt_suspended', '0')
            db_set(conn, 'rt_suspend_reason', '')
            db_set(conn, 'rt_suspend_evidence', '')

        allowed, why = license_ok(conn)
        if not allowed:
            log.error('Real-time monitoring requires a valid license (%s)', why)
            db_set(conn, 'rt_monitor_status', 'unlicensed')
            db_set(conn, 'rt_engine', 'disabled')
            return

        db_set(conn,'rt_monitor_status','running')

        limits = load_profile(conn)
        apply_cpu_priority_nice(limits['nice'])
        apply_io_priority()
        log.info('profile=%s nice=%d files/s=%d max_file=%dMB poll=%ds watches=%d debounce=%ds',
                 limits['profile'], limits['nice'], limits['files_per_sec'],
                 limits['max_file_size'] // (1024*1024), limits['poll_interval'],
                 limits['max_watches'], limits['debounce'])

        # Publish what is actually in effect so the UI shows the real limits
        # rather than what someone believes they configured.
        db_set(conn,'rt_effective_profile', limits['profile'])
        db_set(conn,'rt_effective_files_per_sec', str(limits['files_per_sec']))
        db_set(conn,'rt_effective_poll_interval', str(limits['poll_interval']))

        paths = watch_paths(conn)
        if not paths:
            paths = [p for p in ['/home','/var/www'] if os.path.isdir(p)] or ['/']
        log.info('Watch paths: %s', paths)
        try:
            import inotify_simple
            db_set(conn,'rt_engine','inotify')
            log.info('Engine: inotify_simple')
            run_inotify(conn, paths, limits)
        except ImportError:
            db_set(conn,'rt_engine','polling')
            log.info('Engine: polling interval=%ds', limits['poll_interval'])
            run_polling(conn, paths, limits)
    except Exception as e:
        log.error('Fatal: %s', e, exc_info=True)
    finally:
        if conn:
            try: flush(conn); db_set(conn,'rt_monitor_status','stopped'); conn.close()
            except: pass
        remove_pid()
        log.info('Monitor stopped')

if __name__ == '__main__':
    main()
