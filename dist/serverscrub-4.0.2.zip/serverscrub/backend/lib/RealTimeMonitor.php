<?php
/**
 * ServerScrub — Real-Time Monitor Manager
 * Controls the Python inotify daemon from the PHP API
 */

class RealTimeMonitor {

    private string $daemonScript;
    private string $pidFile;
    private string $logFile;
    private string $serviceFile;

    /**
     * How shell commands are run. Injectable so the status logic can be tested
     * without systemd: the previous code called exec() directly, which made
     * every branch of it unreachable from a test and is why "Active" could be
     * displayed beside empty counters for so long without anyone noticing.
     *
     * @var callable(string):array{0:string[],1:int}
     */
    private $exec;

    public function __construct(?array $paths = null, ?callable $exec = null) {
        $this->daemonScript = $paths['daemon']  ?? SG_ROOT . '/backend/daemon/monitor.py';
        $this->pidFile      = $paths['pid']     ?? '/var/run/serverscrub-monitor.pid';
        $this->logFile      = $paths['log']     ?? SG_LOGS . '/monitor.log';
        $this->serviceFile  = $paths['service'] ?? '/etc/systemd/system/serverscrub-monitor.service';

        $this->exec = $exec ?? function (string $cmd): array {
            $out = [];
            $code = 0;
            exec($cmd, $out, $code);
            return [$out, $code];
        };
    }

    /** @return array{0:string[],1:int} */
    private function run(string $cmd): array {
        return ($this->exec)($cmd);
    }

    // ── Status ──────────────────────────────────────────────────────────────

    /**
     * Is the daemon actually running?
     *
     * The PID file is written by the daemon itself and lives in /var/run, which
     * is tmpfs: it disappears on reboot, and a crash can leave it behind
     * pointing at a PID that no longer exists or has been reused. Systemd is
     * the authority on a service it manages, so it is consulted whenever the
     * PID file does not give a clear answer. Reporting "stopped" for a running
     * monitor is exactly as harmful as the reverse.
     */
    public function isRunning(): bool {
        if (file_exists($this->pidFile)) {
            $pid = (int) trim((string) @file_get_contents($this->pidFile));
            if ($pid > 0 && file_exists("/proc/$pid")) {
                return true;
            }
        }
        return $this->isServiceActive();
    }

    /**
     * Is the unit running right now, AND staying up?
     *
     * `is-active` alone is not enough. A daemon that crashes on its first line
     * and is relaunched by Restart=on-failure cycles through active/activating
     * for as long as systemd keeps trying, so `is-active` answers "active"
     * about a process that has never worked. That is precisely what happened:
     * the daemon died on a Python 3.8 argument under 3.6, systemd restarted it
     * in a loop, and the dashboard reported "Monitor started".
     *
     * SubState separates them: `running` is up, `auto-restart` is being
     * resurrected.
     */
    public function isServiceActive(): bool {
        $d = $this->serviceDetail();
        return $d['active'] === 'active' && $d['sub'] === 'running';
    }

    /**
     * ActiveState, SubState and the restart count.
     *
     * @return array{active:string,sub:string,restarts:int}
     */
    public function serviceDetail(): array {
        if (!file_exists($this->serviceFile)) {
            return ['active' => 'not-installed', 'sub' => '', 'restarts' => 0];
        }
        [$out, ] = $this->run(
            'systemctl show serverscrub-monitor -p ActiveState -p SubState -p NRestarts 2>/dev/null');

        $vals = [];
        foreach ($out as $line) {
            $parts = explode('=', trim($line), 2);
            if (count($parts) === 2) { $vals[$parts[0]] = $parts[1]; }
        }
        return [
            'active'   => $vals['ActiveState'] ?? 'unknown',
            'sub'      => $vals['SubState'] ?? '',
            'restarts' => (int)($vals['NRestarts'] ?? 0),
        ];
    }

    /** The last lines the daemon logged — what a failed start must report. */
    public function recentLog(int $lines = 12): string {
        if (is_readable($this->logFile)) {
            [$out, ] = $this->run('tail -n ' . (int)$lines . ' ' . escapeshellarg($this->logFile));
            if ($out) { return trim(implode("\n", $out)); }
        }
        [$out, ] = $this->run(
            'journalctl -u serverscrub-monitor -n ' . (int)$lines . ' --no-pager 2>/dev/null');
        return trim(implode("\n", $out));
    }

    /**
     * Is the stored suspension still meaningful?
     *
     * False when the daemon is not running (nothing is suspended if nothing is
     * scanning) or when the flag has outlived the configured maximum
     * suspension, which means whoever set it never got to clear it.
     */
    private static function suspensionIsCurrent(bool $daemonRunning): bool
    {
        if (!$daemonRunning) { return false; }
        if (Database::setting('rt_suspended', '0') !== '1') { return false; }

        $since = (int) (Database::setting('rt_suspend_since', '0') ?? 0);
        if ($since <= 0) { return false; }

        $max = (int) (Database::setting('rt_backup_max_suspend_secs', '14400') ?? 14400);
        return (time() - $since) < max(60, $max);
    }

    public function getStatus(): array {
        $detail       = $this->serviceDetail();
        $running      = $this->isRunning();
        // Running may be true on systemd's word alone, with no PID file present
        // — reading it unconditionally warned on every request in that case.
        $pid = null;
        if ($running && is_readable($this->pidFile)) {
            $pid = (int) trim((string) @file_get_contents($this->pidFile)) ?: null;
        }
        $filesChecked = (int) (Database::setting('rt_files_checked') ?? 0);
        $threatsFound = (int) (Database::setting('rt_threats_found') ?? 0);
        $lastActivity = Database::setting('rt_last_activity');
        $engine       = $this->detectEngine();

        // Count real-time detections (last 24h)
        $since      = time() - 86400;
        $rt24h      = Database::fetchOne(
            "SELECT COUNT(*) as c FROM threats WHERE threat_type='realtime_detection' AND detected_at >= ?",
            [$since]
        )['c'] ?? 0;

        // Total real-time detections ever
        $rtTotal = Database::fetchOne(
            "SELECT COUNT(*) as c FROM threats WHERE threat_type='realtime_detection'"
        )['c'] ?? 0;

        // Watch paths
        $paths = Database::setting('scan_paths', '/home');

        // A daemon can be "running" and yet doing nothing — wrong watch paths,
        // an exception in its loop, inotify watches exhausted. It stamps
        // rt_last_activity as it works, so silence is measurable and worth
        // surfacing rather than showing a green badge and empty counters.
        $age   = $lastActivity !== null ? max(0, time() - (int) $lastActivity) : null;
        $stale = $running && ($age === null || $age > 3600);

        return [
            'running'           => $running,
            'pid'               => $pid,
            'engine'            => $engine,
            'watch_paths'       => array_map('trim', explode(',', $paths)),
            'files_checked'     => $filesChecked,
            'threats_found'     => $threatsFound,
            'detections_24h'    => (int) $rt24h,
            'detections_all'    => (int) $rtTotal,
            'last_activity'     => $lastActivity !== null ? (int) $lastActivity : null,
            'last_activity_age' => $age,
            'stale'             => $stale,
            'log_file'          => $this->logFile,
            // What the daemon reports as ACTUALLY in effect, which is not
            // necessarily what the settings say: it re-reads them on a cycle,
            // and a value out of range is clamped rather than obeyed.
            'profile'           => Database::setting('rt_profile', 'balanced'),
            'effective_profile' => Database::setting('rt_effective_profile'),
            'effective_rate'    => (int) (Database::setting('rt_effective_files_per_sec', '0') ?? 0),
            'watch_count'       => (int) (Database::setting('rt_watch_count', '0') ?? 0),
            'watch_capped'      => Database::setting('rt_watch_capped', '0') === '1',
            // A crash loop is the state that looked like success. Report it.
            'restarts'          => $detail['restarts'],
            'crash_looping'     => $detail['sub'] === 'auto-restart',
            'service_installed' => file_exists($this->serviceFile),
            'service_enabled'   => $this->isServiceEnabled(),
            'service_active'    => $this->isServiceActive(),

            // Suspended while a backup runs.
            //
            // This is a THIRD state, and conflating it with either of the other
            // two would be a lie: the daemon is running, so a red "stopped"
            // badge is wrong, but it is not scanning, so a green "active" badge
            // is worse -- it claims protection that is deliberately paused.
            // A suspension is only believable while the daemon that set it is
            // alive and the flag is recent.
            //
            // These flags live in the database and only the daemon writes
            // them. A daemon killed while suspended never runs its resume
            // path, so the flags persist -- and the dashboard showed "Paused
            // -- jetbackup" indefinitely over a monitor that was scanning
            // normally. The daemon now clears them at startup; this is the
            // second line of defence for the window before it does, and for a
            // daemon that is not running at all.
            'suspended'         => self::suspensionIsCurrent($running),
            'suspend_reason'    => self::suspensionIsCurrent($running)
                                    ? (Database::setting('rt_suspend_reason', '') ?: null)
                                    : null,
            // What actually matched, so "Paused -- jetbackup" can be checked
            // rather than argued with.
            'suspend_evidence'  => self::suspensionIsCurrent($running)
                                    ? (Database::setting('rt_suspend_evidence', '') ?: null)
                                    : null,
            'suspend_since'     => (int) (Database::setting('rt_suspend_since', '0') ?? 0),
            'last_gap_seconds'  => (int) (Database::setting('rt_last_gap_seconds', '0') ?? 0),
            'last_gap_end'      => (int) (Database::setting('rt_last_gap_end', '0') ?? 0),
            'pause_on_backup'   => Database::setting('rt_pause_on_backup', '1') === '1',
        ];
    }

    // ── Start / Stop ─────────────────────────────────────────────────────────

    /**
     * Backup or bulk-transfer processes running right now.
     *
     * The daemon has its own detector in Python, used to suspend scanning from
     * inside its loop. This is the same question asked from outside, by
     * something deciding whether the daemon should be running at all -- a
     * suspended daemon and a stopped one are different states and only the
     * daemon can answer for the first.
     *
     * Reads /proc rather than forking pgrep: this runs from cron every 15
     * minutes for the life of the server.
     *
     * @return string[] names of the matching processes
     */
    /**
     * Processes whose presence means the backup software is INSTALLED, never
     * that a backup is running. They must never trigger a suspension.
     */
    public const ALWAYS_ON_BACKUP_DAEMONS = ['jetbackupd', 'jetbackup5d', 'jetbackupmysqld'];

    /** Command-line fragments that indicate an actual JetBackup task. */
    public const JETBACKUP_JOB_HINTS = ['jetbackup5/core/queue', 'jetbackup/core/queue',
                                        'jb5 backup', 'jetbackup backup'];

    public static function backupProcesses(): array
    {
        $found = [];
        if (!is_dir('/proc')) { return $found; }

        $raw = (string) (Database::setting('rt_backup_procs', 'jetbackup,rsync') ?? '');
        $names = [];
        foreach (explode(',', $raw) as $n) {
            $n = strtolower(trim($n));
            // A blank or wildcard entry would match everything and make the
            // server look permanently busy, so monitoring would never resume.
            if ($n !== '' && $n !== '*') { $names[$n] = true; }
        }
        if (!$names) { $names = ['jetbackup' => true, 'rsync' => true]; }

        $rawEx = (string) (Database::setting('rt_backup_exclude', '') ?? '');
        $excl  = [];
        foreach (explode(',', $rawEx) as $x) {
            $x = strtolower(trim($x));
            if ($x !== '') { $excl[$x] = true; }
        }
        if (!$excl) {
            foreach (self::ALWAYS_ON_BACKUP_DAEMONS as $x) { $excl[$x] = true; }
        }

        $self = getmypid();
        foreach (glob('/proc/[0-9]*') ?: [] as $dir) {
            $pid = (int) basename($dir);
            if ($pid <= 1 || $pid === $self) { continue; }

            $comm = @file_get_contents($dir . '/comm');
            if ($comm === false) { continue; }
            $comm = strtolower(trim($comm));

            // An always-on daemon means the software is installed, not that a
            // backup is running. jetbackupd runs continuously; matching it
            // suspended monitoring permanently on every server with JetBackup.
            if (isset($excl[$comm])) { continue; }

            if (isset($names[$comm])) { $found[] = $comm; continue; }

            // JetBackup runs jobs under generic interpreter names, so the
            // command line is what identifies one. The fragments looked for
            // indicate a TASK -- an install path does not, which is what
            // '/jetapps/' used to match here and in the daemon.
            if (isset($names['jetbackup'])) {
                $cmd = @file_get_contents($dir . '/cmdline');
                if ($cmd === false || $cmd === '') { continue; }
                $cmd = strtolower(str_replace("\0", ' ', $cmd));

                foreach (array_keys($excl) as $x) {
                    if ($x !== '' && strpos($cmd, $x) !== false) { continue 2; }
                }
                foreach (self::JETBACKUP_JOB_HINTS as $h) {
                    if (strpos($cmd, $h) !== false) { $found[] = 'jetbackup'; break; }
                }
            }
        }
        return array_values(array_unique($found));
    }

    /**
     * Bring monitoring back up once the backups are done.
     *
     * Run from the scheduler, which cron fires every 15 minutes. Without it,
     * a monitor that went down during a backup window stays down until someone
     * notices and presses Start -- which is exactly the manual step this
     * removes.
     *
     * It will not fight a deliberate decision. Stopping the monitor while no
     * backup is running records that a person wanted it off, and this leaves
     * it off. Stopping it DURING a backup does not: that reads as "off for the
     * backup", which is the case this exists to undo.
     */
    public function autoResume(): array
    {
        if ((Database::setting('rt_autostart_after_backup', '1') ?? '1') !== '1') {
            return ['acted' => false, 'reason' => 'auto-resume is disabled'];
        }

        $backups = self::backupProcesses();
        if ($backups) {
            // Remember the window so a stop during it is understood as
            // temporary, and clear any earlier manual intent for the same
            // reason.
            Database::setSetting('rt_backup_seen_at', (string) time());
            Database::setSetting('rt_manual_stop', '0');
            return ['acted' => false, 'reason' => 'backup running: ' . implode(', ', $backups),
                    'backups' => $backups];
        }

        if ($this->isRunning()) {
            return ['acted' => false, 'reason' => 'already running'];
        }

        if ((Database::setting('rt_manual_stop', '0') ?? '0') === '1') {
            return ['acted' => false, 'reason' => 'stopped deliberately; leaving it off'];
        }

        $res = $this->start();
        if (!empty($res['success'])) {
            Database::setSetting('rt_monitor_status', 'running');
            Logger::info('Real-time monitor started automatically: no backup processes running');
            Database::insert('security_events', [
                'type'        => 'monitor_autostarted',
                'severity'    => 'low',
                'description' => 'Real-time monitoring was started automatically once the '
                               . 'backup window ended.',
            ]);
            return ['acted' => true, 'reason' => 'started'];
        }

        Logger::error('Auto-resume could not start the monitor: '
                    . ($res['error'] ?? 'unknown'));
        return ['acted' => false, 'reason' => 'start failed: ' . ($res['error'] ?? 'unknown'),
                'error' => $res['error'] ?? null];
    }

    public function start(): array {
        if ($this->isRunning()) {
            return ['success' => true, 'message' => 'Monitor already running'];
        }

        if (!file_exists($this->daemonScript)) {
            return ['success' => false, 'error' => 'Daemon script not found: ' . $this->daemonScript];
        }

        // Prefer systemd whenever the unit file is present
        if (file_exists($this->serviceFile)) {
            // A unit in 'failed' will not start, and once systemd's start rate
            // limit has been reached it refuses outright with "start request
            // repeated too quickly" -- which is a monitor that cannot be
            // turned on from the dashboard at all, however many times Start is
            // pressed. reset-failed is what clears both. It was added to
            // stop() in 3.30.1 and should always have been here too.
            $pre = $this->serviceDetail();
            if (($pre['active'] ?? '') === 'failed' || ($pre['sub'] ?? '') === 'failed') {
                exec('systemctl reset-failed serverscrub-monitor 2>&1');
                Logger::info('Cleared failed state before starting the monitor');
            }

            [$out, $code] = $this->run('systemctl start serverscrub-monitor 2>&1');

            // The rate limiter can also refuse a unit that is not currently
            // 'failed'. The message is the only signal, so it is what we act on.
            if ($code !== 0 && stripos(implode(' ', (array) $out), 'repeated too quickly') !== false) {
                exec('systemctl reset-failed serverscrub-monitor 2>&1');
                Logger::info('Start was rate limited; reset and retrying');
                [$out, $code] = $this->run('systemctl start serverscrub-monitor 2>&1');
            }

            if ($code === 0) {
                // Exit 0 means the process was LAUNCHED, not that it survived.
                // A daemon that dies immediately gets relaunched by
                // Restart=on-failure, and returning success here is how
                // "Monitor started" came to be shown over something that had
                // already crashed. Wait, then confirm it is still up.
                $detail = ['active' => '', 'sub' => '', 'restarts' => 0];
                for ($i = 0; $i < 8; $i++) {
                    usleep(400000);
                    $detail = $this->serviceDetail();
                    if ($detail['active'] === 'active' && $detail['sub'] === 'running') {
                        Database::setSetting('rt_monitor_status', 'running');
                        // Running again, so there is no stop to respect.
                        Database::setSetting('rt_manual_stop', '0');
                        Logger::info('Real-time monitor started via systemd');
                        return ['success' => true, 'method' => 'systemd'];
                    }
                    if ($detail['sub'] === 'auto-restart' || $detail['active'] === 'failed') {
                        break;   // crashing; waiting longer will not help
                    }
                }

                $log = $this->recentLog();
                Logger::error('Monitor did not stay running: '
                              . $detail['active'] . '/' . $detail['sub']);
                return [
                    'success' => false,
                    'error'   => 'The service started but did not stay running ('
                               . $detail['active'] . '/' . $detail['sub']
                               . ($detail['restarts'] > 0
                                  ? ', ' . $detail['restarts'] . ' restarts' : '')
                               . '). Last log lines: ' . ($log !== '' ? $log : 'none'),
                    'detail'  => $detail,
                ];
            }

            return ['success' => false,
                    'error'   => 'systemctl start failed: ' . trim(implode(' ', $out))];
        }

        // Fallback: direct background launch
        $logFile = escapeshellarg($this->logFile);
        $script  = escapeshellarg($this->daemonScript);
        $cmd = "SG_ROOT=" . escapeshellarg(SG_ROOT) .
               " /usr/bin/python3 $script >> $logFile 2>&1 &";
        exec($cmd, $out, $code);

        usleep(500000); // 0.5s — let it start
        $started = $this->isRunning();

        if ($started) {
            Database::setSetting('rt_monitor_status', 'running');
            Logger::info("Real-time monitor started (direct)");
        }

        return [
            'success' => $started,
            'method'  => 'direct',
            'error'   => $started ? null : 'Daemon failed to start — check ' . $this->logFile,
        ];
    }

    /**
     * Record why the monitor is being stopped.
     *
     * A stop with no backup running is a decision, and auto-resume must not
     * overrule it. A stop during a backup window is housekeeping, and is
     * exactly what auto-resume exists to undo.
     */
    private function recordStopIntent(): void
    {
        $backups = self::backupProcesses();
        Database::setSetting('rt_manual_stop', $backups ? '0' : '1');
        if ($backups) {
            Database::setSetting('rt_backup_seen_at', (string) time());
        }
    }

    public function stop(): array {
        $this->recordStopIntent();

        // Prefer systemd whenever the unit file is present (installed),
        // regardless of whether auto-start is enabled.
        if (file_exists($this->serviceFile)) {
            exec('systemctl stop serverscrub-monitor 2>&1', $out, $code);

            // A unit that died stays in 'failed' after a stop -- `systemctl
            // stop` succeeds and leaves the state exactly where it was. The
            // dashboard then shows "failed" indefinitely with no way to clear
            // it, and once the start-rate limit is hit systemd refuses to start
            // the unit again until it is reset. Clearing it here is what makes
            // the Stop button leave the service in a state Start can act on.
            $detail = $this->serviceDetail();
            if (($detail['active'] ?? '') === 'failed' || ($detail['sub'] ?? '') === 'failed') {
                exec('systemctl reset-failed serverscrub-monitor 2>&1');
                Logger::info('Cleared failed state on serverscrub-monitor');
            }

            Database::setSetting('rt_monitor_status', 'stopped');
            Logger::info("Real-time monitor stopped via systemd");
            return ['success' => $code === 0, 'output' => implode("\n", $out)];
        }

        // Kill by PID
        if (!file_exists($this->pidFile)) {
            return ['success' => true, 'message' => 'Not running'];
        }
        $pid = (int) trim(file_get_contents($this->pidFile));
        if ($pid > 0) {
            // The process group, not just the process. The daemon itself spawns
            // nothing today, but a signal that reaches only the parent is the
            // same shape of bug as a stopped scan leaving clamscan running, and
            // costs nothing to avoid here.
            $pgid = function_exists('posix_getpgid') ? @posix_getpgid($pid) : false;
            if ($pgid && $pgid > 1) {
                function_exists('posix_kill')
                    ? @posix_kill(-$pgid, 15)
                    : exec('kill -TERM -- -' . $pgid . ' 2>/dev/null');
            } else {
                exec("kill -TERM $pid 2>&1", $out, $code);
            }
            sleep(1);
            if ($this->isRunning()) {
                if ($pgid && $pgid > 1) {
                    function_exists('posix_kill')
                        ? @posix_kill(-$pgid, 9)
                        : exec('kill -KILL -- -' . $pgid . ' 2>/dev/null');
                } else {
                    exec("kill -KILL $pid 2>&1");
                }
            }
        }
        @unlink($this->pidFile);
        Database::setSetting('rt_monitor_status', 'stopped');
        Logger::info("Real-time monitor stopped");
        return ['success' => true];
    }

    public function restart(): array {
        $this->stop();
        sleep(1);
        return $this->start();
    }

    // ── Watch Paths ───────────────────────────────────────────────────────────

    public function addWatchPath(string $path): array {
        if (!is_dir($path)) {
            return ['success' => false, 'error' => "Path does not exist: $path"];
        }
        $current = Database::setting('scan_paths', '/home');
        $paths   = array_map('trim', explode(',', $current));
        if (in_array($path, $paths)) {
            return ['success' => true, 'message' => 'Path already watched'];
        }
        $paths[] = $path;
        Database::setSetting('scan_paths', implode(',', $paths));

        // Restart daemon to pick up new path
        if ($this->isRunning()) $this->restart();

        return ['success' => true, 'paths' => $paths];
    }

    public function removeWatchPath(string $path): array {
        $current = Database::setting('scan_paths', '/home');
        $paths   = array_filter(
            array_map('trim', explode(',', $current)),
            fn($p) => $p !== $path
        );
        Database::setSetting('scan_paths', implode(',', $paths));
        if ($this->isRunning()) $this->restart();
        return ['success' => true, 'paths' => array_values($paths)];
    }

    // ── Systemd ───────────────────────────────────────────────────────────────

    public function installService(): array {
        $service = $this->buildServiceUnit();
        if (!file_put_contents($this->serviceFile, $service)) {
            return ['success' => false, 'error' => 'Cannot write service file — run as root'];
        }
        exec('systemctl daemon-reload 2>&1', $o1);
        exec('systemctl enable serverscrub-monitor 2>&1', $o2);
        Logger::info("systemd service installed and enabled");
        return ['success' => true, 'output' => implode("\n", array_merge($o1, $o2))];
    }

    private function buildServiceUnit(): string {
        $root    = SG_ROOT;
        $script  = $this->daemonScript;
        $logFile = $this->logFile;
        return <<<UNIT
[Unit]
Description=ServerScrub Real-Time File Monitor
After=network.target
Wants=network.target

[Service]
Type=simple
User=root
Environment="SG_ROOT={$root}"
ExecStart=/usr/bin/python3 {$script}
Restart=on-failure
RestartSec=10
StandardOutput=append:{$logFile}
StandardError=append:{$logFile}
KillSignal=SIGTERM
TimeoutStopSec=10

[Install]
WantedBy=multi-user.target
UNIT;
    }

    /**
     * Enabled means "starts at boot". It does NOT mean running — a unit can be
     * enabled and dead. getStatus() used to report this as `service_active`,
     * so the dashboard displayed "Active" for a monitor that was not running,
     * beside counters that stayed empty because nothing was watching anything.
     */
    public function isServiceEnabled(): bool {
        if (!file_exists($this->serviceFile)) { return false; }
        [$out, ] = $this->run('systemctl is-enabled serverscrub-monitor 2>/dev/null');
        return trim($out[0] ?? '') === 'enabled';
    }

    /**
     * Detailed systemd service status — installed, enabled, active-state,
     * uptime, PID, memory.  Works whether running or not.
     */
    public function getServiceStatus(): array {
        $installed = file_exists($this->serviceFile);
        $enabled   = $installed && $this->isServiceEnabled();

        if (!$installed) {
            return [
                'installed'    => false,
                'enabled'      => false,
                'active'       => false,
                'active_state' => 'not-installed',
                'sub_state'    => '',
                'since'        => null,
                'main_pid'     => null,
                'memory_mb'    => null,
                'description'  => 'Service unit not installed',
            ];
        }

        // `systemctl show` returns KEY=VALUE lines — fast, machine-readable
        exec('systemctl show serverscrub-monitor ' .
             '--no-pager 2>/dev/null', $out);
        $props = [];
        foreach ($out as $line) {
            [$k, $v] = array_pad(explode('=', $line, 2), 2, '');
            $props[$k] = $v;
        }

        $activeState = $props['ActiveState']  ?? 'unknown';
        $subState    = $props['SubState']     ?? '';
        $mainPid     = (int) ($props['MainPID']     ?? 0);
        $memBytes    = (int) ($props['MemoryCurrent'] ?? 0);

        // ActiveEnterTimestamp is microseconds since epoch
        $since = null;
        $ts = $props['ActiveEnterTimestamp'] ?? '';
        if ($ts && $ts !== '0') {
            $since = (int) (substr($ts, 0, -6) ?: '0'); // strip µs
        }

        return [
            'installed'    => true,
            'enabled'      => $enabled,
            'active'       => $activeState === 'active',
            'active_state' => $activeState,
            'sub_state'    => $subState,
            'since'        => $since ?: null,
            'main_pid'     => $mainPid ?: null,
            'memory_mb'    => $memBytes > 0 ? round($memBytes / 1048576, 1) : null,
            'description'  => $props['Description'] ?? 'ServerScrub Monitor',
            'unit_file'    => $this->serviceFile,
        ];
    }

    public function enableService(): array {
        if (!file_exists($this->serviceFile)) {
            return ['success' => false, 'error' => 'Service not installed — install it first'];
        }
        exec('systemctl enable serverscrub-monitor 2>&1', $out, $code);
        Logger::info("Monitor service enabled");
        return ['success' => $code === 0, 'output' => implode("\n", $out)];
    }

    public function disableService(): array {
        exec('systemctl disable serverscrub-monitor 2>&1', $out, $code);
        Logger::info("Monitor service disabled");
        return ['success' => $code === 0, 'output' => implode("\n", $out)];
    }

    /**
     * Pull recent journal entries for the unit.
     * Returns plain-text lines newest-first.
     */
    public function getServiceLogs(int $lines = 50): array {
        exec(
            "journalctl -u serverscrub-monitor -n {$lines} " .
            "--no-pager --output=short-iso 2>/dev/null",
            $out, $code
        );
        if ($code !== 0 || empty($out)) {
            // Journald may not be available — fall back to daemon log tail
            return $this->getRecentLogs($lines);
        }
        return array_reverse($out); // newest first
    }

    // ── Recent Detections ─────────────────────────────────────────────────────

    public function getRecentDetections(int $limit = 50): array {
        return Database::fetchAll(
            "SELECT * FROM threats WHERE threat_type='realtime_detection' ORDER BY detected_at DESC LIMIT ?",
            [$limit]
        );
    }

    public function getRecentLogs(int $lines = 100): array {
        if (!file_exists($this->logFile)) return [];
        $all = file($this->logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        return array_slice(array_reverse($all), 0, $lines);
    }

    // ── Engine detection ──────────────────────────────────────────────────────

    private function detectEngine(): string {
        [$out, $code] = $this->run('/usr/bin/python3 -c "import inotify_simple; print(\'inotify\')" 2>/dev/null');
        return ($code === 0 && trim($out[0] ?? '') === 'inotify') ? 'inotify' : 'polling';
    }

    // ── Stats summary for dashboard ───────────────────────────────────────────

    public function getDashboardStats(): array {
        $status = $this->getStatus();
        return [
            'enabled'        => $status['running'],
            'running'        => $status['running'],
            'stale'          => $status['stale'],
            'engine'         => $status['engine'],
            'watch_paths'    => $status['watch_paths'],
            'files_checked'  => $status['files_checked'],
            'detections_24h' => $status['detections_24h'],
            'detections_all' => $status['detections_all'],
            'last_activity'  => $status['last_activity'],
        ];
    }
}
