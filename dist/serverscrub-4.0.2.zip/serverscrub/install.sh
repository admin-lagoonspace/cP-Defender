#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
# ServerScrub — Installer
# Version is read dynamically from the VERSION file in this directory.
# Supports: cPanel/WHM  |  Standalone Linux (any distro)
# Usage:    bash install.sh
# ═══════════════════════════════════════════════════════════════════════════════

set -o pipefail
PLUGIN_NAME="serverscrub"
INSTALL_DIR="/usr/local/serverscrub"
CRON_FILE="/etc/cron.d/serverscrub"
# Defined here, not down beside the block that populates it: that block sits
# inside the INSTALL-ONLY span, which --register-only skips entirely, while the
# cPanel registration section below it appends to MANIFEST in either mode.
MANIFEST="${INSTALL_DIR}/install-manifest.env"
LOG_DIR="${INSTALL_DIR}/logs"
SG_PORT=31150

# ── Arguments ───────────────────────────────────────────────────────────────────
# --register-only : re-run ONLY the WHM/cPanel (or standalone service) registration
#                   against an already-installed copy. Used by update.sh after it
#                   overlays new code, so plugin-registration fixes reach upgrades.
# --mode MODE     : force install mode (cpanel|standalone), skips the prompt.
# --admin-user U  : standalone admin username (default: admin)
# --admin-pass P  : standalone admin password. Supply this for unattended
#                   standalone installs, otherwise one is generated and printed.
#                   Prefer the SG_ADMIN_PASS env var — flags are visible in `ps`.
REGISTER_ONLY=false
INSTALL_MODE=""
SKIP_DEPS=false
# rkhunter and chkrootkit come from EPEL on RHEL-family hosts, and some
# operators will not have EPEL on a cPanel box at any price. The built-in
# engine covers the same ground without them, so declining is supported.
SKIP_ROOTKIT_TOOLS=false
ADMIN_USER=""
ADMIN_PASS=""
GENERATED_PASS=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --register-only) REGISTER_ONLY=true ;;
    --no-deps)       SKIP_DEPS=true ;;
    --no-rootkit-tools) SKIP_ROOTKIT_TOOLS=true ;;
    --mode)          shift; INSTALL_MODE="${1:-}" ;;
    --mode=*)        INSTALL_MODE="${1#--mode=}" ;;
    --admin-user)    shift; ADMIN_USER="${1:-}" ;;
    --admin-user=*)  ADMIN_USER="${1#--admin-user=}" ;;
    --admin-pass)    shift; ADMIN_PASS="${1:-}" ;;
    --admin-pass=*)  ADMIN_PASS="${1#--admin-pass=}" ;;
    *) ;;
  esac
  shift
done

# Auto-detect mode from a prior install so re-runs/upgrades never need the prompt
_MODE_PHP="${INSTALL_DIR}/backend/config/mode.php"
if [[ -z "$INSTALL_MODE" && -f "$_MODE_PHP" ]]; then
  if grep -q "INSTALL_MODE', 'standalone'" "$_MODE_PHP" 2>/dev/null; then
    INSTALL_MODE="standalone"
  elif grep -q "INSTALL_MODE', 'cpanel'" "$_MODE_PHP" 2>/dev/null; then
    INSTALL_MODE="cpanel"
  fi
fi

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC}  $*"; }
ok()      { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }
section() { echo -e "\n${CYAN}${BOLD}── $* ──${NC}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Read version from VERSION file ─────────────────────────────────────────────
VERSION_FILE="${SCRIPT_DIR}/VERSION"
if [[ -f "$VERSION_FILE" ]]; then
  SG_VERSION="$(tr -d '[:space:]' < "$VERSION_FILE")"
else
  SG_VERSION="unknown"
fi

# ── Banner ─────────────────────────────────────────────────────────────────────
clear
echo ""
echo -e "${BOLD}${CYAN}"
echo "  ███████╗███████╗██████╗ ██╗   ██╗███████╗██████╗ "
echo "  ██╔════╝██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗"
echo "  ███████╗█████╗  ██████╔╝██║   ██║█████╗  ██████╔╝"
echo "  ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██╔══╝  ██╔══██╗"
echo "  ███████║███████╗██║  ██║ ╚████╔╝ ███████╗██║  ██║"
echo "  ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝"
echo -e "${NC}${BOLD}${GREEN}"
echo "      ███████╗ ██████╗ ██████╗ ██╗   ██╗██████╗ "
echo "      ██╔════╝██╔════╝ ██╔══██╗██║   ██║██╔══██╗"
echo "      ███████╗██║      ██████╔╝██║   ██║██████╔╝"
echo "      ╚════██║██║      ██╔══██╗██║   ██║██╔══██╗"
echo "      ███████║╚██████╗ ██║  ██║╚██████╔╝██████╔╝"
echo "      ╚══════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ "
echo -e "${NC}"
echo -e "  ${BOLD}SERVERSCRUB v${SG_VERSION}${NC} — Security Suite"
echo ""

# ── Pre-flight checks ──────────────────────────────────────────────────────────
# ── Migrating a Sentinel Gate install ─────────────────────────────────────────
# The product was called Sentinel Gate and lived in /usr/local/sentinel-gate.
# An existing server has its database, its quarantine and its settings there,
# so this is a MOVE, not a fresh install beside the old one. Getting it wrong
# would either lose a customer's quarantined files or leave two copies of the
# product fighting over the same cron entries and systemd units.
#
# Everything here uses the old names literally. They are deliberately not
# swept by the rebrand: this is the one place that still has to know them.
MIGRATED_FROM=""
OLD_DIR="/usr/local/sentinel-gate"
if [[ -d "${OLD_DIR}" && "${OLD_DIR}" != "${INSTALL_DIR}" ]]; then
  section "Migrating from Sentinel Gate"

  # 1. Stop the old services FIRST. Moving a directory out from under a running
  #    daemon leaves it writing into a path that no longer exists.
  for _svc in sentinel-gate-monitor sentinel-gate-web sentinel-gate-firewall; do
    if systemctl list-unit-files 2>/dev/null | grep -q "^${_svc}.service"; then
      systemctl stop "${_svc}" 2>/dev/null || true
      systemctl disable "${_svc}" 2>/dev/null || true
      systemctl reset-failed "${_svc}" 2>/dev/null || true
      rm -f "/etc/systemd/system/${_svc}.service"
      info "  Removed old service: ${_svc}"
    fi
  done
  systemctl daemon-reload 2>/dev/null || true

  # 2. Scan workers are detached and outlive their service. One left running
  #    would keep writing to the old path and spawning clamscan.
  pkill -f "${OLD_DIR}/backend/cron/scan.php" 2>/dev/null || true
  pkill -f "${OLD_DIR}/backend/daemon/monitor.py" 2>/dev/null || true

  # 3. Old cron entries, before new ones are written, so the two never overlap.
  rm -f /etc/cron.d/sentinel-gate /etc/cron.d/sentinel_gate 2>/dev/null || true

  # 4. Deregister the old WHM plugin. Left in place it stays in the WHM menu
  #    pointing at a directory that is about to stop existing.
  if [[ -x /usr/local/cpanel/bin/unregister_appconfig ]]; then
    /usr/local/cpanel/bin/unregister_appconfig sentinel_gate >/dev/null 2>&1 || true
    /usr/local/cpanel/bin/unregister_appconfig sentinelgate  >/dev/null 2>&1 || true
  fi
  rm -f /var/cpanel/apps/sentinel_gate.conf /var/cpanel/apps/sentinelgate.conf 2>/dev/null || true
  rm -rf /usr/local/cpanel/whostmgr/docroot/cgi/sentinel_gate \
         /usr/local/cpanel/whostmgr/docroot/cgi/sentinelgate 2>/dev/null || true

  # 5. The old cPanel user plugin, in both themes.
  for _th in paper_lantern jupiter; do
    rm -rf "/usr/local/cpanel/base/frontend/${_th}/sentinel_gate" 2>/dev/null || true
    rm -f  "/usr/local/cpanel/base/frontend/${_th}/dynamicui/dynamicui_sentinel_gate.conf" 2>/dev/null || true
  done

  # 6. The old WHM Driver module. Left behind, cPanel keeps loading a Perl
  #    package for a plugin that no longer exists.
  rm -f  /usr/local/cpanel/Cpanel/Config/ConfigObj/Driver/SentinelGate.pm 2>/dev/null || true
  rm -rf /usr/local/cpanel/Cpanel/Config/ConfigObj/Driver/SentinelGate 2>/dev/null || true

  # 7. The old CLI.
  rm -f /usr/bin/sentinel 2>/dev/null || true

  # 8. Move the data across. A move keeps the database, the quarantined files
  #    and the logs exactly as they are; copying and deleting would risk
  #    half-copying several hundred quarantined files.
  if [[ -e "${INSTALL_DIR}" ]]; then
    # Both present: an interrupted migration, or someone installed fresh after
    # the rename. Keep whatever is already under the new name and put the old
    # one aside rather than overwriting either.
    _BAK="${OLD_DIR}.pre-serverscrub.$(date +%s)"
    mv "${OLD_DIR}" "${_BAK}"
    warn "  ${INSTALL_DIR} already existed; old install kept at ${_BAK}"
  else
    mv "${OLD_DIR}" "${INSTALL_DIR}"
    ok "  Moved ${OLD_DIR} -> ${INSTALL_DIR} (database and quarantine preserved)"

    # The database file is named after the product too.
    if [[ -f "${INSTALL_DIR}/database/sentinel.db" && ! -f "${INSTALL_DIR}/database/serverscrub.db" ]]; then
      mv "${INSTALL_DIR}/database/sentinel.db" "${INSTALL_DIR}/database/serverscrub.db"
      # SQLite keeps its write-ahead log and shared-memory file beside the
      # database; leaving them behind under the old name can strand a
      # transaction that has not been checkpointed.
      for _x in wal shm journal; do
        [[ -f "${INSTALL_DIR}/database/sentinel.db-${_x}" ]] && \
          mv "${INSTALL_DIR}/database/sentinel.db-${_x}" \
             "${INSTALL_DIR}/database/serverscrub.db-${_x}"
      done
      ok "  Database renamed, contents untouched"
    fi
  fi

  # 9. The WAF include is named after the product and is referenced by Apache.
  #    Renaming it without putting the new name in place would drop every rule.
  for _d in /etc/apache2/conf.d /usr/local/apache/conf /etc/httpd/conf.d; do
    if [[ -f "${_d}/sentinel-waf.conf" ]]; then
      if [[ ! -f "${_d}/serverscrub-waf.conf" ]]; then
        mv "${_d}/sentinel-waf.conf" "${_d}/serverscrub-waf.conf"
        ok "  WAF config renamed in ${_d}"
      else
        rm -f "${_d}/sentinel-waf.conf"
      fi
    fi
  done

  rm -rf /tmp/sentinel-gate 2>/dev/null || true
  MIGRATED_FROM="${OLD_DIR}"
  ok "  Migration complete — continuing as ServerScrub"
fi

section "Pre-flight checks"
[[ $EUID -ne 0 ]] && error "Must be run as root"

# ── Dependency bootstrap (best-effort, non-fatal) ─────────────────────────────
# Install missing runtime dependencies via the host package manager so a bare
# server reaches full capability instead of silently degrading. Skipped on
# --register-only and --no-deps. PHP is NOT auto-installed on cPanel hosts —
# cPanel manages its own PHP and a distro php would conflict.
if ! $REGISTER_ONLY && ! $SKIP_DEPS; then
  section "Dependency bootstrap"
  _PM=""; _INSTALL=""
  if   command -v apt-get >/dev/null 2>&1; then _PM=apt; _INSTALL="apt-get install -y -q"
  elif command -v dnf     >/dev/null 2>&1; then _PM=dnf; _INSTALL="dnf install -y -q"
  elif command -v yum     >/dev/null 2>&1; then _PM=yum; _INSTALL="yum install -y -q"
  fi
  if [[ -z "$_PM" ]]; then
    warn "No supported package manager (apt/dnf/yum) — skipping dependency bootstrap"
  else
    info "Package manager: ${_PM}"
    declare -a _PKGS=()
    command -v sqlite3   >/dev/null 2>&1 || _PKGS+=( sqlite3 )
    command -v python3   >/dev/null 2>&1 || _PKGS+=( python3 )
    command -v ipset     >/dev/null 2>&1 || _PKGS+=( ipset )
    if [[ "$_PM" == "apt" ]]; then
      command -v inotifywait >/dev/null 2>&1 || _PKGS+=( inotify-tools )
      dpkg -s python3-pip   >/dev/null 2>&1 || _PKGS+=( python3-pip )
    else
      rpm -q python3-pip    >/dev/null 2>&1 || _PKGS+=( python3-pip )
    fi
    # ClamAV — only if no clamscan anywhere (incl. cPanel's 3rdparty path)
    if ! command -v clamscan >/dev/null 2>&1 && [[ ! -x /usr/local/cpanel/3rdparty/bin/clamscan ]]; then
      if [[ "$_PM" == "apt" ]]; then _PKGS+=( clamav clamav-freshclam ); else _PKGS+=( clamav clamav-update ); fi
    fi
    # PHP + sqlite PDO — ONLY on non-cPanel servers
    if [[ ! -d /usr/local/cpanel ]]; then
      command -v php >/dev/null 2>&1 || _PKGS+=( php-cli )
      if [[ "$_PM" == "apt" ]]; then _PKGS+=( php-sqlite3 ); else _PKGS+=( php-pdo ); fi
    fi
    if [[ ${#_PKGS[@]} -eq 0 ]]; then
      ok "All runtime dependencies already present"
    else
      info "Installing: ${_PKGS[*]}"
      [[ "$_PM" == "apt" ]] && { apt-get update -q >/dev/null 2>&1 || true; }
      if $_INSTALL "${_PKGS[@]}" >/dev/null 2>&1; then
        ok "Dependencies installed: ${_PKGS[*]}"
      else
        warn "Some packages failed to install (${_PKGS[*]}) — continuing; features may degrade"
      fi
    fi
  fi
fi

command -v php >/dev/null 2>&1 || error "PHP not found. Install php-cli first."

# ── Resolve a real CLI PHP, once ──────────────────────────────────────────────
# `php` and `/usr/bin/php` are not interchangeable on a cPanel box, and neither
# is guaranteed to be the CLI binary:
#
#   * /usr/bin/php is frequently a symlink to php-cgi, which REFUSES -r --
#     "Error in argument 1, char 2: option not found r" -- and, when it does run
#     a script, prints CGI headers into whatever captured its output. The
#     firewall engine was initialised this way and reported its backend as a
#     php-cgi usage dump.
#   * `php` on PATH is often cPanel's Perl wrapper (/var/cpanel/ea4/ea_php_cli.pm),
#     which dies on any argument containing a newline.
#
# So candidates are not trusted by name: each is asked what SAPI it is, and the
# first that answers "cli" is used for everything from here on.
SG_PHP=""
for _c in "$(command -v php 2>/dev/null)"           /usr/local/cpanel/3rdparty/bin/php           /opt/cpanel/ea-php83/root/usr/bin/php           /opt/cpanel/ea-php82/root/usr/bin/php           /opt/cpanel/ea-php81/root/usr/bin/php           /usr/local/bin/php /usr/bin/php; do
  [[ -z "$_c" || ! -x "$_c" ]] && continue
  if [[ "$("$_c" -r 'echo PHP_SAPI;' 2>/dev/null)" == "cli" ]]; then
    SG_PHP="$_c"; break
  fi
done
[[ -z "$SG_PHP" ]] && error "No CLI PHP found. Install php-cli (php-cgi alone cannot run this installer)."

PHP_VER=$("$SG_PHP" -r 'echo PHP_MAJOR_VERSION;')
[[ $PHP_VER -lt 7 ]] && error "PHP 7.4+ required (found PHP $PHP_VER)"
ok "PHP $PHP_VER found: ${SG_PHP}"

# ── Pre-install cleanup ─────────────────────────────────────────────────────────
# Makes reinstalls clean: stops running services, refreshes code dirs so files
# deleted in newer versions don't linger, and sweeps legacy artifacts from old
# layouts. Data (database, logs, quarantine) is preserved on reinstall —
# uninstall.sh is the only thing that deletes data.
section "Pre-install cleanup"
if $REGISTER_ONLY; then
  info "Register-only mode — skipping cleanup, dirs, files, DB, services"
fi
if ! $REGISTER_ONLY && command -v systemctl >/dev/null 2>&1; then
  for _SVC in serverscrub-web serverscrub-monitor; do
    if systemctl is-active --quiet "${_SVC}" 2>/dev/null; then
      systemctl stop "${_SVC}" 2>/dev/null || true
      info "Stopped running service: ${_SVC}"
    fi
  done
fi
if ! $REGISTER_ONLY && [[ -d "${INSTALL_DIR}" ]]; then
  info "Existing installation detected — refreshing code, keeping data"
  for _OLD in "${INSTALL_DIR}/backend" "${INSTALL_DIR}/frontend"; do
    [[ -d "${_OLD}" ]] && rm -rf "${_OLD}" && info "Removed stale code dir: ${_OLD}"
  done
fi
# Legacy artifacts from pre-3.2 layouts — harmless to sweep when absent
for _LEGACY in \
  /usr/local/cpanel/whostmgr/docroot/cgi/addon_serverscrub.cgi \
  /usr/local/cpanel/whostmgr/docroot/cgi/addon_serverscrub.cgi \
  /usr/local/cpanel/whostmgr/docroot/cgi/serverscrub \
  /usr/local/cpanel/whostmgr/docroot/cgi/addon_plugins/serverscrub.conf \
  /usr/local/cpanel/whostmgr/docroot/cgi/addon_plugins/serverscrub.conf \
  /var/cpanel/apps/serverscrub.conf; do
  [[ -e "${_LEGACY}" ]] && rm -rf "${_LEGACY}" && info "Removed legacy artifact: ${_LEGACY}"
done
ok "Pre-install cleanup complete"

# ── Mode selection ─────────────────────────────────────────────────────────────
section "Installation Mode"
if [[ -n "$INSTALL_MODE" ]]; then
  # Mode already known (--mode flag, --register-only, or detected from mode.php)
  info "Mode: ${BOLD}${INSTALL_MODE}${NC} (auto-detected)"
elif [[ ! -t 0 ]]; then
  # Non-interactive (piped) install with no prior mode. PROBE for cPanel rather
  # than assuming it — blindly defaulting to cpanel on a plain Linux box runs the
  # whole WHM registration path against nothing and leaves no working dashboard.
  if [[ -d /usr/local/cpanel ]]; then
    INSTALL_MODE="cpanel"
    info "Non-interactive — detected /usr/local/cpanel, mode: ${BOLD}cpanel${NC}"
  else
    INSTALL_MODE="standalone"
    info "Non-interactive — no cPanel found, mode: ${BOLD}standalone${NC}"
  fi
else
  echo ""
  echo -e "  ${BOLD}Select where you are installing ServerScrub:${NC}"
  echo ""
  echo -e "  ${CYAN}1)${NC} ${BOLD}cPanel / WHM Server${NC}"
  echo "     Integrates into WHM as a plugin. Uses cPanel authentication."
  echo "     Accessed via: WHM → Plugins → ServerScrub"
  echo ""
  echo -e "  ${CYAN}2)${NC} ${BOLD}Standalone Linux Server${NC} (no cPanel)"
  echo "     Self-contained browser dashboard on port ${SG_PORT}."
  echo "     Works on any Linux distro. No cPanel required."
  echo "     Accessed via: http://YOUR_SERVER_IP:${SG_PORT}"
  echo ""
  read -rp "  Enter choice [1/2]: " MODE_CHOICE
  case "$MODE_CHOICE" in
    2) INSTALL_MODE="standalone" ;;
    *) INSTALL_MODE="cpanel" ;;
  esac
  echo ""
  info "Mode: ${BOLD}${INSTALL_MODE}${NC}"
fi

# ── Migrate an older mode.php ─────────────────────────────────────────────────
# Installs made before 3.21.2 recorded SG_VERSION here. Because config.php loads
# this file and updates never rewrite it, that frozen value was reported as the
# running version -- an install first set up on 3.18.2 still called itself
# 3.18.2 after every update, and the update checker compared against it.
#
# Only the SG_VERSION line is removed. Everything else, above all
# SG_LICENSE_SECRET, is left exactly as the operator set it.
_MODE_PHP_EXISTING="${INSTALL_DIR}/backend/config/mode.php"
if [[ -f "$_MODE_PHP_EXISTING" ]] && grep -q "SG_VERSION" "$_MODE_PHP_EXISTING"; then
  cp -a "$_MODE_PHP_EXISTING" "${_MODE_PHP_EXISTING}.bak" 2>/dev/null || true
  sed -i "/define('SG_VERSION'/d" "$_MODE_PHP_EXISTING"
  ok "Removed the frozen SG_VERSION from mode.php (backup: mode.php.bak)"
fi

# ── Move quarantine off the root partition ────────────────────────────────────
# Quarantine MOVES infected files into its directory. That directory used to
# default to ${INSTALL_DIR}/quarantine, which is on / -- so on a hosting server,
# where customer data lives on a separate and far larger volume, a busy scan
# filled the root filesystem and took the machine down. It did, on a live server.
#
# Runs on --register-only too, because the installs that need moving are the
# ones being updated. Files are MOVED, never deleted: they are evidence, and
# some of them may be a customer's only copy of something.
_SG_QUAR_OLD="${INSTALL_DIR}/quarantine"
_SG_QUAR_NEW=""
for _v in /home /var; do
  if [[ -d "$_v" && -w "$_v" ]]; then _SG_QUAR_NEW="${_v}/.serverscrub/quarantine"; break; fi
done

if [[ -n "$_SG_QUAR_NEW" ]]; then
  mkdir -p "$_SG_QUAR_NEW" 2>/dev/null || true
  chmod 700 "$(dirname "$_SG_QUAR_NEW")" 2>/dev/null || true
  chmod 700 "$_SG_QUAR_NEW" 2>/dev/null || true

  # Same filesystem? Then there is nothing to gain by moving.
  _SG_OLD_DEV=$(stat -c %d "$_SG_QUAR_OLD" 2>/dev/null || echo "x")
  _SG_NEW_DEV=$(stat -c %d "$_SG_QUAR_NEW" 2>/dev/null || echo "y")

  if [[ -d "$_SG_QUAR_OLD" && "$_SG_OLD_DEV" != "$_SG_NEW_DEV" ]]; then
    _SG_QUAR_SIZE=$(du -sh "$_SG_QUAR_OLD" 2>/dev/null | cut -f1)
    if [[ -n "$(ls -A "$_SG_QUAR_OLD" 2>/dev/null)" ]]; then
      info "Moving quarantine (${_SG_QUAR_SIZE:-unknown}) off the root partition…"
      if command -v rsync >/dev/null 2>&1; then
        rsync -a --remove-source-files "$_SG_QUAR_OLD/" "$_SG_QUAR_NEW/" 2>/dev/null \
          && find "$_SG_QUAR_OLD" -type d -empty -delete 2>/dev/null \
          && ok "  Quarantine moved to ${_SG_QUAR_NEW}" \
          || warn "  Could not move every quarantined file; nothing was deleted"
      else
        cp -a "$_SG_QUAR_OLD/." "$_SG_QUAR_NEW/" 2>/dev/null \
          && rm -rf "${_SG_QUAR_OLD:?}"/* 2>/dev/null \
          && ok "  Quarantine moved to ${_SG_QUAR_NEW}" \
          || warn "  Could not move every quarantined file; nothing was deleted"
      fi
    fi
  fi

  # Record the location so the app writes there from now on.
  if [[ -f "${INSTALL_DIR}/database/serverscrub.db" ]] && command -v sqlite3 >/dev/null 2>&1; then
    sqlite3 "${INSTALL_DIR}/database/serverscrub.db" \
      "INSERT INTO settings(key,value,updated_at) VALUES('quarantine_dir','${_SG_QUAR_NEW}',strftime('%s','now')) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at;" \
      2>/dev/null && ok "  Quarantine directory set to ${_SG_QUAR_NEW}"
  fi
fi

# Per-scan logs accumulate one file per scan and were never pruned. On a server
# scanning nightly that is unbounded growth on the root partition too.
find "${LOG_DIR:-${INSTALL_DIR}/logs}" -name 'scan_*.log' -mtime +7 -delete 2>/dev/null || true

# ═══ INSTALL-ONLY SECTIONS (skipped in --register-only mode) ═══════════════════
if ! $REGISTER_ONLY; then

# ── Standalone: collect admin credentials ──────────────────────────────────────
if [[ "$INSTALL_MODE" == "standalone" ]]; then
  section "Admin Account Setup"

  # Credentials may arrive as flags/env (piped installs) — otherwise prompt.
  ADMIN_USER="${ADMIN_USER:-${SG_ADMIN_USER:-}}"
  ADMIN_PASS="${ADMIN_PASS:-${SG_ADMIN_PASS:-}}"

  if [[ -n "$ADMIN_PASS" ]]; then
    ADMIN_USER="${ADMIN_USER:-admin}"
    [[ ${#ADMIN_PASS} -ge 8 ]] || error "Admin password must be at least 8 characters."
    ok "Admin account: ${ADMIN_USER} (supplied via flag/env)"

  elif [[ ! -t 0 ]]; then
    # Non-interactive with no password supplied. NEVER prompt here — `read` would
    # hit EOF on the pipe, leave ADMIN_PASS empty, and spin the length-check loop
    # forever. Generate a strong one and surface it at the end of the install.
    ADMIN_USER="${ADMIN_USER:-admin}"
    if command -v openssl >/dev/null 2>&1; then
      ADMIN_PASS="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-20)"
    else
      ADMIN_PASS="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 20)"
    fi
    GENERATED_PASS=true
    warn "Non-interactive install — generated a random admin password."
    warn "It is printed at the end of this install. Save it, then change it."

  else
    echo "  Create the local admin account for the web dashboard."
    echo ""
    read -rp "  Admin username [admin]: " _IN_USER
    ADMIN_USER="${_IN_USER:-admin}"

    while true; do
      read -srp "  Admin password (min 8 chars): " ADMIN_PASS; echo
      [[ ${#ADMIN_PASS} -ge 8 ]] && break
      echo -e "  ${RED}Password too short — minimum 8 characters.${NC}"
    done

    read -srp "  Confirm password: " ADMIN_PASS2; echo
    [[ "$ADMIN_PASS" != "$ADMIN_PASS2" ]] && error "Passwords do not match"
    ok "Admin account: ${ADMIN_USER}"
  fi
fi

# ── Create directories ─────────────────────────────────────────────────────────
section "Creating directories"
mkdir -p "$INSTALL_DIR"/{database,logs,quarantine,tmp}
chmod 750 "$INSTALL_DIR"/{database,quarantine,logs}
ok "Directories created under $INSTALL_DIR"

# ── Copy plugin files ──────────────────────────────────────────────────────────
section "Installing files"
cp -r "${SCRIPT_DIR}/backend"  "$INSTALL_DIR/"
cp -r "${SCRIPT_DIR}/frontend" "$INSTALL_DIR/"
cp    "${SCRIPT_DIR}/VERSION"  "$INSTALL_DIR/"
[[ -f "${SCRIPT_DIR}/install.sh"   ]] && cp "${SCRIPT_DIR}/install.sh"   "$INSTALL_DIR/"
[[ -f "${SCRIPT_DIR}/update.sh"   ]] && cp "${SCRIPT_DIR}/update.sh"   "$INSTALL_DIR/"
[[ -f "${SCRIPT_DIR}/uninstall.sh" ]] && cp "${SCRIPT_DIR}/uninstall.sh" "$INSTALL_DIR/"
# The WHM appconfig is generated below, not copied from the tree.
# Keep SG_VERSION constant in config.php in sync with VERSION file
sed -i "s/define('SG_VERSION',  '[0-9.]*')/define('SG_VERSION',  '${SG_VERSION}')/" "${INSTALL_DIR}/backend/config/config.php" 2>/dev/null || true
ok "Files installed to $INSTALL_DIR"

# ── Set permissions ────────────────────────────────────────────────────────────
chown -R root:nobody "$INSTALL_DIR" 2>/dev/null || chown -R root:root "$INSTALL_DIR"
chmod -R 750 "$INSTALL_DIR"
chmod -R 700 "$INSTALL_DIR/database"
chmod -R 700 "$INSTALL_DIR/quarantine"
chmod -R 700 "$INSTALL_DIR/logs"
chmod +x "$INSTALL_DIR/backend/cron/scan.php"
chmod +x "$INSTALL_DIR/backend/cron/scheduler.php" 2>/dev/null || true
chmod +x "$INSTALL_DIR/backend/daemon/monitor.py"
[[ -f "$INSTALL_DIR/backend/cli/serverscrub.php" ]] && chmod +x "$INSTALL_DIR/backend/cli/serverscrub.php"
ok "Permissions set"

# ── Write mode.php ─────────────────────────────────────────────────────────────
cat > "${INSTALL_DIR}/backend/config/mode.php" << MODEPHP
<?php
// Written by install.sh — do not edit manually
//
// config.php defines SG_ROOT and SG_VERSION and THEN includes this file, so
// redefining them unconditionally emitted a "Constant already defined" warning
// on every single request. Guarded, so this file can be included either before
// config.php (as the CLI entry points do) or after it.
if (!defined('INSTALL_MODE')) { define('INSTALL_MODE', '${INSTALL_MODE}'); }
if (!defined('SG_ROOT'))      { define('SG_ROOT',      '${INSTALL_DIR}'); }
// SG_VERSION is deliberately NOT written here. It describes the code, not this
// installation, and this file is not rewritten by updates -- so a version
// recorded here would freeze at whatever was installed first and be reported
// for ever afterwards. config.php owns it.
// Licensing. SG_LICENSE_SECRET must match the salt configured in the WHMCS
// licensing addon — it is what makes a cached local key unforgeable. Supply it
// at install time with SG_LICENSE_SECRET=... ; the placeholder is deliberately
// obvious so a misconfiguration is visible rather than silently insecure.
define('SG_WHMCS_URL',     '${SG_WHMCS_URL:-https://clientarea.lagoonspace.net}');
define('SG_LICENSE_SECRET','${SG_LICENSE_SECRET:-CHANGEME_SET_IN_mode_php}');
MODEPHP
ok "Install mode recorded"

# Stamp the install time so the trial starts at install rather than at first
# login — otherwise a server set up and left alone would still show 3 full days
# whenever someone eventually opened the dashboard.
mkdir -p /var/lib/serverscrub 2>/dev/null || true
[[ -f /var/lib/serverscrub/installed-at ]] || date +%s > /var/lib/serverscrub/installed-at

# ── Initialize database ────────────────────────────────────────────────────────
section "Initialising database"
"$SG_PHP" -r "define('SG_ROOT', '$INSTALL_DIR'); define('SG_DB', '$INSTALL_DIR/database/serverscrub.db'); define('SG_LOGS', '$INSTALL_DIR/logs'); define('SG_TMP', '/tmp/serverscrub'); define('CPANEL_BASE', '/usr/local/cpanel'); define('CPANEL_USER', 'root'); define('SCAN_MAX_SIZE', 52428800); define('SIG_DIR', '$INSTALL_DIR/backend/signatures'); define('QUARANTINE_DIR', '$INSTALL_DIR/quarantine'); define('RBL_FEEDS', serialize([])); define('JWT_SECRET', hash('sha256', gethostname() . 'serverscrub_secret_2024')); define('JWT_EXPIRY', 28800); define('INSTALL_MODE', '${INSTALL_MODE}'); define('SG_PORT', ${SG_PORT}); require_once '$INSTALL_DIR/backend/lib/Database.php'; \$db = Database::get(); Database::setSetting('install_mode', '${INSTALL_MODE}'); echo 'Database initialised' . PHP_EOL;"
ok "SQLite database ready"

# ── Set standalone admin credentials ──────────────────────────────────────────
if [[ "$INSTALL_MODE" == "standalone" ]]; then
  PASS_HASH=$("$SG_PHP" -r "echo password_hash('${ADMIN_PASS}', PASSWORD_BCRYPT, ['cost'=>12]);")
  "$SG_PHP" -r "define('SG_ROOT', '$INSTALL_DIR'); define('SG_DB', '$INSTALL_DIR/database/serverscrub.db'); define('SG_LOGS', '$INSTALL_DIR/logs'); define('SG_TMP', '/tmp/serverscrub'); define('CPANEL_BASE', '/usr/local/cpanel'); define('CPANEL_USER', 'root'); define('SCAN_MAX_SIZE', 52428800); define('SIG_DIR', '$INSTALL_DIR/backend/signatures'); define('QUARANTINE_DIR', '$INSTALL_DIR/quarantine'); define('RBL_FEEDS', serialize([])); define('JWT_SECRET', hash('sha256', gethostname() . 'serverscrub_secret_2024')); define('JWT_EXPIRY', 28800); define('INSTALL_MODE', 'standalone'); define('SG_PORT', ${SG_PORT}); require_once '$INSTALL_DIR/backend/lib/Database.php'; require_once '$INSTALL_DIR/backend/lib/Auth.php'; Auth::setLocalCredentials('${ADMIN_USER}', '${ADMIN_PASS}'); echo 'Admin credentials stored' . PHP_EOL;"
  ok "Admin credentials stored (bcrypt)"
fi

# ── ClamAV detection and setup ────────────────────────────────────────────────
section "ClamAV setup"
# cPanel servers often install ClamAV outside the default PATH.
# Check all common locations before giving up.
CLAMSCAN_BIN=""
FRESHCLAM_BIN=""
for _BIN in \
  clamscan \
  /usr/bin/clamscan \
  /usr/local/bin/clamscan \
  /usr/local/cpanel/3rdparty/bin/clamscan \
  /opt/cpanel/ea-php*/root/usr/bin/clamscan \
  /opt/clamav/bin/clamscan; do
  # Expand globs, skip if not executable
  for _EXPANDED in $_BIN; do
    if [[ -x "${_EXPANDED}" ]] || command -v "${_EXPANDED}" >/dev/null 2>&1; then
      CLAMSCAN_BIN="${_EXPANDED}"; break 2
    fi
  done
done

for _BIN in \
  freshclam \
  /usr/bin/freshclam \
  /usr/local/bin/freshclam \
  /usr/local/cpanel/3rdparty/bin/freshclam \
  /opt/cpanel/ea-php*/root/usr/bin/freshclam \
  /opt/clamav/bin/freshclam; do
  for _EXPANDED in $_BIN; do
    if [[ -x "${_EXPANDED}" ]] || command -v "${_EXPANDED}" >/dev/null 2>&1; then
      FRESHCLAM_BIN="${_EXPANDED}"; break 2
    fi
  done
done

if [[ -n "${CLAMSCAN_BIN}" ]]; then
  ok "ClamAV found: ${CLAMSCAN_BIN}"
  # Record path so the scanner backend can use it directly
  "$SG_PHP" -r "define('SG_ROOT','${INSTALL_DIR}'); define('SG_DB','${INSTALL_DIR}/database/serverscrub.db'); define('SG_LOGS','${INSTALL_DIR}/logs'); define('SG_TMP','/tmp/serverscrub'); define('CPANEL_BASE','/usr/local/cpanel'); define('CPANEL_USER','root'); define('SCAN_MAX_SIZE',52428800); define('SIG_DIR','${INSTALL_DIR}/backend/signatures'); define('QUARANTINE_DIR','${INSTALL_DIR}/quarantine'); define('RBL_FEEDS',serialize([])); define('JWT_SECRET',hash('sha256',gethostname().'serverscrub_secret_2024')); define('JWT_EXPIRY',28800); define('INSTALL_MODE','${INSTALL_MODE}'); define('SG_PORT',${SG_PORT}); require_once '${INSTALL_DIR}/backend/lib/Database.php'; Database::setSetting('clamscan_path','${CLAMSCAN_BIN}'); echo 'ClamAV path stored' . PHP_EOL;" 2>/dev/null || true
  if [[ -n "${FRESHCLAM_BIN}" ]]; then
    # On Debian/Ubuntu the clamav-freshclam DAEMON starts automatically on
    # install and holds a lock on the database directory. A manual freshclam run
    # then fails with "can't lock" — which previously surfaced as a vague
    # "signature update failed" and left a scanner with no signatures at all.
    # Stop it for the initial fetch, then hand the job back to it.
    _FC_WAS_RUNNING=false
    if systemctl is-active --quiet clamav-freshclam 2>/dev/null; then
      _FC_WAS_RUNNING=true
      systemctl stop clamav-freshclam 2>/dev/null || true
    fi

    # A first-time download is several hundred MB. Bounded so a slow or blocked
    # mirror cannot hang the installer indefinitely.
    info "Downloading ClamAV signatures (first run can take a few minutes)…"
    if timeout 900 "${FRESHCLAM_BIN}" --quiet 2>&1 | tail -3 | sed 's/^/    /'; then
      ok "ClamAV signatures downloaded"
    else
      warn "Signature download did not complete — the scheduler retries weekly"
    fi

    # Verify rather than assume. clamscan is unusable without a database, and
    # reporting the scanner as ready when it cannot match anything is worse than
    # saying so plainly.
    # The search list must include wherever THIS clamscan actually looks. On
    # cPanel, clamscan is /usr/local/cpanel/3rdparty/bin/clamscan and its
    # database lives under .../3rdparty/share/clamav -- not in any of the
    # distro locations. The installer therefore downloaded signatures
    # successfully and then reported, in the next breath, that there were none.
    # Ask the binary where it looks before falling back to a fixed list.
    _SIGDIR=""
    _SIGDIRS=()
    if command -v clamconf >/dev/null 2>&1; then
      _CONF_DIR="$(clamconf 2>/dev/null | sed -n 's/^DatabaseDirectory = "\(.*\)"$//p' | head -1)"
      [[ -n "$_CONF_DIR" ]] && _SIGDIRS+=( "$_CONF_DIR" )
    fi
    # .../bin/clamscan -> .../share/clamav, which covers the cPanel layout
    if [[ -n "${CLAMSCAN_BIN:-}" ]]; then
      _SIGDIRS+=( "$(dirname "$(dirname "$CLAMSCAN_BIN")")/share/clamav" )
    fi
    _SIGDIRS+=( /usr/local/cpanel/3rdparty/share/clamav                 /var/lib/clamav /usr/local/share/clamav /usr/share/clamav )

    for _d in "${_SIGDIRS[@]}"; do
      [[ -z "$_d" || ! -d "$_d" ]] && continue
      if [[ -f "$_d/main.cvd" || -f "$_d/main.cld" || -f "$_d/daily.cvd" || -f "$_d/daily.cld" ]]; then
        _SIGDIR="$_d"; break
      fi
    done
    if [[ -n "$_SIGDIR" ]]; then
      ok "Signature database present: ${_SIGDIR}"
    else
      warn "No ClamAV signature database found — malware scanning will fall back"
      warn "to the built-in pattern engine until signatures download successfully."
    fi

    # Hand ongoing updates to the daemon where one exists, so signatures stay
    # current between our weekly scheduler run.
    for _svc in clamav-freshclam freshclam clamav-freshclam.service; do
      if systemctl list-unit-files 2>/dev/null | grep -q "^${_svc}"; then
        systemctl enable --now "$_svc" 2>/dev/null && ok "Automatic signature updates enabled (${_svc})"
        break
      fi
    done
    $_FC_WAS_RUNNING && systemctl start clamav-freshclam 2>/dev/null || true
  else
    warn "freshclam not found — signatures will not be auto-updated"
  fi
else
  warn "ClamAV not detected in any standard location."
  info "  Checked: /usr/bin, /usr/local/bin, /usr/local/cpanel/3rdparty/bin, /opt/clamav/bin"
  info "  Scanning continues using the built-in pattern engine, which needs no"
  info "  signature database — ClamAV adds broader coverage rather than being required."
  info "  Install on cPanel: yum install -y clamav clamav-update"
  info "  Install on Debian/Ubuntu: apt install -y clamav"
  info "  Pattern-based scanning will be used until ClamAV is installed."
fi

# ── Kernel tuning for the inotify monitor ─────────────────────────────────────
# monitor.py watches the filesystem via inotify. The default per-user watch
# limit (often 8192) is far too low for a busy hosting server — the monitor
# silently stops receiving events once it's exhausted. Raise it persistently.
section "Kernel tuning (inotify watch limit)"
SYSCTL_CONF="/etc/sysctl.d/60-serverscrub.conf"
cat > "${SYSCTL_CONF}" << SYSCTLEOF
# ServerScrub — raise inotify limits for the real-time file monitor
fs.inotify.max_user_watches = 1048576
fs.inotify.max_user_instances = 1024
SYSCTLEOF
chmod 644 "${SYSCTL_CONF}"
if command -v sysctl >/dev/null 2>&1; then
  sysctl -p "${SYSCTL_CONF}" >/dev/null 2>&1 && \
    ok "inotify limits raised (max_user_watches=1048576)" || \
    warn "sysctl reload failed — limits apply after next reboot"
else
  warn "sysctl not found — ${SYSCTL_CONF} written, applies after reboot"
fi

# ── Real-time monitor: Python dependency + systemd service ────────────────────
section "Real-time file monitor"
if ! command -v python3 >/dev/null 2>&1; then
  warn "Python 3 not found — real-time monitor unavailable"
else
  info "Installing inotify_simple…"
  if pip3 install inotify_simple --break-system-packages -q 2>/dev/null ||
     pip3 install inotify_simple -q 2>/dev/null; then
    ok "inotify_simple installed (kernel inotify engine active)"
  else
    warn "inotify_simple failed — monitor will use polling fallback"
  fi

  if command -v systemctl >/dev/null 2>&1 && [[ -d /etc/systemd/system ]]; then
    # Generate the service unit dynamically so paths match this installation
    cat > /etc/systemd/system/serverscrub-monitor.service << SVCEOF
[Unit]
Description=ServerScrub Real-Time File Monitor
After=network.target
Wants=network.target

[Service]
Type=simple
User=root
Environment="SG_ROOT=${INSTALL_DIR}"
ExecStart=/usr/bin/python3 ${INSTALL_DIR}/backend/daemon/monitor.py
Restart=on-failure
RestartSec=10
StandardOutput=append:${LOG_DIR}/monitor.log
StandardError=append:${LOG_DIR}/monitor.log
KillSignal=SIGTERM
TimeoutStopSec=10

[Install]
WantedBy=multi-user.target
SVCEOF
    chmod 644 /etc/systemd/system/serverscrub-monitor.service
    systemctl daemon-reload
    systemctl enable serverscrub-monitor 2>/dev/null
    systemctl start  serverscrub-monitor 2>/dev/null && \
      ok "Real-time monitor started" || warn "Monitor start failed — check: journalctl -u serverscrub-monitor"
  else
    nohup python3 "${INSTALL_DIR}/backend/daemon/monitor.py" \
      >> "${LOG_DIR}/monitor.log" 2>&1 &
    echo $! > "${INSTALL_DIR}/monitor.pid"
    ok "Real-time monitor started (background PID: $(cat ${INSTALL_DIR}/monitor.pid))"
  fi
fi

# ── Write install manifest (uninstaller reads this) ───────────────────────────
# This has to come BEFORE anything that appends to it. It used to sit after the
# cron section, so the firewall section's two `>> "${MANIFEST}"` lines ran with
# MANIFEST unset and the installer printed
#   install.sh: line 622: : No such file or directory
# twice -- a redirect to an empty filename. Worse, the block below opens the
# file with `>`, so even had they worked those keys would have been truncated
# away, and the uninstaller would never have known about the firewall service
# it was supposed to remove.
if ! $REGISTER_ONLY; then
  {
    echo "INSTALL_MODE=${INSTALL_MODE}"
    echo "INSTALL_VERSION=${SG_VERSION}"
    echo "INSTALL_DATE=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "INSTALL_DIR=${INSTALL_DIR}"
    echo "CRON_FILE=${CRON_FILE}"
    echo "SOURCE_DIR=${SCRIPT_DIR}"
  } > "${MANIFEST}"
# Recorded after the manifest exists: the migration runs long before this
# point, and a line appended then would be thrown away by the truncation
# above.
[[ -n "${MIGRATED_FROM:-}" ]] && echo "MIGRATED_FROM=${MIGRATED_FROM}" >> "${MANIFEST}"
  info "Manifest started: ${MANIFEST}"
else
  info "Register-only — re-registering plugin against existing install"
fi

# ── Built-in firewall ─────────────────────────────────────────────────────────
# The product ships its own packet-filter manager so an operator does not have
# to install and learn a separate firewall first. It defers to CSF or firewalld
# when either is already in charge — overwriting a firewall the server is
# already managing would be worse than adding nothing.
section "Firewall engine"
FW_INIT="$("$SG_PHP" -r "define('SG_API', true); require_once '${INSTALL_DIR}/backend/config/config.php'; require_once '${INSTALL_DIR}/backend/lib/Database.php'; require_once '${INSTALL_DIR}/backend/lib/FirewallEngine.php'; \$i = FirewallEngine::backendInfo(); echo \$i['backend'];" 2>/dev/null || echo unknown)"
info "Detected firewall backend: ${FW_INIT}"

if [[ "$FW_INIT" == "none" ]]; then
  # Nothing usable present — install a packet filter rather than leaving the
  # firewall UI inert. nftables is the modern default on every supported distro.
  warn "No packet filter found — installing nftables…"
  if   command -v dnf >/dev/null 2>&1; then dnf install -y -q nftables >/dev/null 2>&1
  elif command -v yum >/dev/null 2>&1; then yum install -y -q nftables >/dev/null 2>&1
  elif command -v apt-get >/dev/null 2>&1; then apt-get install -y -q nftables >/dev/null 2>&1
  fi
  command -v nft >/dev/null 2>&1     && ok "nftables installed"     || warn "Could not install nftables — the firewall UI will be read-only"
fi

"$SG_PHP" -r "define('SG_API', true); require_once '${INSTALL_DIR}/backend/config/config.php'; require_once '${INSTALL_DIR}/backend/lib/Database.php'; require_once '${INSTALL_DIR}/backend/lib/FirewallEngine.php'; \$r = FirewallEngine::initialise(); echo (\$r['success'] ? 'OK ' : 'FAIL ') . (\$r['message'] ?? \$r['error'] ?? '');" 2>&1 | sed 's/^/  /' || warn "Firewall init reported an error"

# Restore rules at boot. nftables and iptables keep rules in kernel memory only,
# so without this every block silently disappears on reboot while the database
# still reports them as active — the product claiming protection it is not
# providing.
if command -v systemctl >/dev/null 2>&1 && [[ -d /etc/systemd/system ]]; then
  cat > /etc/systemd/system/serverscrub-firewall.service << FWEOF
[Unit]
Description=ServerScrub firewall rule restore
DefaultDependencies=no
After=network-pre.target
Before=network-pre.target
Wants=network-pre.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=${SG_PHP} -r "define('SG_API',true); require_once '${INSTALL_DIR}/backend/config/config.php'; require_once '${INSTALL_DIR}/backend/lib/Database.php'; require_once '${INSTALL_DIR}/backend/lib/FirewallEngine.php'; FirewallEngine::restore();"

[Install]
WantedBy=multi-user.target
FWEOF
  chmod 644 /etc/systemd/system/serverscrub-firewall.service
  systemctl daemon-reload
  systemctl enable serverscrub-firewall 2>/dev/null && ok "Boot-time rule restore enabled"
  echo "FIREWALL_SERVICE=/etc/systemd/system/serverscrub-firewall.service" >> "${MANIFEST}"
fi
echo "FIREWALL_BACKEND=${FW_INIT}" >> "${MANIFEST}"

# ── Cron jobs ──────────────────────────────────────────────────────────────────
section "Cron jobs"
cat > "${CRON_FILE}" << CRONEOF
# ServerScrub — scheduled tasks
MAILTO=""
# Task scheduler — decides what is due from the user's Settings. Runs every
# 15 min; exits silently when nothing is due. Schedules are changed in the UI,
# NOT by editing this file.
*/15 * * * * root ${SG_PHP} ${INSTALL_DIR}/backend/cron/scheduler.php >> ${LOG_DIR}/cron.log 2>&1
# Daily update check at 8am
0 8 * * * root SG_ROOT=${INSTALL_DIR} ${SG_PHP} ${INSTALL_DIR}/backend/cron/update-check.php >> ${LOG_DIR}/cron.log 2>&1
CRONEOF
chmod 644 "${CRON_FILE}"
ok "Cron jobs installed to ${CRON_FILE}"

# On SELinux-enforcing hosts (CloudLinux/RHEL) a freshly written /etc/cron.d
# file lacks the system_cron_spool_t context and crond will refuse to run it.
if command -v getenforce >/dev/null 2>&1 && [[ "$(getenforce 2>/dev/null)" == "Enforcing" ]]; then
  if command -v semanage >/dev/null 2>&1; then
    semanage fcontext -a -t system_cron_spool_t "${CRON_FILE}" 2>/dev/null || true
  fi
  command -v restorecon >/dev/null 2>&1 && restorecon -Fv "${CRON_FILE}" 2>/dev/null || true
  ok "SELinux context applied to ${CRON_FILE}"
fi

fi  # ═══ end INSTALL-ONLY SECTIONS ═══════════════════════════════════════════════

# ── Firewall & WAF integration (CSF/LFD + ModSecurity) ─────────────────────────
# These wire ServerScrub into the server's existing security stack. They are
# idempotent (guarded by grep) so they run safely on both fresh installs and
# --register-only upgrades. All entries are removed by uninstall.sh.
SG_ETC="/etc/serverscrub"
mkdir -p "${SG_ETC}"

# ── CSF / LFD (ConfigServer Firewall) ──
# Firewall.php already speaks `csf -a/-d` at runtime; here we register the
# persistent include files CSF reads on every restart, and exempt
# ServerScrub's own long-running root daemons from LFD process tracking so they are
# never flagged or killed.
section "CSF / LFD firewall integration"
if [[ -f /usr/sbin/csf ]]; then
  touch "${SG_ETC}/csf_allow.txt" "${SG_ETC}/csf_ignore.txt"
  chmod 600 "${SG_ETC}/csf_allow.txt" "${SG_ETC}/csf_ignore.txt"

  if [[ -f /etc/csf/csf.allow ]] && ! grep -q "serverscrub/csf_allow.txt" /etc/csf/csf.allow 2>/dev/null; then
    echo "Include ${SG_ETC}/csf_allow.txt" >> /etc/csf/csf.allow
    ok "Registered allow include in csf.allow"
  fi
  if [[ -f /etc/csf/csf.ignore ]] && ! grep -q "serverscrub/csf_ignore.txt" /etc/csf/csf.ignore 2>/dev/null; then
    echo "Include ${SG_ETC}/csf_ignore.txt" >> /etc/csf/csf.ignore
    ok "Registered ignore include in csf.ignore"
  fi
  if [[ -f /etc/csf/csf.pignore ]]; then
    grep -q "serverscrub/backend/daemon/monitor.py" /etc/csf/csf.pignore 2>/dev/null || \
      echo "cmd:.*serverscrub/backend/daemon/monitor.py" >> /etc/csf/csf.pignore
    grep -q "serverscrub/backend/standalone-router.php" /etc/csf/csf.pignore 2>/dev/null || \
      echo "cmd:.*serverscrub/backend/standalone-router.php" >> /etc/csf/csf.pignore
    ok "Exempted ServerScrub daemons in csf.pignore"
  fi

  # `csf -r` reloads csf AND lfd; fall back to a direct lfd restart if absent.
  if csf -r >/dev/null 2>&1; then
    ok "CSF reloaded (csf.allow/ignore/pignore active)"
  else
    systemctl restart lfd 2>/dev/null || service lfd restart 2>/dev/null || true
    ok "lfd restarted"
  fi
  {
    echo "CSF_ALLOW_INCLUDE=${SG_ETC}/csf_allow.txt"
    echo "CSF_IGNORE_INCLUDE=${SG_ETC}/csf_ignore.txt"
    echo "SG_ETC=${SG_ETC}"
  } >> "${MANIFEST}"
else
  info "CSF not installed — skipping CSF integration (firewalld/iptables fallback stays active)"
fi

# ── ModSecurity Apache hook ──
# WAF.php writes custom SecRules under the modsec vendor configs dir. Apache
# does not load that path automatically, so we add an explicit Include to the
# ModSecurity user config. The Apache restart at the end of install activates it.
section "ModSecurity WAF integration"
MODSEC_USER_CONF=""
for _MSC in \
  /etc/apache2/conf.d/modsec/modsec2.user.conf \
  /etc/apache2/conf.d/modsec2.user.conf \
  /usr/local/apache/conf/modsec2.user.conf \
  /etc/httpd/conf.d/mod_security.conf; do
  [[ -f "${_MSC}" ]] && { MODSEC_USER_CONF="${_MSC}"; break; }
done
if [[ -n "${MODSEC_USER_CONF}" ]]; then
  SG_MODSEC_DIR="/etc/apache2/conf.d/modsec_vendor_configs/serverscrub"
  SG_MODSEC_RULES="${SG_MODSEC_DIR}/custom_rules.conf"
  mkdir -p "${SG_MODSEC_DIR}"
  if [[ ! -f "${SG_MODSEC_RULES}" ]]; then
    cat > "${SG_MODSEC_RULES}" << 'MODRULEEOF'
# ServerScrub — custom ModSecurity rules (managed by the WAF module).
# Rules added from the dashboard are written here; Apache reload applies them.
MODRULEEOF
    chmod 644 "${SG_MODSEC_RULES}"
  fi
  if ! grep -q "serverscrub/custom_rules.conf" "${MODSEC_USER_CONF}" 2>/dev/null; then
    {
      echo ""
      echo "# ServerScrub WAF rules"
      echo "Include ${SG_MODSEC_RULES}"
    } >> "${MODSEC_USER_CONF}"
    ok "Registered WAF Include in ${MODSEC_USER_CONF}"
  else
    info "WAF Include already present in ${MODSEC_USER_CONF}"
  fi
  {
    echo "MODSEC_USER_CONF=${MODSEC_USER_CONF}"
    echo "SG_MODSEC_DIR=${SG_MODSEC_DIR}"
  } >> "${MANIFEST}"
else
  info "ModSecurity user config not found — skipping WAF Apache hook (WAF stays app-level)"
fi

# ── CLI entrypoint (`serverscrub` command) ───────────────────────────────────────
# Thin bash wrapper in /usr/bin so admins get a `serverscrub` command (parity with
# CPGuard's cpgcli). Placed here (not the install-only block) so upgrades run via
# --register-only pick it up too. Points at the installed CLI, not the source.
section "CLI entrypoint"
if [[ -f "${INSTALL_DIR}/backend/cli/serverscrub.php" ]]; then
  _PHP_BIN="${SG_PHP}"
  cat > /usr/bin/serverscrub << CLIEOF
#!/usr/bin/env bash
# ServerScrub CLI — installed by install.sh (do not edit)
exec ${_PHP_BIN} ${INSTALL_DIR}/backend/cli/serverscrub.php "\$@"
CLIEOF
  chmod 755 /usr/bin/serverscrub
  ok "CLI installed: /usr/bin/serverscrub (run: serverscrub help)"
  grep -q "^SG_CLI=" "${MANIFEST}" 2>/dev/null || echo "SG_CLI=/usr/bin/serverscrub" >> "${MANIFEST}"
else
  info "CLI script not present in install dir — skipping /usr/bin/serverscrub"
fi

# ── Mode-specific setup ────────────────────────────────────────────────────────
if [[ "$INSTALL_MODE" == "standalone" ]]; then

  section "Standalone web server (port ${SG_PORT})"

  # ── Open port in firewall ──
  info "Opening port ${SG_PORT}/tcp in firewall…"
  if command -v firewall-cmd >/dev/null 2>&1; then
    info "  Firewall manager: firewall-cmd"
    if firewall-cmd --permanent --add-port=${SG_PORT}/tcp 2>&1 && \
       firewall-cmd --reload 2>&1; then
      ok "Port ${SG_PORT} opened in firewalld"
      echo "FIREWALL_TOOL=firewalld" >> "${MANIFEST}"
    else
      warn "firewall-cmd failed — open port ${SG_PORT}/tcp manually"
    fi
  elif command -v iptables >/dev/null 2>&1; then
    info "  Firewall manager: iptables"
    iptables -C INPUT -p tcp --dport ${SG_PORT} -j ACCEPT 2>/dev/null || \
      iptables -I INPUT -p tcp --dport ${SG_PORT} -j ACCEPT
    iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
    ok "Port ${SG_PORT} opened in iptables"
    echo "FIREWALL_TOOL=iptables" >> "${MANIFEST}"
  else
    warn "No firewall manager found — open port ${SG_PORT}/tcp manually"
  fi

  # ── Systemd web service ──
  WEB_SVC=""
  if command -v systemctl >/dev/null 2>&1 && [[ -d /etc/systemd/system ]]; then
    WEB_SVC="/etc/systemd/system/serverscrub-web.service"
    info "Installing systemd service: ${WEB_SVC}"
    cp "${SCRIPT_DIR}/whm/serverscrub-web.service" "${WEB_SVC}"
    chmod 644 "${WEB_SVC}"
    systemctl daemon-reload
    systemctl enable serverscrub-web 2>&1 | sed 's/^/  /'
    if systemctl start serverscrub-web 2>&1; then
      ok "Service started: serverscrub-web"
      systemctl status serverscrub-web --no-pager -l 2>&1 | head -6 | sed 's/^/  /'
    else
      warn "Service start failed — check: journalctl -u serverscrub-web -n 20"
    fi
    echo "WEB_SERVICE=${WEB_SVC}" >> "${MANIFEST}"
  else
    info "  systemd not available — starting PHP server in background"
    nohup "$SG_PHP" -S 0.0.0.0:${SG_PORT} \
      "${INSTALL_DIR}/backend/standalone-router.php" \
      >> "${LOG_DIR}/web.log" 2>&1 &
    echo $! > "${INSTALL_DIR}/web.pid"
    ok "Web server started (PID: $(cat ${INSTALL_DIR}/web.pid))"
    echo "WEB_PID_FILE=${INSTALL_DIR}/web.pid" >> "${MANIFEST}"
  fi

elif [[ "$INSTALL_MODE" == "cpanel" ]]; then

  section "cPanel / WHM Plugin Registration"

  # ── Detect Apache config directory ──
  info "Detecting Apache config directory…"
  info "  Checking /etc/apache2/conf.d …"
  if [[ -d /etc/apache2/conf.d ]]; then
    APACHE_CONF_D="/etc/apache2/conf.d"
    info "  Found: /etc/apache2/conf.d"
  else
    info "  Checking /usr/local/apache/conf/includes …"
    if [[ -d /usr/local/apache/conf/includes ]]; then
      APACHE_CONF_D="/usr/local/apache/conf/includes"
      info "  Found: /usr/local/apache/conf/includes"
    else
      info "  Checking /etc/httpd/conf.d …"
      if [[ -d /etc/httpd/conf.d ]]; then
        APACHE_CONF_D="/etc/httpd/conf.d"
        info "  Found: /etc/httpd/conf.d"
      else
        APACHE_CONF_D="/etc/apache2/conf.d"
        info "  None found — creating ${APACHE_CONF_D}"
        mkdir -p "$APACHE_CONF_D"
      fi
    fi
  fi
  ok "Apache config dir: ${APACHE_CONF_D}"

  # ── Detect PHP handler for this server ────────────────────────────────────
  # EasyApache 4 (cPanel): handler is per-EA4 PHP version, e.g. ea-php81
  # Standard mod_php / other: application/x-httpd-php
  PHP_HANDLER="application/x-httpd-php"
  if [[ -d /opt/cpanel ]]; then
    _PHP_VER=$("$SG_PHP" -r 'echo PHP_MAJOR_VERSION . PHP_MINOR_VERSION;' 2>/dev/null)
    if [[ -n "$_PHP_VER" ]]; then
      PHP_HANDLER="application/x-httpd-ea-php${_PHP_VER}"
      info "Detected EasyApache 4 PHP handler: ${PHP_HANDLER}"
    fi
  else
    # Non-cPanel: try to find the handler from existing Apache config
    _H=$(grep -r "SetHandler.*php\|AddHandler.*php" /etc/apache2/ /etc/httpd/ 2>/dev/null \
         | grep -oP 'application/x-httpd-php\S*' | head -1)
    [[ -n "$_H" ]] && PHP_HANDLER="$_H"
    info "PHP handler: ${PHP_HANDLER}"
  fi

  # ── What should https://<host>/serverscrub/ serve? ──────────────────────
  # On cPanel: NOT the app. That copy cannot work — Apache has no PHP handler
  # for this directory and would run it as the web user anyway — yet it looks
  # identical to the real dashboard and silently fails every API call. Anyone
  # with an old bookmark lands there and sees a login form that can never
  # succeed. It now redirects to the WHM plugin, which is the working UI.
  #
  # The redirect is computed client-side from location.hostname so no hostname
  # is baked into the config at install time.
  if [[ "${INSTALL_MODE}" == "cpanel" ]]; then
    SG_WEB_DIR="${INSTALL_DIR}/whm/webredirect"
    mkdir -p "${SG_WEB_DIR}"
    cat > "${SG_WEB_DIR}/index.html" << 'ENDREDIR'
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>ServerScrub</title>
<style>body{background:#0b1020;color:#e2e8f0;font-family:system-ui,-apple-system,
Segoe UI,sans-serif;display:flex;align-items:center;justify-content:center;
height:100vh;margin:0;text-align:center}a{color:#a78bfa}</style></head>
<body><div>
  <div style="font-size:2.2rem;margin-bottom:12px">&#x1F6E1;&#xFE0F;</div>
  <h2 style="margin:0 0 8px;font-size:1.2rem">ServerScrub</h2>
  <p style="color:#94a3b8;font-size:.9rem" id="m">Taking you to the dashboard&hellip;</p>
  <p style="margin-top:16px;font-size:.85rem"><a id="l" href="#">Open the dashboard</a></p>
</div>
<script>
// The dashboard runs under WHM (cpsrvd), which is what gives it the privileges
// the firewall and scanner need. This address is only a signpost.
var u = 'https://' + location.hostname + ':2087/cgi/serverscrub/serverscrub.cgi';
document.getElementById('l').href = u;
location.replace(u);
</script>
</body></html>
ENDREDIR
    ok "  /serverscrub/ redirects to the WHM plugin"
  else
    SG_WEB_DIR="${INSTALL_DIR}/frontend"
  fi

  # ── Write Apache alias config ──
  APACHE_CONF="${APACHE_CONF_D}/serverscrub.conf"
  info "Writing Apache alias config: ${APACHE_CONF}"
  cat > "${APACHE_CONF}" << APACHEEOF
# ServerScrub v${SG_VERSION} — Apache aliases
# API alias MUST come before the root alias (more-specific path first)
<IfModule mod_alias.c>
  Alias /serverscrub/backend/api ${INSTALL_DIR}/backend/api
  Alias /serverscrub             ${SG_WEB_DIR}
</IfModule>

<Directory "${INSTALL_DIR}/backend/api">
  Options -Indexes -MultiViews
  AllowOverride FileInfo
  Require all granted
  DirectoryIndex index.php
  <FilesMatch "\.php$">
    SetHandler ${PHP_HANDLER}
  </FilesMatch>
  <IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteRule ^ index.php [QSA,L]
  </IfModule>
</Directory>

<Directory "${INSTALL_DIR}/backend">
  Options -Indexes
  AllowOverride None
  Require all denied
</Directory>

<Directory "${SG_WEB_DIR}">
  Options -Indexes
  AllowOverride None
  Require all granted
  DirectoryIndex index.html
</Directory>
APACHEEOF

  if [[ -f "${APACHE_CONF}" ]]; then
    ok "Apache config written: ${APACHE_CONF} ($(wc -c < "${APACHE_CONF}") bytes)"
    echo "APACHE_CONF=${APACHE_CONF}" >> "${MANIFEST}"
  else
    warn "Apache config write FAILED: ${APACHE_CONF}"
  fi

  # ── Register plugin via AppConfig ────────────────────────────────────────────
  # Follows the exact same pattern as ConfigServer Security & Firewall (CSF),
  # the most widely deployed WHM plugin. Key facts from CSF's installer:
  #   1. CGI + conf live in a named subdirectory of cgi docroot
  #   2. register_appconfig copies the conf to /var/cpanel/apps/ AND restarts cpsrvd
  #   3. No manual cpsrvd restart is needed — register_appconfig handles it
  #   4. Invalid AppConfig fields (like icon=plugin) cause silent rejection
  info "Registering ServerScrub with cPanel AppConfig system…"
  if [[ ! -d /usr/local/cpanel ]]; then
    warn "/usr/local/cpanel not found — skipping cPanel registration"
  else
    ok "cPanel found"
    SERVER_HOST=$(hostname -f 2>/dev/null || hostname 2>/dev/null || echo "localhost")
    info "  Server hostname: ${SERVER_HOST}"

    # ── Step 1: Create named CGI subdirectory in WHM docroot ─────────────────
    # CSF uses:  /usr/local/cpanel/whostmgr/docroot/cgi/configserver/csf/
    # We follow: /usr/local/cpanel/whostmgr/docroot/cgi/serverscrub/
    WHM_CGI_DIR="/usr/local/cpanel/whostmgr/docroot/cgi/serverscrub"
    WHM_CGI="${WHM_CGI_DIR}/serverscrub.cgi"
    WHM_PLUGIN_CONF="${WHM_CGI_DIR}/serverscrub.conf"
    mkdir -p "${WHM_CGI_DIR}"
    info "  WHM CGI dir: ${WHM_CGI_DIR}"

    # ── Step 2: Serve the app from cpsrvd, not Apache ─────────────────────────
    # The CGI used to redirect to https://<host>/serverscrub/, handing the app
    # to Apache. That was wrong for a WHM plugin in two ways that only show up on
    # a real server:
    #
    #   1. Apache only executes PHP in an aliased directory if a loaded module
    #      claims the handler. On EA4 that may be mod_php, mod_lsapi, PHP-FPM or
    #      suPHP — four different correct answers, and guessing wrong returns
    #      "501 Not supported" for every API call, which is exactly what happened.
    #   2. Even when it works, Apache runs the code as the web user. This product
    #      needs root: nft/iptables, quarantine, clamscan, reading /proc.
    #
    # cpsrvd has neither problem. It executes CGI in the WHM docroot as root, it
    # is always present on a cPanel box, and the UI and API then share one origin
    # so no CORS or cross-port session juggling is involved.

    # PHP interpreter for the API CGI. php-cgi is strongly preferred: the CLI SAPI
    # ignores header() and http_response_code(), so the 401/402 statuses the UI
    # depends on would be flattened to 200.
    SG_PHP_CGI=""
    for _c in /usr/local/cpanel/3rdparty/bin/php-cgi \
              /opt/cpanel/ea-php83/root/usr/bin/php-cgi \
              /opt/cpanel/ea-php82/root/usr/bin/php-cgi \
              /opt/cpanel/ea-php81/root/usr/bin/php-cgi \
              /opt/cpanel/ea-php80/root/usr/bin/php-cgi \
              /usr/bin/php-cgi; do
      [[ -x "$_c" ]] && { SG_PHP_CGI="$_c"; break; }
    done
    if [[ -z "$SG_PHP_CGI" ]]; then
      warn "  No php-cgi found — API status codes will be degraded"
      SG_PHP_CGI="/usr/local/cpanel/3rdparty/bin/php"
    fi
    info "  API CGI interpreter: ${SG_PHP_CGI}"

    # Copy the UI into the CGI directory so cpsrvd serves it same-origin.
    # cpsrvd serves static files from this directory (this is how CSF ships its
    # css and images), and executes the .cgi entry points.
    info "  Publishing UI into ${WHM_CGI_DIR}"
    cp -rf "${INSTALL_DIR}/frontend/." "${WHM_CGI_DIR}/" 2>/dev/null || true

    # The API endpoint: a sibling of the UI, so './api.cgi' resolves from it.
    # ── ONE entry point, because AppConfig authorises exactly one ─────────────
    # cpsrvd refuses to execute any CGI in the WHM docroot that is not
    # registered with AppConfig, returning a 403 HTML page:
    #
    #   "WHM is configured to disallow execution of unregistered applications
    #    when logged in as root or a reseller with the all ACL"
    #
    # A separate api.cgi was therefore 403 on every request from the browser,
    # while the same file ran fine from the shell — which is why this survived
    # several releases of shell-side testing. Registering a second application
    # would work but adds a second WHM menu entry, and relaxing the setting
    # (permit_unregistered_apps_as_root) weakens the server to suit us.
    #
    # So the single registered CGI serves both: a request carrying ?r= is the
    # API, anything else is the dashboard. Static assets are untouched by this —
    # cpsrvd serves css/js/images as files, not applications.
    rm -f "${WHM_CGI_DIR}/api.cgi"

    info "  Writing CGI: ${WHM_CGI}"
    cat > "${WHM_CGI}" << ENDCGI
#!/bin/sh
# ServerScrub — the one AppConfig-registered entry point (runs as root).
#   ?r=module/action  -> REST API, handed to php-cgi
#   anything else     -> the dashboard
#
# php-cgi is given its target through SCRIPT_FILENAME so the file it parses is
# ordinary PHP with no shebang, and it emits CGI status lines itself, keeping
# 401/402 intact. REDIRECT_STATUS is required or php-cgi refuses to run.
case "\${QUERY_STRING}" in
  *r=*)
    SCRIPT_FILENAME="${INSTALL_DIR}/backend/api/index.php"
    PATH_TRANSLATED="\${SCRIPT_FILENAME}"
    REDIRECT_STATUS=200
    export SCRIPT_FILENAME PATH_TRANSLATED REDIRECT_STATUS
    exec "${SG_PHP_CGI}"
    ;;
esac

printf 'Content-Type: text/html; charset=utf-8\r\n'
printf 'Cache-Control: no-store, must-revalidate\r\n'
printf '\r\n'
cat "${WHM_CGI_DIR}/index.html"
ENDCGI
    chmod 755 "${WHM_CGI}"
    if [[ -f "${WHM_CGI}" ]]; then
      ok "  CGI written and executable: ${WHM_CGI}"
      echo "WHM_CGI=${WHM_CGI}" >> "${MANIFEST}"
    else
      warn "  CGI write FAILED: ${WHM_CGI}"
    fi

    # Pin the UI to this endpoint so it does not have to discover it.
    cat > "${WHM_CGI_DIR}/config.js" << ENDCFG
// Written by the installer. The API is served by the same registered CGI as
// the dashboard: AppConfig authorises exactly one application per directory, so
// a separate endpoint is refused by cpsrvd with 403.
window.SG_API_BASE = './serverscrub.cgi';
ENDCFG
    ok "  API base pinned: ./serverscrub.cgi"

    # ── Prove the API actually answers, here, now ─────────────────────────────
    # The installer previously reported success without ever invoking the API,
    # which is how a build whose every endpoint returned 501 was handed over as
    # working. Execute it directly and require JSON back.
    info "  Testing API CGI…"
    # Invoke the wrapper exactly as cpsrvd does, and require a body whose FIRST
    # non-header character is '{'. Merely containing a brace is not enough: the
    # failure being guarded against is stray bytes preceding valid JSON, which a
    # substring match would happily pass.
    _API_OUT=$(cd "${WHM_CGI_DIR}" && REQUEST_METHOD=GET QUERY_STRING="r=auth/status" \
               REMOTE_USER=root SERVER_PROTOCOL=HTTP/1.1 \
               "${WHM_CGI}" 2>&1)
    _API_BODY=$(printf '%s' "$_API_OUT" | sed -n '/^[[:space:]]*$/,$p' | sed '1d')
    [[ -z "$_API_BODY" ]] && _API_BODY="$_API_OUT"
    if printf '%s' "$_API_BODY" | grep -q '^[[:space:]]*{'; then
      ok "  API responds with JSON"
    else
      warn "  API did NOT return clean JSON. Raw output was:"
      printf '%s\n' "$_API_OUT" | head -20 | sed 's/^/      /'
      warn "  The dashboard will not load until this is resolved."
      warn "  Interpreter used: ${SG_PHP_CGI}"
    fi

    # ── Step 3: Write AppConfig conf file ALONGSIDE the CGI ──────────────────
    # Fields follow CSF's exact format (the reference implementation):
    #   url      = path registered with AppConfig (cgi/ prefix required)
    #   entryurl = clickable link shown in WHM nav (relative to cgi/, no prefix)
    #   acls     = all — root + all resellers with the 'all' ACL can access
    # No target= field: WHM opens the plugin in the main content area (embedded),
    # matching how CSF, CPGuard, and MagicSpam appear in WHM.
    # acls=any — visible to ALL authenticated WHM users: root AND every reseller.
    # (acls=all means only users with the 'all' ACL i.e. root + superadmin
    #  resellers; acls=any means every reseller regardless of their ACL set.)
    # target=_blank — opens the plugin in a new browser tab (not embedded in WHM).
    # Do NOT include 'icon=...' unless you have an actual installed icon file.
    # ── Install the plugin icon into WHM's addon_plugins directory ───────────
    # WHM renders the icon referenced by the AppConfig `icon=` field from
    # whostmgr/docroot/addon_plugins/. Without it the plugin shows a blank tile.
    ADDON_PLUGINS_DIR="/usr/local/cpanel/whostmgr/docroot/addon_plugins"
    SG_ICON_SRC="${SCRIPT_DIR}/whm/serverscrub.png"
    SG_ICON_DEST="${ADDON_PLUGINS_DIR}/serverscrub.png"
    if [[ -f "${SG_ICON_SRC}" && -d "${ADDON_PLUGINS_DIR}" ]]; then
      cp -f "${SG_ICON_SRC}" "${SG_ICON_DEST}"
      chmod 644 "${SG_ICON_DEST}"
      ok "  Plugin icon installed: ${SG_ICON_DEST}"
      echo "WHM_ICON=${SG_ICON_DEST}" >> "${MANIFEST}"
    else
      warn "  Icon source or addon_plugins dir missing — plugin will show no icon"
    fi

    info "  Writing AppConfig conf: ${WHM_PLUGIN_CONF}"
    # Remove any stale /var/cpanel/apps/ copy first so register_appconfig writes fresh
    rm -f /var/cpanel/apps/serverscrub.conf 2>/dev/null || true
    cat > "${WHM_PLUGIN_CONF}" << APPEOF
name=serverscrub
service=whostmgr
url=/cgi/serverscrub/serverscrub.cgi
entryurl=serverscrub/serverscrub.cgi
acls=any
displayname=ServerScrub Security
icon=serverscrub.png
target=_blank
APPEOF
    chmod 644 "${WHM_PLUGIN_CONF}"
    if [[ -f "${WHM_PLUGIN_CONF}" ]]; then
      ok "  AppConfig conf written: ${WHM_PLUGIN_CONF}"
      info "  Contents: $(tr '\n' ' ' < "${WHM_PLUGIN_CONF}")"
      echo "WHM_PLUGIN_CONF=${WHM_PLUGIN_CONF}" >> "${MANIFEST}"
    else
      warn "  AppConfig conf write FAILED: ${WHM_PLUGIN_CONF}"
    fi

    # ── Step 4: Install Driver files and touch directory ─────────────────────
    # CSF installs Driver files and touches the directory BEFORE calling
    # register_appconfig. The touch updates the directory mtime which signals
    # cpsrvd to rescan and fully load new AppConfig entries into the WHM nav.
    # Without this step the plugin conf may be registered but not shown in nav.
    DRIVER_DEST="/usr/local/cpanel/Cpanel/Config/ConfigObj/Driver"
    DRIVER_SRC="${SCRIPT_DIR}/whm/Driver"
    if [[ -d "${DRIVER_DEST}" && -d "${DRIVER_SRC}" ]]; then
      info "  Installing Driver files to ${DRIVER_DEST}…"
      cp -af "${DRIVER_SRC}/ServerScrub.pm" "${DRIVER_DEST}/"
      mkdir -p "${DRIVER_DEST}/ServerScrub"
      cp -af "${DRIVER_SRC}/ServerScrub/META.pm" "${DRIVER_DEST}/ServerScrub/"
      touch "${DRIVER_DEST}"
      ok "  Driver files installed; directory mtime updated"
      echo "DRIVER_DEST=${DRIVER_DEST}" >> "${MANIFEST}"
    else
      warn "  Driver destination not found (${DRIVER_DEST}) — skipping Driver install"
    fi

    # ── Step 5: Register with AppConfig (exactly as CSF does it) ─────────────
    # register_appconfig:
    #   • Reads conf from the path given
    #   • Copies it to /var/cpanel/apps/<name>.conf
    #   • Restarts cpsrvd automatically
    # We pass the path in the CGI docroot (not /var/cpanel/apps/) —
    # this is the documented, CSF-proven approach.
    info "  Running register_appconfig ${WHM_PLUGIN_CONF}…"
    _REG_OK=false
    if [[ -x /usr/local/cpanel/bin/register_appconfig ]]; then
      _REG_OUT=$(/usr/local/cpanel/bin/register_appconfig "${WHM_PLUGIN_CONF}" 2>&1)
      _REG_EXIT=$?
      echo "${_REG_OUT}" | sed 's/^/    /'
      if [[ $_REG_EXIT -eq 0 ]]; then
        ok "  register_appconfig succeeded"
        _REG_OK=true
        # Verify it landed in /var/cpanel/apps/
        if [[ -f /var/cpanel/apps/serverscrub.conf ]]; then
          ok "  Confirmed deployed to /var/cpanel/apps/serverscrub.conf"
          echo "APPCONFIG_CONF=/var/cpanel/apps/serverscrub.conf" >> "${MANIFEST}"
        fi
      else
        warn "  register_appconfig exited ${_REG_EXIT} — trying --all rescan…"
        /usr/local/cpanel/bin/register_appconfig --all 2>&1 | sed 's/^/    /'
        [[ $? -eq 0 ]] && _REG_OK=true
      fi
    else
      warn "  register_appconfig not found — manually restarting cpsrvd to pick up conf…"
      # Fallback: copy conf directly and restart
      cp -f "${WHM_PLUGIN_CONF}" /var/cpanel/apps/serverscrub.conf 2>/dev/null || true
      echo "APPCONFIG_CONF=/var/cpanel/apps/serverscrub.conf" >> "${MANIFEST}"
    fi

    # ── Step 6: cPanel user-level plugin (per-account cPanel dashboard) ─────
    # Each cPanel account holder sees a "ServerScrub" icon in their dashboard.
    # Clicking it opens the ServerScrub dashboard in a new tab.
    # Registered via:
    #   a) install_plugin (modern, 11.44+) — processes install.json
    #   b) dynamicui .conf (legacy fallback) — direct conf file
    #   c) service=cpanel AppConfig entry — security integration
    info "  Installing cPanel user-level plugin…"
    for CPANEL_THEME in paper_lantern jupiter; do
      CPANEL_THEME_BASE="/usr/local/cpanel/base/frontend/${CPANEL_THEME}"
      [[ ! -d "${CPANEL_THEME_BASE}" ]] && { info "  Theme not found: ${CPANEL_THEME} — skip"; continue; }

      # Create plugin directory and PHP redirect page
      CPANEL_PLUGIN_DIR="${CPANEL_THEME_BASE}/serverscrub"
      mkdir -p "${CPANEL_PLUGIN_DIR}"
      # The user-facing page, shipped as a file rather than written inline.
      #
      # It used to be a redirect to https://<host>/serverscrub/ -- the WHM
      # dashboard, which authenticates against WHM. A cPanel user following the
      # menu entry therefore arrived at a login screen they could never pass,
      # so the plugin was present and useless. The page now reads the report
      # the privileged side writes into the user's own home and renders it in
      # place, with no login of its own and no access to the server-wide
      # database (which is 0700 root, and must stay that way).
      #
      # Keeping it in the repo as cpanel/serverscrub/index.php means php -l,
      # the preflight gates and the test suite all see it; a heredoc inside an
      # installer is invisible to every one of them.
      if [[ -f "${SCRIPT_DIR}/cpanel/serverscrub/index.php" ]]; then
        cp -f "${SCRIPT_DIR}/cpanel/serverscrub/index.php" "${CPANEL_PLUGIN_DIR}/index.php"
      else
        warn "  cPanel user page missing from the package — menu entry would be empty"
      fi
      chmod 644 "${CPANEL_PLUGIN_DIR}/index.php"

      # The icon has to be BESIDE install.json, and named in it. Without it
      # install_plugin dies with
      #   Cpanel::Exception::MissingParameter ... lacks the required parameter "icon"
      # for both themes, and the plugin only ever appeared through the legacy
      # dynamicui fallback.
      if [[ -f "${SCRIPT_DIR}/whm/serverscrub.png" ]]; then
        cp -f "${SCRIPT_DIR}/whm/serverscrub.png" "${CPANEL_PLUGIN_DIR}/serverscrub.png"
        chmod 644 "${CPANEL_PLUGIN_DIR}/serverscrub.png"
      fi

      # install.json for the modern install_plugin mechanism (cPanel 11.44+)
      cat > "${CPANEL_PLUGIN_DIR}/install.json" << JSONEOF
[
  {
    "id":       "serverscrub",
    "type":     "link",
    "name":     "ServerScrub",
    "order":    100,
    "group_id": "security",
    "uri":      "/frontend/${CPANEL_THEME}/serverscrub/index.php",
    "icon":     "serverscrub.png"
  }
]
JSONEOF
      chmod 644 "${CPANEL_PLUGIN_DIR}/install.json"

      # Run install_plugin if the binary exists (modern method)
      if [[ -x /usr/local/cpanel/scripts/install_plugin ]]; then
        _INS_OUT=$(/usr/local/cpanel/scripts/install_plugin \
          "${CPANEL_PLUGIN_DIR}" --theme "${CPANEL_THEME}" 2>&1)
        _INS_EXIT=$?
        echo "${_INS_OUT}" | sed 's/^/    /'
        if [[ ${_INS_EXIT} -eq 0 ]]; then
          ok "  install_plugin: ${CPANEL_THEME}"
        else
          warn "  install_plugin failed for ${CPANEL_THEME} — dynamicui fallback active"
        fi
      else
        info "  install_plugin not found — using dynamicui conf only"
      fi

      # Legacy dynamicui conf (works on all cPanel versions, parallel to install_plugin)
      DYNUI_DIR="${CPANEL_THEME_BASE}/dynamicui"
      if [[ -d "${DYNUI_DIR}" ]]; then
        DYNUI_CONF="${DYNUI_DIR}/dynamicui_serverscrub.conf"
        cat > "${DYNUI_CONF}" << DYNEOF
group=security
groupdesc=Security
grouporder=30
name=serverscrub
itemdesc=ServerScrub Security
imgtype=icon
icon=serverscrub.png
url=/frontend/${CPANEL_THEME}/serverscrub/index.php
target=_blank
itemorder=1
DYNEOF
        chmod 644 "${DYNUI_CONF}"
        ok "  DynamicUI conf: ${DYNUI_CONF}"
        echo "DYNUI_${CPANEL_THEME}=${DYNUI_CONF}" >> "${MANIFEST}"
      fi
      echo "CPANEL_PLUGIN_${CPANEL_THEME}=${CPANEL_PLUGIN_DIR}" >> "${MANIFEST}"
    done

    # cPanel-level AppConfig entry (service=cpanel) — integrates with cPanel security framework
    # features=any means ALL cPanel users see it regardless of their feature list
    CPANEL_APPCONF="${WHM_CGI_DIR}/serverscrub_cpanel.conf"
    rm -f /var/cpanel/apps/serverscrub_cpanel.conf 2>/dev/null || true
    cat > "${CPANEL_APPCONF}" << CPANELEOF
name=serverscrub_cpanel
service=cpanel
url=/frontend/jupiter/serverscrub/index.php
features=any
displayname=ServerScrub Security
CPANELEOF
    chmod 644 "${CPANEL_APPCONF}"
    if [[ -x /usr/local/cpanel/bin/register_appconfig ]]; then
      _CREG_OUT=$(/usr/local/cpanel/bin/register_appconfig "${CPANEL_APPCONF}" 2>&1)
      echo "${_CREG_OUT}" | sed 's/^/    /'
      ok "  cPanel AppConfig registered (service=cpanel, features=any)"
      [[ -f /var/cpanel/apps/serverscrub_cpanel.conf ]] && \
        echo "CPANEL_APPCONFIG=/var/cpanel/apps/serverscrub_cpanel.conf" >> "${MANIFEST}"
    fi

    # ── Step 7: Feature flags — enable ServerScrub for all cPanel users ─────
    # Feature flags control which icons appear in a cPanel user's dashboard.
    # Adding serverscrub=1 to the 'default' feature list means it's ON for
    # every account unless an admin or reseller explicitly disables it.
    # NOTE ON THE FEATURE GATE
    #
    # install.json and the dynamicui conf no longer carry feature=serverscrub.
    # cPanel hides an item whose feature is not enabled in the user's feature
    # list, and only /var/cpanel/features/default was ever updated -- so every
    # account on a reseller's own feature list, which is most of them on a
    # reseller box, had the entry hidden. The request was that every cPanel user
    # and reseller can reach this, so the item is no longer gated.
    #
    # The flags below are still written: they cost nothing, they are recorded in
    # the manifest so the uninstaller removes them, and an operator who later
    # wants per-package control can add the feature key back and have the lists
    # already populated.
    info "  Writing feature flags…"
    # Modern location (cPanel 11.44+ / CENTOS 7+ — the authoritative path)
    mkdir -p /var/cpanel/features
    # Every list, not just 'default'. A reseller's accounts sit on that
    # reseller's own list, and writing only to default left them out.
    _SG_FEAT_N=0
    for _fl in /var/cpanel/features/*; do
      [[ -f "$_fl" ]] || continue
      grep -q "^serverscrub=" "$_fl" 2>/dev/null || echo "serverscrub=1" >> "$_fl"
      _SG_FEAT_N=$((_SG_FEAT_N + 1))
    done
    grep -q "^serverscrub=" /var/cpanel/features/default 2>/dev/null || \
      echo "serverscrub=1" >> /var/cpanel/features/default
    ok "  Feature flag written to ${_SG_FEAT_N} feature list(s)"
    echo "FEATURE_FLAG_MODERN=/var/cpanel/features/default" >> "${MANIFEST}"
    # Legacy location (older cPanel — kept for compatibility)
    _LEGACY_FEAT="/usr/local/cpanel/cpanel/features"
    if [[ -d "${_LEGACY_FEAT}" ]]; then
      grep -q "^serverscrub=" "${_LEGACY_FEAT}/default" 2>/dev/null || \
        echo "serverscrub=1" >> "${_LEGACY_FEAT}/default"
      ok "  Feature flag (legacy): ${_LEGACY_FEAT}/default"
      echo "FEATURE_FLAG_LEGACY=${_LEGACY_FEAT}/default" >> "${MANIFEST}"
    fi

    # ── Step 8: Restart cpsrvd if register_appconfig didn't already do it ────
    # register_appconfig normally handles this, but we restart explicitly as a
    # safety net in case the binary was missing or the conf was copied manually.
    if ! $_REG_OK; then
      info "  Manually restarting cpsrvd (register_appconfig fallback)…"
      if [[ -x /usr/local/cpanel/scripts/restartsrv_cpsrvd ]]; then
        /usr/local/cpanel/scripts/restartsrv_cpsrvd 2>&1 | tail -4 | sed 's/^/    /'
        ok "  cpsrvd restarted"
      fi
    fi

    # ── Step 9: Post-registration verification ────────────────────────────────
    info "  Verifying plugin registration (give cpsrvd 3s to settle)…"
    sleep 3
    _VERIFIED=false
    if command -v whmapi1 >/dev/null 2>&1; then
      _APP_LIST=$(whmapi1 appconfig_get_apps 2>/dev/null)
      if echo "${_APP_LIST}" | grep -q "serverscrub"; then
        ok "  VERIFIED via whmapi1: ServerScrub is live in WHM Plugins menu"
        _VERIFIED=true
      else
        warn "  whmapi1 does not yet list serverscrub"
        warn "  If plugin is not visible in WHM → Plugins, try: Log out and log back in to WHM"
      fi
    fi
    if ! $_VERIFIED && [[ -f /var/cpanel/apps/serverscrub.conf ]]; then
      ok "  /var/cpanel/apps/serverscrub.conf exists — plugin should appear after WHM re-login"
      _VERIFIED=true
    fi
    $_VERIFIED || warn "  Registration could not be verified — check WHM manually"

  fi  # end: if [[ ! -d /usr/local/cpanel ]]

fi  # end: if standalone / elif cpanel

# ── Firewall measurements ─────────────────────────────────────────────────────
# Taken once now so the firewall page has a reading immediately. The scheduler
# refreshes them from then on; nothing is measured on a page load, because a
# request that waits on the xtables lock stalls every other page with it.
section "Firewall measurements"
_SG_FWP="${TMP_DIR:-/tmp}/sg-fwprobe.php"
cat > "$_SG_FWP" <<FWEOF
<?php
define('SG_API', true);
require_once '${INSTALL_DIR}/backend/config/config.php';
require_once '${INSTALL_DIR}/backend/lib/Database.php';
require_once '${INSTALL_DIR}/backend/lib/Logger.php';
require_once '${INSTALL_DIR}/backend/lib/Firewall.php';
\$r = Firewall::refreshProbes();
echo 'iptables rules: ' . \$r['iptables_rules'] . PHP_EOL;
FWEOF
if _SG_FWP_OUT="$(timeout 30 "$SG_PHP" "$_SG_FWP" 2>&1)"; then
  ok "  ${_SG_FWP_OUT}"
else
  info "  Could not measure now; the scheduler will do it shortly"
fi
rm -f "$_SG_FWP"

# ── Rootkit scanning tools ────────────────────────────────────────────────────
# The Rootkit Scanner page offered rkhunter and chkrootkit and then reported
# both "Not installed", leaving the operator to work out what to do about it.
# A tool the product offers should be present when the product is.
#
# ON EPEL: on RHEL-family hosts these two live in EPEL, and cPanel cautions
# against enabling it because it can shadow packages cPanel manages. So EPEL is
# installed with the repository DISABLED and enabled for this one transaction
# only (--enablerepo=epel). Nothing else on the server is exposed to it, now or
# at the next update.
#
# None of this is fatal: RootkitEngine is built in and needs neither tool.
if ! $REGISTER_ONLY && ! $SKIP_DEPS && ! $SKIP_ROOTKIT_TOOLS; then
  section "Rootkit scanning tools"

  _RK_HAVE=true
  command -v rkhunter   >/dev/null 2>&1 || _RK_HAVE=false
  command -v chkrootkit >/dev/null 2>&1 || _RK_HAVE=false

  if $_RK_HAVE; then
    ok "  rkhunter and chkrootkit are already installed"
  else
    _RK_PM=""
    if   command -v apt-get >/dev/null 2>&1; then _RK_PM=apt
    elif command -v dnf     >/dev/null 2>&1; then _RK_PM=dnf
    elif command -v yum     >/dev/null 2>&1; then _RK_PM=yum
    fi

    case "$_RK_PM" in
      apt)
        info "  Installing rkhunter and chkrootkit (apt)…"
        DEBIAN_FRONTEND=noninteractive apt-get install -y -q rkhunter chkrootkit >/dev/null 2>&1 || true
        ;;
      dnf|yum)
        # Try the configured repositories first: a host that already carries
        # these packages needs nothing doing to it.
        info "  Installing rkhunter and chkrootkit…"
        $_RK_PM install -y -q rkhunter chkrootkit >/dev/null 2>&1 || true

        if ! command -v rkhunter >/dev/null 2>&1 || ! command -v chkrootkit >/dev/null 2>&1; then
          if [[ ! -f /etc/yum.repos.d/epel.repo ]]; then
            info "  Adding EPEL (disabled by default) for these two packages…"
            $_RK_PM install -y -q epel-release >/dev/null 2>&1 || true
            # Disabled unless explicitly asked for, so EPEL cannot take part in
            # any later transaction on a cPanel server.
            if [[ -f /etc/yum.repos.d/epel.repo ]]; then
              sed -i 's/^enabled=1/enabled=0/' /etc/yum.repos.d/epel.repo 2>/dev/null || true
              echo "EPEL_ADDED=1" >> "${MANIFEST}"
            fi
          fi
          $_RK_PM install -y -q --enablerepo=epel rkhunter chkrootkit >/dev/null 2>&1 || true
        fi
        ;;
      *)
        warn "  No supported package manager — skipping rootkit tools"
        ;;
    esac

    # Report what actually happened rather than assuming the install worked.
    _RK_OK=0
    if command -v rkhunter >/dev/null 2>&1; then
      ok "  rkhunter installed"; _RK_OK=$((_RK_OK+1))
      echo "ROOTKIT_TOOL_RKHUNTER=1" >> "${MANIFEST}"
    else
      warn "  rkhunter unavailable"
    fi
    if command -v chkrootkit >/dev/null 2>&1; then
      ok "  chkrootkit installed"; _RK_OK=$((_RK_OK+1))
      echo "ROOTKIT_TOOL_CHKROOTKIT=1" >> "${MANIFEST}"
    else
      warn "  chkrootkit unavailable"
    fi
    if [[ $_RK_OK -eq 0 ]]; then
      info "  The built-in rootkit engine needs neither tool and is used instead."
    fi
  fi

  # rkhunter compares system binaries against a database of their expected
  # properties. Until that database exists every binary looks modified, so the
  # first scan is a wall of warnings that means nothing. Build it now, in the
  # background: on a large server this takes a while and must not hold up the
  # install.
  if command -v rkhunter >/dev/null 2>&1; then
    if [[ ! -f /var/lib/rkhunter/db/rkhunter.dat ]]; then
      info "  Initialising rkhunter's file property database in the background…"
      nohup rkhunter --propupd --nocolors >/dev/null 2>&1 &
      disown 2>/dev/null || true
    fi
  fi
fi

# ── Apache restart (cpanel mode) ─────────────────────────────────────────────
if [[ "$INSTALL_MODE" == "cpanel" ]]; then
# ── Stop anything still scanning ──────────────────────────────────────────────
# An upgrade replaces the code underneath any worker that is mid-scan. Those
# workers are detached, so nothing else stops them: they keep running the old
# code against a database this installer may have just migrated, and they keep
# their clamscan processes -- which is how a server ends up with several at
# once in the first place. Stop them before the new scheduler can start more.
section "Stopping running scans"
_SG_STOPALL="${TMP_DIR:-/tmp}/sg-stopall.php"
cat > "$_SG_STOPALL" <<STOPEOF
<?php
define('SG_API', true);
require_once '${INSTALL_DIR}/backend/config/config.php';
require_once '${INSTALL_DIR}/backend/lib/Database.php';
require_once '${INSTALL_DIR}/backend/lib/Logger.php';
require_once '${INSTALL_DIR}/backend/lib/Scanner.php';
\$r = Scanner::stopAllScans();
echo \$r['message'] . PHP_EOL;
STOPEOF
if _SG_STOP_OUT="$("$SG_PHP" "$_SG_STOPALL" 2>&1)"; then
  ok "  ${_SG_STOP_OUT}"
else
  # A fresh install has no database yet; nothing to stop is the normal case.
  info "  No running scans to stop"
fi
rm -f "$_SG_STOPALL"

# Stale slot locks from workers that were killed rather than exiting. The
# kernel releases a lock when its process dies, so these files are only ever
# empty husks -- but leaving them is untidy and confuses manual inspection.
rm -f /tmp/serverscrub/scan.lock.* 2>/dev/null || true

# ── Per-user reports ──────────────────────────────────────────────────────────
# Generated now so the cPanel menu entry has something to show immediately.
# Without this the first thing every user sees is "no report yet", until the
# next scheduled scan -- which on a weekly schedule is a week of the plugin
# looking broken.
section "Per-user security reports"
_SG_REPORTS="${TMP_DIR:-/tmp}/sg-reports.php"
cat > "$_SG_REPORTS" <<REPEOF
<?php
define('SG_API', true);
require_once '${INSTALL_DIR}/backend/config/config.php';
require_once '${INSTALL_DIR}/backend/lib/Database.php';
require_once '${INSTALL_DIR}/backend/lib/Logger.php';
require_once '${INSTALL_DIR}/backend/lib/UserReport.php';
\$r = UserReport::writeAll();
echo 'Reports written: ' . \$r['written'] . ', skipped: ' . \$r['skipped'] . PHP_EOL;
REPEOF
if _SG_REP_OUT="$("$SG_PHP" "$_SG_REPORTS" 2>&1)"; then
  ok "  ${_SG_REP_OUT}"
else
  # Not fatal: the scheduler writes these after every scan anyway.
  warn "  Could not generate per-user reports yet — they will appear after the next scan"
fi
rm -f "$_SG_REPORTS"

section "Restarting Apache"
  if command -v /scripts/restartsrv_httpd >/dev/null 2>&1; then
    /scripts/restartsrv_httpd 2>&1 | tail -4 | sed 's/^/  /'
    ok "Apache restarted"
  elif command -v httpd >/dev/null 2>&1; then
    httpd -t 2>&1 && systemctl restart httpd 2>&1 && ok "Apache restarted" || warn "Apache restart failed — restart manually"
  elif command -v apache2 >/dev/null 2>&1; then
    apache2ctl -t 2>&1 && systemctl restart apache2 2>&1 && ok "Apache restarted" || warn "Apache restart failed — restart manually"
  else
    warn "Could not detect Apache — restart it manually to activate the config"
  fi
fi

# ── Post-install test suite ───────────────────────────────────────────────────
section "Post-install verification"

TEST_SCRIPT="${SCRIPT_DIR}/test.sh"
TEST_EXIT=0

if [[ -f "$TEST_SCRIPT" ]]; then
  # Give Apache/cpsrvd a moment to fully apply the new config
  info "Waiting 10 seconds for services to settle…"
  sleep 10
  echo ""
  bash "$TEST_SCRIPT"
  TEST_EXIT=$?
else
  warn "test.sh not found in ${SCRIPT_DIR} — skipping verification"
fi

# ── Outcome ───────────────────────────────────────────────────────────────────
echo ""
if [[ $TEST_EXIT -eq 0 ]]; then
  echo -e "${CYAN}${BOLD}══════════════════════════════════════════════════════${NC}"
  echo -e "${GREEN}${BOLD}  ServerScrub v${SG_VERSION} installed successfully!${NC}"
  echo -e "${CYAN}${BOLD}══════════════════════════════════════════════════════${NC}"
  echo ""

  if [[ "$INSTALL_MODE" == "cpanel" ]]; then
    echo -e "  ${BOLD}Access:${NC}  WHM → Plugins → ServerScrub Security"
    echo -e "  ${BOLD}Also:${NC}    https://$(hostname -f 2>/dev/null || hostname)/serverscrub/"
  elif [[ "$INSTALL_MODE" == "standalone" ]]; then
    echo -e "  ${BOLD}Access:${NC}  http://$(hostname -f 2>/dev/null || hostname):${SG_PORT}"
    if $GENERATED_PASS; then
      echo ""
      echo -e "  ${YELLOW}${BOLD}┌─ GENERATED ADMIN PASSWORD — SAVE THIS NOW ─────────────┐${NC}"
      echo -e "  ${YELLOW}${BOLD}│${NC}  Username:  ${BOLD}${ADMIN_USER}${NC}"
      echo -e "  ${YELLOW}${BOLD}│${NC}  Password:  ${BOLD}${ADMIN_PASS}${NC}"
      echo -e "  ${YELLOW}${BOLD}└────────────────────────────────────────────────────────┘${NC}"
      echo -e "  It is not stored anywhere in plaintext. Change it after first login."
    else
      echo -e "  ${BOLD}Login:${NC}   ${ADMIN_USER} / (password you set)"
    fi
  fi

  echo ""
  # Activation is the required next step, and without saying so the operator
  # opens the dashboard, finds every feature refused, and reasonably concludes
  # the install failed.
  echo -e "  ${YELLOW}${BOLD}┌─ 3-DAY TRIAL ACTIVE ───────────────────────────────────┐${NC}"
  echo -e "  ${YELLOW}${BOLD}│${NC}  Full protection is running for the next 3 days."
  echo -e "  ${YELLOW}${BOLD}│${NC}  Activate a licence before then to keep it running."
  echo -e "  ${YELLOW}${BOLD}│${NC}"
  echo -e "  ${YELLOW}${BOLD}│${NC}  From the dashboard: an activation screen is shown on"
  echo -e "  ${YELLOW}${BOLD}│${NC}  first sign-in — paste your key there."
  echo -e "  ${YELLOW}${BOLD}│${NC}"
  echo -e "  ${YELLOW}${BOLD}│${NC}  Or from the shell:"
  echo -e "  ${YELLOW}${BOLD}│${NC}    ${BOLD}serverscrub license activate <your-key>${NC}"
  echo -e "  ${YELLOW}${BOLD}└────────────────────────────────────────────────────────┘${NC}"
  echo ""
  echo -e "  ${BOLD}Install dir:${NC}  ${INSTALL_DIR}"
  echo -e "  ${BOLD}Manifest:${NC}     ${MANIFEST}"
  echo -e "  ${BOLD}Logs:${NC}         ${LOG_DIR}/"
  echo ""
  echo -e "  To uninstall: ${CYAN}bash ${SCRIPT_DIR}/uninstall.sh${NC}"
  echo ""

else
  echo -e "${RED}${BOLD}══════════════════════════════════════════════════════${NC}"
  echo -e "${RED}${BOLD}  Installation verification failed — ${TEST_EXIT} test(s) failed${NC}"
  echo -e "${RED}${BOLD}══════════════════════════════════════════════════════${NC}"
  echo ""
  # During an upgrade (--register-only) NEVER offer uninstall — that would wipe
  # customer data. Just report and exit non-zero so update.sh can warn.
  if $REGISTER_ONLY; then
    warn "Re-registration self-tests reported failures — install left intact."
    info "Review the FAIL lines above and re-run: bash ${SCRIPT_DIR}/test.sh"
    exit 1
  fi
  echo -e "  The plugin was installed but one or more self-tests failed."
  echo -e "  ${BOLD}What would you like to do?${NC}"
  echo ""
  echo -e "  ${CYAN}1)${NC} Keep the installation — I'll fix the issues manually"
  echo -e "  ${CYAN}2)${NC} Automatically uninstall and clean up everything"
  echo ""
  if [[ -t 0 ]]; then
    read -rp "  Choice [1/2]: " ROLLBACK_CHOICE
  else
    info "Non-interactive shell detected — keeping installation (default)"
    ROLLBACK_CHOICE=1
  fi

  if [[ "${ROLLBACK_CHOICE}" == "2" ]]; then
    echo ""
    warn "Rolling back installation…"
    bash "${SCRIPT_DIR}/uninstall.sh" --auto
    echo ""
    echo -e "${YELLOW}${BOLD}  Uninstall complete. Fix the failed tests above, then re-run install.sh.${NC}"
    echo ""
    exit 1
  else
    echo ""
    info "Installation kept."
    info "Review the FAIL lines above, fix the issues, then run:"
    echo -e "  ${CYAN}bash ${SCRIPT_DIR}/test.sh${NC}"
    echo ""
    exit 1
  fi
fi
