<?php
/* This class pulls in what it uses.
 *
 * It used to pull in nothing and rely on every caller having required the
 * right things first. scheduler.php and user-scans.php did; the CLI did not,
 * so `serverscrub user-reports` hit
 *
 *     Error: Class "UserScanRequest" not found
 *
 * inside build(), which writeAll() catches per account and counts as a skip.
 * The CLI then reported "0 written, 132 skipped - accounts have no usable
 * home directory", a cause it had invented, and every customer's report.json
 * stayed frozen at whatever was last written.
 *
 * A class that depends on the caller's include list is a class that breaks
 * whenever a new caller appears, and breaks silently when the caller catches
 * Throwable. require_once is idempotent; this costs nothing.
 */
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/UserScanRequest.php';

/**
 * Per-user security reports for the cPanel-side plugin.
 *
 * WHY A FILE AND NOT AN API CALL
 *
 * The cPanel plugin page runs as the cPanel user, under cpsrvd. The database
 * lives in /usr/local/serverscrub/database, which is 0700 root, and the API
 * that reads it requires an admin role. A user process therefore cannot reach
 * any of it, and the alternatives -- a setuid helper, or relaxing those
 * permissions -- would hand every hosting customer on the box a path to the
 * server-wide security database.
 *
 * So the privileged side does the reading. This class runs as root, after the
 * scans that produce the data, and writes each user a small JSON file inside
 * their own home directory. The plugin page reads nothing else. Cross-user
 * disclosure is then impossible by construction rather than by a filter
 * somebody has to remember to apply: user A's report is in user A's home,
 * owned by user A, and user B's process cannot open it.
 *
 * WRITING INTO A DIRECTORY THE USER CONTROLS
 *
 * Every write here is root writing into a path a hostile user can rearrange
 * between one call and the next. A symlink at ~/.serverscrub, or at
 * report.json, would make root overwrite whatever it points at -- /etc/shadow,
 * an authorized_keys file, anything. Each step below therefore verifies what
 * it is about to touch and refuses rather than following a link.
 */

class UserReport
{
    /** Directory created inside each user's home. */
    private const DIR = '.serverscrub';

    /** How many rows of each kind a report carries. */
    private const LIMIT = 200;

    /**
     * cPanel usernames are lowercase alphanumeric with dashes/underscores.
     * Anything else must never reach a filesystem path.
     */
    public static function validUsername(string $user): bool
    {
        return $user !== ''
            && strlen($user) <= 64
            && preg_match('/^[a-z0-9][a-z0-9_-]*$/', $user) === 1;
    }

    /** Every cPanel account on this server. */
    public static function listUsers(): array
    {
        $users = [];
        foreach (glob('/var/cpanel/users/*') ?: [] as $f) {
            if (!is_file($f)) {
                continue;
            }
            $name = basename($f);
            if (self::validUsername($name)) {
                $users[] = $name;
            }
        }
        sort($users);
        return $users;
    }

    /**
     * The user's home directory, confirmed to be a real directory that they
     * own. A home that is a symlink, or owned by somebody else, is not written
     * to: both are signs the account has been tampered with, and following
     * either would have root writing somewhere it was not asked to.
     */
    public static function homeDir(string $user): ?string
    {
        if (!self::validUsername($user)) {
            return null;
        }

        $home = null;
        if (function_exists('posix_getpwnam')) {
            $pw = @posix_getpwnam($user);
            if (is_array($pw) && !empty($pw['dir'])) {
                $home = $pw['dir'];
            }
        }
        if ($home === null) {
            $candidate = '/home/' . $user;
            $home = is_dir($candidate) ? $candidate : null;
        }
        if ($home === null || is_link($home) || !is_dir($home)) {
            return null;
        }

        // Root's own view of who owns it, not the user's claim.
        $uid = @fileowner($home);
        if ($uid === false) {
            return null;
        }
        if (function_exists('posix_getpwnam')) {
            $pw = @posix_getpwnam($user);
            if (is_array($pw) && isset($pw['uid']) && (int)$pw['uid'] !== (int)$uid) {
                return null;
            }
        }
        return rtrim($home, '/');
    }

    /**
     * Every domain this account owns.
     *
     * Needed because the interesting per-account security data is keyed on a
     * DOMAIN, not a username: a WAF event knows the host it was aimed at, and
     * nothing else ties it to a customer. Read from the account's own cPanel
     * file, where DNS= is the main domain and DNS1..DNSn are the addon,
     * parked and sub domains.
     *
     * Bounded, and every value validated. This feeds SQL placeholders and a
     * page, and the file is writable by cPanel rather than by us.
     *
     * @return string[]
     */
    public static function domainsFor(string $user): array
    {
        if (!self::validUsername($user)) { return []; }
        $path = '/var/cpanel/users/' . $user;
        if (is_link($path) || !is_file($path) || !is_readable($path)) { return []; }
        if ((int) @filesize($path) > 262144) { return []; }

        $out = [];
        foreach (preg_split('/
?
/', (string) @file_get_contents($path)) ?: [] as $line) {
            if (!preg_match('/^DNS\d*=(.+)$/', trim($line), $m)) { continue; }
            $d = strtolower(trim($m[1]));
            // A hostname, and nothing that could be a wildcard or a pattern.
            if ($d === '' || strlen($d) > 253) { continue; }
            if (!preg_match('/^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$/', $d)) { continue; }
            $out[$d] = true;
            if (count($out) >= 200) { break; }
        }
        return array_keys($out);
    }

    /**
     * Placeholders and parameters for "host IN (...)", or null when the
     * account has no domains.
     *
     * Returning null rather than an empty IN list matters: "host IN ()" is a
     * syntax error in SQLite, and "WHERE host IN (NULL)" silently matches
     * nothing while looking like it works.
     *
     * @return array{0:string,1:array}|null
     */
    private static function inClause(array $values): ?array
    {
        $values = array_values(array_filter($values, 'strlen'));
        if ($values === []) { return null; }
        return [implode(',', array_fill(0, count($values), '?')), $values];
    }

    /** The report's path for a user, or null if the home is unusable. */
    public static function reportPath(string $user): ?string
    {
        $home = self::homeDir($user);
        return $home === null ? null : $home . '/' . self::DIR . '/report.json';
    }

    /**
     * A query whose table may not exist yet.
     *
     * cms_installs and file_integrity are created lazily by the modules that
     * own them, so on a server where CMS Guard or integrity monitoring has
     * never run they are simply absent. Querying one threw a PDOException that
     * aborted the whole report -- which is the hourly task, for every account
     * on the server. A module that has not run yet means "nothing to report",
     * not "reporting is broken".
     */
    private static function safeFetch(string $sql, array $params): array
    {
        try {
            return Database::fetchAll($sql, $params);
        } catch (Throwable $e) {
            if (stripos($e->getMessage(), 'no such table') === false) {
                Logger::warn('UserReport query failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /**
     * Build the report body for one user.
     *
     * Everything is filtered by the username the CALLER supplies, which comes
     * from the account list -- never from a request parameter.
     */
    public static function build(string $user, ?string $home = null): array
    {
        // The caller may already have resolved the home (writeFor does, and it
        // must not resolve twice -- the account could change underneath).
        $home = $home ?? self::homeDir($user);

        // Threats are matched on cpanel_user where the scan recorded it, and
        // on the home prefix otherwise: older rows predate that column.
        $prefix = ($home ?? ('/home/' . $user)) . '/';
        $threats = self::safeFetch(
            "SELECT file_path, threat_name, threat_type, severity, status,
                    detected_at, action_taken
               FROM threats
              WHERE (cpanel_user = ? OR file_path LIKE ?)
                AND status != 'deleted'
              ORDER BY detected_at DESC
              LIMIT " . self::LIMIT,
            [$user, $prefix . '%']
        );

        $cms = self::safeFetch(
            "SELECT cms_type, version, install_path, outdated, status, issues, last_check
               FROM cms_installs
              WHERE cpanel_user = ?
              ORDER BY outdated DESC, cms_type ASC
              LIMIT " . self::LIMIT,
            [$user]
        );

        // Integrity rows have no user column; the path prefix is what ties a
        // change to an account.
        $changes = self::safeFetch(
            "SELECT file_path, status, last_check
               FROM file_integrity
              WHERE file_path LIKE ? AND status != 'clean'
              ORDER BY last_check DESC
              LIMIT " . self::LIMIT,
            [$prefix . '%']
        );

        $active = 0;
        foreach ($threats as &$t) {
            if (($t['status'] ?? '') === 'active') {
                $active++;
            }
            // Relative paths: the absolute path adds nothing for someone who
            // only has one home directory, and it is longer than the column.
            $t['relative_path'] = $home !== null && strpos($t['file_path'], $prefix) === 0
                ? substr($t['file_path'], strlen($prefix))
                : $t['file_path'];
        }
        unset($t);

        $outdated = 0;
        foreach ($cms as &$c) {
            if ((int)($c['outdated'] ?? 0) === 1) {
                $outdated++;
            }
            $decoded = json_decode((string)($c['issues'] ?? '[]'), true);
            $c['issues'] = is_array($decoded)
                ? array_values(array_map(
                    fn($i) => is_array($i) ? (string)($i['type'] ?? '') : (string)$i,
                    $decoded
                  ))
                : [];
            $c['relative_path'] = $home !== null && strpos($c['install_path'], $prefix) === 0
                ? substr($c['install_path'], strlen($prefix))
                : $c['install_path'];
        }
        unset($c);

        foreach ($changes as &$ch) {
            $ch['relative_path'] = $home !== null && strpos($ch['file_path'], $prefix) === 0
                ? substr($ch['file_path'], strlen($prefix))
                : $ch['file_path'];
        }
        unset($ch);

        // ── The per-domain data ────────────────────────────────────────────
        //
        // WAF events and security events are keyed on a HOST, which is the
        // only thing that ties them to a customer. An account with no domains
        // gets empty lists rather than a query with an empty IN clause --
        // "host IN ()" is a syntax error, and "IN (NULL)" matches nothing
        // while looking like it worked.
        $domains = self::domainsFor($user);
        $in      = self::inClause($domains);
        $since30 = time() - (30 * 86400);

        $waf = [];
        $attacks = [];
        if ($in !== null) {
            [$ph, $args] = $in;
            $waf = self::safeFetch(
                "SELECT rule_id, rule_msg, severity, ip_address, uri, method,
                        host, action, timestamp
                   FROM waf_events
                  WHERE host IN ($ph)
                  ORDER BY timestamp DESC
                  LIMIT " . self::LIMIT,
                $args
            );
            $attacks = self::safeFetch(
                "SELECT type, severity, source_ip, target, description, timestamp
                   FROM security_events
                  WHERE target IN ($ph)
                  ORDER BY timestamp DESC
                  LIMIT " . self::LIMIT,
                $args
            );
        }

        // Scan history for THIS account. scan_path is the directory a job
        // covered, so a job over the whole of /home counts for everybody and a
        // job over one home counts for that account only.
        $scans = self::safeFetch(
            "SELECT id, scan_type, status, started_at, finished_at,
                    files_scanned, threats_found, scan_path, requested_by,
                    stop_reason
               FROM scan_jobs
              WHERE scan_path = ? OR scan_path = ? OR ? LIKE scan_path || '%'
              ORDER BY COALESCE(started_at, created_at) DESC
              LIMIT 25",
            [rtrim($prefix, '/'), $prefix, rtrim($prefix, '/')]
        );

        /**
         * Who started each scan, in words the account owner can act on.
         *
         * Asked for after a customer looked at this table and could not tell
         * which rows were the nightly server sweep and which were their own
         * -- every row said "full" and nothing said who.
         *
         * The row's raw requested_by NEVER reaches the page. This list can
         * contain server-wide scans, because a scan of /home covers
         * /home/thisuser, and printing the name on such a row would hand one
         * customer another customer's account name. Anything that is not this
         * account is described by its role instead.
         */
        foreach ($scans as $i => $row) {
            $by = trim((string) ($row['requested_by'] ?? ''));
            if ($by === $user && $by !== '') {
                $who = 'you';
            } elseif ($by === '@schedule') {
                $who = 'schedule';
            } elseif ($by === '@operator' || $by === '@cli') {
                $who = 'provider';
            } elseif ($by === '') {
                // Rows from before this was recorded. "Unknown" is honest;
                // guessing "schedule" would be wrong for every scan an
                // operator ever started by hand.
                $who = 'unknown';
            } else {
                // Another account's request. Its existence is already visible
                // through the row; its name is not ours to pass on.
                $who = 'provider';
            }
            $scans[$i]['triggered_by'] = $who;
            unset($scans[$i]['requested_by']);
        }

        /**
         * What each scan actually found IN THIS ACCOUNT.
         *
         * The log showed a Threats number and nothing behind it, so a
         * customer could be told a scan found three things and had no way to
         * learn which files, or what had become of them. "Detected" and
         * "detected, quarantined, and here is where it went" are very
         * different things to be told about your own website.
         *
         * TWO corrections happen here, and the second matters more.
         *
         * 1. The count. scan_jobs.threats_found is SERVER-WIDE. A nightly
         *    /home sweep that found three webshells in three other people's
         *    accounts showed this customer "3" -- a number about somebody
         *    else, on their own page, with their name nowhere near it. The
         *    count is recomputed from their own files.
         *
         * 2. The list. Which is why it is scoped the same way the threats
         *    table above is, by cpanel_user or the home prefix. A /home scan
         *    covers every account on the server; listing its findings
         *    unfiltered would hand one customer the paths, filenames and
         *    malware names inside another customer's site.
         *
         * Unlike the Detected-threats card this does NOT hide status
         * 'deleted'. What happened to the file is half the question being
         * asked, and a scan that found two and removed both would otherwise
         * read as a scan that found nothing.
         */
        $byScan = [];
        $jobIds = [];
        foreach ($scans as $row) {
            $jid = (int) ($row['id'] ?? 0);
            if ($jid > 0) { $jobIds[] = $jid; $byScan[$jid] = []; }
        }
        if ($jobIds) {
            $in = self::inClause($jobIds);
            if ($in !== null) {
                // inClause() returns [placeholders, values] POSITIONALLY, and
                // the placeholders are bare "?,?,?" with no IN(...) around
                // them. Read as $in['sql'] / $in['params'] it yields null and
                // an empty array, so the query became
                //
                //     WHERE scan_job_id  AND (cpanel_user = ? OR ...)
                //
                // -- a syntax error, on every account, which safeFetch turned
                // into a skip. "0 written, 132 skipped": every customer's
                // report frozen, and the page silently serving whatever was
                // last written before 4.29.0.
                [$ph, $jobArgs] = $in;
                // Bounded: 25 scans are listed, and a single bad night can
                // produce thousands of findings. This is written into every
                // account's home on a schedule.
                $rows = self::safeFetch(
                    "SELECT scan_job_id, file_path, threat_name, threat_type,
                            severity, status, detected_at, action_taken
                       FROM threats
                      WHERE scan_job_id IN (" . $ph . ")
                        AND (cpanel_user = ? OR file_path LIKE ?)
                      ORDER BY detected_at DESC
                      LIMIT 200",
                    array_merge($jobArgs, [$user, $prefix . '%'])
                );
                foreach ($rows as $t) {
                    $jid = (int) ($t['scan_job_id'] ?? 0);
                    if (!isset($byScan[$jid])) { continue; }
                    if (count($byScan[$jid]) >= 50) { continue; }
                    unset($t['scan_job_id']);
                    // The path is already inside this account; show it
                    // relative to home so it reads like their own file tree.
                    $t['relative_path'] = (strpos((string) $t['file_path'], $prefix) === 0)
                        ? substr((string) $t['file_path'], strlen($prefix))
                        : (string) $t['file_path'];
                    $byScan[$jid][] = $t;
                }
            }
        }
        foreach ($scans as $i => $row) {
            $jid = (int) ($row['id'] ?? 0);
            $scans[$i]['threats_found'] = count($byScan[$jid] ?? []);
        }
        // Returned below, alongside 'scans'.

        // Thirty-day counters for the dashboard tiles.
        $cnt = static function (string $sql, array $a): int {
            $r = self::safeFetch($sql, $a);
            return (int) ($r[0]['c'] ?? 0);
        };
        $threats30 = $cnt(
            "SELECT COUNT(*) AS c FROM threats
              WHERE (cpanel_user = ? OR file_path LIKE ?)
                AND status != 'deleted' AND detected_at >= ?",
            [$user, $prefix . '%', $since30]
        );
        $attacks30 = 0;
        if ($in !== null) {
            [$ph, $args] = $in;
            $attacks30 = $cnt(
                "SELECT COUNT(*) AS c FROM waf_events
                  WHERE host IN ($ph) AND timestamp >= ?",
                array_merge($args, [$since30])
            );
        }

        return [
            'schema'       => 1,
            'user'         => $user,
            'generated_at' => time(),
            'version'      => defined('SG_VERSION') ? SG_VERSION : 'unknown',
            'last_scan_at' => (int) Database::setting('last_run_scan', '0'),
            'summary'      => [
                'threats'        => count($threats),
                'threats_active' => $active,
                'cms_installs'   => count($cms),
                'cms_outdated'   => $outdated,
                'file_changes'   => count($changes),
            ],
            'threats'      => $threats,
            'cms'          => $cms,
            'file_changes' => $changes,
            // What the page needs to render the Scan button honestly: whether
            // the feature is on, whether this account already has a request
            // waiting, and how long until it may ask again. Computed here as
            // root, because the page cannot read any of it.
            'scan_request' => UserScanRequest::statusFor($user),
            'domains'      => $domains,
            'waf'          => $waf,
            'attacks'      => $attacks,
            'scans'        => $scans,
            'scan_threats' => $byScan,
            'stats30'      => [
                'threats'    => $threats30,
                'attacks'    => $attacks30,
                'cms_issues' => $outdated,
            ],
        ];
    }

    /**
     * Write one user's report. Returns the path written, or null.
     */
    public static function writeFor(string $user): ?string
    {
        $home = self::homeDir($user);
        if ($home === null) {
            return null;
        }
        $json = json_encode(self::build($user, $home),
                            JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return null;
        }
        return self::writeInHome($user, 'report.json', $json, $home);
    }

    /**
     * Put a file in an account's ~/.serverscrub, safely.
     *
     * Split out of writeFor() so the live scan status can use the same path.
     * It is the only part of this class that is genuinely dangerous -- root
     * writing into a directory a hostile user can rearrange between one call
     * and the next -- and having two copies of it would mean the second one
     * eventually drifting from the first.
     *
     * Returns the path written, or null if anything looked wrong. Refuses
     * rather than deleting: removing something in a customer's home because it
     * is in our way is not a decision this class should make on its own.
     *
     * @param string      $name A bare filename. Never from user input.
     * @param string|null $home Passed in when the caller already resolved it.
     */
    public static function writeInHome(string $user, string $name, string $data,
                                       ?string $home = null): ?string
    {
        if (!self::validUsername($user)) { return null; }
        if ($name === '' || strpbrk($name, "/\\\0") !== false || $name[0] === '.') {
            // A name with a separator in it would escape the directory every
            // check below is about.
            Logger::warn("UserReport: refusing to write unsafe filename '{$name}'");
            return null;
        }

        $home = $home ?? self::homeDir($user);
        if ($home === null) { return null; }

        $dir = $home . '/' . self::DIR;

        // A symlink here would redirect every write below. Refuse rather than
        // delete: removing something in a user's home because it is in our way
        // is not a decision this class should be making on its own.
        if (is_link($dir)) {
            Logger::warn("UserReport: {$dir} is a symlink — refusing to write through it");
            return null;
        }
        if (!is_dir($dir) && !@mkdir($dir, 0700, false)) {
            return null;
        }
        if (is_link($dir) || !is_dir($dir)) {
            return null;
        }

        $uid = @fileowner($home);
        $gid = @filegroup($home);
        if ($uid !== false) { @chown($dir, $uid); }
        if ($gid !== false) { @chgrp($dir, $gid); }
        @chmod($dir, 0700);

        $path = $dir . '/' . $name;
        $tmp  = $dir . '/.' . $name . '.' . getmypid();

        // Written to a temp file and renamed: a reader never sees a half-built
        // file, and the rename replaces whatever was there -- including a
        // symlink the user planted -- without ever opening it.
        if (@file_put_contents($tmp, $data) === false) {
            return null;
        }
        if ($uid !== false) { @chown($tmp, $uid); }
        if ($gid !== false) { @chgrp($tmp, $gid); }
        @chmod($tmp, 0600);

        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            return null;
        }
        return $path;
    }

    /**
     * Write reports for every account. Returns [written, skipped].
     */
    public static function writeAll(): array
    {
        $written = 0;
        $skipped = 0;
        // WHY each account was skipped, carried back to the caller.
        //
        // This used to return two integers, and the CLI then announced that
        // skipped accounts "have no usable home directory, or one that is a
        // symlink or owned by another user" -- a cause it had no way to know.
        //
        // When build() threw "Class UserScanRequest not found" on all 132
        // accounts, that is what the operator was told. The real error was
        // written to a log nobody was pointed at, and three rounds of
        // debugging went looking at home directories. A caught exception
        // reported as a guess about the filesystem is worse than no message.
        $reasons = [];
        $note = static function (string $user, string $why) use (&$reasons): void {
            if (count($reasons) < 50) { $reasons[] = $user . ': ' . $why; }
        };
        foreach (self::listUsers() as $user) {
            // One unusable home must not stop the rest of the server.
            try {
                if (self::writeFor($user) !== null) {
                    $written++;
                } else {
                    $skipped++;
                    $note($user, self::homeDir($user) === null
                        ? 'no usable home directory (missing, a symlink, or owned by another user)'
                        : 'home is fine; the write into ~/.serverscrub was refused');
                }
            } catch (Throwable $e) {
                $skipped++;
                $note($user, get_class($e) . ': ' . $e->getMessage()
                           . ' at ' . basename($e->getFile()) . ':' . $e->getLine());
                Logger::warn('UserReport: ' . $user . ' — ' . $e->getMessage());
            }
        }
        Logger::info("UserReport: wrote {$written} report(s), skipped {$skipped}");
        return ['written' => $written, 'skipped' => $skipped, 'reasons' => $reasons];
    }
}
