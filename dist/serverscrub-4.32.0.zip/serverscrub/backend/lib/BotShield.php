<?php

/* Pulls in what it calls, rather than trusting the caller to have done it.
 * UserReport did not, and `serverscrub user-reports` died with
 * Class "UserScanRequest" not found on all 132 accounts -- silently,
 * because writeAll() catches Throwable per account. require_once is
 * idempotent and safe across the cycles these classes form. */
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Logger.php';

/**
 * ServerScrub — Bot Shield Module
 * Detects and blocks malicious bots via access log analysis and UA pattern matching
 */

class BotShield {

    /** UA pattern groups that indicate bad bots */
    private array $badBotPatterns = [
        'scanner' => '/masscan|zgrab|nuclei|nmap|nikto|sqlmap|dirbuster|gobuster|wfuzz|hydra|acunetix|nessus|qualys/i',
        'scraper' => '/AhrefsBot|SemrushBot|DotBot|MJ12bot|BLEXBot|DataForSeoBot|PetalBot/i',
        'exploit' => '/(?:python-requests|curl\/)[^\s]+ .+(?:wp-login|xmlrpc)|Go-http-client.+(?:wp-admin|wp-login|xmlrpc)/i',
    ];

    /** UA patterns for legitimate crawlers — never block these */
    private array $goodBotPatterns = [
        '/Googlebot|Bingbot|Slurp|DuckDuckBot|Baiduspider|YandexBot|facebot|ia_archiver|Twitterbot/i',
    ];

    /** Access log locations to try, in order */
    private array $logPaths = [
        '/var/log/apache2/access.log',
        '/usr/local/apache/logs/access_log',
        '/var/log/nginx/access.log',
    ];

    public function __construct() {
        $this->ensureSchema();
    }

    private function ensureSchema(): void {
        Database::get()->exec("
            CREATE TABLE IF NOT EXISTS bot_events (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ip_address  TEXT NOT NULL,
                user_agent  TEXT,
                uri         TEXT,
                method      TEXT,
                country     TEXT,
                threat_type TEXT,
                action      TEXT NOT NULL DEFAULT 'block',
                hits        INTEGER NOT NULL DEFAULT 1,
                timestamp   INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS bot_whitelist (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern  TEXT NOT NULL UNIQUE,
                note     TEXT,
                added_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );
        ");
    }

    // ── Stats ─────────────────────────────────────────────────────────────────

    public function getStats(): array {
        $today         = mktime(0, 0, 0);
        $blockedToday  = Database::fetchOne(
            "SELECT COUNT(*) as c FROM bot_events WHERE action='block' AND timestamp >= ?", [$today]
        )['c'];
        $totalBlocked  = Database::fetchOne(
            "SELECT COUNT(*) as c FROM bot_events WHERE action='block'"
        )['c'];
        $whitelisted   = Database::fetchOne("SELECT COUNT(*) as c FROM bot_whitelist")['c'];
        $lastParse     = Database::setting('bot_last_requests_analyzed', '0');

        return [
            'bots_blocked_today'  => (int) $blockedToday,
            'total_blocked'       => (int) $totalBlocked,
            'whitelisted'         => (int) $whitelisted,
            'requests_analyzed'   => (int) $lastParse,
        ];
    }

    // ── Event Fetching ────────────────────────────────────────────────────────

    /** 50 by default, 500 at most. Beyond that a page stops being a page. */
    public const MIN_PAGE = 50;
    public const MAX_PAGE = 500;

    public static function clampPage(int $n): int
    {
        return max(self::MIN_PAGE, min(self::MAX_PAGE, $n));
    }

    /**
     * One page of events, WITH the total.
     *
     * The total is the point. The previous version returned up to 100 rows and
     * the front end then silently rendered the first 50 of them, so a server
     * with thousands of events showed fifty and said nothing at all. A table
     * that shows part of the data without saying so invites exactly the wrong
     * conclusion -- that there is nothing more to see.
     *
     * @return array{items:array,total:int,limit:int,offset:int}
     */
    public function getBotEvents(int $limit = self::MIN_PAGE, int $offset = 0): array {
        $limit  = self::clampPage($limit);
        $offset = max(0, $offset);
        $total  = (int) (Database::fetchOne(
            'SELECT COUNT(*) AS c FROM bot_events')['c'] ?? 0);
        $rows = Database::fetchAll(
            'SELECT * FROM bot_events ORDER BY timestamp DESC LIMIT ? OFFSET ?',
            [$limit, $offset]
        ) ?: [];
        foreach ($rows as &$r) {
            $r['description'] = self::describe($r['threat_type'] ?? null,
                                               $r['user_agent'] ?? null);
        }
        unset($r);
        return ['items' => $rows, 'total' => $total,
                'limit' => $limit, 'offset' => $offset];
    }

    /**
     * One page of blocked addresses, WITH the total.
     *
     * Counted over the grouped set, not the rows: this groups by address, so
     * COUNT(*) on bot_events would report the number of EVENTS and the pager
     * would offer pages that do not exist.
     *
     * @return array{items:array,total:int,limit:int,offset:int}
     */
    public function getBlockedBots(int $limit = self::MIN_PAGE, int $offset = 0): array {
        $limit  = self::clampPage($limit);
        $offset = max(0, $offset);
        $total  = (int) (Database::fetchOne(
            "SELECT COUNT(*) AS c FROM (
                 SELECT ip_address FROM bot_events
                  WHERE action = 'block' GROUP BY ip_address)")['c'] ?? 0);
        $rows = Database::fetchAll(
            // threat_type was stored from the first version and never
            // selected, so every row in the panel read "bot". With exactly one
            // MAX() aggregate SQLite takes the bare columns from the matching
            // row, so this is the type and agent of the most recent hit.
            "SELECT ip_address, user_agent, threat_type, SUM(hits) as hits, country,
                    MAX(timestamp) as last_seen
             FROM bot_events
             WHERE action = 'block'
             GROUP BY ip_address
             ORDER BY last_seen DESC
             LIMIT ? OFFSET ?", [$limit, $offset]
        ) ?: [];
        foreach ($rows as &$r) {
            $r['description'] = self::describe($r['threat_type'] ?? null,
                                               $r['user_agent'] ?? null);
        }
        unset($r);
        return ['items' => $rows, 'total' => $total,
                'limit' => $limit, 'offset' => $offset];
    }

    public function getWhitelistedBots(): array {
        return Database::fetchAll("SELECT * FROM bot_whitelist ORDER BY added_at DESC");
    }

    // ── Log Analysis ──────────────────────────────────────────────────────────

    public function analyzeLogs(): array {
        $logFile = null;
        foreach ($this->logPaths as $path) {
            if (file_exists($path) && is_readable($path)) {
                $logFile = $path;
                break;
            }
        }

        if ($logFile === null) {
            Logger::error('BotShield: no accessible access log found');
            return ['error' => 'No access log found', 'findings' => []];
        }

        $findings        = [];
        $requestsRead    = 0;
        $whitelistPats   = $this->getWhitelistedBots();

        // Read last 50 000 lines to avoid memory exhaustion on large logs
        $lines = $this->tailFile($logFile, 50000);

        foreach ($lines as $line) {
            $requestsRead++;

            // Combined Log Format:
            // 1.2.3.4 - - [date] "METHOD /uri HTTP/1.1" status size "ref" "ua"
            if (!preg_match(
                '/^(\S+)\s+\S+\s+\S+\s+\[([^\]]+)\]\s+"(\w+)\s+(\S+)\s+\S+"\s+(\d+)\s+\S+(?:\s+"[^"]*")?\s+"([^"]*)"/',
                $line, $m
            )) {
                continue;
            }

            [, $ip, , $method, $uri, , $ua] = $m;

            // Skip good bots
            if ($this->isGoodBot($ua)) continue;

            // Skip whitelisted patterns
            if ($this->isWhitelisted($ua, $whitelistPats)) continue;

            $threat = $this->detectThreatType($ua, $uri);
            if ($threat === null) continue;

            $findings[] = [
                'ip'         => $ip,
                'user_agent' => $ua,
                'uri'        => $uri,
                'method'     => $method,
                'threat_type'=> $threat,
            ];
        }

        Database::setSetting('bot_last_requests_analyzed', (string) $requestsRead);
        Logger::info("BotShield: analyzed $requestsRead log lines, found " . count($findings) . " bot hits");

        return [
            'log_file'          => $logFile,
            'requests_analyzed' => $requestsRead,
            'findings'          => $findings,
        ];
    }

    // ── Block / Unblock ───────────────────────────────────────────────────────

    public function blockBot(string $ip, string $ua, string $reason): bool {
        try {
            // Through the firewall gate, not around it.
            //
            // This used to shell out to `csf -d` itself, which meant it
            // bypassed every check Firewall::blockIP() performs — including
            // the proxy guard added in 4.21.3, so Bot Shield could still put a
            // Cloudflare edge into csf.deny after that guard shipped. A guard
            // that each caller has to remember is a guard the next caller will
            // not have.
            //
            // The firewall is asked FIRST and the row is written only if it
            // agrees, for the same reason blockIP() checks before writing
            // blocked_ips: a panel listing an address as blocked while packets
            // from it keep arriving is the most expensive kind of wrong a
            // security tool can be.
            require_once __DIR__ . '/Firewall.php';
            $fw  = new Firewall();
            $res = $fw->blockIP($ip, 'Bot Shield: ' . $reason);
            if (empty($res['success'])) {
                $why = trim((string) ($res['error'] ?? '')) ?: 'the firewall refused the block';
                Logger::warn("BotShield: could NOT block {$ip} — {$why}");
                return false;
            }

            // Upsert bot_events — increment hits if already present
            $existing = Database::fetchOne(
                "SELECT id, hits FROM bot_events WHERE ip_address = ? AND action = 'block'", [$ip]
            );
            if ($existing) {
                Database::query(
                    "UPDATE bot_events SET hits = hits + 1, timestamp = strftime('%s','now'),
                     user_agent = ?, threat_type = ? WHERE id = ?",
                    [$ua, $reason, $existing['id']]
                );
            } else {
                Database::insert('bot_events', [
                    'ip_address'  => $ip,
                    'user_agent'  => $ua,
                    'threat_type' => $reason,
                    'action'      => 'block',
                ]);
            }

            Logger::info("BotShield: blocked bot IP $ip — $reason");
            Logger::event('bot_blocked', 'medium', $ip, 'web', "Bot blocked: {$reason}");
            return true;
        } catch (Exception $e) {
            Logger::error('BotShield::blockBot — ' . $e->getMessage());
            return false;
        }
    }

    public function unblockBot(string $ip): bool {
        try {
            Database::query(
                "UPDATE bot_events SET action = 'unblocked' WHERE ip_address = ?", [$ip]
            );

            if (file_exists(CSF_BIN)) {
                exec(CSF_BIN . " -dr " . escapeshellarg($ip) . " 2>/dev/null");
            } else {
                exec(IPTABLES_BIN . " -D INPUT -s " . escapeshellarg($ip) . " -j DROP 2>/dev/null");
            }

            Logger::info("BotShield: unblocked IP $ip");
            return true;
        } catch (Exception $e) {
            Logger::error('BotShield::unblockBot — ' . $e->getMessage());
            return false;
        }
    }

    // ── Whitelist ─────────────────────────────────────────────────────────────

    public function addWhitelist(string $pattern, string $note = ''): bool {
        try {
            Database::insert('bot_whitelist', ['pattern' => $pattern, 'note' => $note]);
            Logger::info("BotShield: whitelisted pattern '$pattern'");
            return true;
        } catch (Exception $e) {
            Logger::error('BotShield::addWhitelist — ' . $e->getMessage());
            return false;
        }
    }

    public function removeWhitelist(int $id): bool {
        try {
            Database::query("DELETE FROM bot_whitelist WHERE id = ?", [$id]);
            return true;
        } catch (Exception $e) {
            Logger::error('BotShield::removeWhitelist — ' . $e->getMessage());
            return false;
        }
    }

    // ── Run Analysis ──────────────────────────────────────────────────────────

    public function runAnalysis(): array {
        $result      = $this->analyzeLogs();
        $blocked     = 0;
        $skipped     = 0;
        $alreadyBlocked = [];

        // Pre-load already-blocked IPs for fast lookup
        $rows = Database::fetchAll("SELECT ip_address FROM bot_events WHERE action = 'block'");
        foreach ($rows as $r) {
            $alreadyBlocked[$r['ip_address']] = true;
        }

        foreach ($result['findings'] ?? [] as $finding) {
            $ip = $finding['ip'];

            if (isset($alreadyBlocked[$ip])) {
                $skipped++;
                continue;
            }

            if ($this->blockBot($ip, $finding['user_agent'], $finding['threat_type'])) {
                $alreadyBlocked[$ip] = true;
                $blocked++;
            }
        }

        return [
            'requests_analyzed' => $result['requests_analyzed'] ?? 0,
            'findings'          => count($result['findings'] ?? []),
            'newly_blocked'     => $blocked,
            'already_blocked'   => $skipped,
            'log_file'          => $result['log_file'] ?? null,
        ];
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function isGoodBot(string $ua): bool {
        foreach ($this->goodBotPatterns as $pattern) {
            if (preg_match($pattern, $ua)) return true;
        }
        return false;
    }

    private function isWhitelisted(string $ua, array $whitelistRows): bool {
        foreach ($whitelistRows as $row) {
            $pat = $row['pattern'];
            // Support plain substring or /regex/ patterns
            if (str_starts_with($pat, '/')) {
                if (@preg_match($pat, $ua)) return true;
            } else {
                if (stripos($ua, $pat) !== false) return true;
            }
        }
        return false;
    }

    /**
     * The tools behind the user agents we block, in the words an operator
     * would use. Keyed on a lowercase fragment of the user agent.
     *
     * Deliberately short labels: this ends up on one line of a narrow table,
     * and a description that wraps to three lines is a description nobody
     * reads.
     */
    private const TOOL_LABELS = [
        'sqlmap'          => 'sqlmap',
        'nuclei'          => 'nuclei',
        'nikto'           => 'Nikto',
        'nmap'            => 'Nmap',
        'masscan'         => 'masscan',
        'zgrab'           => 'ZGrab',
        'dirbuster'       => 'DirBuster',
        'gobuster'        => 'Gobuster',
        'wfuzz'           => 'Wfuzz',
        'hydra'           => 'Hydra',
        'acunetix'        => 'Acunetix',
        'nessus'          => 'Nessus',
        'qualys'          => 'Qualys',
        'ahrefsbot'       => 'AhrefsBot',
        'semrushbot'      => 'SemrushBot',
        'dataforseobot'   => 'DataForSeoBot',
        'blexbot'         => 'BLEXBot',
        'petalbot'        => 'PetalBot',
        'mj12bot'         => 'MJ12bot',
        'dotbot'          => 'DotBot',
        'python-requests' => 'a Python script',
        'go-http-client'  => 'a Go program',
        'curl'            => 'curl',
    ];

    /** The recognisable tool in a user agent, or '' if none stands out. */
    public static function toolLabel(?string $ua): string
    {
        $ua = strtolower(trim((string) $ua));
        if ($ua === '' || $ua === '-') { return ''; }
        foreach (self::TOOL_LABELS as $needle => $label) {
            if (strpos($ua, $needle) !== false) { return $label; }
        }
        return '';
    }

    /**
     * One line saying what this bot was doing.
     *
     * The table used to show the word "bot" on every row — the type was being
     * stored and never selected, so the column said nothing at all. An
     * operator looking at a list of blocked addresses needs to know whether
     * they stopped a vulnerability scanner or an SEO crawler, because those
     * warrant completely different reactions.
     */
    public static function describe(?string $type, ?string $ua): string
    {
        $tool = self::toolLabel($ua);
        $via  = $tool !== '' ? ' (' . $tool . ')' : '';

        switch ((string) $type) {
            case 'scanner':
                return 'Scanning for known vulnerabilities' . $via;
            case 'scraper':
                return 'Crawling the site for its own index' . $via;
            case 'exploit':
                return 'Attacking WordPress login or XML-RPC' . $via;
        }

        // Older rows predate the type being recorded, and an empty user agent
        // is itself worth saying out loud: ordinary browsers always send one.
        if (trim((string) $ua) === '' || trim((string) $ua) === '-') {
            return 'Automated client that sent no user agent';
        }
        return 'Automated client' . $via;
    }

    private function detectThreatType(string $ua, string $uri): ?string {
        foreach ($this->badBotPatterns as $type => $pattern) {
            if ($type === 'exploit') {
                // Exploit bots: combine UA + URI for context
                if (preg_match('/python-requests|curl\//i', $ua) &&
                    preg_match('/wp-login|xmlrpc/i', $uri)) {
                    return 'exploit';
                }
                if (preg_match('/Go-http-client/i', $ua) &&
                    preg_match('/wp-admin|wp-login|xmlrpc/i', $uri)) {
                    return 'exploit';
                }
            } else {
                if (preg_match($pattern, $ua)) return $type;
            }
        }
        return null;
    }

    /**
     * Return the last $n lines of a file without loading the whole file into memory.
     */
    private function tailFile(string $path, int $lines): array {
        $out = [];
        exec("tail -n $lines " . escapeshellarg($path) . " 2>/dev/null", $out);
        return $out;
    }
}
