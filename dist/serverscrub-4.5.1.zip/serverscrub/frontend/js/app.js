/**
 * ServerScrub — Main Application
 * SPA controller, page routing, all UI interactions
 */

// ── State ─────────────────────────────────────────────────────────────────────
const State = {
  currentPage:  'dashboard',
  scanJobId:    null,
  scanInterval: null,
  refreshInt:   null,
  geoSelected:  new Set(),
  user:         null,
};

// ── Install mode (fetched from API on load) ───────────────────────────────────
State.installMode = 'cpanel'; // default until API responds
State.version     = '';       // filled by detectMode()

async function detectMode() {
  try {
    const res = await API.status();
    if (res?.success) {
      State.installMode = res.mode    || 'cpanel';
      State.version     = res.version || '';
    }
  } catch (_) { /* stay with default */ }
  applyModeUI(State.installMode); // always update UI, even on API failure
}

function applyModeUI(mode) {
  const isStandalone = mode === 'standalone';

  // Login screen labels
  const sub   = document.getElementById('login-mode-sub');
  const badge = document.getElementById('login-mode-badge');
  const label = document.getElementById('login-user-label');
  const hint  = document.getElementById('login-hint');
  const userEl = document.getElementById('login-user');

  if (sub)   sub.textContent   = isStandalone ? 'Standalone Linux Server' : 'cPanel Security Suite';
  if (label) label.textContent = isStandalone ? 'Admin Username' : 'cPanel / WHM Username';
  if (userEl) userEl.placeholder = isStandalone ? 'admin' : 'root';
  if (hint)  hint.textContent  = isStandalone
    ? 'Local admin credentials set during installation'
    : 'Uses your existing cPanel / WHM credentials  ·  Demo: demo / demo';
  if (badge) badge.innerHTML = isStandalone
    ? '<span style="font-size:.68rem;padding:3px 10px;border-radius:20px;background:rgba(16,185,129,.15);color:var(--green);border:1px solid rgba(16,185,129,.3);letter-spacing:.05em">⚡ STANDALONE LINUX</span>'
    : '<span style="font-size:.68rem;padding:3px 10px;border-radius:20px;background:rgba(59,130,246,.15);color:var(--blue);border:1px solid rgba(59,130,246,.3);letter-spacing:.05em">🖥 cPANEL / WHM</span>';

  // Sidebar version / mode label
  const sideLabel = document.getElementById('sidebar-mode-label');
  if (sideLabel) {
    const ver = State.version ? `v${State.version}` : '';
    sideLabel.textContent = isStandalone ? `${ver} · Standalone` : `${ver} · cPanel Plugin`;
  }

  // Settings page: show/hide standalone-only cards
  const banner = document.getElementById('standalone-settings-banner');
  const chpw   = document.getElementById('card-change-password');
  if (banner) banner.classList.toggle('hidden', !isStandalone);
  if (chpw)   chpw.classList.toggle('hidden',   !isStandalone);
}

// ── Auth ──────────────────────────────────────────────────────────────────────
const Auth = {
  isLoggedIn() { return !!localStorage.getItem('sg_token'); },

  logout() {
    localStorage.removeItem('sg_token');
    localStorage.removeItem('sg_user');
    location.reload();
  },

  init() {
    if (this.isLoggedIn()) {
      document.getElementById('login-screen').style.display = 'none';
      const u = JSON.parse(localStorage.getItem('sg_user') || '{}');
      State.user = u;
      State.installMode = u.mode || 'cpanel';
      const av = document.getElementById('user-avatar');
      if (av && u.username) av.textContent = u.username.slice(0,2).toUpperCase();
      applyModeUI(State.installMode);
      detectMode(); // async: fetches live version from API and updates sidebar

      // Licence gate, checked before the dashboard loads rather than after.
      // Letting the pages load first means every panel fires a request that is
      // refused with 402 and renders empty behind the activation screen.
      enforceLicenseGate();

      return true;
    }
    // Not logged in — detect mode for login screen
    detectMode();
    return false;
  }
};

// ── Toast Notifications ───────────────────────────────────────────────────────
function toast(msg, type = 'info') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  const icons = { success: '✓', error: '✕', info: 'ℹ' };
  el.innerHTML = `<span style="font-size:1rem">${icons[type]||'ℹ'}</span><span>${msg}</span>`;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ── Page Navigation ───────────────────────────────────────────────────────────
// The monitor page had no refresh of its own: it loaded once when opened and
// then showed whatever was true at that moment until someone pressed Refresh.
// A paused/running state that changes on its own -- which is the whole point of
// the backup pause and the auto-resume -- was therefore routinely wrong on
// screen. Poll while the page is actually visible, and stop when it is not.
let _monitorPoll = null;

function startMonitorPolling(name) {
  if (_monitorPoll) { clearInterval(_monitorPoll); _monitorPoll = null; }
  if (name !== 'monitor' && name !== 'dashboard') { return; }

  _monitorPoll = setInterval(() => {
    // Not while a start/stop is mid-flight: refreshing then would render the
    // state the button is in the middle of changing.
    if (_monitorBusy) { return; }
    if (document.hidden) { return; }   // background tab: no point polling
    if (State.currentPage === 'monitor')        { loadMonitor(); }
    else if (State.currentPage === 'dashboard') { loadMonitorStats(); }
    else { clearInterval(_monitorPoll); _monitorPoll = null; }
  }, 15000);
}

// The markup every page shows while its data is on the way.
// An image URL that changes when the release does.
//
// Cache-busting the markup is not enough: several images are referenced from
// here, and a filename whose CONTENTS change between releases is cached by the
// browser exactly as hard as one whose name never changes. icon-64.png held
// the old crop in 4.0.0 and the new mark in 4.1.0, so updated servers kept
// drawing the old logo with nothing to suggest why.
function assetUrl(path) {
  const v = (typeof window !== 'undefined' && window.SG_ASSET_V) || '';
  return v ? path + '?v=' + encodeURIComponent(v) : path;
}

function loadingMark(caption) {
  return '<div class="ss-load" style="padding:28px 0">'
       + '<img src="' + assetUrl('images/icon.png') + '" alt="">'
       + '<span class="ss-cap">' + esc(caption || 'Loading…') + '</span>'
       + '</div>';
}

// Same thing sized for a table cell, so a table does not jump as it fills.
function loadingRow(cols, caption) {
  return '<tr><td colspan="' + (cols || 6) + '" style="padding:18px 0">'
       + loadingMark(caption) + '</td></tr>';
}

// Drop the splash once the first page has actually drawn something. Hiding it
// on a timer would either cover a ready page or uncover a blank one.
let _splashGone = false;

// Nothing may leave the user looking at a logo for ever.
//
// The splash is dismissed when a page renders, which is the right moment --
// but it is also the only moment, and 4.1.0 shipped with that call landing
// after a `return` in an unrelated function. The result was an app that was
// running perfectly behind a cover that never lifted, with no error anywhere
// to say so. A cover that can stick is worse than no cover, so these remove it
// regardless of whether anything remembered to.
window.addEventListener('load', () => setTimeout(dismissSplash, 1200));
setTimeout(dismissSplash, 6000);

function dismissSplash() {
  if (_splashGone) return;
  _splashGone = true;
  const el = document.getElementById('ss-splash');
  if (!el) return;
  el.classList.add('gone');
  setTimeout(() => el.remove(), 400);
}

function openPage(name) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));

  // Show target
  const page = document.getElementById(`page-${name}`);
  if (page) page.classList.remove('hidden');

  // Update nav state
  document.querySelectorAll('.nav-item, .sidebar-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page === name);
  });

  State.currentPage = name;
  startMonitorPolling(name);

  // Trigger page-specific data load
  switch (name) {
    case 'dashboard': refreshDashboard();   break;
    case 'scanner':   loadThreats(); adoptRunningScan(); break;
    case 'firewall':  loadFirewall();       break;
    case 'waf':       loadWAF(); loadWafEngine();            break;
    case 'iprep':     loadTopAttackers(); loadServerIpForBlocklist();   break;
    case 'events':    loadEvents();         break;
    case 'bruteforce': loadBruteForce();     break;
    case 'settings':  loadSettings();       break;
    case 'botshield': loadBotShield();      break;
    case 'cms':       loadCMSGuard();       break;
    case 'rootkit':   loadRootkit();        break;
    case 'integrity': loadIntegrity();      break;
    case 'logs':      loadLogs();           break;
    case 'php':       loadPHPHardening();   break;
  }

  // The page is on screen now, so the splash has done its job. Its loading
  // marks cover the data still arriving.
  dismissSplash();
}

// ── Utilities ─────────────────────────────────────────────────────────────────
function reltime(ts) {
  const diff = Math.floor(Date.now() / 1000 - ts);
  if (diff < 60)    return `${diff}s ago`;
  if (diff < 3600)  return `${Math.floor(diff/60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
  return `${Math.floor(diff/86400)}d ago`;
}

function fmtBytes(b) {
  if (b < 1024)     return `${b} B`;
  if (b < 1048576)  return `${(b/1024).toFixed(1)} KB`;
  return `${(b/1048576).toFixed(1)} MB`;
}

function fmtNum(n) {
  return Number(n).toLocaleString();
}

function sevBadge(sev) {
  return `<span class="sev sev-${sev}">${sev.toUpperCase()}</span>`;
}

// The element lookup every handler uses.
//
// This existed only as a `const g` inside two functions, so any module-scope
// code calling g() threw ReferenceError the moment it ran -- silently, inside
// an event handler. Three shipped features did nothing at all because of it:
// the custom-scan account picker, adopting an already-running scan, and the
// brute-force ladder preview. Defined once, here, where everything can see it.
function g(id) { return document.getElementById(id); }

function openModal(id)  { document.getElementById(id)?.classList.remove('hidden'); }
function closeModal(id) { document.getElementById(id)?.classList.add('hidden'); }

// ── Dashboard ─────────────────────────────────────────────────────────────────
async function checkForUpdates(forceLive = false) {
  if (Demo.active) {
    showUpdateButton({ update_available: true, latest_version: '3.11.0' });
    return;
  }
  try {
    const res = forceLive
      ? await API.updateCheck()
      : await API.updateStatus();
    if (!res?.success) return;
    const d = res.data;
    const banner  = document.getElementById('update-banner');
    const dot     = document.getElementById('sidebar-update-dot');
    const newVer  = document.getElementById('update-new-version');
    const curVer  = document.getElementById('update-cur-version');
    const relLink = document.getElementById('update-release-link');

    showUpdateButton(d);

    if (d.update_available) {
      if (banner)  { banner.style.display  = 'flex'; }
      if (dot)     { dot.style.display     = 'block'; }
      if (newVer)  newVer.textContent  = 'v' + d.latest_version;
      if (curVer)  curVer.textContent  = 'v' + d.current_version;
      if (relLink && d.release_url) relLink.href = d.release_url;
    } else {
      if (banner)  banner.style.display  = 'none';
      if (dot)     dot.style.display     = 'none';
    }
  } catch (_) {}
}

async function runUpdate() {
  toast('To update: SSH into your server and run:  bash /usr/local/serverscrub/update.sh', 'info', 8000);
}

async function refreshDashboard() {
  checkForUpdates();   // non-blocking — uses cached result

  // The Real-Time Monitor widget on this page was only ever filled in by
  // toggleMonitor(), so on a fresh dashboard it kept whatever the markup
  // shipped with -- a green "Active" badge -- and the module-level
  // monitorRunning stayed false. The button reads "Stop" from the HTML while
  // the code believes nothing is running, so the first click calls START.
  // Reported as "I cannot turn it off": it was doing the opposite.
  loadMonitorStats();
  const data = Demo.active
    ? Demo.mockDashStats()
    : await API.dashStats();

  // A failed load must never leave the page asserting a security posture. The
  // markup ships with "Protected" pre-rendered, so returning silently here left
  // a green tick and an empty dashboard on a server whose API was answering 501
  // to every request — the single most misleading thing this product could do.
  if (!data?.success) {
    const icon   = document.getElementById('dash-scan-icon');
    const status = document.getElementById('dash-scan-status');
    const badge  = document.getElementById('dash-scan-badge');
    const meta   = document.getElementById('dash-scan-meta');
    const info   = document.getElementById('dash-server-info');

    if (icon)   icon.textContent = '⛔';
    if (status) { status.textContent = 'Status unknown'; status.style.color = 'var(--red)'; }
    if (badge)  { badge.className = 'badge badge-red'; badge.textContent = 'API unreachable'; }
    // Prefer the server's detail over the generic line: pointing the user at a
    // log file they then have to go and read is a worse answer than the error.
    if (meta)   meta.textContent = (data && (data.detail || data.error))
                                   || 'Could not reach the ServerScrub API.';
    if (info)   info.textContent = 'Could not reach the API — protection status cannot be confirmed.';

    ['stat-files','stat-threats','stat-fw','stat-waf'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.textContent = '—';
    });
    return;
  }

  // Server info
  const s = data.server;
  document.getElementById('dash-server-info').textContent =
    `${s?.hostname || 'server'} · PHP ${s?.php_version || '?'} · Load: ${(s?.load?.[0] || 0).toFixed(2)}`;

  // Stat cards
  const sc = data.scanner;
  const fw = data.firewall;
  const waf = data.waf;

  document.getElementById('stat-files').textContent    = fmtNum(sc?.files_scanned || 0);
  document.getElementById('stat-threats').textContent  = fmtNum(sc?.total_threats || 0);
  document.getElementById('stat-fw').textContent       = fmtNum(fw?.blocked_today || 0);
  document.getElementById('stat-waf').textContent      = fmtNum(waf?.events_today || 0);

  document.getElementById('stat-files-sub').textContent   = 'Total scanned';
  document.getElementById('stat-threats-sub').textContent = `${sc?.active || 0} active`;
  document.getElementById('stat-fw-sub').textContent      = `${fmtNum(fw?.blocked_ips || 0)} blocked IPs`;
  document.getElementById('stat-waf-sub').textContent     = 'Today';

  // Update sidebar badges
  const sbT = document.getElementById('sb-threats');
  if (sbT) { sbT.textContent = sc?.active || 0; sbT.style.display = sc?.active ? '' : 'none'; }
  const sbE = document.getElementById('sb-events');
  if (sbE) sbE.textContent = data.events?.filter(e => !e.resolved).length || 0;

  // Scanner status card
  const lastJob = sc?.last_scan;
  const threats = sc?.active || 0;
  const scanIcon   = document.getElementById('dash-scan-icon');
  const scanStatus = document.getElementById('dash-scan-status');
  const scanMeta   = document.getElementById('dash-scan-meta');
  const scanBadge  = document.getElementById('dash-scan-badge');

  if (threats > 0) {
    scanIcon.textContent = '⚠️';
    scanStatus.textContent = `${threats} Active Threat${threats > 1 ? 's' : ''}`;
    scanStatus.style.color = 'var(--red)';
    scanBadge.className = 'badge badge-red';
    scanBadge.textContent = 'Threats Found';
  } else {
    scanIcon.textContent = '✅';
    scanStatus.textContent = 'Protected';
    scanStatus.style.color = 'var(--green)';
    scanBadge.className = 'badge badge-green';
    scanBadge.textContent = 'Protected';
  }

  if (lastJob?.finished_at) {
    scanMeta.textContent = `Last scan: ${reltime(lastJob.finished_at)} · 0 new threats`;
  }

  // Coverage bar
  const total = sc?.files_scanned || 0;
  const pct   = total > 0 ? 98.7 : 0;
  document.getElementById('dash-coverage-bar').style.width = `${pct}%`;
  document.getElementById('dash-coverage-pct').textContent = `${pct}%`;

  // File stats
  document.getElementById('fs-scanned').textContent = fmtNum(total);
  document.getElementById('fs-clean').textContent   = fmtNum(total - (sc?.quarantined || 0) - (sc?.deleted || 0));
  document.getElementById('fs-quar').textContent    = fmtNum(sc?.quarantined || 0);
  document.getElementById('fs-del').textContent     = fmtNum(0);

  // Threat breakdown
  const byType = sc?.by_type || [];
  Charts.threatBars(document.getElementById('dash-threat-breakdown'), byType);

  // Kept so the alerts panel can be built from what is already known rather
  // than a second round of requests.
  State.lastDash = data;
  loadOverview();

  // Brute force counts beside the chart that has always drawn the series.
  const bf = data.bruteforce;
  if (bf) {
    setText('dash-bf-24h',     fmtNum(bf.attempts_24h || 0));
    setText('dash-bf-blocked', fmtNum(bf.blocked      || 0));
  }

  // Timeline chart
  if (data.timeline?.length) {
    const dates = data.timeline.map(d => d.date);
    const svgEl = document.getElementById('timeline-chart');
    if (svgEl) {
      Charts.timeline(svgEl, dates, [
        { values: data.timeline.map(d => d.waf_blocks),  color: '#3b82f6', label: 'WAF Blocks' },
        { values: data.timeline.map(d => d.brute_force), color: '#f59e0b', label: 'Brute Force' },
        { values: data.timeline.map(d => d.malware),     color: '#ef4444', label: 'Malware' },
      ]);
    }
  }

  // Events table
  renderEventsTable(data.events || [], 'dash-events-body');
  const unresolved = (data.events || []).filter(e => !e.resolved).length;
  document.getElementById('dash-events-badge').textContent = `${unresolved} unresolved`;

  // Sparklines (fake trend data for now)
  Charts.sparkline(document.getElementById('spark-files'),   [45,52,48,61,58,64,70,68,72,80,76,84], '#3b82f6');
  Charts.sparkline(document.getElementById('spark-threats'), [2,5,3,8,4,12,7,15,9,11,6,8],          '#ef4444');
  Charts.sparkline(document.getElementById('spark-fw'),      [30,45,38,55,42,60,52,48,65,58,72,61], '#f59e0b');
  Charts.sparkline(document.getElementById('spark-waf'),     [92,94,91,95,93,97,95,98,96,99,98,99], '#22c55e');
}

function renderEventsTable(events, tbodyId) {
  const tbody = document.getElementById(tbodyId);
  if (!tbody) return;

  // The dashboard shows a trimmed version of this table with no checkbox and
  // no Description; only the full Security Events page has them.
  const full = tbodyId === 'events-body';
  const cols = full ? 8 : 6;

  if (!events.length) {
    tbody.innerHTML = `<tr><td colspan="${cols}" style="text-align:center;color:var(--txt3);padding:20px">No events found</td></tr>`;
    if (full) updateEventBulkBar();
    return;
  }

  // Every one of these fields comes from a request someone else made -- a
  // request path, a user agent, an attacker-chosen target. Interpolating them
  // raw put an attacker's markup into the page of the operator reviewing their
  // attack, which is about the worst place for it in a security product.
  tbody.innerHTML = events.map(e => `
    <tr>
      ${full ? `<td><input type="checkbox" class="event-check" value="${Number(e.id) || 0}"
                     onchange="updateEventBulkBar()" ${e.resolved ? 'disabled' : ''}></td>` : ''}
      <td>${sevBadge(e.severity)}</td>
      <td class="primary">${esc(e.type)}</td>
      <td class="mono">${esc(e.source_ip) || '—'}</td>
      <td class="mono">${esc(e.target) || '—'}</td>
      ${full ? `<td class="dim" style="max-width:320px;overflow:hidden;text-overflow:ellipsis">${esc(e.description)}</td>` : ''}
      <td class="dim">${reltime(e.timestamp)}</td>
      <td>
        ${e.resolved
          ? '<span class="badge badge-gray">Resolved</span>'
          : `<button class="btn btn-ghost btn-xs" onclick="resolveEvent(${Number(e.id) || 0})">Resolve</button>`
        }
      </td>
    </tr>`).join('');

  if (full) updateEventBulkBar();
}

// ── Bulk resolve ─────────────────────────────────────────────────────────────
function selectedEventIds() {
  return Array.from(document.querySelectorAll('.event-check:checked'))
              .map(c => parseInt(c.value, 10))
              .filter(n => n > 0);
}

function toggleAllEvents(master) {
  // Resolved rows are disabled, so this selects every unresolved event shown.
  document.querySelectorAll('.event-check:not(:disabled)')
          .forEach(c => { c.checked = master.checked; });
  updateEventBulkBar();
}

function updateEventBulkBar() {
  const ids   = selectedEventIds();
  const count = document.getElementById('event-bulk-count');
  if (count) {
    count.textContent = ids.length + ' selected';
    count.style.color = ids.length ? 'var(--primary)' : 'var(--txt2)';
  }
  const btn = document.getElementById('event-bulk-resolve');
  if (btn) btn.disabled = ids.length === 0;

  const master = document.getElementById('event-check-all');
  if (master) {
    const all = document.querySelectorAll('.event-check:not(:disabled)').length;
    master.checked       = all > 0 && ids.length === all;
    master.indeterminate = ids.length > 0 && ids.length < all;
  }
}

async function bulkResolveEvents() {
  const ids = selectedEventIds();
  if (!ids.length) { toast('Select one or more events first', 'error'); return; }

  const btn = document.getElementById('event-bulk-resolve');
  if (btn) { btn.disabled = true; btn.textContent = 'Resolving…'; }

  const res = Demo.active ? { success: true, resolved: ids.length }
                          : await API.post('events/resolve-bulk', { ids });

  if (btn) { btn.textContent = '✓ Resolve selected'; }

  if (res?.success) {
    toast(`Resolved ${res.resolved ?? ids.length} event(s)`, 'success');
    await loadEvents();
    refreshDashboard();
  } else {
    toast(res?.error || 'Could not resolve the selected events', 'error');
    if (btn) btn.disabled = false;
  }
}

async function resolveAllEvents() {
  const res = Demo.active ? { success: true, resolved: 0 }
                          : await API.post('events/resolve-all', {});
  if (res?.success) {
    toast(`Resolved ${res.resolved ?? 0} event(s)`, 'success');
    await loadEvents();
    refreshDashboard();
  } else {
    toast(res?.error || 'Could not resolve events', 'error');
  }
}

// ── Scanner ───────────────────────────────────────────────────────────────────
async function startScan() {
  openPage('scanner');
  const type = document.getElementById('scan-type-sel')?.value || 'quick';

  // A custom scan names accounts. Refusing to start with none selected is
  // better than quietly scanning everything, which is what a path default
  // would do.
  let accounts = [];
  if (type === 'custom') {
    accounts = scanAccountsSelected();
    // Pressing Start Scan with Custom chosen and nothing ticked reopens the
    // dialog rather than failing: the operator plainly meant to pick.
    if (!accounts.length) {
      openScanAccounts();
      return;
    }
  }

  const res = Demo.active
    ? { success: true, job_id: 999 }
    : await API.startScan('/home', type, accounts);

  if (!res?.success) {
    toast(res?.error || 'Failed to start scan', 'error');
    return;
  }

  State.scanJobId = res.job_id;
  document.getElementById('scan-progress-card').style.display = '';
  setScanButton(true);

  // Name the target straight away rather than waiting for the first poll two
  // seconds later: the moment an operator most wants to know what they just
  // launched is the moment they launched it. The poll then replaces this with
  // the server's own description of the job.
  const tw = g('scan-live-target-wrap');
  const te = g('scan-live-target');
  if (tw && te) {
    // Paths, matching what the server reports two seconds later. The picker
    // already holds each account's home directory, so the label does not have
    // to say "alice" now and "/home/alice" the moment the first poll lands.
    const homes = (_scanAccounts || [])
      .filter(a => accounts.includes(a.user))
      .map(a => a.home);
    const label = type === 'custom'
      ? (homes.length <= 3
          ? homes.join(', ')
          : homes.slice(0, 3).join(', ') + ' and ' + (homes.length - 3) + ' more')
      : (type === 'quick' ? 'web roots' : 'the whole server');
    te.textContent = label;
    te.title = homes.join(', ');
    tw.style.display = '';
  }
  const txt0 = g('scan-progress-text');
  if (txt0) txt0.textContent = 'Scanning…';
  State._scanStallTicks = 0;

  if (Demo.active) {
    simulateDemoScan();
    return;
  }

  followScan(State.scanJobId);
}

// Follow a running scan to completion, updating the progress card.
function followScan(jobId) {
  State.scanJobId = jobId;
  if (State.scanInterval) clearInterval(State.scanInterval);
  State.scanInterval = setInterval(async () => {
    const st = await API.scanStatus(State.scanJobId);
    if (!st?.success) return;
    const job = st.data?.job;
    if (!job) return;

    // There is no honest percentage to show. A scan walks the filesystem
    // without counting it first, so the total is unknown until the scan ends —
    // and the previous code filled that gap with Math.random(), which is why a
    // scan that had examined ZERO files displayed "51%". Fabricating progress
    // in a security product is worse than admitting the total is unknown.
    //
    // So: an indeterminate bar while running, and real counters beside it. The
    // file count IS known and IS truthful, which makes it the useful signal.
    const bar  = document.getElementById('scan-progress-bar');
    const pctEl = document.getElementById('scan-progress-pct');
    const done = job.status === 'done';

    if (done) {
      bar.classList.remove('indeterminate');
      bar.style.width = '100%';
      pctEl.textContent = '100%';
    } else {
      // Width is set by the animation, not by a made-up number.
      bar.classList.add('indeterminate');
      bar.style.width = '';
      pctEl.textContent = fmtNum(job.files_scanned || 0) + ' files';
    }

    document.getElementById('scan-live-files').textContent = fmtNum(job.files_scanned || 0);
    document.getElementById('scan-live-threats').textContent = job.threats_found || 0;
    document.getElementById('scan-live-status').textContent = job.status;

    // What this scan is actually working on. A custom scan of three accounts
    // used to look identical to a full scan of the whole server: the job row
    // has always carried the path, and the card simply never showed it.
    const tgt  = st.data?.target;
    const wrap = g('scan-live-target-wrap');
    const tEl  = g('scan-live-target');
    if (wrap && tEl && tgt?.label) {
      tEl.textContent = tgt.label;
      // The full list on hover, since the label is abbreviated past three.
      tEl.title = (tgt.paths || []).join('\n');
      wrap.style.display = '';
    }

    // A running job whose file count never moves is stuck, not working. Say so
    // rather than animating a bar forever: the scan runs detached, so the UI
    // cannot see it die.
    if (!done) {
      if (State._lastScanFiles === (job.files_scanned || 0)) {
        State._scanStallTicks = (State._scanStallTicks || 0) + 1;
      } else {
        State._scanStallTicks = 0;
      }
      State._lastScanFiles = job.files_scanned || 0;

      // The warning has to come back down again.
      //
      // This was set once and never cleared, so a scan that paused briefly --
      // loading the ClamAV signature database, or working through one large
      // file -- displayed "the scan process may not be running" for the rest
      // of its life, while the counter beside it climbed past five thousand
      // files. A warning that contradicts the number next to it trains an
      // operator to ignore both.
      //
      // The log file is named exactly, too: logs/scanner.log has never
      // existed. Each worker writes to logs/scan_<job>.log.
      const txt = document.getElementById('scan-progress-text');
      if (txt) {
        if (State._scanStallTicks >= 15) {               // ~30s of no movement
          txt.textContent = 'No new files scanned for 30s \u2014 the scan process may '
                          + 'have stopped. Check ' + (st.data?.log || 'the scan log') + '.';
        } else {
          txt.textContent = 'Scanning\u2026';
        }
      }
    }

    if (job.status === 'done' || job.status === 'error') {
      clearInterval(State.scanInterval);
      State.scanInterval = null;
      State.scanJobId = null;
      setScanButton(false);
      document.getElementById('scan-spinner').textContent = job.status === 'done' ? '✅' : '❌';
      document.getElementById('scan-progress-text').textContent =
        `Scan complete — ${job.threats_found || 0} threats found`;
      loadThreats();
      toast(`Scan complete. ${job.threats_found || 0} threats found.`, job.threats_found ? 'error' : 'success');
    }
  }, 2000);
}

function simulateDemoScan() {
  let pct = 0;
  const interval = setInterval(() => {
    pct = Math.min(100, pct + Math.floor(Math.random() * 8) + 2);
    document.getElementById('scan-progress-bar').style.width = `${pct}%`;
    document.getElementById('scan-progress-pct').textContent = `${pct}%`;
    document.getElementById('scan-live-files').textContent = fmtNum(Math.floor(pct / 100 * 1284930));
    document.getElementById('scan-live-threats').textContent = pct > 60 ? 5 : 0;
    document.getElementById('scan-live-status').textContent = pct < 100 ? 'Running…' : 'Done';
    if (pct >= 100) {
      clearInterval(interval);
      setScanButton(false);
      document.getElementById('scan-spinner').textContent = '✅';
      document.getElementById('scan-progress-text').textContent = 'Scan complete — 5 threats found';
      loadThreats();
      toast('Scan complete. 5 threats found.', 'error');
    }
  }, 200);
}

// Stop the scan on the SERVER, not just the progress bar in front of it.
//
// This used to clear the polling interval, hide the card and toast "Scan
// stopped" -- and tell the server nothing at all. The scan carried on at full
// speed with clamscan running flat out, while the UI reported that it had been
// stopped. Reported as "the stop button is not stopping clamscan"; it was not
// stopping anything.
// Adopt a scan that is already running.
//
// Called on every visit to the Scanner page. A scan started by the nightly
// cron, by another admin, or before a reload is now shown with its Stop
// button, instead of the page pretending nothing is happening.
async function adoptRunningScan() {
  if (Demo.active) return;
  let res;
  try { res = await API.scanActive(); } catch (e) { return; }
  const job = res?.data;
  if (!job || !job.id) return;
  if (State.scanJobId === job.id && State.scanInterval) return;   // already following

  State.scanJobId = job.id;
  const card = g('scan-progress-card');
  if (card) card.style.display = '';
  setScanButton(true);
  const st = g('scan-live-status');
  if (st) st.textContent = job.status === 'cancelling' ? 'Stopping\u2026' : 'Running';
  followScan(job.id);
}

// ---- Custom scan: which accounts ------------------------------------------
// "Custom Path" was a free-text directory box, which is not how an operator
// thinks about a shared server: they think in accounts. Choosing Custom opens
// a dialog listing every account with a checkbox.
let _scanAccounts = null;

async function openScanAccounts() {
  openModal('scan-accounts-modal');
  const list = g('scan-accounts-list');
  if (!list) return;

  if (_scanAccounts === null) {
    list.innerHTML = '<div class="dim">Loading accounts\u2026</div>';
    try {
      const res = await API.scanAccounts();
      _scanAccounts = res?.data || [];
    } catch (e) {
      _scanAccounts = [];
    }
  }
  renderScanAccounts();
}

function renderScanAccounts() {
  const list = g('scan-accounts-list');
  if (!list) return;

  const accounts = _scanAccounts || [];
  if (!accounts.length) {
    list.innerHTML = '<div class="dim">No accounts found under the configured scan paths.</div>';
    scanAccountsCount();
    return;
  }

  // Keep what is already ticked across a filter change, or filtering would
  // quietly discard a selection the operator had already made.
  const picked = new Set(scanAccountsSelected());
  const q = (g('scan-accounts-filter')?.value || '').trim().toLowerCase();
  const shown = q ? accounts.filter(a => a.user.toLowerCase().includes(q)) : accounts;

  if (!shown.length) {
    list.innerHTML = '<div class="dim">No account matches that filter.</div>';
    scanAccountsCount();
    return;
  }

  list.innerHTML = shown.map(a => `
    <label style="display:flex;align-items:center;gap:8px;padding:7px 9px;border:1px solid var(--border);border-radius:7px;cursor:pointer">
      <input type="checkbox" class="scan-acct" value="${esc(a.user)}"
             ${picked.has(a.user) ? 'checked' : ''} onchange="scanAccountsCount()">
      <span style="min-width:0">
        <span class="mono" style="display:block;overflow:hidden;text-overflow:ellipsis">${esc(a.user)}</span>
        <span class="dim" style="font-size:.7rem">${a.has_web ? 'has public_html' : 'no web root'}</span>
      </span>
    </label>`).join('');
  scanAccountsCount();
}

function scanAccountsSelected() {
  return Array.from(document.querySelectorAll('.scan-acct:checked')).map(c => c.value);
}

function scanAccountsCount() {
  const n = scanAccountsSelected().length;
  const el = g('scan-accounts-count');
  if (el) el.textContent = n + ' selected';
  const go = g('scan-accounts-go');
  if (go) go.disabled = (n === 0);      // nothing selected is not a scan
}

function scanAccountsAll(on) {
  document.querySelectorAll('.scan-acct').forEach(c => { c.checked = !!on; });
  scanAccountsCount();
}

// Start the scan from inside the dialog, which is where the selection is.
function startScanFromPicker() {
  if (!scanAccountsSelected().length) {
    toast('Select at least one account to scan', 'error');
    return;
  }
  closeModal('scan-accounts-modal');
  startScan();
}

// Choosing Custom opens the dialog; choosing anything else is a plain scan.
function onScanTypeChange() {
  const type = g('scan-type-sel')?.value || 'quick';
  if (type === 'custom') openScanAccounts();
}

// The toolbar button, in whichever of its two states applies.
//
// While a scan runs it IS the stop control. It previously read "Scanning..."
// and was disabled, which left the only way to stop a scan as a ghost button
// at the far right of the progress row -- the least visible element on the
// page, for the one action an operator urgently wants during a scan that is
// loading the server.
//
// Five separate places set this button's label and disabled state by hand,
// which is how it came to disagree with itself. They all call this now.
function setScanButton(running) {
  const btn = g('scan-btn');
  if (!btn) return;
  btn.disabled = false;
  if (running) {
    btn.textContent = '\u25A0 Stop Scan';
    btn.classList.remove('btn-primary');
    btn.classList.add('btn-danger');
    btn.title = 'Stop the scan in progress';
  } else {
    btn.textContent = '\u25B6 Start Scan';
    btn.classList.remove('btn-danger');
    btn.classList.add('btn-primary');
    btn.title = '';
  }
}

// What the toolbar button does depends on what it currently says.
function onScanButton() {
  if (State.scanJobId && State.scanInterval) { stopScan(State.scanJobId); return; }
  startScan();
}

async function stopScan(jobId) {
  const btn = g('scan-stop-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Stopping…'; }

  const res = Demo.active
    ? { success: true, message: 'Scan stopped.' }
    : await API.post('scanner/stop', jobId ? { job_id: jobId } : {});

  if (btn) { btn.disabled = false; btn.textContent = '\u25A0 Stop Scan'; }

  if (!res?.success) {
    // Leave the progress card up on failure: hiding it would imply the scan
    // had stopped, which is the behaviour being fixed.
    toast(res?.error || 'Could not stop the scan', 'error');
    return;
  }

  clearInterval(State.scanInterval);
  State.scanInterval = null;
  State.scanJobId = null;
  setScanButton(false);
  const card = document.getElementById('scan-progress-card');
  if (card) card.style.display = 'none';

  // Say what actually happened. A clamscan the kernel had not reaped yet is
  // worth mentioning rather than glossing over with a flat "stopped".
  let msg = res.message || 'Scan stopped.';
  if (res.stragglers) {
    msg += ' ' + res.stragglers + ' clamscan process(es) are still finishing.';
  }
  toast(msg, res.stragglers ? 'info' : 'success');

  loadThreats();
  refreshDashboard();
}

// The scanner page's "auto-quarantine off" line was hard-coded in the markup
// and only ever corrected by loadSettings(), which runs on the Settings page.
// Open the Scanner page directly and it stated the default regardless of the
// real setting -- so the toggle looked like it did nothing.
async function loadScannerQuarantineState() {
  const el = document.getElementById('scanner-quar-state');
  if (!el) return;

  const res = Demo.active ? { success: true, data: { auto_quarantine: '0' } }
                          : await API.getSettings();
  if (!res?.success) { el.textContent = 'auto-quarantine state unknown'; return; }

  const on = (res.data?.auto_quarantine ?? '0') === '1';
  el.textContent = on ? 'auto-quarantine on' : 'auto-quarantine off';
  el.style.color = on ? 'var(--ok, #22c55e)' : 'var(--txt3)';
  el.title = on
    ? 'Detected files are moved to the quarantine directory automatically.'
    : 'Threats are recorded but files are left in place. Turn this on in Settings.';
}

async function loadThreats() {
  loadScannerQuarantineState();
  const filter = document.getElementById('threat-filter')?.value || '';
  const res = Demo.active
    ? Demo.mockThreats()
    : await API.threats(filter);

  const tbody = document.getElementById('threats-body');
  if (!tbody) return;

  const threats = res?.data || [];
  document.getElementById('threat-count-badge').textContent = threats.length;

  if (!threats.length) {
    tbody.innerHTML = '<tr><td colspan="10" style="text-align:center;color:var(--txt3);padding:28px">No threats found. Run a scan to check your server.</td></tr>';
    const masterEmpty = document.getElementById('threat-check-all');
    if (masterEmpty) { masterEmpty.checked = false; masterEmpty.indeterminate = false; }
    updateBulkBar();
    return;
  }

  // Every value below is escaped. A file path is attacker-controlled -- naming
  // a file is exactly the kind of thing malware does -- and interpolating it
  // raw into innerHTML made the threats table an XSS sink in the dashboard of
  // a security product. The View button reads such a file deliberately, which
  // makes getting this right more important, not less.
  tbody.innerHTML = threats.map(t => {
    const path  = String(t.file_path || '');
    const short = path.split('/').slice(-2).join('/');
    const id    = parseInt(t.id, 10) || 0;

    return `
    <tr>
      <td style="width:34px">
        <input type="checkbox" class="threat-check" data-id="${id}"
               onchange="updateBulkBar()" aria-label="Select ${esc(short)}">
      </td>
      <td>${sevBadge(t.severity)}</td>
      <td class="mono primary" style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(path)}">
        ${esc(short)}
      </td>
      <td class="mono" style="color:var(--blue);font-size:.75rem">${esc(t.cpanel_user || '—')}</td>
      <td class="mono" style="color:var(--red)">${esc(t.threat_name || '')}</td>
      <td><span class="badge badge-amber">${esc(t.threat_type || '')}</span></td>
      <td class="dim">${fmtBytes(t.size || 0)}</td>
      <td class="dim">${reltime(t.detected_at)}</td>
      <td>${threatStatusBadge(t.status)}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-ghost btn-xs" onclick="viewThreatFile(${id})"
                title="View contents (does not run the file)">👁</button>
        ${t.status === 'active' ? `
          <button class="btn btn-ghost btn-xs" onclick="quarantineThreat(${id})" title="Quarantine">🔒</button>
          <button class="btn btn-danger btn-xs" onclick="deleteThreat(${id})" title="Delete file">🗑</button>
        ` : ''}
        ${t.status === 'quarantined' ? `
          <button class="btn btn-ghost btn-xs" onclick="restoreThreat(${id})" title="Restore">↺</button>
        ` : ''}
      </td>
    </tr>`;
  }).join('');

  const master = document.getElementById('threat-check-all');
  if (master) { master.checked = false; master.indeterminate = false; }
  updateBulkBar();
}

function threatStatusBadge(status) {
  const map = {
    active:      '<span class="badge badge-red">Active</span>',
    quarantined: '<span class="badge badge-amber">Quarantined</span>',
    deleted:     '<span class="badge badge-gray">Deleted</span>',
    restored:    '<span class="badge badge-blue">Restored</span>',
  };
  return map[status] || `<span class="badge badge-gray">${esc(status || '')}</span>`;
}

async function quarantineThreat(id) {
  const res = Demo.active ? { success: true } : await API.quarantineThreat(id);
  if (res?.success) { toast('File quarantined', 'success'); loadThreats(); return; }
  // "Quarantine failed" with no reason is what made this look like a mystery.
  // The API now explains itself -- cross-device move, unwritable directory, an
  // immutable file -- so show that.
  toast('Quarantine failed: ' + ((res && (res.error || res.detail)) || 'no reason given'),
        'error', 10000);
}

async function restoreThreat(id) {
  if (!confirm('Restore this file from quarantine?')) return;
  const res = Demo.active ? { success: true } : await API.restoreThreat(id);
  if (res?.success) { toast('File restored', 'success'); loadThreats(); }
  else toast('Restore failed', 'error');
}

async function deleteThreat(id) {
  if (!confirm('Permanently delete this file? This cannot be undone.')) return;
  const res = Demo.active ? { success: true } : await API.deleteThreat(id);
  if (res?.success) { toast('File deleted', 'success'); loadThreats(); }
  else toast('Delete failed', 'error');
}

async function updateSignatures() {
  toast('Updating signatures…', 'info');
  const res = Demo.active ? { success: true } : await API.updateSigs();
  if (res?.success) toast('Signatures updated', 'success');
  else toast('Update failed', 'error');
}

// ── Firewall ──────────────────────────────────────────────────────────────────
// Loaded in stages, newest-first, with each panel drawn as its data arrives.
//
// All three were fetched together and rendered together, so the slowest
// decided when ANY of them appeared -- the page sat entirely blank until the
// last one landed. Staging them means the numbers at the top are on screen
// while the tables are still coming, and a slow panel can no longer hold up
// the ones that are ready.
//
// The overlay is up for the whole sequence, which is what stops the page being
// clicked into a queue of overlapping work while it fills in.
async function loadFirewall() {
  return API.withBusy('Loading firewall…', () => loadFirewallStages());
}

async function loadFirewallStages() {
  // Stage 1 — the three counts. Indexed queries, so this is the one that is
  // reliably quick, and it is what the eye goes to first.
  const stats = Demo.active
    ? { success: true, data: { blocked_ips: 382, active_rules: 14, blocked_today: 8241 } }
    : await API.fwStats().catch(() => null);

  if (stats?.success) {
    document.getElementById('fw-stat-rules').textContent   = fmtNum(stats.data?.active_rules || 0);
    document.getElementById('fw-stat-blocked').textContent = fmtNum(stats.data?.blocked_ips  || 0);
    document.getElementById('fw-stat-today').textContent   = fmtNum(stats.data?.blocked_today || 0);
    // "iptables active" was printed unconditionally -- including when the
    // count could not be taken at all, which reads as a working firewall.
    const csf = stats.data?.csf_status || {};
    // Three states, not two: measured, measured-and-failed, and not yet
    // measured. The probe runs in the scheduler now, so a freshly installed
    // server has no reading for the first few minutes -- saying "0 rules"
    // there would read as "no firewall".
    const ipt = stats.data?.probe_pending
      ? 'iptables: not measured yet'
      : (stats.data?.iptables_unknown
          ? 'iptables status unavailable (busy)'
          : 'iptables: ' + fmtNum(stats.data?.iptables_rules || 0) + ' rule(s)');
    document.getElementById('fw-status-line').textContent =
      `CSF ${csf.installed ? '✓ installed' : '✗ not found'}`
      + (csf.installed && csf.running === false ? ' (lfd not running)' : '')
      + ' · ' + ipt;
  }

  // Stage 2 — the rules table.
  const rules = Demo.active ? Demo.mockFWRules() : await API.fwRules().catch(() => null);

  const tbody = document.getElementById('fw-rules-body');
  if (tbody && rules?.data) {
    tbody.innerHTML = rules.data.map(r => `
      <tr>
        <td class="primary">${r.name}</td>
        <td>${r.direction}</td>
        <td class="mono">${r.protocol || '—'}</td>
        <td class="mono">${r.port || 'any'}</td>
        <td>${actionBadge(r.action)}</td>
        <td>
          <label class="toggle">
            <input type="checkbox" ${r.enabled ? 'checked' : ''} onchange="toggleRule(${r.id}, this.checked)">
            <span class="toggle-slider"></span>
          </label>
        </td>
        <td>
          <button class="btn btn-ghost btn-xs" onclick="deleteRule(${r.id})">✕</button>
        </td>
      </tr>`).join('');
  }

  // Stage 3 — recently blocked addresses. Last because it is the panel you
  // look at after the counts and the rules, so it is the one that can afford
  // to arrive last.
  const blocked = Demo.active
    ? { success: true, data: [] }
    : await API.fwBlocked().catch(() => null);

  const recentEl = document.getElementById('fw-recent-blocked');
  if (recentEl && blocked?.data?.length) {
    recentEl.innerHTML = blocked.data.slice(0, 8).map(b => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border)">
        <span class="mono" style="font-size:.72rem">${b.ip_address}</span>
        <div style="display:flex;gap:6px;align-items:center">
          <span class="dim" style="font-size:.65rem">${reltime(b.blocked_at)}</span>
          <button class="btn btn-ghost btn-xs" onclick="unblockIP('${b.ip_address}')">Unblock</button>
        </div>
      </div>`).join('');
  } else if (recentEl) {
    recentEl.innerHTML = '<div class="dim" style="font-size:.78rem">No recently blocked IPs</div>';
  }

  // Geo block grid
  renderGeoGrid();
}

function actionBadge(action) {
  const map = {
    ACCEPT: 'badge-green', DROP: 'badge-red',
    REJECT: 'badge-red',   LIMIT: 'badge-amber',
  };
  return `<span class="badge ${map[action] || 'badge-gray'}">${action}</span>`;
}

async function blockIP() {
  const ip = document.getElementById('fw-ip-input')?.value?.trim();
  const reason = document.getElementById('fw-ip-reason')?.value?.trim() || 'Manual block';
  if (!ip) { toast('Enter an IP address', 'error'); return; }

  const res = Demo.active ? { success: true } : await API.fwBlockIP(ip, reason, false);
  if (res?.success) { toast(`${ip} blocked`, 'success'); loadFirewall(); }
  else toast(res?.error || 'Block failed', 'error');
}

async function allowIP() {
  const ip = document.getElementById('fw-ip-input')?.value?.trim();
  if (!ip) { toast('Enter an IP address', 'error'); return; }
  const res = Demo.active ? { success: true } : await API.fwAllowIP(ip, '');
  if (res?.success) { toast(`${ip} allowed`, 'success'); }
  else toast('Failed', 'error');
}

async function unblockIP(ip) {
  const res = Demo.active ? { success: true } : await API.fwUnblockIP(ip);
  if (res?.success) { toast(`${ip} unblocked`, 'success'); loadFirewall(); }
  else toast('Unblock failed', 'error');
}

async function toggleRule(id, enabled) {
  const res = Demo.active ? { success: true } : await API.fwToggleRule(id, enabled);
  if (!res?.success) toast('Failed to toggle rule', 'error');
}

async function deleteRule(id) {
  if (!confirm('Delete this firewall rule?')) return;
  const res = Demo.active ? { success: true } : await API.fwDeleteRule(id);
  if (res?.success) { toast('Rule deleted', 'success'); loadFirewall(); }
  else toast('Failed', 'error');
}

async function reloadFirewall() {
  const res = Demo.active ? { success: true } : await API.fwReload();
  if (res?.success) toast('Firewall reloaded', 'success');
  else toast('Reload failed', 'error');
}

function openAddRuleModal() { openModal('add-rule-modal'); }

async function submitAddRule() {
  const rule = {
    name:      document.getElementById('rule-name')?.value,
    direction: document.getElementById('rule-dir')?.value,
    protocol:  document.getElementById('rule-proto')?.value,
    port:      document.getElementById('rule-port')?.value,
    action:    document.getElementById('rule-action')?.value,
    source_ip: document.getElementById('rule-source')?.value,
    comment:   document.getElementById('rule-comment')?.value,
  };
  if (!rule.name) { toast('Rule name required', 'error'); return; }

  const res = Demo.active ? { success: true } : await API.fwAddRule(rule);
  if (res?.success) {
    toast('Rule added', 'success');
    closeModal('add-rule-modal');
    loadFirewall();
  } else toast(res?.error || 'Failed', 'error');
}

const GEO_COUNTRIES = [
  ['AF','Afghanistan'],['BY','Belarus'],['CN','China'],['CU','Cuba'],
  ['IR','Iran'],['IQ','Iraq'],['KP','North Korea'],['LY','Libya'],
  ['RU','Russia'],['SD','Sudan'],['SY','Syria'],['VE','Venezuela'],
  ['UA','Ukraine'],['MM','Myanmar'],['YE','Yemen'],['ZW','Zimbabwe'],
  ['NG','Nigeria'],['PK','Pakistan'],['BD','Bangladesh'],['ID','Indonesia'],
  ['VN','Vietnam'],['IN','India'],['BR','Brazil'],['MX','Mexico'],
];

function renderGeoGrid() {
  const grid = document.getElementById('geo-block-grid');
  if (!grid) return;
  const saved = (Database?.setting?.('geo_block_countries') || '').split(',').filter(Boolean);
  grid.innerHTML = GEO_COUNTRIES.map(([cc, name]) => {
    const sel = saved.includes(cc) || State.geoSelected.has(cc);
    return `
      <div onclick="toggleGeo('${cc}', this)"
           style="padding:8px 10px;border-radius:8px;cursor:pointer;font-size:.72rem;
                  border:1px solid ${sel ? 'var(--red)' : 'var(--border)'};
                  background:${sel ? 'var(--red-dim)' : 'var(--card2)'};
                  color:${sel ? 'var(--red)' : 'var(--txt2)'};
                  user-select:none;transition:all .15s"
           data-cc="${cc}" data-sel="${sel ? '1' : '0'}">
        <div style="font-weight:700">${cc}</div>
        <div style="font-size:.6rem;margin-top:2px;opacity:.7">${name}</div>
      </div>`;
  }).join('');
}

function toggleGeo(cc, el) {
  const sel = el.dataset.sel === '1';
  el.dataset.sel = sel ? '0' : '1';
  el.style.border  = sel ? '1px solid var(--border)' : '1px solid var(--red)';
  el.style.background = sel ? 'var(--card2)' : 'var(--red-dim)';
  el.style.color   = sel ? 'var(--txt2)' : 'var(--red)';
  sel ? State.geoSelected.delete(cc) : State.geoSelected.add(cc);
}

async function saveGeoBlock() {
  const countries = [...State.geoSelected];
  const res = Demo.active ? { success: true } : await API.fwGeoBlock(countries);
  if (res?.success) toast(`Geo block saved (${countries.length} countries)`, 'success');
  else toast('Failed to save', 'error');
}

// ── WAF ───────────────────────────────────────────────────────────────────────
// Explain an empty WAF table.
//
// "No attacks were blocked" and "nothing is reading a ModSecurity log" look
// identical as a blank table, and the second was true on every install:
// ingestModSecLog() was reachable only from an API route nothing called, so
// waf_events stayed empty for ever. The banner names which it is.
async function loadWafIngestState() {
  const banner = document.getElementById('waf-ingest-banner');
  if (!banner) return;

  const res = await API.wafIngestStatus();
  if (!res?.success) { banner.style.display = 'none'; return; }
  const d = res.data || {};

  const title  = document.getElementById('waf-ingest-title');
  const detail = document.getElementById('waf-ingest-detail');

  if (!d.log_found) {
    banner.style.display = '';
    if (title) title.textContent = 'No ModSecurity audit log found';
    if (detail) {
      detail.textContent =
        'Nothing can be reported until ModSecurity is writing an audit log this '
        + 'server can read. Looked in: ' + (d.candidates || []).join(', ')
        + '. If ModSecurity logs somewhere else, set waf_audit_log_override in Settings.';
    }
    return;
  }

  // Found, but never read — the state every install was in.
  if (!d.last_run) {
    banner.style.display = '';
    if (title) title.textContent = 'ModSecurity log found but not yet read';
    if (detail) {
      detail.textContent = d.log_path + ' (' + fmtNum(d.log_size || 0)
        + ' bytes). It is read every 15 minutes from now on; use the button to '
        + 'read it immediately.';
    }
    return;
  }

  // Working. Only worth saying something if it is finding nothing at all.
  if ((d.total_events || 0) === 0) {
    banner.style.display = '';
    if (title) title.textContent = 'Reading the log, no events recorded yet';
    if (detail) {
      detail.textContent = 'Reading ' + d.log_path + '. No ModSecurity events have '
        + 'been logged yet — that is normal on a quiet server, or if ModSecurity '
        + 'is in DetectionOnly with no rules matching.';
    }
    return;
  }
  banner.style.display = 'none';
}

async function wafIngestNow() {
  const res = await API.wafIngest();
  if (!res?.success) { toast(res?.error || 'Could not read the log', 'error'); return; }
  toast('Read ' + (res.ingested || 0) + ' new event(s)', 'success');
  loadWafIngestState();
  loadWAF();
}

async function loadWAF() {
  loadWafIngestState();
  const [stats, cats] = await Promise.all([
    Demo.active ? Demo.mockWAFStats() : API.wafStats(),
    API.wafCats(),
  ]);

  if (stats?.success) {
    const d = stats.data;
    document.getElementById('waf-stat-total').textContent    = fmtNum(d.total_events || 0);
    document.getElementById('waf-stat-today').textContent    = fmtNum(d.events_today || 0);
    document.getElementById('waf-stat-top-rule').textContent = d.top_rules?.[0]?.rule_id || '—';
    document.getElementById('waf-stat-mode').textContent     = 'On';
  }

  loadWAFEvents();

  // CRS Categories
  const catContainer = document.getElementById('waf-categories');
  if (catContainer && cats?.data) {
    catContainer.innerHTML = cats.data.map(c => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
        <div>
          <div style="font-size:.78rem;font-weight:600">${c.id} — ${c.name}</div>
          <div style="font-size:.65rem;color:var(--txt3)">${c.rules} rules</div>
        </div>
        <span class="badge ${c.active ? 'badge-green' : 'badge-gray'}">${c.active ? 'Active' : 'Disabled'}</span>
      </div>`).join('');
  }
}

async function loadWAFEvents() {
  const sev = document.getElementById('waf-sev-filter')?.value || '';
  const res = Demo.active
    ? { success: true, data: [] }
    : await API.wafEvents(sev);

  const tbody = document.getElementById('waf-events-body');
  if (!tbody) return;
  const events = res?.data || [];
  if (!events.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--txt3);padding:24px">No WAF events. Events are ingested from ModSecurity audit log.</td></tr>';
    return;
  }
  // Keyed by id so the dialog can render from what is already loaded, without
  // a second request and without putting the row's data into the markup.
  _wafEvents = {};
  events.forEach(e => { _wafEvents[String(e.id)] = e; });

  // EVERY field here comes from an attacker-controlled HTTP request: the URI,
  // the rule message quoting the matched data, the user agent. Interpolating
  // them raw into innerHTML -- which is what this did -- means a request
  // crafted to contain markup runs as script in the dashboard of whoever reads
  // the log. A security product's own attack log is the last place that should
  // be true.
  tbody.innerHTML = events.map(e => `
    <tr class="waf-row" tabindex="0" role="button"
        style="cursor:pointer"
        onclick="showWafEvent('${esc(String(e.id))}')"
        onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();showWafEvent('${esc(String(e.id))}')}"
        title="Show full details">
      <td>${sevBadge(e.severity)}</td>
      <td class="mono">${esc(e.rule_id)}</td>
      <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(e.rule_msg)}</td>
      <td class="mono">${esc(e.ip_address) || '<span class="dim">—</span>'}</td>
      <td class="mono" style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(e.uri)}</td>
      <td class="dim">${esc(reltime(e.timestamp))}</td>
    </tr>`).join('');
}

// ── WAF event detail ────────────────────────────────────────────────────────
let _wafEvents = {};
let _wafEventShown = null;

function showWafEvent(id) {
  const e = _wafEvents[String(id)];
  if (!e) return;
  _wafEventShown = e;

  const put = (elId, val, mono) => {
    const el = document.getElementById(elId);
    if (!el) return;
    // textContent, not innerHTML: same attacker-controlled data as the table.
    el.textContent = (val === null || val === undefined || val === '') ? '—' : String(val);
    if (mono) el.classList.add('mono');
  };

  const sev = document.getElementById('wem-sev');
  if (sev) sev.innerHTML = sevBadge(e.severity);   // our own markup, fixed set

  put('wem-rule',   e.rule_id);
  put('wem-msg',    e.rule_msg);
  put('wem-ip',     e.ip_address);
  put('wem-method', e.method);
  put('wem-host',   e.host);
  put('wem-action', e.action);
  put('wem-when',   e.timestamp ? new Date(e.timestamp * 1000).toLocaleString()
                                + ' (' + reltime(e.timestamp) + ')' : '—');
  put('wem-uri',    e.uri);

  // Hide the user-agent block entirely when there is none, rather than showing
  // an empty box: these rows predate the parser learning to read it.
  const uaWrap = document.getElementById('wem-ua-wrap');
  if (uaWrap) uaWrap.style.display = e.user_agent ? '' : 'none';
  put('wem-ua', e.user_agent);

  // Nothing to block or look up without a source address.
  ['wem-block', 'wem-lookup'].forEach(b => {
    const el = document.getElementById(b);
    if (el) el.disabled = !e.ip_address;
  });

  openModal('waf-event-modal');
}

async function blockWafEventIp() {
  const e = _wafEventShown;
  if (!e?.ip_address) return;
  const res = await API.fwBlockIP(e.ip_address,
    'WAF rule ' + (e.rule_id || '') + ' - ' + (e.rule_msg || ''), false);
  if (res?.success) {
    toast('Blocked ' + e.ip_address, 'success');
    closeModal('waf-event-modal');
  } else {
    toast(res?.error || 'Could not block that address', 'error');
  }
}

function lookupWafEventIp() {
  const e = _wafEventShown;
  if (!e?.ip_address) return;
  closeModal('waf-event-modal');
  openPage('iprep');
  const input = document.getElementById('iprep-ip-input');
  if (input) { input.value = e.ip_address; checkIP(); }
}

function copyWafEvent() {
  const e = _wafEventShown;
  if (!e) return;
  const text = [
    'Rule ID:    ' + (e.rule_id    || '—'),
    'Message:    ' + (e.rule_msg   || '—'),
    'Severity:   ' + (e.severity   || '—'),
    'Source IP:  ' + (e.ip_address || '—'),
    'Method:     ' + (e.method     || '—'),
    'Host:       ' + (e.host       || '—'),
    'URI:        ' + (e.uri        || '—'),
    'User agent: ' + (e.user_agent || '—'),
    'Action:     ' + (e.action     || '—'),
    'When:       ' + (e.timestamp ? new Date(e.timestamp * 1000).toISOString() : '—'),
  ].join('\n');

  const done = () => toast('Event details copied', 'success');
  if (navigator.clipboard?.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else {
    fallbackCopy(text, done);
  }
}

function fallbackCopy(text, done) {
  // clipboard API needs a secure context; WHM is often reached over a hostname
  // with a self-signed certificate, where it is unavailable.
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); done(); }
  catch (_) { toast('Could not copy to the clipboard', 'error'); }
  document.body.removeChild(ta);
}

async function setWAFMode() {
  const mode = document.getElementById('waf-mode-sel')?.value;
  const res  = Demo.active ? { success: true } : await API.wafSetMode(mode);
  if (res?.success) toast(`WAF mode set to ${mode}`, 'success');
  else toast('Failed', 'error');
}

// ── Dashboard overview ─────────────────────────────────────────────────────
//
// Headline figures for the period, against the period before it. A number on
// its own says nothing about direction; the comparison is what makes it worth
// the space.

function ovDelta(d) {
  // null means there was nothing to compare against -- a first month, or a
  // metric that has only just started being collected. "+100%" would be a
  // fabrication, and "0%" would claim nothing changed.
  if (d === null || d === undefined) {
    return '<span class="dim" style="font-size:.72rem">no earlier period</span>';
  }
  const up   = d > 0;
  const flat = Math.abs(d) < 0.005;
  if (flat) return '<span class="dim" style="font-size:.72rem">no change</span>';
  // More blocked attacks is not bad news, so neither direction is coloured as
  // good or bad here -- it is a direction, not a verdict.
  return '<span style="font-size:.74rem;color:var(--txt2)">'
       + (up ? '\u25b2 ' : '\u25bc ') + Math.abs(d).toFixed(2) + '%</span>';
}

async function loadOverview() {
  const daysEl = document.getElementById('ov-days');
  const days   = parseInt(daysEl?.value, 10) || 30;

  const cards = document.getElementById('ov-cards');
  if (cards && !cards.children.length) { cards.innerHTML = loadingMark('Loading figures…'); }

  const res = await API.overview(days).catch(() => null);
  if (!res?.success) {
    if (cards) cards.innerHTML = '<div class="dim" style="font-size:.82rem">'
      + 'Could not load the overview.</div>';
    return;
  }
  const d = res.data;

  // ── Headline cards ──────────────────────────────────────────────────────
  if (cards) {
    cards.innerHTML = d.cards.map(c => `
      <div class="card" style="position:relative;overflow:hidden">
        <div class="card-body" style="display:flex;align-items:center;gap:14px">
          <img src="${assetUrl('images/icon.png')}" alt="" aria-hidden="true"
               style="width:62px;height:62px;object-fit:contain;opacity:.13;flex:none">
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:baseline;gap:9px;flex-wrap:wrap">
              <div style="font-size:1.9rem;font-weight:800;letter-spacing:-.02em">${fmtNum(c.value)}</div>
              ${ovDelta(c.delta)}
            </div>
            <div class="dim" style="font-size:.76rem;margin-top:2px">${esc(c.label)}</div>
          </div>
          <div style="text-align:right;flex:none">
            <div style="font-weight:700;font-size:.95rem">${fmtNum(c.overall)}</div>
            <div class="dim" style="font-size:.66rem">Overall</div>
          </div>
        </div>
      </div>`).join('');
  }

  // ── Donut: what the period was made of ──────────────────────────────────
  const slices = [
    { label: 'Web attacks',   value: d.cards[1].value, color: '#3b82f6' },
    { label: 'Threats',       value: d.cards[0].value, color: '#ef4444' },
    { label: 'Blocked IPs',   value: d.cards[2].value, color: '#22c55e' },
  ];
  const total = slices.reduce((a, s) => a + s.value, 0);
  const donut = document.getElementById('ov-donut');
  if (donut && typeof Charts !== 'undefined' && Charts.donut) {
    Charts.donut(donut, slices, { value: fmtNum(total), caption: `last ${d.days} days` });
  }
  const legend = document.getElementById('ov-donut-legend');
  if (legend) {
    legend.innerHTML = slices.map(s => `
      <div style="display:flex;align-items:center;gap:7px">
        <span style="width:9px;height:9px;border-radius:2px;background:${s.color};flex:none"></span>
        <span style="flex:1">${esc(s.label)}</span>
        <span class="dim">${fmtNum(s.value)}</span>
      </div>`).join('');
  }

  // ── This period against the last, as bars ───────────────────────────────
  const cmp = document.getElementById('ov-compare');
  if (cmp) {
    const mx = Math.max(...d.cards.map(c => Math.max(c.value, c.prev)), 1);
    cmp.innerHTML = d.cards.map(c => `
      <div style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;font-size:.76rem;margin-bottom:5px">
          <span>${esc(c.label)}</span>
        </div>
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:3px">
          <div style="flex:1;height:9px;border-radius:5px;background:var(--card2,#1b2029);overflow:hidden">
            <div style="width:${(c.value / mx) * 100}%;height:100%;background:#3b82f6"></div>
          </div>
          <span style="font-size:.74rem;min-width:62px;text-align:right">${fmtNum(c.value)}</span>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="flex:1;height:9px;border-radius:5px;background:var(--card2,#1b2029);overflow:hidden">
            <div style="width:${(c.prev / mx) * 100}%;height:100%;background:#64748b"></div>
          </div>
          <span class="dim" style="font-size:.74rem;min-width:62px;text-align:right">${fmtNum(c.prev)}</span>
        </div>
      </div>`).join('')
      + `<div style="display:flex;gap:16px;font-size:.72rem;margin-top:4px">
           <span style="display:flex;align-items:center;gap:6px">
             <span style="width:9px;height:9px;border-radius:2px;background:#3b82f6"></span>This period</span>
           <span style="display:flex;align-items:center;gap:6px">
             <span style="width:9px;height:9px;border-radius:2px;background:#64748b"></span>Previous</span>
         </div>`;
  }

  // ── Per-day charts ──────────────────────────────────────────────────────
  const wafTitle = document.getElementById('ov-waf-title');
  if (wafTitle) wafTitle.textContent = `Web attacks blocked — ${d.days} days`;

  const wafChart = document.getElementById('ov-waf-chart');
  if (wafChart && typeof Charts !== 'undefined' && Charts.bars) {
    Charts.bars(wafChart, d.series.labels,
      [{ values: d.series.waf, color: '#3b82f6', label: 'Web attacks' }]);
  }
  const thChart = document.getElementById('ov-threat-chart');
  if (thChart && typeof Charts !== 'undefined' && Charts.bars) {
    Charts.bars(thChart, d.series.labels, [
      { values: d.series.threats, color: '#ef4444', label: 'Malware' },
      { values: d.series.brute,   color: '#f59e0b', label: 'Failed logins' },
    ]);
  }

  // ── Summary ─────────────────────────────────────────────────────────────
  const sum = document.getElementById('ov-summary');
  if (sum) {
    sum.innerHTML = d.summary.map(r => `
      <div onclick="openPage('${esc(r.page)}')"
           style="display:flex;align-items:center;justify-content:space-between;
                  padding:13px 18px;border-bottom:1px solid var(--line,#2d333a);
                  cursor:pointer;font-size:.84rem">
        <span>${esc(r.label)}</span>
        <span style="font-weight:800;font-size:1.05rem;
                     color:${r.value > 0 ? 'var(--amber,#f59e0b)' : 'var(--txt2)'}">${fmtNum(r.value)}</span>
      </div>`).join('');
  }

  renderOverviewAlerts();
}

// Alerts, built from what the dashboard already knows rather than a second
// round of requests.
function renderOverviewAlerts() {
  const el = document.getElementById('ov-alerts');
  if (!el) return;
  const items = [];

  const push = (tone, text, page) => items.push({ tone, text, page });

  if (State.lastDash?.firewall && State.lastDash.firewall.active_rules === 0) {
    push('red', 'No firewall rules are active', 'firewall');
  }
  if (State.lastMonitor && !State.lastMonitor.running) {
    push('red', 'Real-time monitoring is not running', 'monitor');
  } else if (State.lastMonitor?.suspended) {
    push('amber', 'Real-time scanning is paused for a backup', 'monitor');
  }
  if (State.lastDash?.scanner?.last_scan) {
    const age = (Date.now() / 1000) - Number(State.lastDash.scanner.last_scan);
    if (age > 7 * 86400) { push('amber', 'No scan in over a week', 'scanner'); }
  }

  el.innerHTML = items.length
    ? items.map(i => `
        <div onclick="openPage('${esc(i.page)}')"
             style="display:flex;align-items:center;gap:11px;padding:12px 14px;border-radius:9px;
                    cursor:pointer;font-size:.82rem;
                    background:${i.tone === 'red' ? 'rgba(239,68,68,.12)' : 'rgba(245,158,11,.12)'};
                    border:1px solid ${i.tone === 'red' ? 'rgba(239,68,68,.32)' : 'rgba(245,158,11,.32)'}">
          <span style="font-size:1rem">${i.tone === 'red' ? '\u26d4' : '\u26a0\ufe0f'}</span>
          <span style="flex:1">${esc(i.text)}</span>
        </div>`).join('')
    : '<div class="dim" style="font-size:.82rem;padding:6px 0">Nothing needs attention.</div>';
}

// ── Brute Force ────────────────────────────────────────────────────────────────
//
// The dashboard has charted a "Brute Force" series since it was written, and
// nothing ever produced the data for it. These read what the detector now
// records.

async function loadBruteForce() {
  const [statsRes, tlRes, offRes, tgtRes] = await Promise.all([
    API.bfStats().catch(() => null),
    API.bfTimeline(14).catch(() => null),
    API.bfOffenders().catch(() => null),
    API.bfTargets().catch(() => null),
  ]);

  const d = statsRes?.data;
  if (d) {
    setText('bf-24h',       fmtNum(d.attempts_24h || 0));
    setText('bf-7d',        fmtNum(d.attempts_7d  || 0));
    setText('bf-offenders', fmtNum(d.offenders    || 0));
    setText('bf-blocked',   fmtNum(d.blocked      || 0));

    const state = document.getElementById('bf-state');
    if (state) {
      state.textContent = d.enabled
        ? (d.auto_block ? 'detecting and blocking automatically' : 'detecting only')
        : 'detection is switched off';
      state.style.color = d.enabled ? 'var(--ok, #22c55e)' : 'var(--amber, #f59e0b)';
    }

    // Settings, filled from what the server actually has rather than from
    // whatever the markup shipped with.
    const chk = (id, v) => { const e = document.getElementById(id); if (e) e.checked = !!v; };
    const val = (id, v) => { const e = document.getElementById(id); if (e) e.value = v; };
    chk('bf-set-enabled', d.enabled);
    chk('bf-set-block',   d.auto_block);
    val('bf-set-threshold', d.threshold || 5);
    val('bf-set-window',    Math.round((d.window || 600) / 60));
    // The ladder, in hours, which is how the policy is written.
    val('bf-set-ladder', (d.ladder_secs || [10800, 21600, 86400, 0])
          .map(x => x === 0 ? '0' : String(x / 3600)).join(', '));
    const prev = g('bf-ladder-preview');
    if (prev) {
      prev.textContent = (d.ladder || []).length
        ? ' Currently: ' + d.ladder.join(' → ') : '';
    }

    // Which logs are actually being read. An empty table means "nothing is
    // attacking you" or "we are reading nothing", and those look identical.
    const src = document.getElementById('bf-sources');
    if (src) {
      src.innerHTML = Object.entries(d.sources || {}).map(([k, v]) => `
        <div style="display:flex;gap:10px;align-items:center;font-size:.78rem">
          <span style="width:16px;color:${v.log_found ? 'var(--ok,#22c55e)' : 'var(--amber,#f59e0b)'}">
            ${v.log_found ? '\u2713' : '\u2717'}</span>
          <span style="min-width:150px">${esc(v.label)}</span>
          <span class="mono dim" style="flex:1">${esc(v.log_path || 'no readable log found')}</span>
          <span class="dim">${fmtNum(v.attempts_24h || 0)} in 24h</span>
        </div>`).join('');
    }
  }

  const tl = tlRes?.data || [];
  const svg = document.getElementById('bf-chart');
  if (svg && tl.length && typeof Charts !== 'undefined' && Charts.timeline) {
    Charts.timeline(svg, tl.map(x => x.date), [
      { values: tl.map(x => x.attempts), color: '#f59e0b', label: 'Failed logins' },
      { values: tl.map(x => x.blocked),  color: '#ef4444', label: 'Blocked' },
    ]);
  }

  // Offenders. Every value here comes from a log line written by whoever is
  // attacking the server, so all of it is escaped.
  const tb = document.getElementById('bf-offenders-body');
  if (tb) {
    const rows = offRes?.data || [];
    if (!rows.length) {
      tb.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--txt3);padding:22px">'
        + 'No offending addresses. Either nothing has crossed the threshold, or no '
        + 'authentication log could be read — the Log sources panel below says which.</td></tr>';
    } else {
      tb.innerHTML = rows.map(r => `
        <tr>
          <td class="mono">${esc(r.ip_address)}</td>
          <td>${esc(r.service)}</td>
          <td><b>${fmtNum(r.attempts)}</b></td>
          <td class="dim" style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
              title="${esc(r.usernames || '')}">${esc(r.usernames || '—')}</td>
          <td class="dim">${esc(reltime(r.last_seen))}</td>
          <td>${bfStatusBadge(r)}</td>
          <td><button class="btn btn-ghost btn-xs"
                      onclick="bfRelease('${esc(r.ip_address)}')">Release</button></td>
        </tr>`).join('');
    }
  }

  const tgt = document.getElementById('bf-targets');
  if (tgt) {
    const rows = tgtRes?.data || [];
    tgt.innerHTML = rows.length
      ? rows.map(r => `
          <div style="display:flex;justify-content:space-between;gap:10px;font-size:.8rem;padding:4px 0">
            <span class="mono">${esc(r.username)}</span>
            <span class="dim">${fmtNum(r.attempts)}</span>
          </div>`).join('')
      : '<div class="dim" style="font-size:.8rem">No usernames recorded in the last 24 hours.</div>';
  }
}

async function bfScanNow() {
  const res = await API.bfScan();
  if (!res?.success) { toast(res?.error || 'Could not read the logs', 'error'); return; }
  const d = res.data || {};
  toast(d.enabled === false
    ? 'Detection is switched off'
    : `${d.collected || 0} failure(s) read, ${d.blocked || 0} address(es) blocked`,
    'success');
  loadBruteForce();
}

// How an offender's state reads in the table.
//
// "Watching" against two hundred failures was the complaint that prompted the
// escalation ladder: a status that never changes tells an operator the product
// is doing nothing. Each row now says which term is being served, how long is
// left, and -- while only watching -- what the next offence will cost, so the
// policy is visible from the list rather than buried in settings.
function bfTermLeft(secs) {
  if (secs === null || secs === undefined) return '';
  if (secs <= 0) return 'expiring';
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  if (h >= 24) return Math.floor(h / 24) + 'd ' + (h % 24) + 'h left';
  if (h > 0)   return h + 'h ' + m + 'm left';
  return m + 'm left';
}

function bfStatusBadge(r) {
  const strike = Number(r.offences || 0);
  const nth = strike > 0 ? ` &middot; offence ${strike}` : '';
  if (!Number(r.blocked)) {
    const next = r.next_term ? ` &middot; next: ${esc(String(r.next_term))}` : '';
    return `<span class="badge badge-amber">Watching</span>`
         + `<span class="dim" style="font-size:.72rem">${nth}${next}</span>`;
  }
  if (Number(r.permanent)) {
    return `<span class="badge badge-red">Blocked &middot; permanent</span>`
         + `<span class="dim" style="font-size:.72rem">${nth}</span>`;
  }
  return `<span class="badge badge-red">Blocked</span>`
       + `<span class="dim" style="font-size:.72rem"> ${esc(bfTermLeft(r.expires_in))}${nth}</span>`;
}

async function bfRelease(ip) {
  const res = await API.bfRelease(ip);
  if (res?.success) { toast('Released ' + ip, 'success'); loadBruteForce(); }
  else { toast(res?.error || 'Could not release that address', 'error'); }
}

async function bfSave() {
  const g = (id) => document.getElementById(id);
  const status = g('bf-save-status');

  // Minutes in the UI, seconds in the settings: an operator thinks in minutes
  // and the detector works in seconds.
  const payload = {
    bf_enabled:        g('bf-set-enabled')?.checked ? '1' : '0',
    bf_auto_block:     g('bf-set-block')?.checked   ? '1' : '0',
    bf_threshold:      String(g('bf-set-threshold')?.value || '10'),
    bf_window:         String((parseInt(g('bf-set-window')?.value, 10)   || 10) * 60),
    // Hours in, seconds out. A rung of 0 means permanent and ends the ladder;
    // anything unparseable is dropped rather than silently becoming 0, which
    // would turn a typo into a permanent block.
    bf_ladder: (g('bf-set-ladder')?.value || '3, 6, 24, 0')
                 .split(',')
                 .map(x => x.trim())
                 .filter(x => x !== '' && !isNaN(Number(x)))
                 .map(x => String(Math.max(0, Math.round(Number(x) * 3600))))
                 .join(',') || '10800,21600,86400,0',
    bf_retention_days: String(g('bf-set-retention')?.value || '7'),
    bf_whitelist:      (g('bf-set-whitelist')?.value || '').trim(),
  };

  const res = await API.saveSettings(payload);
  if (status) {
    status.textContent = res?.success ? 'Saved' : (res?.error || 'Could not save');
    status.style.color = res?.success ? 'var(--ok, #22c55e)' : 'var(--red)';
    setTimeout(() => { status.textContent = ''; }, 4000);
  }
  if (res?.success) loadBruteForce();
}

// ── IP Reputation ──────────────────────────────────────────────────────────────
async function checkIP() {
  const ip = document.getElementById('iprep-ip-input')?.value?.trim();
  if (!ip) { toast('Enter an IP address', 'error'); return; }

  const container = document.getElementById('iprep-result');
  container.innerHTML = '<div class="dim" style="font-size:.8rem">Checking…</div>';

  const res = Demo.active
    ? { success: true, data: { ip, score: 78, risk: 'high', country: 'RU', asn: 'AS12345 Demo ISP', rbl_hits: ['spamhaus', 'sorbs'] } }
    : await API.ipCheck(ip);

  if (!res?.success) { container.innerHTML = `<div style="color:var(--red)">${res?.error || 'Failed'}</div>`; return; }

  const d = res.data;
  const riskCol = { critical:'var(--red)', high:'var(--red)', medium:'var(--amber)', low:'var(--green)' }[d.risk] || 'var(--blue)';

  container.innerHTML = `
    <div class="card" style="padding:16px">
      <div style="display:flex;align-items:center;gap:16px;margin-bottom:14px">
        <div style="font-size:1.5rem;font-family:var(--font-mono);font-weight:800">${d.ip}</div>
        <span class="badge" style="background:${riskCol}20;color:${riskCol};border-color:${riskCol}40">
          ${d.risk?.toUpperCase()} RISK
        </span>
        <span class="badge badge-gray">${d.country || 'XX'}</span>
      </div>
      ${Charts.ipRiskGauge(d.score || 0)}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px;font-size:.78rem">
        <div><span class="dim">ASN: </span>${d.asn || '—'}</div>
        <div><span class="dim">RBL Hits: </span>${d.rbl_hits?.join(', ') || 'None'}</div>
      </div>
      <div style="display:flex;gap:8px;margin-top:14px">
        <button class="btn btn-danger btn-sm" onclick="blockIPDirect('${d.ip}')">Block this IP</button>
      </div>
    </div>`;
}

async function blockIPDirect(ip) {
  const res = Demo.active ? { success: true } : await API.fwBlockIP(ip, 'IP Reputation: High risk', false);
  if (res?.success) toast(`${ip} blocked`, 'success');
  else toast('Block failed', 'error');
}

async function loadTopAttackers() {
  const res = Demo.active ? Demo.mockIPAttackers() : await API.ipTopAttack();
  const tbody = document.getElementById('iprep-table-body');
  if (!tbody) return;

  const data = res?.data || [];
  if (!data.length) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--txt3);padding:24px">No data yet — IP reputation requires incoming events.</td></tr>';
    return;
  }

  tbody.innerHTML = data.map(r => {
    const rblHits = typeof r.rbl_hits === 'string' ? JSON.parse(r.rbl_hits || '[]') : (r.rbl_hits || []);
    const scoreCol = r.score >= 75 ? 'var(--red)' : r.score >= 50 ? 'var(--amber)' : 'var(--green)';
    return `
      <tr>
        <td class="mono primary">${r.ip_address}</td>
        <td><span class="cc-badge" style="background:var(--blue-dim);color:var(--blue2)">${r.country || 'XX'}</span></td>
        <td>
          <div style="display:flex;align-items:center;gap:8px">
            <div class="progress-bar" style="width:80px;height:6px">
              <div class="progress-fill" style="width:${r.score}%;background:${scoreCol}"></div>
            </div>
            <span style="font-family:var(--font-mono);font-size:.72rem;color:${scoreCol}">${r.score}</span>
          </div>
        </td>
        <td class="dim">${rblHits.join(', ') || '—'}</td>
        <td class="mono">${fmtNum(r.hits || 0)}</td>
        <td class="dim">${r.last_seen ? reltime(r.last_seen) : '—'}</td>
        <td>
          <button class="btn btn-danger btn-xs" onclick="blockIPDirect('${r.ip_address}')">Block</button>
        </td>
      </tr>`;
  }).join('');
}

// ── Events ────────────────────────────────────────────────────────────────────
async function loadEvents() {
  const sev = document.getElementById('events-sev-filter')?.value || '';
  const res = Demo.active
    ? { success: true, data: [], unresolved: 0 }
    : await API.events(sev);

  const tbody = document.getElementById('events-body');
  if (tbody) renderEventsTable(res?.data || [], 'events-body');

  const badge = document.getElementById('events-unresolved-badge');
  if (badge) badge.textContent = `${res?.unresolved || 0} unresolved`;
}

async function resolveEvent(id) {
  const res = Demo.active ? { success: true } : await API.resolveEvent(id);
  if (res?.success) {
    toast('Event resolved', 'success');
    await loadEvents();
    refreshDashboard();
  } else {
    // Previously the failure branch did not exist, so a resolve that changed
    // nothing looked identical to one that worked until the row reappeared.
    toast(res?.error || 'Could not resolve that event', 'error');
  }
}


// ── Log Analyzer ─────────────────────────────────────────────────────────────
let _logDaysLoaded = false;
let _logSearchTimer = null;

function debouncedLogSearch() {
  // Typing a path into the search box should not fire a request per keystroke.
  clearTimeout(_logSearchTimer);
  _logSearchTimer = setTimeout(loadLogs, 250);
}

async function loadLogs() {
  const dateEl   = document.getElementById('log-date');
  const levelEl  = document.getElementById('log-level');
  const searchEl = document.getElementById('log-search');
  const tbody    = document.getElementById('log-body');
  if (!tbody) return;

  // Populate the day picker once, from the days that actually have a log.
  if (!_logDaysLoaded && dateEl) {
    _logDaysLoaded = true;
    const daysRes = Demo.active
      ? { success: true, data: [{ date: new Date().toISOString().slice(0, 10), lines: 0 }] }
      : await API.get('logs/days');
    const days = daysRes?.data || [];
    if (days.length) {
      dateEl.innerHTML = days.map((d, i) =>
        `<option value="${esc(d.date)}">${esc(d.date)} (${fmtNum(d.lines || 0)} lines)${i === 0 ? ' — latest' : ''}</option>`
      ).join('');
    }
  }

  const params = new URLSearchParams();
  if (dateEl?.value)   params.set('date',   dateEl.value);
  if (levelEl?.value)  params.set('level',  levelEl.value);
  if (searchEl?.value) params.set('search', searchEl.value);
  params.set('lines', '500');

  const res = Demo.active
    ? { success: true, data: { entries: [], total: 0, counts: {} } }
    : await API.get('logs/query?' + params.toString());

  const d = res?.data || {};
  const entries = d.entries || [];
  const counts  = d.counts  || {};

  const setTxt = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  setTxt('log-stat-total', fmtNum(d.total || 0));
  setTxt('log-stat-error', fmtNum(counts.ERROR || 0));
  setTxt('log-stat-warn',  fmtNum(counts.WARN  || 0));
  setTxt('log-stat-info',  fmtNum(counts.INFO  || 0));
  setTxt('log-showing-badge', fmtNum(entries.length) + ' shown');

  if (!entries.length) {
    // Say which of the two reasons applies. "No entries" alone reads as a
    // broken page, which is how this module was reported in the first place.
    const filtered = (searchEl?.value || '') !== ''
                  || ((levelEl?.value || 'ALL') !== 'ALL');
    tbody.innerHTML = `<tr><td colspan="3" style="text-align:center;color:var(--txt3);padding:28px">${
      (d.total || 0) > 0 && filtered
        ? 'No entries match this filter — ' + fmtNum(d.total) + ' entries on this day.'
        : 'Nothing logged on this day yet.'
    }</td></tr>`;
    return;
  }

  tbody.innerHTML = entries.map(e => `
    <tr>
      <td class="mono dim" style="white-space:nowrap">${esc(e.time) || '—'}</td>
      <td>${logLevelBadge(e.level)}</td>
      <td class="mono" style="word-break:break-word;font-size:.75rem">${esc(e.message)}</td>
    </tr>`).join('');
}

function logLevelBadge(level) {
  const map = {
    ERROR: 'badge badge-red',
    WARN:  'badge badge-amber',
    INFO:  'badge badge-green',
    DEBUG: 'badge badge-gray',
  };
  // A line that did not parse still gets a row -- dropping it would hide
  // exactly the unusual output most worth reading.
  if (!level) return '<span class="badge badge-gray">raw</span>';
  return `<span class="${map[level] || 'badge badge-gray'}">${esc(level)}</span>`;
}

function downloadLogs() {
  const rows = Array.from(document.querySelectorAll('#log-body tr'))
    .map(tr => Array.from(tr.children).map(td => td.textContent.trim()).join('  '))
    .join('\n');
  if (!rows.trim()) { toast('Nothing to download', 'error'); return; }

  const day = document.getElementById('log-date')?.value || 'today';
  const blob = new Blob([rows], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `serverscrub-${day}.log`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(a.href);
}
// ── Settings ──────────────────────────────────────────────────────────────────
function updateCpuSliderLabel(val) {
  val = parseInt(val, 10);
  const labelEl = document.getElementById('cpu-limit-label');
  const descEl  = document.getElementById('cpu-limit-desc');
  if (labelEl) labelEl.textContent = val + '%';

  if (descEl) {
    // nice value: 100% → 0, 10% → 19
    const niceVal = Math.round(19 * (1 - val / 100));
    // scan sleep: 100% → 0ms, 10% → 550ms
    const sleepMs = Math.round(Math.max(0, (1 - val / 100) * 550));

    let label, color;
    if (val <= 25)      { label = 'Minimal — maximum headroom for web traffic'; color = '#10b981'; }
    else if (val <= 50) { label = 'Balanced — recommended for most servers';   color = '#3b82f6'; }
    else if (val <= 75) { label = 'Performance — faster scans, higher CPU';    color = '#f59e0b'; }
    else                { label = 'Maximum — fastest scans, unrestricted CPU';  color = '#ef4444'; }

    descEl.innerHTML =
      '<span style="color:' + color + ';font-weight:600">' + label + '</span><br>' +
      '<span style="color:var(--txt3)">Process priority: </span><code>nice ' + niceVal + '</code>' +
      ' &nbsp;·&nbsp; ' +
      '<span style="color:var(--txt3)">Scan throttle: </span><code>' + (sleepMs ? sleepMs + 'ms between files' : 'no throttle') + '</code>';
  }
}

function selectPollInterval(seconds) {
  [60, 300, 900].forEach(v => {
    const el = document.getElementById('poll-opt-' + v);
    if (!el) return;
    const active = v === seconds;
    el.style.borderColor    = active ? 'var(--primary)' : 'var(--border)';
    el.style.background     = active ? 'rgba(59,130,246,.08)' : '';
    const radio = el.querySelector('input[type=radio]');
    if (radio) radio.checked = active;
  });
}

async function loadSettings() {
  loadLicense();   // license card lives on this page

  const res = Demo.active
    ? { success: true, data: {
        scan_schedule: 'daily', scan_paths: '/home', auto_quarantine: '0',
        email_alerts: '1', alert_email: '', php_disable_funcs: 'exec,passthru,shell_exec,system',
        rate_limit_ssh: '5', rate_limit_http: '100',
        firewall_enabled: '1', waf_enabled: '1', bot_shield_enabled: '1', ip_rep_enabled: '1',
        cpu_limit_percent: '50', rt_poll_interval: '300',
        scan_time: '02:00', scan_day: '0', scan_type: 'full',
        sig_update_schedule: 'weekly', sig_update_day: '0',
        iprep_schedule: 'daily',
        sig_last_update: String(Math.floor(Date.now()/1000) - 3*86400),
        iprep_last_run:  String(Math.floor(Date.now()/1000) - 9*3600),
        iprep_last_count: '183',
      }}
    : await API.getSettings();

  if (!res?.success) return;
  const d = res.data;

  const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ''; };
  const chk = (id, val) => { const el = document.getElementById(id); if (el) el.checked = val === '1' || val === true; };

  set('set-scan-schedule', d.scan_schedule);
  set('set-scan-time',     d.scan_time || '02:00');
  set('set-scan-day',      d.scan_day  || '0');
  set('set-scan-type',     d.scan_type || 'full');
  set('set-sig-schedule',  d.sig_update_schedule || 'weekly');
  set('set-sig-day',       d.sig_update_day || '0');
  set('set-iprep-schedule',d.iprep_schedule || 'daily');
  set('set-scan-paths',    d.scan_paths);

  // Rootkit schedule — the scheduler has always read these; nothing set them.
  set('set-rootkit-schedule', d.rootkit_schedule || 'weekly');
  set('set-rootkit-time',     d.rootkit_time     || '05:00');
  set('set-rootkit-day',      d.rootkit_day      || '0');
  loadQuarantineInfo();

  // Real-time monitor resource profile
  selectRtProfile(d.rt_profile || 'balanced');
  set('set-rt-fps',      d.rt_max_files_per_sec || '25');
  set('set-rt-maxmb',    d.rt_max_file_size_mb  || '16');
  set('set-rt-nice',     d.rt_nice              || '10');
  set('set-rt-watches',  d.rt_max_watches       || '20000');
  set('set-rt-debounce', d.rt_debounce_seconds  || '5');
  set('set-rt-excludes', d.rt_exclude_dirs      || '');

  // Pause-during-backup
  const pauseEl = document.getElementById('set-rt-pause-backup');
  if (pauseEl) pauseEl.checked = (d.rt_pause_on_backup ?? '1') === '1';
  set('set-rt-backup-procs',  d.rt_backup_procs            || 'jetbackup,rsync');
  set('set-rt-backup-resume', d.rt_backup_resume_secs      || '60');
  set('set-rt-backup-max',    d.rt_backup_max_suspend_secs || '14400');
  const autoEl = document.getElementById('set-rt-autostart');
  if (autoEl) autoEl.checked = (d.rt_autostart_after_backup ?? '1') === '1';

  // Last-run readouts
  const ts = v => (v && +v) ? new Date(+v * 1000).toLocaleString() : 'never';
  const txt = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  txt('sig-last-update',  ts(d.sig_last_update));
  txt('iprep-last-run',   ts(d.iprep_last_run));
  txt('iprep-last-count', d.iprep_last_count || '0');
  txt('rootkit-last-run',      ts(d.rootkit_last_run));
  txt('rootkit-last-findings', d.rootkit_last_findings || '0');

  syncScheduleFields();
  chk('set-auto-quar',     d.auto_quarantine);

  // The scanner page used to state "auto-quarantine enabled" as static text,
  // which was wrong the moment the setting was off -- and it now ships off.
  const quarState = document.getElementById('scanner-quar-state');
  if (quarState) {
    quarState.textContent = d.auto_quarantine === '1'
      ? 'auto-quarantine on' : 'auto-quarantine off';
  }
  chk('set-email-alerts',  d.email_alerts);
  set('set-alert-email',   d.alert_email);
  set('set-php-disable',   d.php_disable_funcs);
  set('set-rate-ssh',      d.rate_limit_ssh);
  set('set-rate-http',     d.rate_limit_http);
  chk('set-fw-enabled',    d.firewall_enabled);
  chk('set-waf-enabled',   d.waf_enabled);
  chk('set-bot-enabled',   d.bot_shield_enabled);
  chk('set-iprep-enabled', d.ip_rep_enabled);

  // CPU slider
  const cpuVal = parseInt(d.cpu_limit_percent || '50', 10);
  const cpuSlider = document.getElementById('set-cpu-limit');
  if (cpuSlider) { cpuSlider.value = cpuVal; updateCpuSliderLabel(cpuVal); }

  // Poll interval selector
  const pollVal = parseInt(d.rt_poll_interval || '300', 10);
  selectPollInterval([60, 300, 900].includes(pollVal) ? pollVal : 300);
}

async function saveSettings() {
  const g = id => document.getElementById(id);
  const data = {
    scan_schedule:       g('set-scan-schedule')?.value,
    scan_time:           g('set-scan-time')?.value,
    scan_day:            g('set-scan-day')?.value,
    scan_type:           g('set-scan-type')?.value,
    sig_update_schedule: g('set-sig-schedule')?.value,
    sig_update_day:      g('set-sig-day')?.value,
    iprep_schedule:      g('set-iprep-schedule')?.value,
    scan_paths:          g('set-scan-paths')?.value,

    rt_profile:            g('set-rt-profile')?.value || 'balanced',
    rt_max_files_per_sec:  g('set-rt-fps')?.value      || '25',
    rt_max_file_size_mb:   g('set-rt-maxmb')?.value    || '16',
    rt_nice:               g('set-rt-nice')?.value     || '10',
    rt_max_watches:        g('set-rt-watches')?.value  || '20000',
    rt_debounce_seconds:   g('set-rt-debounce')?.value || '5',
    rt_exclude_dirs:       g('set-rt-excludes')?.value || '',
    auto_quarantine:    g('set-auto-quar')?.checked ? '1' : '0',
    email_alerts:       g('set-email-alerts')?.checked ? '1' : '0',
    alert_email:        g('set-alert-email')?.value,
    php_disable_funcs:  g('set-php-disable')?.value,
    rate_limit_ssh:     g('set-rate-ssh')?.value,
    rate_limit_http:    g('set-rate-http')?.value,
    firewall_enabled:   g('set-fw-enabled')?.checked ? '1' : '0',
    waf_enabled:        g('set-waf-enabled')?.checked ? '1' : '0',
    bot_shield_enabled: g('set-bot-enabled')?.checked ? '1' : '0',
    ip_rep_enabled:     g('set-iprep-enabled')?.checked ? '1' : '0',
    cpu_limit_percent:  g('set-cpu-limit')?.value || '50',
    rt_poll_interval:   document.querySelector('input[name="rt_poll_interval"]:checked')?.value || '300',
  };

  const res = Demo.active ? { success: true } : await API.saveSettings(data);
  if (res?.success) toast('Settings saved', 'success');
  else toast('Failed to save', 'error');
}


// ── Scanner settings ─────────────────────────────────────────────────────────
// A save control that belongs to the card it saves. The page-level "Save
// Changes" lives in a different card further up the page, so changing a scan
// schedule here left the operator with nothing to click and no way to tell
// whether the change had taken.
async function saveScannerSettings() {
  const g = id => document.getElementById(id);
  const status = g('scanner-settings-status');
  const data = {
    scan_schedule:       g('set-scan-schedule')?.value,
    scan_time:           g('set-scan-time')?.value,
    scan_day:            g('set-scan-day')?.value,
    scan_type:           g('set-scan-type')?.value,
    scan_paths:          g('set-scan-paths')?.value,
    sig_update_schedule: g('set-sig-schedule')?.value,
    sig_update_day:      g('set-sig-day')?.value,
    iprep_schedule:      g('set-iprep-schedule')?.value,
    auto_quarantine:     g('set-auto-quar')?.checked ? '1' : '0',
    rootkit_schedule:    g('set-rootkit-schedule')?.value,
    rootkit_time:        g('set-rootkit-time')?.value,
    rootkit_day:         g('set-rootkit-day')?.value,
  };

  if (status) { status.textContent = 'Saving…'; status.style.color = 'var(--txt3)'; }

  const res = Demo.active ? { success: true } : await API.saveSettings(data);

  if (res?.success) {
    // Read it back rather than trusting the button's own optimism: the
    // complaint was that a changed schedule did not appear to update anywhere,
    // and only a re-read can actually show that it did.
    await loadSettings();
    if (status) {
      status.textContent = 'Saved · scan runs ' + describeSchedule(data);
      status.style.color = 'var(--ok, #22c55e)';
    }
    toast('Scanner settings saved', 'success');
  } else {
    if (status) {
      status.textContent = res?.error || 'Save failed';
      status.style.color = 'var(--danger, #ef4444)';
    }
    toast(res?.error || 'Could not save scanner settings', 'error');
  }
}

function describeSchedule(d) {
  if (!d || d.scan_schedule === 'disabled') return 'never (disabled)';
  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const at = d.scan_time || '02:00';
  if (d.scan_schedule === 'daily')   return 'daily at ' + at;
  if (d.scan_schedule === 'weekly')  return days[+d.scan_day || 0] + 's at ' + at;
  if (d.scan_schedule === 'monthly') return 'monthly at ' + at;
  return String(d.scan_schedule || '');
}

// ── Quarantine location ──────────────────────────────────────────────────────
async function checkQuarantinePath() {
  const dir = document.getElementById('set-quar-dir')?.value?.trim();
  const badge = document.getElementById('quar-writable');
  if (!dir) { toast('Enter a quarantine path first', 'error'); return; }
  if (badge) { badge.textContent = 'checking…'; badge.className = 'badge badge-gray'; }

  const res = Demo.active ? { success: true, data: { writable: true } }
                          : await API.post('storage/quarantine-check', { path: dir });
  const d = res?.data || {};
  if (!badge) return;

  if (res?.success && d.writable) {
    badge.textContent = 'readable & writable';
    badge.className   = 'badge badge-green';
  } else {
    // Saying "not writable" without saying why leaves the operator guessing
    // between a missing directory, a permission problem and a full disk.
    badge.textContent = d.reason || res?.error || 'not writable';
    badge.className   = 'badge badge-red';
  }
}

async function moveQuarantineDir() {
  const dir = document.getElementById('set-quar-dir')?.value?.trim();
  if (!dir) { toast('Enter a quarantine path first', 'error'); return; }
  if (!confirm('Move quarantined files to:\n\n' + dir + '\n\nFiles are moved, never deleted.')) return;

  const res = Demo.active ? { success: true, data: { moved: 0 } }
                          : await API.post('storage/quarantine-move', { path: dir });
  if (res?.success) {
    toast('Quarantine moved (' + (res.data?.moved ?? 0) + ' file(s))', 'success');
    loadQuarantineInfo();
  } else {
    toast(res?.error || res?.data?.error || 'Could not move quarantine', 'error');
  }
}

async function loadQuarantineInfo() {
  const res = Demo.active
    ? { success: true, data: { dir: '/home/.serverscrub/quarantine', files: 0, human: '0 B', writable: true, on_root: false } }
    : await API.get('storage/quarantine-usage');
  const d = res?.data || {};

  const input = document.getElementById('set-quar-dir');
  if (input && !input.dataset.touched) input.value = d.dir || '';

  const usage = document.getElementById('quar-usage');
  if (usage) {
    usage.textContent = (d.files ?? 0) + ' file(s) · ' + (d.human ?? '0 B')
                      + (d.on_root ? ' · on the root partition' : '');
    usage.style.color = d.on_root ? 'var(--danger, #ef4444)' : 'var(--txt3)';
  }

  const badge = document.getElementById('quar-writable');
  if (badge) {
    badge.textContent = d.writable ? 'readable & writable' : 'not writable';
    badge.className   = d.writable ? 'badge badge-green' : 'badge badge-red';
  }
}

async function runRootkitNow() {
  toast('Rootkit scan started…', 'info');
  const res = Demo.active ? { success: true, data: { summary: { critical: 0, high: 0 } } }
                          : await API.post('rootkit/scan-builtin', {});
  if (res?.success) {
    const sum = res.data?.summary || {};
    toast('Rootkit scan finished — ' + (sum.critical || 0) + ' critical, ' + (sum.high || 0) + ' high', 'success');
    loadSettings();
  } else {
    toast(res?.error || 'Rootkit scan failed', 'error');
  }
}

// ── Real-Time Monitor ─────────────────────────────────────────────────────────
let monitorRunning = false;

async function loadMonitorStats() {
  const res = Demo.active ? Demo.mockMonitorStatus() : await API.monitorStatus();
  if (!res?.success) return;
  const d = res.data;
  monitorRunning = d.running;
  State.lastMonitor = d;

  const card = document.getElementById('rt-monitor-card');
  if (card) card.style.borderLeftColor = d.running ? 'var(--green)' : 'var(--red)';
  // A monitor can be running and yet doing nothing: wrong watch paths, a dead
  // loop, inotify watches exhausted. That state used to render as a green
  // "Active" badge beside counters stuck at zero, which is the least useful
  // thing the card could say. The daemon stamps rt_last_activity as it works,
  // so silence is measurable — report it.
  const badge = document.getElementById('rt-status-badge');
  if (badge) {
    if (!d.running) {
      badge.className = 'badge badge-red';   badge.textContent = 'Stopped';
    } else if (d.suspended) {
      // A third state, and it must not borrow either of the other two. The
      // daemon IS running, so "Stopped" is wrong; it is deliberately not
      // scanning, so "Active" is worse -- that claims protection that is
      // currently paused.
      badge.className = 'badge badge-amber';
      badge.textContent = 'Paused' + (d.suspend_reason ? ' — ' + d.suspend_reason : '');
    } else if (d.stale) {
      badge.className = 'badge badge-amber'; badge.textContent = 'No activity';
    } else {
      badge.className = 'badge badge-green'; badge.textContent = 'Active';
    }
  }
  const icon = document.getElementById('rt-icon');
  if (icon) icon.textContent = !d.running ? '⏸' : (d.suspended ? '⏸' : (d.stale ? '⚠️' : '🔍'));

  if (card) {
    card.style.borderLeftColor = !d.running ? 'var(--red)'
                               : ((d.suspended || d.stale) ? 'var(--amber, #f59e0b)' : 'var(--green)');
  }

  // Say why, and for how long. A paused badge with no explanation is the kind
  // of thing that gets reported as the monitor being broken.
  const note = document.getElementById('rt-suspend-note');
  if (note) {
    if (d.suspended) {
      const mins = d.suspend_since ? Math.max(0, Math.round((Date.now() / 1000 - d.suspend_since) / 60)) : 0;
      note.textContent = 'Scanning is paused because ' + (d.suspend_reason || 'a backup')
                       + ' is running' + (mins ? ' (' + mins + ' min)' : '')
                       + (d.suspend_evidence ? ' — matched ' + d.suspend_evidence : '')
                       + '. Changes made now are not scanned in real time; the next '
                       + 'scheduled scan covers them.';
      note.style.display = '';
    } else if (d.last_gap_seconds > 0 && d.last_gap_end
               && (Date.now() / 1000 - d.last_gap_end) < 86400) {
      note.textContent = 'Resumed after a ' + Math.round(d.last_gap_seconds / 60)
                       + ' minute pause for a backup. Changes made during it were not '
                       + 'scanned in real time.';
      note.style.display = '';
    } else {
      note.style.display = 'none';
    }
  }

  const rtPaths  = document.getElementById('rt-paths');
  // "Watching ..." with nothing after it was the placeholder showing through.
  if (rtPaths) {
    const paths = (d.watch_paths || []).filter(Boolean);
    rtPaths.textContent = paths.length ? paths.join(', ') : 'no paths configured';
  }
  const rtEngine = document.getElementById('rt-engine');
  if (rtEngine) rtEngine.textContent = d.engine || 'polling';

  setText('rt-files-checked',  fmtNum(d.files_checked || 0));
  setText('rt-detections-24h', d.detections_24h || 0);
  setText('rt-detections-all', d.detections_all  || 0);

  const toggleBtn = document.getElementById('rt-toggle-btn');
  if (toggleBtn) {
    toggleBtn.textContent = d.running ? 'Stop' : 'Start';
    toggleBtn.disabled = false;
    toggleBtn.dataset.ready = '1';
  }

  const sbRt = document.getElementById('sb-rt-threats');
  if (sbRt) {
    sbRt.style.display = d.detections_24h > 0 ? '' : 'none';
    sbRt.textContent   = d.detections_24h || '';
  }
}

async function loadMonitor() {
  const res = Demo.active ? Demo.mockMonitorStatus() : await API.monitorStatus();
  if (!res?.success) return;
  const d = res.data;
  monitorRunning = d.running;

  const badge = document.getElementById('monitor-status-badge');
  if (badge) {
    // Running/stopped alone is not the whole truth. A daemon that is up but
    // scanning nothing, or deliberately paused for a backup, both rendered as
    // a green "Running" -- claiming protection that is not happening.
    if (!d.running) {
      badge.className = 'badge badge-red';   badge.textContent = '○ Stopped';
    } else if (d.suspended) {
      badge.className = 'badge badge-amber';
      badge.textContent = '⏸ Paused' + (d.suspend_reason ? ' — ' + d.suspend_reason : '');
    } else if (d.stale) {
      badge.className = 'badge badge-amber'; badge.textContent = '● Running, no activity';
    } else {
      badge.className = 'badge badge-green'; badge.textContent = '● Running';
    }
  }
  const pgBtn = document.getElementById('monitor-page-toggle');
  if (pgBtn) pgBtn.textContent = d.running ? 'Stop Monitor' : 'Start Monitor';

  setText('mon-engine',  d.engine || 'polling');
  setText('mon-pid',     d.pid    || '—');
  setText('mon-files',   fmtNum(d.files_checked || 0));
  setText('mon-det-24h', d.detections_24h || 0);
  setText('mon-det-all', d.detections_all  || 0);

  const pathsList = document.getElementById('mon-paths-list');
  if (pathsList) {
    pathsList.innerHTML = (d.watch_paths || []).map(p =>
      '<div style="display:flex;justify-content:space-between;align-items:center;' +
      'padding:6px 10px;background:var(--bg1);border-radius:6px;margin-bottom:6px;' +
      'font-size:.78rem;font-family:monospace">' +
      '<span style="color:var(--txt1)">' + p + '</span>' +
      '<button class="btn btn-ghost btn-sm" style="padding:2px 8px;font-size:.7rem" ' +
      'onclick="removeWatchPath(\'' + p + '\')">✕ Remove</button></div>'
    ).join('') || '<div style="color:var(--txt3);font-size:.8rem">No paths configured</div>';
  }

  // Also refresh service panel
  loadServiceStatus();
  loadServiceLogs();
}

let _monitorBusy = false;

async function toggleMonitor() {
  // systemctl start/stop takes seconds, and the daemon needs a moment more to
  // write its PID file. The button used to fire and return immediately, so it
  // felt dead, a second click could race the first, and the state it flipped to
  // was assumed rather than confirmed -- which is why it looked unreliable.
  if (_monitorBusy) return;

  // Refuse to act on a guess. monitorRunning starts false, so a click before
  // the first status load would start a monitor whose button says "Stop".
  const rtBtn = document.getElementById('rt-toggle-btn');
  if (rtBtn && rtBtn.dataset.ready !== '1' && !Demo.active) {
    toast('Still reading the monitor status — try again in a moment', 'info');
    loadMonitorStats();
    return;
  }

  _monitorBusy = true;

  const starting = !monitorRunning;
  const buttons  = ['rt-toggle-btn', 'monitor-page-toggle']
    .map(id => document.getElementById(id)).filter(Boolean);
  const original = buttons.map(b => b.textContent);
  buttons.forEach(b => { b.disabled = true; b.textContent = starting ? 'Starting…' : 'Stopping…'; });

  const fn  = starting ? API.monitorStart : API.monitorStop;
  const res = Demo.active ? { success: true } : await fn();

  const restore = () => {
    buttons.forEach((b, i) => { b.disabled = false; b.textContent = original[i]; });
    _monitorBusy = false;
  };

  if (res?.success) {
    // Confirm with the server rather than assuming. systemd reports the unit
    // started before the daemon has finished coming up, so the first poll can
    // legitimately disagree with what we just asked for.
    let confirmed = false;
    for (let attempt = 0; attempt < 6 && !confirmed; attempt++) {
      await new Promise(r => setTimeout(r, 700));
      const st = await API.monitorStatus();
      if (st?.success && st.data && st.data.running === starting) {
        confirmed = true;
        monitorRunning = starting;
      }
    }

    restore();
    loadMonitor();
    loadMonitorStats();

    if (confirmed) {
      toast(starting ? 'Monitor started' : 'Monitor stopped', 'success');
    } else {
      // The command was accepted and the state did not follow. Saying so beats
      // a success toast over a monitor that is not running.
      toast(starting
        ? 'Start was accepted but the monitor is not running yet — check Details'
        : 'Stop was accepted but the monitor is still running — check Details',
        'error', 8000);
    }
    return;
  }

  restore();
  {
    // "Action failed" tells the operator nothing. The API explains itself --
    // the daemon script missing, systemd refusing, the unit not installed --
    // and that explanation is what makes the difference actionable.
    const why = (res && (res.error || res.message)) || 'no reason given by the server';
    toast('Monitor: ' + why, 'error', 7000);
    console.error('toggleMonitor failed:', res);
  }
}

async function loadMonitorDetections() {
  const res   = Demo.active ? Demo.mockMonitorDetections() : await API.monitorDetections(50);
  const tbody = document.getElementById('rt-detections-body');
  if (!tbody || !res?.success) return;
  const rows = res.data || [];
  tbody.innerHTML = rows.length === 0
    ? '<tr><td colspan="5" style="text-align:center;color:var(--txt3);padding:24px">No real-time detections</td></tr>'
    : rows.map(r =>
        '<tr>' +
        '<td>' + sevBadge(r.severity) + '</td>' +
        '<td style="font-family:monospace;font-size:.75rem;word-break:break-all">' + r.file_path + '</td>' +
        '<td><span class="badge badge-red" style="font-size:.7rem">' + r.threat_name + '</span></td>' +
        '<td><span class="sev sev-' + (r.status === 'quarantined' ? 'medium' : 'critical') + '">' + r.status + '</span></td>' +
        '<td style="color:var(--txt3)">' + reltime(r.detected_at) + '</td>' +
        '</tr>'
      ).join('');
}

async function loadMonitorLog() {
  if (Demo.active) {
    const el = document.getElementById('monitor-log');
    if (el) el.textContent =
      '[2024-01-15 14:22:01] INFO  Monitor started (inotify engine)\n' +
      '[2024-01-15 14:22:01] INFO  Watching: /home /var/www /tmp\n' +
      '[2024-01-15 14:23:45] ALERT CRITICAL c99_shell: /home/user1/public_html/uploads/image.php\n' +
      '[2024-01-15 14:23:45] INFO  Auto-quarantined -> quarantine/2024-01-15/\n' +
      '[2024-01-15 15:01:18] ALERT HIGH eval_base64: /home/user2/public_html/tmp/update.php';
    return;
  }
  const res = await API.monitorLogs(100);
  const el  = document.getElementById('monitor-log');
  if (el && res?.success) el.textContent = res.data || '(no log entries)';
}

async function addWatchPath() {
  const input = document.getElementById('mon-new-path');
  const path  = input?.value?.trim();
  if (!path) return toast('Enter a path first', 'error');
  const res = Demo.active ? { success: true } : await API.monitorAddPath(path);
  if (res?.success) {
    toast('Now watching: ' + path, 'success');
    if (input) input.value = '';
    loadMonitor();
  } else {
    toast(res?.error || 'Failed to add path', 'error');
  }
}

async function removeWatchPath(path) {
  const res = Demo.active ? { success: true } : await API.monitorRemovePath(path);
  if (res?.success) { toast('Removed: ' + path, 'success'); loadMonitor(); }
  else toast('Failed to remove path', 'error');
}

async function installMonitorService() {
  const btn = document.getElementById('install-service-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Installing…'; }
  const res = Demo.active
    ? { success: true, data: { message: 'Service installed (demo mode)' } }
    : await API.monitorInstallService();
  if (res?.success) toast(res.data?.message || 'Service installed successfully', 'success');
  else toast(res?.error || 'Installation failed', 'error');
  if (btn) { btn.disabled = false; btn.textContent = 'Install as System Service'; }
  loadMonitor();
  loadServiceStatus();
}

// ── Systemd Service Status Panel ─────────────────────────────────────────────

async function loadServiceStatus() {
  const res = Demo.active
    ? { success: true, data: {
        installed: true, enabled: true, active: true,
        active_state: 'active', sub_state: 'running',
        since: Math.floor(Date.now() / 1000) - 3600,
        main_pid: 1234, memory_mb: 18.4,
        description: 'ServerScrub Real-Time File Monitor',
        unit_file: '/etc/systemd/system/serverscrub-monitor.service'
      }}
    : await API.monitorServiceStatus();

  if (!res?.success) return;
  const d = res.data;

  // State badge
  const badge = document.getElementById('svc-state-badge');
  if (badge) {
    const active = d.active_state === 'active';
    const color  = active ? 'badge-green' : (d.active_state === 'failed' ? 'badge-red' : 'badge-yellow');
    badge.className   = 'badge ' + color;
    badge.textContent = active ? '● Active' : ('○ ' + (d.active_state || 'Unknown'));
  }

  // Info cells
  setText('svc-installed',  d.installed ? (d.unit_file || 'Yes') : 'Not installed');
  setText('svc-enabled',    d.enabled   ? 'Enabled (auto-start on boot)' : 'Disabled');
  setText('svc-since',      d.since     ? new Date(d.since * 1000).toLocaleString() : '—');
  setText('svc-pid',        d.main_pid  ? String(d.main_pid) : '—');
  setText('svc-mem',        d.memory_mb ? d.memory_mb + ' MB' : '—');
  setText('svc-substate',   d.sub_state || '—');

  // Auto-start toggle
  const toggle = document.getElementById('svc-autostart-toggle');
  if (toggle) toggle.checked = !!d.enabled;

  // Install strip — hide once installed
  const strip = document.getElementById('svc-install-strip');
  if (strip) strip.style.display = d.installed ? 'none' : '';
}

async function svcAction(action) {
  const validActions = ['start', 'stop', 'restart'];
  if (!validActions.includes(action)) return;

  if (Demo.active) {
    toast('Service ' + action + 'ed (demo)', 'success');
    return;
  }

  const fn = {
    start:   API.monitorStart,
    stop:    API.monitorStop,
    restart: API.monitorRestart
  }[action];

  const res = await fn();
  if (res?.success) {
    toast('Service ' + action + 'ed', 'success');
    setTimeout(() => { loadMonitor(); loadServiceStatus(); }, 800);
  } else {
    toast(res?.error || 'Action failed', 'error');
  }
}

async function toggleServiceAutostart(checked) {
  if (Demo.active) {
    toast(checked ? 'Auto-start enabled (demo)' : 'Auto-start disabled (demo)', 'success');
    return;
  }
  const res = checked ? await API.monitorEnableService() : await API.monitorDisableService();
  if (res?.success) toast(checked ? 'Auto-start enabled' : 'Auto-start disabled', 'success');
  else {
    toast(res?.error || 'Failed to update auto-start', 'error');
    // Revert toggle on failure
    const toggle = document.getElementById('svc-autostart-toggle');
    if (toggle) toggle.checked = !checked;
  }
}

async function loadServiceLogs() {
  if (Demo.active) {
    const el = document.getElementById('svc-journal-log');
    if (el) el.textContent =
      '2024-01-15T14:22:01+0000 serverscrub-monitor[1234]: INFO  Monitor started\n' +
      '2024-01-15T14:22:01+0000 serverscrub-monitor[1234]: INFO  inotify engine active\n' +
      '2024-01-15T14:22:01+0000 serverscrub-monitor[1234]: INFO  Watching /home\n' +
      '2024-01-15T15:30:00+0000 serverscrub-monitor[1234]: ALERT c99_shell detected';
    return;
  }
  const sel   = document.getElementById('svc-log-lines');
  const lines = parseInt(sel?.value || '50', 10);
  const res   = await API.monitorServiceLogs(lines);
  const el    = document.getElementById('svc-journal-log');
  if (el) {
    if (res?.success && Array.isArray(res.data) && res.data.length > 0) {
      el.textContent = res.data.join('\n');
    } else {
      el.textContent = '(no journal entries — service may not have run yet)';
    }
  }
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

// ── Storage Management ────────────────────────────────────────────────────────
async function loadStorageStats() {
  if (Demo.active) {
    populateStorageUI({
      quarantine: { path: '/usr/local/serverscrub/quarantine', size_bytes: 4718592, files: 7, writable: true },
      logs:       { path: '/usr/local/serverscrub/logs', size_bytes: 2097152, files: 12,
                    writable: true, monitor_log_bytes: 1048576 },
      database:   { path: '/usr/local/serverscrub/database/serverscrub.db', size_bytes: 8388608,
                    rows: { waf_events: 94441, security_events: 12803, threats: 47, cron_log: 342 } },
      settings:   { quarantine_dir: '', log_dir: '', log_retention_days: 30,
                    quarantine_retention_days: 90, db_max_waf_events: 100000,
                    db_max_security_events: 50000, db_max_cron_log: 1000, monitor_log_max_mb: 50 },
    });
    return;
  }
  const res = await API.storageStats();
  if (res?.success) populateStorageUI(res.data);
  else toast('Could not load storage stats', 'error');
}

function populateStorageUI(d) {
  const q  = d.quarantine || {};
  const l  = d.logs       || {};
  const db = d.database   || {};
  const s  = d.settings   || {};

  // Quarantine card
  const qs = document.getElementById('stor-quar-size');
  if (qs) qs.textContent = fmtBytes(q.size_bytes || 0);
  const qf = document.getElementById('stor-quar-files');
  if (qf) qf.textContent = q.files || 0;
  const qst = document.getElementById('stor-quar-status');
  if (qst) qst.textContent = q.writable ? '✓ Writable' : '✕ Read-only';
  const qdInput = document.getElementById('stor-quar-dir');
  if (qdInput && s.quarantine_dir !== undefined) qdInput.value = s.quarantine_dir;
  const qRange = document.getElementById('stor-quar-days-range');
  if (qRange) {
    qRange.value = s.quarantine_retention_days || 90;
    const qv = document.getElementById('stor-quar-days-val');
    if (qv) qv.textContent = (s.quarantine_retention_days || 90) + ' days';
  }

  // Logs card
  const ls = document.getElementById('stor-log-size');
  if (ls) ls.textContent = fmtBytes(l.size_bytes || 0);
  const lf = document.getElementById('stor-log-files');
  if (lf) lf.textContent = l.files || 0;
  const lm = document.getElementById('stor-log-monitor');
  if (lm) lm.textContent = fmtBytes(l.monitor_log_bytes || 0);
  const ldInput = document.getElementById('stor-log-dir');
  if (ldInput && s.log_dir !== undefined) ldInput.value = s.log_dir;
  const lRange = document.getElementById('stor-log-days-range');
  if (lRange) {
    lRange.value = s.log_retention_days || 30;
    const lv = document.getElementById('stor-log-days-val');
    if (lv) lv.textContent = (s.log_retention_days || 30) + ' days';
  }
  const mRange = document.getElementById('stor-mon-mb-range');
  if (mRange) {
    mRange.value = s.monitor_log_max_mb || 50;
    const mv = document.getElementById('stor-mon-mb-val');
    if (mv) mv.textContent = (s.monitor_log_max_mb || 50) + ' MB';
  }

  // Database card
  const dbs = document.getElementById('stor-db-size');
  if (dbs) dbs.textContent = fmtBytes(db.size_bytes || 0);
  const dbw = document.getElementById('stor-db-waf');
  if (dbw) dbw.textContent = fmtNum(db.rows?.waf_events || 0);
  const dse = document.getElementById('stor-db-sec');
  if (dse) dse.textContent = fmtNum(db.rows?.security_events || 0);
  const dbt = document.getElementById('stor-db-threats');
  if (dbt) dbt.textContent = fmtNum(db.rows?.threats || 0);
  const dbc = document.getElementById('stor-db-cron');
  if (dbc) dbc.textContent = fmtNum(db.rows?.cron_log || 0);
  const mwInput = document.getElementById('stor-db-max-waf');
  if (mwInput && s.db_max_waf_events !== undefined) mwInput.value = s.db_max_waf_events;
  const msInput = document.getElementById('stor-db-max-sec');
  if (msInput && s.db_max_security_events !== undefined) msInput.value = s.db_max_security_events;
}

async function saveStorageSettings() {
  const g = id => document.getElementById(id);
  const data = {
    quarantine_dir:            g('stor-quar-dir')?.value?.trim()  || '',
    log_dir:                   g('stor-log-dir')?.value?.trim()   || '',
    log_retention_days:        parseInt(g('stor-log-days-range')?.value    || '30'),
    quarantine_retention_days: parseInt(g('stor-quar-days-range')?.value   || '90'),
    monitor_log_max_mb:        parseInt(g('stor-mon-mb-range')?.value      || '50'),
    db_max_waf_events:         parseInt(g('stor-db-max-waf')?.value        || '100000'),
    db_max_security_events:    parseInt(g('stor-db-max-sec')?.value        || '50000'),
  };
  const res = Demo.active ? { success: true } : await API.storageSaveSettings(data);
  if (res?.success) toast('Storage settings saved', 'success');
  else toast(res?.error || 'Save failed', 'error');
}

async function runStoragePrune() {
  const btn = document.getElementById('btn-stor-prune');
  if (btn) { btn.disabled = true; btn.textContent = 'Running…'; }
  const res = Demo.active
    ? { success: true, data: { quarantine_deleted: 2, logs_deleted: 14, waf_pruned: 5000, events_pruned: 1200 } }
    : await API.storagePrune();
  if (btn) { btn.disabled = false; btn.textContent = 'Run Cleanup Now'; }
  if (res?.success) {
    const d = res.data || {};
    const msg = `Cleanup done — Quarantine: ${d.quarantine_deleted||0} files, Logs: ${d.logs_deleted||0} files, WAF rows pruned: ${d.waf_pruned||0}, Event rows pruned: ${d.events_pruned||0}`;
    toast(msg, 'success');
    loadStorageStats();
  } else {
    toast(res?.error || 'Prune failed', 'error');
  }
}

// ── Change Admin Password (Standalone mode only) ──────────────────────────────
async function changeAdminPassword() {
  const u  = document.getElementById('chpw-user')?.value?.trim();
  const p  = document.getElementById('chpw-pass')?.value;
  const p2 = document.getElementById('chpw-pass2')?.value;
  if (!u || !p) return toast('Fill in all fields', 'error');
  if (p !== p2)  return toast('Passwords do not match', 'error');
  if (p.length < 8) return toast('Password too short (min 8 chars)', 'error');
  const res = Demo.active ? { success: true } : await API.changePassword(u, p);
  if (res?.success) {
    toast('Credentials updated — please log in again', 'success');
    document.getElementById('chpw-user').value = '';
    document.getElementById('chpw-pass').value = '';
    document.getElementById('chpw-pass2').value = '';
  } else {
    toast(res?.error || 'Update failed', 'error');
  }
}

// ── Bot Shield ────────────────────────────────────────────────────────────────
async function loadBotShield() {
  const [statsRes, blockedRes, eventsRes, whiteRes] = await Promise.all([
    Demo.active ? { success: true, data: { bots_blocked_today: 142, total_blocked: 1048, whitelisted: 6, requests_analyzed: 284901 } } : API.botStats(),
    Demo.active ? { success: true, data: [] } : API.botBlocked(),
    Demo.active ? { success: true, data: [] } : API.botEvents(100),
    Demo.active ? { success: true, data: [] } : API.botWhitelist(),
  ]);
  if (statsRes?.success) {
    const d = statsRes.data;
    document.getElementById('bot-stat-today').textContent    = fmtNum(d?.bots_blocked_today || 0);
    document.getElementById('bot-stat-total').textContent    = fmtNum(d?.total_blocked || 0);
    document.getElementById('bot-stat-white').textContent    = fmtNum(d?.whitelisted || 0);
    document.getElementById('bot-stat-analyzed').textContent = fmtNum(d?.requests_analyzed || 0);
  }
  loadBotBlocked(blockedRes);
  renderBotEvents(eventsRes?.data || []);
  renderBotWhitelist(whiteRes?.data || []);
}

async function loadBotBlocked(cached) {
  const res = cached || (Demo.active ? { success: true, data: [] } : await API.botBlocked());
  const tbody = document.getElementById('bot-blocked-body');
  if (!tbody) return;
  const rows = res?.data || [];
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--txt3);padding:20px">No blocked bots. Click "Analyze Logs".</td></tr>';
    return;
  }
  tbody.innerHTML = rows.map(b => `
    <tr>
      <td class="mono">${b.ip_address}</td>
      <td><span class="badge badge-red" style="font-size:.65rem">${b.threat_type || 'bot'}</span></td>
      <td>${fmtNum(b.hits || 1)}</td>
      <td class="dim">${b.last_seen ? reltime(b.last_seen) : '-'}</td>
      <td><button class="btn btn-ghost btn-xs" onclick="unblockBot('${b.ip_address}')">Unblock</button></td>
    </tr>`).join('');
}

function renderBotEvents(events) {
  const tbody = document.getElementById('bot-events-body');
  if (!tbody) return;
  if (!events.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--txt3);padding:20px">No events yet</td></tr>';
    return;
  }
  tbody.innerHTML = events.slice(0, 50).map(e => `
    <tr>
      <td class="mono">${e.ip_address}</td>
      <td class="mono" style="font-size:.7rem;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${e.user_agent||''}">${(e.user_agent||'-').slice(0,50)}</td>
      <td><span class="badge badge-amber" style="font-size:.65rem">${e.threat_type||'scanner'}</span></td>
      <td class="mono" style="font-size:.72rem">${e.uri||'-'}</td>
      <td class="dim">${reltime(e.timestamp)}</td>
      <td><span class="badge ${e.action==='block' ? 'badge-red' : 'badge-gray'}" style="font-size:.65rem">${e.action||'block'}</span></td>
    </tr>`).join('');
}

function renderBotWhitelist(items) {
  const el = document.getElementById('bot-whitelist-list');
  if (!el) return;
  if (!items.length) { el.innerHTML = '<div class="dim">No whitelist entries. Good bots (Googlebot etc.) are detected automatically.</div>'; return; }
  el.innerHTML = items.map(w => `
    <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid var(--border)">
      <span class="mono" style="font-size:.78rem">${w.pattern}</span>
      <button class="btn btn-ghost btn-xs" onclick="removeBotWhitelist(${w.id})">x</button>
    </div>`).join('');
}

async function runBotScan() {
  toast('Analyzing access logs for bots...', 'info');
  const res = Demo.active
    ? { success: true, data: { bots_found: 23, bots_blocked: 18, duration_ms: 1240 } }
    : await API.botScan();
  if (res?.success) {
    const d = res.data || {};
    toast(`Analysis done - ${d.bots_found||0} bots found, ${d.bots_blocked||0} blocked`, 'success');
    loadBotShield();
  } else toast(res?.error || 'Analysis failed', 'error');
}

async function unblockBot(ip) {
  if (!confirm('Unblock bot IP ' + ip + '?')) return;
  const res = Demo.active ? { success: true } : await API.botUnblock(ip);
  if (res?.success) { toast(ip + ' unblocked', 'success'); loadBotShield(); }
  else toast('Unblock failed', 'error');
}

async function addBotWhitelist() {
  const pattern = document.getElementById('bot-white-pattern')?.value?.trim();
  if (!pattern) { toast('Enter a pattern', 'error'); return; }
  const res = Demo.active ? { success: true } : await API.botAddWhitelist(pattern, '');
  if (res?.success) {
    toast(pattern + ' whitelisted', 'success');
    document.getElementById('bot-white-pattern').value = '';
    loadBotShield();
  } else toast('Add failed', 'error');
}

async function removeBotWhitelist(id) {
  const res = Demo.active ? { success: true } : await API.botRemoveWhitelist(id);
  if (res?.success) { toast('Removed from whitelist', 'success'); loadBotShield(); }
  else toast('Remove failed', 'error');
}

// ── CMS Guard ─────────────────────────────────────────────────────────────────
async function loadCMSGuard() {
  const [statsRes, installsRes] = await Promise.all([
    Demo.active ? { success: true, data: { total_installs: 4, wordpress: 3, joomla: 1, drupal: 0, outdated: 2, installs_with_issues: 3, last_scan_at: Math.floor(Date.now()/1000), ever_scanned: true } } : API.cmsStats(),
    Demo.active ? { success: true, data: [
      { id:1, cms_type:'wordpress', version:'6.2.1', cpanel_user:'alice', install_path:'/home/alice/public_html', issues:'["xmlrpc_enabled","login_exposed"]', outdated:1, status:'warning' },
      { id:2, cms_type:'wordpress', version:'6.4.2', cpanel_user:'bob',   install_path:'/home/bob/public_html',   issues:'[]', outdated:0, status:'ok' },
      { id:3, cms_type:'joomla',    version:'4.2.0', cpanel_user:'carol', install_path:'/home/carol/public_html', issues:'["outdated_version"]', outdated:1, status:'warning' },
    ]} : API.cmsInstalls(),
  ]);

  if (statsRes?.success) {
    const d = statsRes.data;
    // The API returns total_installs. This read d.total — the key the DEMO
    // fixture uses — so the counter showed 0 no matter how many sites were
    // found. The demo shape and the real shape had drifted apart, and only the
    // demo was ever looked at. Both are accepted now; test_cmsguard.php asserts
    // the real one exists.
    const total = d?.total_installs ?? d?.total ?? 0;
    document.getElementById('cms-stat-total').textContent    = fmtNum(total);
    document.getElementById('cms-stat-outdated').textContent = fmtNum(d?.outdated || 0);
    document.getElementById('cms-stat-issues').textContent   = fmtNum(d?.installs_with_issues || 0);
    document.getElementById('cms-stat-wp').textContent       = fmtNum(d?.wordpress || 0);
  }

  const installs = installsRes?.data || [];
  const badge = document.getElementById('cms-count-badge');
  if (badge) badge.textContent = installs.length + ' found';

  const tbody = document.getElementById('cms-installs-body');
  if (!tbody) return;
  if (!installs.length) {
    // Distinguish "nothing here" from "we have not looked yet". A server with
    // WordPress on it showing "0 websites" reads as a broken product; saying no
    // scan has run reads as a next step.
    const everScanned = statsRes?.data?.ever_scanned;
    const msg = everScanned
      ? 'No CMS installations found. Scan again if you have added sites since '
        + (statsRes.data.last_scan_at ? reltime(statsRes.data.last_scan_at) : 'the last scan') + '.'
      : 'No scan has run yet — click "Scan Server" to discover CMS installations.';
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--txt3);padding:28px">'
                    + esc(msg) + '</td></tr>';
    return;
  }
  // install_path, version and cpanel_user were interpolated raw. A hosting
  // customer chooses their own directory names, so that is markup supplied by
  // someone else rendered into the server administrator's page.
  tbody.innerHTML = installs.map(c => {
    let issues = [];
    try {
      const parsed = JSON.parse(c.issues || '[]');
      // Stored either as slugs or as {type,message} objects depending on age.
      issues = (Array.isArray(parsed) ? parsed : [])
        .map(i => (i && typeof i === 'object') ? (i.type || '') : String(i))
        .filter(Boolean);
    } catch (_) {}

    const icons    = { wordpress: 'WP', joomla: 'JM', drupal: 'DR' };
    const cmsLabel = icons[c.cms_type] || c.cms_type || '?';
    const version  = c.version || 'unknown';
    const target   = c.target_version || '';

    return '<tr>' +
      '<td><span class="badge badge-blue" style="font-size:.7rem">' + esc(cmsLabel) + '</span></td>' +
      '<td class="mono" style="color:' + (c.outdated ? 'var(--amber)' : 'var(--green)') + '">' +
        esc(version) + (c.outdated ? ' ↓' : '') + '</td>' +
      // Showing what it was judged against: "6.5 !" on its own is a verdict
      // the operator has no way to check or disagree with.
      '<td class="mono dim">' + (target ? esc(target) : '—') + '</td>' +
      '<td>' + cmsRiskBadge(c.risk, c.outdated) + '</td>' +
      '<td class="mono" style="color:var(--blue)">' + (esc(c.cpanel_user) || '—') + '</td>' +
      '<td class="mono" style="font-size:.72rem;max-width:180px;overflow:hidden;text-overflow:ellipsis" title="' +
        esc(c.install_path) + '">' + esc(c.install_path) + '</td>' +
      '<td>' + (issues.length
        ? issues.map(i => '<span class="badge badge-amber" style="font-size:.62rem;margin:1px">' +
            esc(i.replace(/_/g, ' ')) + '</span>').join('')
        : '<span class="badge badge-green" style="font-size:.62rem">None</span>') + '</td>' +
      '<td>' + (c.status === 'ok'
        ? '<span class="badge badge-green">OK</span>'
        : '<span class="badge badge-amber">Issues</span>') + '</td>' +
      '<td><button class="btn btn-ghost btn-xs" onclick="recheckCMS(' + (Number(c.id) || 0) + ')">Recheck</button></td>' +
      '</tr>';
  }).join('');
}

function cmsRiskBadge(risk, outdated) {
  // Fall back to the outdated flag for rows written before risk existed,
  // rather than rendering an empty cell that reads as "no risk".
  const level = risk || (outdated ? 'medium' : 'ok');
  const map = {
    high:    ['badge badge-red',   'At risk'],
    medium:  ['badge badge-amber', 'Outdated'],
    low:     ['badge badge-gray',  'Minor'],
    ok:      ['badge badge-green', 'Current'],
    unknown: ['badge badge-gray',  'Unknown'],
  };
  const [cls, label] = map[level] || map.unknown;
  return '<span class="' + cls + '">' + label + '</span>';
}

async function runCMSScan() {
  toast('Scanning server for CMS installations...', 'info');
  const btn = document.getElementById('cms-scan-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Scanning...'; }
  const res = Demo.active
    ? { success: true, data: { found: 4, wordpress: 3, joomla: 1, issues_found: 3 } }
    : await API.cmsScan();
  if (btn) { btn.disabled = false; btn.textContent = 'Scan Server'; }
  if (res?.success) {
    const d = res.data || {};
    toast('Scan complete - ' + (d.found||0) + ' installs found, ' + (d.issues_found||0) + ' with issues', 'success');
    loadCMSGuard();
  } else toast(res?.error || 'Scan failed', 'error');
}

async function recheckCMS(id) {
  const res = Demo.active ? { success: true } : await API.cmsCheck(id);
  if (res?.success) { toast('Re-check complete', 'success'); loadCMSGuard(); }
  else toast('Check failed', 'error');
}

// ── Rootkit Scanner ───────────────────────────────────────────────────────────
async function loadRootkit() {
  const [statusRes, scansRes] = await Promise.all([
    Demo.active ? { success: true, data: { rkhunter_available: true, chkrootkit_available: false } } : API.rootkitStatus(),
    Demo.active ? { success: true, data: [] } : API.rootkitScans(),
  ]);

  if (statusRes?.success) {
    const d = statusRes.data;
    const rkIcon = document.getElementById('rk-rkhunter-icon');
    const rkSt   = document.getElementById('rk-rkhunter-status');
    const ckIcon = document.getElementById('rk-chkrootkit-icon');
    const ckSt   = document.getElementById('rk-chkrootkit-status');
    if (rkIcon) rkIcon.textContent = d?.rkhunter_available ? 'OK' : 'X';
    if (rkSt)   rkSt.textContent   = d?.rkhunter_available ? 'Available' : 'Not installed';
    if (ckIcon) ckIcon.textContent = d?.chkrootkit_available ? 'OK' : 'X';
    if (ckSt)   ckSt.textContent   = d?.chkrootkit_available ? 'Available' : 'Not installed';

    // "Not installed" on its own left the operator to work out what to do
    // about it. The installer fits these now, so if they are still missing
    // something went wrong -- say what, and what covers the gap meanwhile.
    const note = document.getElementById('rk-tools-note');
    if (note) {
      const missing = [];
      if (!d?.rkhunter_available)   missing.push('rkhunter');
      if (!d?.chkrootkit_available) missing.push('chkrootkit');
      if (missing.length) {
        note.style.display = '';
        note.textContent =
          missing.join(' and ') + ' could not be installed on this server. '
          + 'Scans still run: the built-in engine needs neither and covers the '
          + 'same checks. To retry, run  serverscrub install-rootkit-tools  as root.';
      } else {
        note.style.display = 'none';
      }
    }
  }

  const scans = scansRes?.data || [];
  const tbody = document.getElementById('rootkit-history-body');
  if (tbody) {
    if (!scans.length) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--txt3);padding:20px">No scan history</td></tr>';
    } else {
      tbody.innerHTML = scans.map(s => '<tr>' +
        '<td class="mono">' + s.tool + '</td>' +
        '<td class="dim">' + reltime(s.finished_at || s.started_at) + '</td>' +
        '<td style="color:' + (s.warnings_count > 0 ? 'var(--amber)' : 'var(--green)') + '">' + s.warnings_count + '</td>' +
        '<td style="color:' + (s.infected_count > 0 ? 'var(--red)' : 'var(--green)') + '">' + s.infected_count + '</td>' +
        '<td><button class="btn btn-ghost btn-xs" onclick="viewRootkitFindings(' + s.id + ')">View</button></td>' +
        '</tr>').join('');
      const last = scans[0];
      const badge = document.getElementById('rk-last-badge');
      if (badge) {
        badge.textContent = last.infected_count > 0 ? last.infected_count + ' INFECTED' :
          last.warnings_count > 0 ? last.warnings_count + ' Warnings' : 'Clean';
        badge.className = 'badge ' + (last.infected_count > 0 ? 'badge-red' : last.warnings_count > 0 ? 'badge-amber' : 'badge-green');
      }
      const resultEl = document.getElementById('rk-last-result');
      if (resultEl) resultEl.textContent = 'Tool: ' + last.tool + ' | Scanned: ' + reltime(last.finished_at||last.started_at) + ' | Warnings: ' + last.warnings_count + ' | Infected: ' + last.infected_count;
    }
  }
}

async function runRootkitScan() {
  const tool = document.getElementById('rootkit-tool-sel')?.value || 'rkhunter';
  const btn  = document.getElementById('rootkit-scan-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Scanning...'; }
  toast('Running ' + tool + ' scan - this may take a few minutes...', 'info');
  const res = Demo.active
    ? { success: true, data: { tool: tool, warnings_count: 2, clean_count: 167, infected_count: 0 } }
    : await API.rootkitScan(tool);
  if (btn) { btn.disabled = false; btn.textContent = 'Start Scan'; }
  if (res?.success) {
    const d = res.data || {};
    toast(tool + ' scan complete - ' + (d.warnings_count||0) + ' warnings, ' + (d.infected_count||0) + ' infected', d.infected_count > 0 ? 'error' : 'success');
    loadRootkit();
  } else toast(res?.error || 'Scan failed - tool may not be installed', 'error');
}

async function viewRootkitFindings(scanId) {
  const res = Demo.active ? { success: true, data: [] } : await API.rootkitFindings(scanId);
  const container = document.getElementById('rk-findings-list');
  if (!container) return;
  const findings = res?.data || [];
  if (!findings.length) { container.innerHTML = '<div class="dim" style="font-size:.78rem">No findings for this scan.</div>'; return; }
  container.innerHTML = '<div class="label" style="font-size:.72rem;margin-bottom:8px">Findings</div>' +
    findings.map(f => '<div style="display:flex;gap:10px;align-items:flex-start;padding:6px 0;border-bottom:1px solid var(--border)">' +
      '<span class="badge ' + (f.finding_type==='infected' ? 'badge-red' : f.finding_type==='warning' ? 'badge-amber' : 'badge-green') + '" style="font-size:.62rem;white-space:nowrap">' + f.finding_type + '</span>' +
      '<div><div style="font-size:.75rem;font-weight:600;color:var(--txt2)">' + (f.category||'General') + '</div>' +
      '<div style="font-size:.72rem;color:var(--txt3);margin-top:2px">' + f.description + '</div></div>' +
      '</div>').join('');
}

// ── File Integrity ────────────────────────────────────────────────────────────
async function loadIntegrity() {
  const [statsRes, pathsRes] = await Promise.all([
    Demo.active ? { success: true, data: { total_monitored: 0, clean: 0, modified: 0, new_files: 0, missing: 0 } } : API.integrityStats(),
    Demo.active ? { success: true, data: [] } : API.integrityPaths(),
  ]);

  if (statsRes?.success) {
    const d = statsRes.data;
    document.getElementById('int-stat-total').textContent    = fmtNum(d?.total_monitored || 0);
    document.getElementById('int-stat-clean').textContent    = fmtNum(d?.clean || 0);
    document.getElementById('int-stat-modified').textContent = fmtNum(d?.modified || 0);
    document.getElementById('int-stat-issues').textContent   =
      fmtNum((d?.new_files ?? d?.new_count ?? 0) + (d?.missing ?? d?.missing_count ?? 0));
  }

  const paths = pathsRes?.data || [];
  const pathEl = document.getElementById('int-paths-list');
  if (pathEl) {
    pathEl.innerHTML = paths.length
      ? paths.map(p => '<div class="mono" style="font-size:.75rem;padding:3px 0;color:var(--txt2)">/ ' + (p.path||p) + ' <span class="dim">(' + fmtNum(p.count||0) + ' files)</span></div>').join('')
      : '<div class="dim">No baseline created yet</div>';
  }

  loadIntegrityChanges('');
}

async function loadIntegrityChanges(status) {
  const res = Demo.active ? { success: true, data: [] } : await API.integrityChanges(status);
  const changes = res?.data || [];
  const badge = document.getElementById('int-changes-badge');
  if (badge) badge.textContent = changes.length + ' changes';

  const tbody = document.getElementById('integrity-changes-body');
  if (!tbody) return;
  if (!changes.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--txt3);padding:28px">No changes detected - system is clean</td></tr>';
    return;
  }
  const stMap = { modified: 'badge-amber', new: 'badge-blue', missing: 'badge-red', acknowledged: 'badge-gray' };
  tbody.innerHTML = changes.map(c => '<tr>' +
    '<td><span class="badge ' + (stMap[c.status]||'badge-gray') + '">' + c.status + '</span></td>' +
    '<td class="mono" style="font-size:.72rem;max-width:260px;overflow:hidden;text-overflow:ellipsis" title="' + c.file_path + '">' + c.file_path + '</td>' +
    '<td class="dim">' + fmtBytes(c.size||0) + '</td>' +
    '<td class="mono" style="font-size:.72rem">' + (c.owner||'-') + '</td>' +
    '<td class="dim">' + (c.last_check ? reltime(c.last_check) : '-') + '</td>' +
    '<td>' + (c.status !== 'acknowledged' ? '<button class="btn btn-ghost btn-xs" onclick="acknowledgeIntegrityChange(' + c.id + ')">Acknowledge</button>' : '') + '</td>' +
    '</tr>').join('');
}

async function createBaseline() {
  const path = document.getElementById('int-baseline-path')?.value?.trim() || '/home';
  toast('Creating baseline for ' + path + '...', 'info');
  const res = Demo.active ? { success: true, data: { files: 12847 } } : await API.integrityBaseline(path);
  const d = res?.data || {};
  // An error is reported in data.error, not only at the top level: a path that
  // does not exist came back as success:true with an error inside it, so a
  // typo'd path produced a cheerful "0 files hashed".
  if (res?.success && !d.error) {
    toast('Baseline created — ' + fmtNum(d.files ?? d.hashed ?? 0) + ' files hashed', 'success');
    loadIntegrity();
  } else toast(d.error || res?.error || 'Baseline failed', 'error');
}

async function runIntegrityCheck() {
  toast('Running integrity check...', 'info');
  const res = Demo.active ? { success: true, data: { changed: 0 } } : await API.integrityCheck('');
  if (res?.success) {
    const d = res.data || {};
    // d.modified / d.missing / d.new are ARRAYS of the affected files. Adding
    // them as if they were counts produced "[object Object]" arithmetic and a
    // reported 0, so a check that found real tampering said everything was
    // fine. The API now also returns scalar counts; prefer those.
    const changed = d.changed ?? (
      (d.modified_count || 0) + (d.new_count || 0) + (d.missing_count || 0)
    );
    toast('Check complete — ' + fmtNum(changed) + ' change(s) detected',
          changed ? 'error' : 'success');
    loadIntegrity();
  } else toast(res?.error || 'Check failed', 'error');
}

async function acknowledgeIntegrityChange(id) {
  const res = Demo.active ? { success: true } : await API.integrityAck(id);
  if (res?.success) { toast('Change acknowledged', 'success'); loadIntegrityChanges(''); }
  else toast('Acknowledge failed', 'error');
}

// ── PHP Hardening ─────────────────────────────────────────────────────────────
async function loadPHPHardening() {
  const [statsRes, recsRes, settingsRes, accountsRes] = await Promise.all([
    Demo.active ? { success: true, data: { critical: 1, high: 3, medium: 2, already_hardened: 4 } } : API.phpStats(),
    Demo.active ? { success: true, data: [
      { setting:'allow_url_include', current_value:'On', recommended_value:'Off', severity:'critical', description:'Remote file inclusion attack vector', can_apply:true },
      { setting:'display_errors',    current_value:'On', recommended_value:'Off', severity:'high',     description:'Exposes error details to users', can_apply:true },
      { setting:'allow_url_fopen',   current_value:'On', recommended_value:'Off', severity:'high',     description:'Allows remote file access', can_apply:true },
      { setting:'expose_php',        current_value:'On', recommended_value:'Off', severity:'medium',   description:'Reveals PHP version in headers', can_apply:true },
    ]} : API.phpRecs(),
    Demo.active ? { success: true, data: { expose_php:'On', display_errors:'On', allow_url_fopen:'On', allow_url_include:'On', disable_functions:'', 'session.cookie_httponly':'0' } } : API.phpSettings(),
    State.installMode !== 'standalone'
      ? (Demo.active ? { success: true, data: [{ username:'alice', php_version:'8.1', hardened:false },{ username:'bob', php_version:'8.2', hardened:true }] } : API.phpAccounts())
      : { success: true, data: [] },
  ]);

  if (statsRes?.success) {
    const d = statsRes.data;
    document.getElementById('php-stat-critical').textContent = d?.critical || 0;
    document.getElementById('php-stat-high').textContent     = d?.high || 0;
    document.getElementById('php-stat-medium').textContent   = d?.medium || 0;
    document.getElementById('php-stat-ok').textContent       = d?.already_hardened || 0;
  }

  const recs = recsRes?.data || [];
  const recsEl = document.getElementById('php-recs-list');
  if (recsEl) {
    if (!recs.length) {
      recsEl.innerHTML = '<div style="padding:20px;text-align:center;color:var(--green)">PHP is well configured - no issues found!</div>';
    } else {
      const sevClass = { critical:'badge-red', high:'badge-amber', medium:'badge-blue', low:'badge-gray' };
      recsEl.innerHTML = recs.map(r => '<div style="display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border)">' +
        '<span class="badge ' + (sevClass[r.severity]||'badge-gray') + '" style="white-space:nowrap;font-size:.65rem">' + r.severity.toUpperCase() + '</span>' +
        '<div style="flex:1">' +
          '<div style="font-weight:700;font-size:.82rem;font-family:var(--font-mono)">' + r.setting + '</div>' +
          '<div style="font-size:.75rem;color:var(--txt2);margin-top:2px">' + r.description + '</div>' +
          '<div style="font-size:.72rem;color:var(--txt3);margin-top:4px">Current: <code style="background:rgba(239,68,68,.1);color:var(--red);padding:1px 4px;border-radius:3px">' + r.current_value + '</code> &rarr; Recommended: <code style="background:rgba(34,197,94,.1);color:var(--green);padding:1px 4px;border-radius:3px">' + r.recommended_value + '</code></div>' +
        '</div>' +
        (r.can_apply ? '<button class="btn btn-primary btn-xs" onclick="applyPHPSetting(\'' + r.setting + '\',\'' + r.recommended_value + '\')">Apply</button>' : '') +
        '</div>').join('');
    }
  }

  const settings = settingsRes?.data || {};
  const tbody = document.getElementById('php-settings-body');
  if (tbody && Object.keys(settings).length) {
    const dangerKeys = ['allow_url_include','allow_url_fopen','display_errors','expose_php','register_globals'];
    tbody.innerHTML = Object.entries(settings).map(([k, v]) => {
      const isDanger = ['On','1'].includes(String(v)) && dangerKeys.includes(k);
      return '<tr><td class="mono" style="font-size:.75rem">' + k + '</td><td class="mono" style="color:' + (isDanger ? 'var(--red)' : 'var(--txt2)') + ';font-size:.75rem">' + (v||'(empty)') + '</td></tr>';
    }).join('');
  }

  const accounts = accountsRes?.data || [];
  const accTbody = document.getElementById('php-accounts-body');
  if (accTbody) {
    accTbody.innerHTML = accounts.length
      ? accounts.map(a => '<tr>' +
          '<td class="mono">' + (a.username||a.user||'-') + '</td>' +
          '<td class="mono">' + (a.php_version||'Default') + '</td>' +
          '<td>' + (a.hardened ? '<span class="badge badge-green">Yes</span>' : '<span class="badge badge-gray">No</span>') + '</td>' +
          '<td><button class="btn btn-ghost btn-xs" onclick="applyAccountHardening(\'' + (a.username||a.user) + '\')">Harden</button></td>' +
          '</tr>').join('')
      : '<tr><td colspan="4" style="text-align:center;color:var(--txt3);padding:20px">No accounts found</td></tr>';
  }
}

async function applyPHPSetting(setting, value) {
  const data = {};
  data[setting] = value;
  const res = Demo.active ? { success: true } : await API.phpApply(data);
  if (res?.success) { toast(setting + ' applied', 'success'); loadPHPHardening(); }
  else toast(res?.error || 'Apply failed - may require root', 'error');
}

async function applyAllRecommendations() {
  if (Demo.active) { toast('Applied 4 settings (demo)', 'success'); return; }
  const recsRes = await API.phpRecs();
  const safe = (recsRes?.data || []).filter(x => x.can_apply)
    .reduce((acc, x) => { acc[x.setting] = x.recommended_value; return acc; }, {});
  const res = await API.phpApply(safe);
  if (res?.success) {
    const d = res.data || {};
    toast('Applied ' + (d.applied||0) + ' settings, ' + (d.failed||0) + ' failed', 'success');
    loadPHPHardening();
  } else toast(res?.error || 'Apply failed', 'error');
}

async function applyAccountHardening(account) {
  toast('Hardening ' + account + '...', 'info');
  const settings = { display_errors:'Off', allow_url_include:'Off', expose_php:'Off', 'session.cookie_httponly':'1' };
  const res = Demo.active ? { success: true, data: { applied: 4 } } : await API.phpApplyAccount(account, settings);
  if (res?.success) { toast(account + ' hardened', 'success'); loadPHPHardening(); }
  else toast(res?.error || 'Harden failed', 'error');
}

/* ══════════════════════════════════════════════════════════════════════════════
   License
   ══════════════════════════════════════════════════════════════════════════════
   The API returns 402 + needs_license on any gated route. api.js calls
   onLicenseBlocked() centrally so every page behaves the same way rather than
   each rendering its own generic error. */

let _licenseBlockedShown = false;

function onLicenseBlocked(payload) {
  // Only interrupt once per page load — a dashboard fires several parallel
  // requests and would otherwise stack identical banners.
  if (_licenseBlockedShown) return;
  _licenseBlockedShown = true;

  // Show the activation screen rather than a red toast plus a jump to Settings.
  // A licence that has not been entered yet is an expected setup step, not a
  // fault, and presenting it as an error makes a working install look broken.
  showActivateScreen({
    status:  (payload && payload.license_state) || 'Unlicensed',
    message: (payload && payload.error) || '',
  });
}

function _licenseBadgeClass(status) {
  switch (status) {
    case 'Active':    return 'badge badge-green';
    case 'Expired':
    case 'Suspended':
    case 'Invalid':   return 'badge badge-red';
    case 'Unknown':   return 'badge badge-amber';
    default:          return 'badge badge-gray';
  }
}

async function loadLicense() {
  const badge   = document.getElementById('license-badge');
  const summary = document.getElementById('license-summary');
  const meta    = document.getElementById('license-meta');
  if (!badge) return;

  const res = Demo.active
    ? { license: { status:'Active', valid:true, ui_allowed:true, protection_allowed:true,
                   degraded:false, message:'License active.', expires:'2027-08-08',
                   checked_at: Math.floor(Date.now()/1000) - 2*86400,
                   domain:'srv1.example.com', ip:'203.0.113.10' } }
    : await API.get('license/status');
  const lic = res && res.license;
  if (!lic) {
    badge.className = 'badge badge-gray';
    badge.textContent = 'Unavailable';
    if (summary) summary.textContent = 'Could not read license status.';
    return;
  }

  badge.className   = _licenseBadgeClass(lic.status);
  badge.textContent = lic.status + (lic.degraded ? ' (degraded)' : '');
  if (summary) summary.textContent = lic.message || '';

  // The "no secret configured" warning was removed in 3.23.0. The WHMCS
  // Licensing Addon v3.1 signs with an empty secret, so an unset
  // SG_LICENSE_SECRET is the normal state, not a fault -- warning about it
  // would fire on every correctly configured server.
  const warn = document.getElementById('license-config-warning');
  if (warn) { warn.classList.add('hidden'); }

  if (meta) {
    meta.classList.remove('hidden');
    const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v || '—'; };
    set('license-status-val', lic.status);
    set('license-expires-val', lic.expires);
    set('license-checked-val',
        lic.checked_at ? new Date(lic.checked_at * 1000).toLocaleString() : 'never');
  }
}

function _licenseError(msg) {
  const box = document.getElementById('license-error');
  if (!box) return;
  if (!msg) { box.classList.add('hidden'); box.textContent = ''; return; }
  box.classList.remove('hidden');
  box.textContent = msg;
}

async function activateLicense() {
  const input = document.getElementById('license-key-input');
  const key   = input ? input.value.trim() : '';
  _licenseError('');

  if (!key) { _licenseError('Enter a license key first.'); return; }

  const res = await API.post('license/activate', { key });
  if (res && res.success) {
    toast('License activated', 'success');
    if (input) input.value = '';
    _licenseBlockedShown = false;   // allow a fresh prompt if it lapses again
    await loadLicense();
    // Re-run whatever page the user is on now that the gate has lifted
    if (typeof refreshDashboard === 'function') refreshDashboard();
  } else {
    _licenseError((res && res.error) || 'Activation failed.');
    await loadLicense();
  }
}

async function refreshLicense() {
  _licenseError('');
  const res = await API.post('license/refresh');
  if (res && res.success) {
    toast('License re-checked', 'success');
    _licenseBlockedShown = false;
  } else {
    _licenseError((res && res.error) || 'Re-check failed.');
  }
  await loadLicense();
}


/* ── Schedule field visibility ────────────────────────────────────────────────
   Only show the inputs a given schedule actually uses. Leaving "day of week"
   visible on a daily schedule invites the user to set a value that is silently
   ignored, and then to report it as a bug. */
function syncScheduleFields() {
  const vis = (id, on) => { const e = document.getElementById(id); if (e) e.style.display = on ? '' : 'none'; };
  const val = id => document.getElementById(id)?.value;

  const scan = val('set-scan-schedule');
  vis('wrap-scan-time', scan === 'daily' || scan === 'weekly');
  vis('wrap-scan-day',  scan === 'weekly');

  vis('wrap-sig-day', val('set-sig-schedule') === 'weekly');
}

['set-scan-schedule', 'set-sig-schedule'].forEach(id => {
  document.addEventListener('change', e => {
    if (e.target && e.target.id === id) syncScheduleFields();
  });
});

async function updateSignaturesNow() {
  toast('Updating virus definitions…', 'info');
  const res = await API.updateSigs();
  if (res && res.success) {
    toast('Virus definitions updated', 'success');
    loadSettings();
  } else {
    toast((res && res.error) || 'Definition update failed', 'error');
  }
}

/* ══════════════════════════════════════════════════════════════════════════════
   Self-update
   ══════════════════════════════════════════════════════════════════════════════
   The update replaces the very code that serves the API, so this cannot be a
   single request-and-wait. The server starts the updater detached and writes
   progress to a file outside the install directory; the UI polls that.

   The important consequence: mid-update the API is BEING OVERWRITTEN, so polls
   will fail — connection refused, 502, half-written PHP. Those are expected, not
   errors, and must not abort the flow. Only a long unbroken run of failures
   means something is actually wrong. */

let _updPoll = null;
let _updFails = 0;
let _updStarted = 0;

function _el(id) { return document.getElementById(id); }

function showUpdateButton(info) {
  const btn = _el('update-now-btn');
  if (!btn) return;
  if (info && info.update_available) {
    _el('update-btn-version').textContent = 'v' + (info.latest_version || '?');
    btn.classList.remove('hidden');
  } else {
    btn.classList.add('hidden');
  }
}

function _setProgress(pct, msg, title) {
  const f = _el('update-bar-fill'), p = _el('update-pct'),
        m = _el('update-msg'),      t = _el('update-title');
  if (f) f.style.width = Math.max(0, Math.min(100, pct)) + '%';
  if (p) p.textContent = Math.round(pct) + '%';
  if (m && msg) m.textContent = msg;
  if (t && title) t.textContent = title;
}

async function startUpdate() {
  if (Demo.active) { _demoUpdate(); return; }

  const overlay = _el('update-overlay');
  overlay.classList.remove('hidden');
  _el('update-close').classList.add('hidden');
  _el('update-spinner').className = 'update-spinner';
  _setProgress(1, 'Starting update…', 'Updating ServerScrub');

  const res = await API.post('update/run', {});
  if (!res || !res.success) {
    // 409 means one is already running — attach to it rather than failing.
    if (res && res.data && res.data.status === 'running') {
      _pollUpdate();
      return;
    }
    _updateFailed((res && res.error) || 'Could not start the update.');
    return;
  }

  _updFails = 0;
  _updStarted = Date.now();
  _pollUpdate();
}

function _pollUpdate() {
  clearInterval(_updPoll);
  _updPoll = setInterval(async () => {
    let d = null;
    try {
      const r = await API.get('update/progress');
      d = r && r.data;
    } catch (_) { d = null; }

    if (!d) {
      // Expected while the API's own files are being replaced. Give it a long
      // rope — 40 polls at 2s is over a minute of tolerated unavailability —
      // before calling it a failure.
      if (++_updFails > 40) {
        clearInterval(_updPoll);
        _updateFailed('Lost contact with the server. Check logs/update.log.');
      }
      return;
    }
    _updFails = 0;

    _setProgress(d.percent || 0, d.message || '');

    if (d.status === 'success') {
      clearInterval(_updPoll);
      _el('update-spinner').className = 'update-spinner done';
      _setProgress(100, d.message || 'Update complete', 'Updated successfully');
      _el('update-close').classList.remove('hidden');
      // Give the services a moment to come back before reloading.
      setTimeout(finishUpdate, 2500);
    } else if (d.status === 'rolled_back') {
      clearInterval(_updPoll);
      _el('update-spinner').className = 'update-spinner failed';
      _setProgress(100,
        d.message || 'Rolled back to the previous version. Your data is intact.',
        'Update failed — rolled back');
      _el('update-close').classList.remove('hidden');
    } else if (d.status === 'failed') {
      clearInterval(_updPoll);
      _updateFailed(d.message || 'The update failed.');
    }
  }, 2000);
}

function _updateFailed(msg) {
  clearInterval(_updPoll);
  _el('update-spinner').className = 'update-spinner failed';
  _setProgress(100, msg, 'Update failed');
  _el('update-close').classList.remove('hidden');
}

function finishUpdate() {
  // Full reload, not just a data refresh: the JS and CSS themselves have been
  // replaced on disk, so the running page is the OLD build talking to the NEW
  // backend. Reloading is the only way to get a consistent pair.
  window.location.reload();
}

/* Demo-mode walkthrough so the flow can be reviewed without a real update. */
function _demoUpdate() {
  const overlay = _el('update-overlay');
  overlay.classList.remove('hidden');
  _el('update-close').classList.add('hidden');
  _el('update-spinner').className = 'update-spinner';
  const steps = [
    [5,  'Checking for updates…'],
    [15, 'Downloading v3.11.0…'],
    [30, 'Backing up your data…'],
    [45, 'Snapshotting current version…'],
    [55, 'Applying v3.11.0…'],
    [75, 'Restoring your settings and data…'],
    [85, 'Running database migrations…'],
    [100,'Update complete'],
  ];
  let i = 0;
  const t = setInterval(() => {
    if (i >= steps.length) {
      clearInterval(t);
      _el('update-spinner').className = 'update-spinner done';
      _setProgress(100, 'Updated to v3.11.0', 'Updated successfully');
      _el('update-close').classList.remove('hidden');
      return;
    }
    _setProgress(steps[i][0], steps[i][1]);
    i++;
  }, 900);
}


/* HTML-escape before interpolating into innerHTML.
   Not optional here: blocklist "reason" text derives from DNS answers, and
   rootkit findings embed filesystem paths — an attacker who can create a file
   named `<img onerror=...>` would otherwise get script execution in the
   admin's browser, from inside the tool meant to detect them. */
function esc(v) {
  if (v === null || v === undefined) return '';
  return String(v)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* ══════════════════════════════════════════════════════════════════════════════
   Blocklist matrix
   ══════════════════════════════════════════════════════════════════════════════
   Every list is shown separately rather than as one score, because delisting
   requires knowing WHICH service lists you — a single number cannot tell an
   operator where to go. */

// Check every address this server sends from, not just the first one.
async function checkAllServerIps() {
  const tbody   = document.getElementById('srv-ips-body');
  const summary = document.getElementById('srv-ips-summary');
  if (!tbody) return;

  tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--txt3);padding:18px">Querying blocklists for every server address… this takes a few seconds per address.</td></tr>';
  if (summary) { summary.textContent = 'checking…'; summary.className = 'badge badge-gray'; }

  const res = Demo.active
    ? { success: true, data: { checked: 1, listed: 0, worst_score: 0,
        ips: [{ ip: '203.0.113.10', checked: 25, listed: 0, score: 0, risk: 'clean' }] } }
    : await API.get('iprep/check-server-ips');

  if (!res?.success) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--txt3);padding:18px">${
      esc(res?.error || 'Could not check the server addresses')}</td></tr>`;
    if (summary) { summary.textContent = 'check failed'; summary.className = 'badge badge-amber'; }
    return;
  }

  const d   = res.data || {};
  const ips = d.ips || [];

  if (summary) {
    summary.textContent = d.listed
      ? `${d.listed} of ${d.checked} listed`
      : `${d.checked} address(es) clean`;
    summary.className = d.listed ? 'badge badge-red' : 'badge badge-green';
  }

  if (!ips.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--txt3);padding:18px">No public IPv4 address detected on this host.</td></tr>';
    return;
  }

  tbody.innerHTML = ips.map(r => {
    const listed = Number(r.listed || 0);
    const verdict = r.error
      ? '<span class="badge badge-amber">lookup failed</span>'
      : listed
        ? '<span class="badge badge-red">listed</span>'
        : '<span class="badge badge-green">clean</span>';
    return `
      <tr>
        <td class="mono primary">${esc(r.ip)}</td>
        <td>${fmtNum(r.checked || 0)}</td>
        <td>${listed ? fmtNum(listed) : '—'}</td>
        <td>${fmtNum(r.score || 0)}</td>
        <td>${verdict}</td>
        <td><button class="btn btn-ghost btn-xs"
                    onclick="inspectServerIp('${esc(r.ip)}')">Details</button></td>
      </tr>`;
  }).join('');
}

// Load one address into the per-list matrix below, so "listed" can be acted on.
function inspectServerIp(ip) {
  const input = document.getElementById('bl-ip');
  if (input) { input.value = ip; }
  runBlocklistCheck();
}

async function loadServerIpForBlocklist() {
  const input = document.getElementById('bl-ip');
  if (!input || input.value.trim()) return;
  if (Demo.active) { input.value = '203.0.113.10'; input.placeholder = ''; return; }
  const res = await API.get('iprep/server-ips');
  const ips = (res && res.data) || [];
  input.value = ips[0] || '';
  input.placeholder = ips.length ? '' : 'enter an IP address';
}

function _blBadge(status) {
  return status === 'listed'  ? 'badge badge-red'
       : status === 'refused' ? 'badge badge-amber'
       : 'badge badge-green';
}

async function runBlocklistCheck() {
  const ipEl = document.getElementById('bl-ip');
  const ip   = ipEl ? ipEl.value.trim() : '';
  if (!ip) { toast('Enter an IP address to check', 'error'); return; }

  document.getElementById('bl-progress').classList.remove('hidden');
  document.getElementById('bl-empty').classList.add('hidden');
  document.getElementById('bl-results').classList.add('hidden');

  const res = Demo.active ? _demoBlocklists(ip)
                          : await API.get('iprep/blocklists?ip=' + encodeURIComponent(ip));

  document.getElementById('bl-progress').classList.add('hidden');
  const d = res && res.data;
  if (!d || d.error) {
    document.getElementById('bl-empty').classList.remove('hidden');
    toast((d && d.error) || 'Blocklist check failed', 'error');
    return;
  }

  const badge = document.getElementById('bl-summary');
  badge.textContent = d.listed
    ? d.listed + ' of ' + d.checked + ' lists — ' + d.risk
    : 'Clean on all ' + d.checked + ' lists';
  badge.className = d.listed
    ? (d.risk === 'critical' || d.risk === 'high' ? 'badge badge-red' : 'badge badge-amber')
    : 'badge badge-green';

  // Listed entries first. An operator opening this page needs the problems, not
  // to scroll past two dozen clean rows to find them.
  const rank = s => s === 'listed' ? 0 : s === 'refused' ? 1 : 2;
  const rows = d.results.slice().sort(
    (a, b) => rank(a.status) - rank(b.status) || b.weight - a.weight);

  document.getElementById('bl-tbody').innerHTML = rows.map(function (r) {
    const hl = r.status === 'listed' ? ' style="background:var(--red-dim)"' : '';
    const link = r.site
      ? '<a href="' + esc(r.site) + '" target="_blank" rel="noopener" class="btn btn-ghost btn-xs">Delist</a>'
      : '—';
    return '<tr' + hl + '>'
      + '<td class="primary">' + esc(r.name)
      + '<div style="font-size:.68rem;color:var(--txt3)">' + esc(r.zone) + '</div></td>'
      + '<td><span class="badge badge-gray">' + esc(r.category) + '</span></td>'
      + '<td><span class="' + _blBadge(r.status) + '">' + esc(r.status) + '</span></td>'
      + '<td style="font-size:.75rem">' + esc(r.reason || '—') + '</td>'
      + '<td>' + link + '</td></tr>';
  }).join('');

  document.getElementById('bl-results').classList.remove('hidden');
}

function _demoBlocklists(ip) {
  const mk = (name, zone, cat, w, status, reason) =>
    ({ name, zone, category: cat, weight: w, status,
       listed: status === 'listed', reason, site: 'https://example.org/delist' });
  return { success: true, data: {
    ip, checked: 25, listed: 2, score: 33, risk: 'medium',
    results: [
      mk('Spamhaus ZEN', 'zen.spamhaus.org', 'composite', 25, 'listed', 'PBL — not a legitimate mail sender'),
      mk('UCEPROTECT L1', 'dnsbl-1.uceprotect.net', 'spam', 12, 'listed', 'Listed (127.0.0.2)'),
      mk('Barracuda BRBL', 'b.barracudacentral.org', 'spam', 18, 'refused', 'The list refused this query'),
      mk('SpamCop', 'bl.spamcop.net', 'spam', 18, 'clean', null),
      mk('SORBS Aggregate', 'dnsbl.sorbs.net', 'composite', 12, 'clean', null),
      mk('CBL / abuseat', 'cbl.abuseat.org', 'exploit', 20, 'clean', null),
      mk('Blocklist.de', 'bl.blocklist.de', 'exploit', 15, 'clean', null),
      mk('PSBL', 'psbl.surriel.com', 'spam', 10, 'clean', null),
    ] } };
}

/* ── Built-in rootkit engine ───────────────────────────────────────────────── */

async function runBuiltinRootkitScan() {
  toast('Running built-in rootkit scan…', 'info');
  const res = Demo.active ? _demoRootkit() : await API.post('rootkit/scan-builtin', {});
  const d = res && res.data;
  if (!d) { toast('Built-in scan failed', 'error'); return; }

  document.getElementById('rk-builtin-card').classList.remove('hidden');

  const crit = d.summary.critical || 0;
  const high = d.summary.high || 0;
  const badge = document.getElementById('rk-builtin-badge');
  badge.textContent = d.clean ? 'Clean' : crit + ' critical · ' + high + ' high';
  badge.className   = d.clean ? 'badge badge-green'
                    : (crit ? 'badge badge-red' : 'badge badge-amber');

  document.getElementById('rk-builtin-meta').textContent =
    d.checks + ' checks in ' + d.duration + 's · ' + d.findings.length + ' finding(s)';
  document.getElementById('rk-builtin-clean').classList.toggle('hidden', !d.clean);

  const order = { critical: 0, high: 1, medium: 2, low: 3 };
  const rows = d.findings.slice().sort((a, b) => order[a.severity] - order[b.severity]);

  document.getElementById('rk-builtin-tbody').innerHTML = rows.map(function (f) {
    return '<tr>'
      + '<td><span class="sev sev-' + esc(f.severity) + '">' + esc(f.severity) + '</span></td>'
      + '<td class="primary" style="font-size:.78rem">' + esc(f.finding) + '</td>'
      + '<td style="font-size:.73rem;color:var(--txt3)">' + esc(f.explanation) + '</td>'
      + '</tr>';
  }).join('');

  toast(d.clean ? 'No critical findings' : (crit + high) + ' significant finding(s)',
        d.clean ? 'success' : 'error');
}

function _demoRootkit() {
  return { success: true, data: {
    checks: 11, duration: 2.4, clean: false,
    summary: { critical: 1, high: 1, medium: 1, low: 0 },
    findings: [
      { severity: 'critical', finding: '/etc/ld.so.preload is populated: /lib/.so/libx.so',
        explanation: 'This forces a library into every dynamically linked process — the standard userland rootkit hook.' },
      { severity: 'high', finding: 'Unexpected SUID root binary: /usr/local/bin/.hst',
        explanation: 'A SUID root binary outside the known set grants privilege escalation to any user.' },
      { severity: 'medium', finding: 'sshd permits direct root login',
        explanation: 'PermitRootLogin yes lets an attacker brute-force root directly.' },
    ] } };
}

/* ══════════════════════════════════════════════════════════════════════════════
   WAF engine provisioning
   ══════════════════════════════════════════════════════════════════════════════
   WAF.php only reads ModSecurity's config and audit log, so with ModSecurity
   absent the page reported status and protected nothing. This installs and
   manages the engine from the dashboard. */

async function loadWafEngine() {
  const badge = document.getElementById('waf-engine-badge');
  if (!badge) return;

  const res = Demo.active ? _demoWafEngine() : await API.get('waf/engine-status');
  const d = res && res.data;
  if (!d) {
    badge.className = 'badge badge-gray';
    badge.textContent = 'Unavailable';
    return;
  }

  const ready = d.modsecurity_installed && d.crs_installed;
  badge.className = ready
    ? (d.mode === 'on' ? 'badge badge-green' : 'badge badge-amber')
    : 'badge badge-red';
  badge.textContent = !d.modsecurity_installed ? 'Not installed'
                    : !d.crs_installed         ? 'No ruleset'
                    : d.mode === 'on'          ? 'Blocking'
                    : d.mode === 'detectiononly' ? 'Detection only'
                    : 'Installed';

  const summary = document.getElementById('waf-engine-summary');
  summary.textContent = ready
    ? (d.mode === 'on'
        ? 'ModSecurity is enforcing the OWASP Core Rule Set.'
        : 'ModSecurity is installed and logging matches, but not blocking them yet.')
    : 'No web application firewall engine is active on this server. '
    + 'ServerScrub can install and configure ModSecurity with the OWASP Core Rule Set.';

  document.getElementById('waf-engine-meta').classList.remove('hidden');
  const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  set('waf-ms-val',  d.modsecurity_installed ? ('installed ' + (d.modsecurity_version || '')) : 'not installed');
  set('waf-crs-val', d.crs_installed ? ('v' + (d.crs_version || '?')) : 'not installed');
  set('waf-mode-val', d.mode === 'unknown' ? '—' : d.mode);

  // Offer install only when it can actually succeed — a button that always
  // fails is worse than no button.
  const btn = document.getElementById('waf-install-btn');
  const sel = document.getElementById('waf-mode-select');
  btn.classList.toggle('hidden', ready || !d.can_install);
  sel.classList.toggle('hidden', !ready);
  if (ready) sel.value = d.mode === 'unknown' ? 'detectiononly' : d.mode;

  if (!ready && !d.can_install) {
    summary.textContent += ' (No supported package manager was found, so this '
                        +  'server cannot be provisioned automatically.)';
  }
}

async function installWafEngine() {
  const btn = document.getElementById('waf-install-btn');
  const log = document.getElementById('waf-install-log');
  btn.disabled = true;
  btn.textContent = 'Installing…';
  log.classList.remove('hidden');
  log.textContent = 'Installing ModSecurity and the OWASP Core Rule Set. This can take a minute…';

  const res = Demo.active ? _demoWafInstall() : await API.post('waf/engine-install', {});
  const d = res && res.data;

  const lines = ((d && d.steps) || []).map(s => (s.ok ? '[ok]   ' : '[fail] ') + s.message);
  if (d && d.error)  lines.push('[fail] ' + d.error);
  if (d && d.note)   lines.push('', d.note);
  log.textContent = lines.join('\n') || 'No output.';

  btn.disabled = false;
  btn.textContent = 'Install ModSecurity + OWASP CRS';

  if (res && res.success) {
    toast('WAF engine installed — running in detection only', 'success');
  } else {
    toast((res && res.error) || 'WAF installation failed', 'error');
  }
  loadWafEngine();
}

async function setWafEngineMode(mode) {
  // Blocking mode can turn away real visitors if a rule misfires, so it is
  // confirmed rather than applied on a stray change event.
  if (mode === 'on' && !confirm(
      'Switch the WAF to blocking mode?\n\n'
    + 'Requests matching a rule will be rejected. Review the audit log first — '
    + 'a false positive will turn away legitimate visitors.')) {
    loadWafEngine();
    return;
  }
  const res = Demo.active ? { success: true } : await API.post('waf/engine-mode', { mode });
  toast(res && res.success ? 'WAF mode updated' : ((res && res.error) || 'Could not change mode'),
        res && res.success ? 'success' : 'error');
  loadWafEngine();
}

function _demoWafEngine() {
  return { success: true, data: {
    modsecurity_installed: false, modsecurity_version: null,
    crs_installed: false, crs_path: null, crs_version: null,
    mode: 'unknown', apache: 'ea4', package_manager: 'dnf',
    can_install: true, managed_by_us: false } };
}

function _demoWafInstall() {
  return { success: true, data: { success: true, steps: [
    { ok: true, message: 'Installed ea-apache24-mod_security2' },
    { ok: true, message: 'Installed OWASP CRS 4.7.0' },
    { ok: true, message: 'Wrote ServerScrub WAF config (DetectionOnly)' },
    { ok: true, message: 'Apache configuration validated' },
    { ok: true, message: 'Apache reloaded — WAF active in DetectionOnly' },
  ], note: 'Running in DetectionOnly: attacks are logged, not blocked. '
         + 'Review the audit log, then switch to blocking.' } };
}

/* ══════════════════════════════════════════════════════════════════════════════
   Activation gate
   ══════════════════════════════════════════════════════════════════════════════
   Anyone may install; the product asks to be licensed here. This replaces the
   previous behaviour, which surfaced the 402 as a red error toast and dropped
   the user into Settings — that reads like a fault rather than the expected
   next step after installing.

   The screen is shown ahead of the dashboard rather than on top of a broken
   one, so no panel ever renders half-empty against a refused API. */

function showActivateScreen(lic) {
  const el = document.getElementById('activate-screen');
  if (!el) return;

  const sub = document.getElementById('activate-sub');
  const line = document.getElementById('activate-status-line');

  if (lic && lic.status && lic.status !== 'Unlicensed') {
    // An explicit verdict deserves its own wording — "enter your key" is wrong
    // advice for a key that exists but has expired.
    const msg = {
      Expired:   'This licence has expired. Renew it, then re-check.',
      Suspended: 'This licence is suspended. Please contact support.',
      Invalid:   'This licence key is not valid for this server.',
      Unknown:   'The licence server could not be reached, so the licence could not be confirmed.',
    }[lic.status] || (lic.message || '');
    if (sub) sub.textContent = msg;
  }
  if (line && lic && lic.status) {
    line.textContent = ' Current status: ' + lic.status + '.';
  }

  el.classList.remove('hidden');
  const input = document.getElementById('activate-key');
  if (input) setTimeout(() => input.focus(), 150);
}

function hideActivateScreen() {
  const el = document.getElementById('activate-screen');
  if (el) el.classList.add('hidden');
}

function _activateError(msg) {
  const box = document.getElementById('activate-error');
  if (!box) return;
  if (!msg) { box.classList.add('hidden'); box.textContent = ''; return; }
  box.classList.remove('hidden');
  box.textContent = msg;
}

async function submitActivation() {
  const input = document.getElementById('activate-key');
  const btn   = document.getElementById('activate-btn');
  const key   = input ? input.value.trim() : '';
  _activateError('');

  if (!key) { _activateError('Enter your licence key.'); return; }

  btn.disabled = true;
  btn.textContent = 'Activating…';

  const res = Demo.active ? { success: true } : await API.post('license/activate', { key });

  btn.disabled = false;
  btn.textContent = 'Activate';

  if (res && res.success) {
    hideActivateScreen();
    toast('Licence activated — protection is on', 'success');
    // Reload rather than refresh in place: every page was blocked while
    // unlicensed, so their state is stale or empty.
    setTimeout(() => window.location.reload(), 700);
  } else {
    _activateError((res && res.error) || 'Activation failed. Check the key and try again.');
  }
}

async function recheckActivation() {
  _activateError('');
  const res = Demo.active ? { success: true } : await API.post('license/refresh', {});
  if (res && res.success) {
    hideActivateScreen();
    setTimeout(() => window.location.reload(), 500);
  } else {
    _activateError((res && res.error) || 'Still not licensed.');
  }
}

/**
 * Called once after sign-in, before the dashboard loads.
 * Returns true when the app may proceed.
 */
async function enforceLicenseGate() {
  if (Demo.active) return true;
  const res = await API.get('license/status');
  const lic = res && res.license;
  // A licence check that cannot complete must not lock a paying customer out of
  // their own dashboard, so an unreadable response is allowed through — the API
  // itself still returns 402 on anything gated, so nothing is actually exposed.
  if (!lic) return true;
  if (lic.protection_allowed) {
    // Trial counts as allowed, but the operator must be told it is running out
    // — otherwise protection stops one day with no warning given.
    if (lic.trial) showTrialBanner(lic.trial_days_left);
    return true;
  }
  showActivateScreen(lic);
  return false;
}


/* Trial banner. Shown only while the initial grace period is active — a licence
   that lapses without warning looks like a fault rather than an expiry. */
function showTrialBanner(daysLeft) {
  const el = document.getElementById('trial-banner');
  if (!el) return;
  const d = document.getElementById('trial-days');
  if (d) d.textContent = daysLeft === 1 ? '1 day' : daysLeft + ' days';
  el.classList.remove('hidden');
}


/**
 * Choose a real-time monitor resource profile.
 *
 * The custom fields are only shown for 'custom': presenting six numeric inputs
 * to someone who picked "Light" invites them to change one and wonder why the
 * profile no longer matches what it says.
 */
function selectRtProfile(name) {
  const hidden = document.getElementById('set-rt-profile');
  if (hidden) hidden.value = name;

  document.querySelectorAll('.rt-profile-opt').forEach(el => {
    const on = el.getAttribute('data-profile') === name;
    el.style.borderColor = on ? 'var(--primary)' : 'var(--border)';
    el.style.background  = on ? 'rgba(124,92,255,.08)' : 'transparent';
  });

  // The limit fields stay visible for every profile: they show what the chosen
  // profile actually does, and hiding them behind a "Custom" click made the
  // section read as preset-only. Editing any of them switches to Custom
  // automatically, so a typed value is never silently discarded because the
  // profile was left on a preset.
  const custom = document.getElementById('rt-custom-fields');
  if (custom) {
    custom.classList.remove('hidden');
    custom.style.opacity = (name === 'custom') ? '1' : '.72';
  }

  const preset = {
    light:    { fps: 5,   mb: 4,  nice: 19, watches: 5000,   debounce: 10 },
    balanced: { fps: 25,  mb: 16, nice: 10, watches: 20000,  debounce: 5  },
    thorough: { fps: 100, mb: 50, nice: 5,  watches: 100000, debounce: 2  },
  }[name];

  if (preset) {
    // Show the numbers the preset stands for, so the two halves of this card
    // can never disagree about what is in force.
    const put = (id, v) => { const e = document.getElementById(id); if (e) e.value = v; };
    put('set-rt-fps', preset.fps);
    put('set-rt-maxmb', preset.mb);
    put('set-rt-nice', preset.nice);
    put('set-rt-watches', preset.watches);
    put('set-rt-debounce', preset.debounce);
  }
}

/** Any edit to a limit means the operator wants Custom. */
function rtLimitEdited() {
  const hidden = document.getElementById('set-rt-profile');
  if (hidden && hidden.value !== 'custom') {
    selectRtProfile('custom');
    if (typeof toast === 'function') {
      toast('Switched to Custom — your values will be saved', 'info');
    }
  }
}


/**
 * Save only the real-time monitor settings.
 *
 * These were previously committed by the page-level "Save Changes" button at the
 * top of Settings, which means editing a limit here and then leaving the section
 * to commit it -- with no confirmation that these particular values were the
 * ones that landed. Asked for more than once, and I fixed the wrong thing first.
 *
 * Reads back what the server stored rather than trusting the POST, so the
 * confirmation reflects the clamped values actually in force.
 */
async function saveMonitorSettings() {
  const btn    = document.getElementById('rt-save-btn');
  const status = document.getElementById('rt-save-status');
  const g      = (id) => document.getElementById(id);

  const payload = {
    rt_profile:            g('set-rt-profile')?.value  || 'balanced',
    rt_max_files_per_sec:  g('set-rt-fps')?.value      || '25',
    rt_max_file_size_mb:   g('set-rt-maxmb')?.value    || '16',
    rt_nice:               g('set-rt-nice')?.value     || '10',
    rt_max_watches:        g('set-rt-watches')?.value  || '20000',
    rt_debounce_seconds:   g('set-rt-debounce')?.value || '5',
    rt_exclude_dirs:       g('set-rt-excludes')?.value || '',
    cpu_limit_percent:     g('set-cpu-limit')?.value   || '50',
    rt_poll_interval:
      document.querySelector('input[name="rt_poll_interval"]:checked')?.value || '300',

    // Pause-during-backup. These live in this card, so they save with it --
    // a control whose save button is somewhere else is the complaint that
    // produced this button in the first place.
    rt_pause_on_backup:          g('set-rt-pause-backup')?.checked ? '1' : '0',
    rt_backup_procs:             (g('set-rt-backup-procs')?.value || '').trim() || 'jetbackup,rsync',
    rt_backup_resume_secs:       g('set-rt-backup-resume')?.value || '60',
    rt_backup_max_suspend_secs:  g('set-rt-backup-max')?.value    || '14400',
    rt_autostart_after_backup:   g('set-rt-autostart')?.checked ? '1' : '0',
  };

  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
  if (status) { status.textContent = ''; status.style.color = 'var(--txt3)'; }

  const res = Demo.active ? { success: true } : await API.saveSettings(payload);

  if (btn) { btn.disabled = false; btn.textContent = 'Save Monitor Settings'; }

  if (!res?.success) {
    const why = (res && (res.detail || res.error)) || 'the server did not say why';
    if (status) { status.textContent = 'Not saved — ' + why; status.style.color = 'var(--red)'; }
    toast('Monitor settings not saved: ' + why, 'error', 7000);
    return;
  }

  // Read back what was actually stored. A value outside the accepted range is
  // clamped by the daemon, so echoing the typed number would be a small lie.
  const check = Demo.active ? null : await API.getSettings();
  if (check?.success) {
    const d = check.data || {};
    if (g('set-rt-fps'))      g('set-rt-fps').value      = d.rt_max_files_per_sec || payload.rt_max_files_per_sec;
    if (g('set-rt-maxmb'))    g('set-rt-maxmb').value    = d.rt_max_file_size_mb  || payload.rt_max_file_size_mb;
    if (g('set-rt-nice'))     g('set-rt-nice').value     = d.rt_nice              || payload.rt_nice;
    if (g('set-rt-watches'))  g('set-rt-watches').value  = d.rt_max_watches       || payload.rt_max_watches;
    if (g('set-rt-debounce')) g('set-rt-debounce').value = d.rt_debounce_seconds  || payload.rt_debounce_seconds;
  }

  if (status) {
    status.textContent = 'Saved. The monitor picks this up within a minute — no restart needed.';
    status.style.color = 'var(--green)';
  }
  toast('Monitor settings saved', 'success');
}


/* ══════════════════════════════════════════════════════════════════════════════
   Refresh, bulk actions and the file viewer
   ══════════════════════════════════════════════════════════════════════════════ */

/**
 * Run a loader with visible feedback.
 *
 * Every Refresh button called a real function that really did refetch -- which
 * is why the handler check passed and I reported it fixed. But nothing on
 * screen changed: on an idle server the numbers are identical, so a working
 * refresh and a dead button look exactly the same. Reported twice as "refresh
 * does not work", and both times it was the feedback that was missing, not the
 * fetch.
 */
async function doRefresh(btn, fn) {
  if (!btn || btn.disabled) { return; }

  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '\u21BB Refreshing\u2026';

  const started = Date.now();
  let failed = false;
  try {
    await fn();
  } catch (e) {
    failed = true;
    console.error('refresh failed:', e);
    toast('Refresh failed: ' + (e && e.message ? e.message : e), 'error', 6000);
  }

  // A refresh that returns instantly still has to be seen to have happened.
  const elapsed = Date.now() - started;
  if (elapsed < 350) { await new Promise(r => setTimeout(r, 350 - elapsed)); }

  btn.disabled = false;
  btn.innerHTML = original;

  if (!failed) {
    const t = new Date().toLocaleTimeString();
    btn.title = 'Last refreshed ' + t;
    const stamp = document.getElementById('refresh-stamp');
    if (stamp) { stamp.textContent = 'Updated ' + t; }
    toast('Updated ' + t, 'success', 2000);
  }
}

// ── Threat selection ─────────────────────────────────────────────────────────

/** Ids currently ticked in the threats table. */
function selectedThreatIds() {
  return Array.from(document.querySelectorAll('.threat-check:checked'))
    .map(el => parseInt(el.getAttribute('data-id'), 10))
    .filter(n => !isNaN(n) && n > 0);
}

function toggleAllThreats(masterEl) {
  const on = !!(masterEl && masterEl.checked);
  document.querySelectorAll('.threat-check').forEach(el => { el.checked = on; });
  updateBulkBar();
}

/** Keep the bulk bar and the master checkbox in step with the rows. */
function updateBulkBar() {
  const ids   = selectedThreatIds();
  const bar   = document.getElementById('threat-bulk-bar');
  const count = document.getElementById('threat-bulk-count');
  const all   = document.querySelectorAll('.threat-check');
  const master = document.getElementById('threat-check-all');

  if (count) {
    count.textContent = ids.length + ' selected';
    count.style.color = ids.length ? 'var(--primary)' : 'var(--txt2)';
  }

  // The bar stays put and the BUTTONS enable instead. Hiding the whole thing
  // until a selection existed made the feature undiscoverable: someone looking
  // for a way to delete several files at once sees nothing to click, and
  // concludes it was never built.
  [document.getElementById('threat-bulk-quarantine'),
   document.getElementById('threat-bulk-delete')].forEach(b => {
    if (b) { b.disabled = ids.length === 0; }
  });
  if (bar) { bar.classList.remove('hidden'); }
  if (master) {
    master.checked = all.length > 0 && ids.length === all.length;
    // Partial selection is neither ticked nor empty, and saying so avoids the
    // master box claiming everything is selected when only some rows are.
    master.indeterminate = ids.length > 0 && ids.length < all.length;
  }
}

/**
 * Quarantine or delete every selected threat.
 *
 * Confirmed first, because both are destructive and delete is irreversible.
 * Per-file results are reported rather than one pass/fail for the batch: with
 * fifty files selected, "some failed" is not something anyone can act on.
 */
async function bulkThreatAction(action) {
  const ids = selectedThreatIds();
  if (!ids.length) { toast('Nothing selected', 'info'); return; }

  const verb = action === 'delete' ? 'Delete' : 'Quarantine';
  const warn = action === 'delete'
    ? '\n\nThis permanently removes the files. It cannot be undone.'
    : '\n\nFiles are moved into quarantine and can be restored.';
  if (!confirm(verb + ' ' + ids.length + ' selected file(s)?' + warn)) { return; }

  const btns = Array.from(document.querySelectorAll('.threat-bulk-btn'));
  btns.forEach(b => { b.disabled = true; });

  const res = Demo.active
    ? { success: true, ok: ids.length, failed: 0, results: [] }
    : await API.bulkThreats(ids, action);

  btns.forEach(b => { b.disabled = false; });

  if (!res) {
    toast('No response from the server', 'error', 6000);
    return;
  }

  const ok     = res.ok || 0;
  const failed = res.failed || 0;

  if (failed === 0) {
    toast(verb + 'd ' + ok + ' file(s)', 'success');
  } else {
    // Name the first few failures with their reasons. A count alone tells the
    // operator nothing about what to do next.
    const reasons = (res.results || [])
      .filter(r => !r.success)
      .slice(0, 3)
      .map(r => '#' + r.id + ': ' + (r.error || 'unknown reason'));
    toast(ok + ' succeeded, ' + failed + ' failed — ' + reasons.join(' | '),
          'error', 12000);
    console.error('bulk ' + action + ' failures:', res.results);
  }

  const master = document.getElementById('threat-check-all');
  if (master) { master.checked = false; master.indeterminate = false; }
  updateBulkBar();
  loadThreats();
}

// ── Safe file viewer ─────────────────────────────────────────────────────────

/**
 * Show what is inside an infected file, without running it.
 *
 * The content is read on the server with file_get_contents -- never included or
 * evaluated -- and inserted here with textContent, not innerHTML. A payload
 * full of markup or script is therefore displayed as characters and cannot act
 * inside the dashboard.
 */
async function viewThreatFile(id) {
  const overlay = document.getElementById('file-view-overlay');
  const body    = document.getElementById('file-view-content');
  const meta    = document.getElementById('file-view-meta');
  const title   = document.getElementById('file-view-title');
  if (!overlay || !body) { return; }

  overlay.classList.remove('hidden');
  body.textContent = 'Loading\u2026';
  if (meta)  { meta.textContent = ''; }
  if (title) { title.textContent = 'File contents'; }

  const res = Demo.active
    ? { success: true, path: '/home/demo/shell.php', size: 42, binary: false,
        sha256: 'demo', content: '<?php // demo only', truncated: false }
    : await API.viewThreat(id);

  if (!res || !res.success) {
    body.textContent = (res && (res.error || res.detail)) || 'Could not read the file.';
    return;
  }

  if (title) { title.textContent = res.path || 'File contents'; }

  if (meta) {
    const parts = [fmtNum(res.size || 0) + ' bytes'];
    if (res.sha256)    { parts.push('sha256 ' + String(res.sha256).slice(0, 16) + '\u2026'); }
    if (res.truncated) { parts.push('showing the first 256 KB'); }
    if (res.binary)    { parts.push('binary file'); }
    meta.textContent = parts.join(' \u00b7 ');
  }

  // textContent, deliberately. This is hostile input being shown to an admin.
  body.textContent = res.binary
    ? 'This is a binary file. Its contents are not shown as text; the SHA-256 above identifies it.'
    : (res.content || '(empty file)');
}

function closeFileView() {
  const overlay = document.getElementById('file-view-overlay');
  if (overlay) { overlay.classList.add('hidden'); }
}
